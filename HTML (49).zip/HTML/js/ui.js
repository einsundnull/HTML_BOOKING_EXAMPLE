/**
 * ui.js — Shared UI Utilities
 * Toast, Modal, Icons — ohne const/let/arrow für maximale Kompatibilität.
 */

/* ── Toast ────────────────────────────────────────────── */
var Toast = (function() {
  var container = null;

  function getContainer() {
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    return container;
  }

  function show(message, type, duration) {
    type     = type     || 'success';
    duration = duration || 4000;

    var el = document.createElement('div');
    el.className = 'toast' + (type === 'error' ? ' toast-error' : type === 'info' ? ' toast-info' : '');

    var iconColor = type === 'success' ? '#4d7aa0' : '#e74c3c';
    var iconPath  = type === 'success'
      ? '<circle cx="8" cy="8" r="7" stroke="' + iconColor + '" stroke-width="1.5"/><path d="M5 8l2 2 4-4" stroke="' + iconColor + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
      : '<circle cx="8" cy="8" r="7" stroke="' + iconColor + '" stroke-width="1.5"/><path d="M8 5v3M8 11v.5" stroke="' + iconColor + '" stroke-width="1.5" stroke-linecap="round"/>';

    el.innerHTML = '<svg class="toast-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">' + iconPath + '</svg>'
      + '<div><span>' + message + '</span></div>';

    getContainer().appendChild(el);
    setTimeout(function() {
      el.classList.add('toast-exit');
      el.addEventListener('animationend', function() { el.remove(); });
    }, duration);
  }

  return {
    success: function(msg) { show(msg, 'success'); },
    error:   function(msg) { show(msg, 'error'); },
    info:    function(msg) { show(msg, 'info'); }
  };
})();

/* ── Modal ────────────────────────────────────────────── */
var Modal = {
  show: function(opts) {
    var title      = opts.title      || '';
    var bodyHTML   = opts.bodyHTML   || '';
    var footerHTML = opts.footerHTML || '';

    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML =
      '<div class="modal" role="dialog" aria-modal="true">'
        + '<div class="modal-header">'
          + '<span class="modal-title">' + title + '</span>'
          + '<button class="modal-close" aria-label="Close">'
            + '<svg width="16" height="16" viewBox="0 0 16 16" fill="none">'
            + '<path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>'
            + '</svg>'
          + '</button>'
        + '</div>'
        + '<div class="modal-body">' + bodyHTML + '</div>'
        + (footerHTML ? '<div class="modal-footer">' + footerHTML + '</div>' : '')
      + '</div>';

    document.body.appendChild(overlay);

    function esc(e) {
      if (e.key === 'Escape') close();
    }
    function close() {
      overlay.remove();
      document.removeEventListener('keydown', esc);
    }

    overlay.querySelector('.modal-close').addEventListener('click', close);
    overlay.addEventListener('click', function(e) { if (e.target === overlay) close(); });
    document.addEventListener('keydown', esc);

    return { overlay: overlay, close: close };
  }
};

/* ── Icons ────────────────────────────────────────────── */
var Icons = {
  trash: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  plus:  '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>'
};


/* ── Shared Move Block Dialog ────────────────────────────
   opts = {
     block:        { dateStr, start, end, bookedSlots:[{slotId}], student:{uid,name} }
     teacherId:    string
     pendingMap:   object  (pendingBookings or pendingDayChanges)
     stuId:        string|null
     onConfirm:    function(pendingMap) — called after staging, before close
     onCalJump:    function(dateStr, result) — navigate to calendar
   }
──────────────────────────────────────────────────────── */
function openMoveBlockDialogShared(opts) {
  var block     = opts.block;
  var teacherId = opts.teacherId;
  var pending   = opts.pendingMap;
  var stuId     = opts.stuId;
  /* displayName override allows callers to pass a pre-resolved name (e.g. student showing teacher name) */
  var stuName = opts.displayName
    ? opts.displayName
    : ProfileStore.getDisplayName(block.student ? block.student.uid : (opts && opts.stuId ? opts.stuId : '?'));
  var slotCount = block.bookedSlots.length;

  /* Check if block is fully confirmed */
  var isFullyConfirmed = block.bookedSlots.every(function(s) {
    var orig = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
    return orig && !!orig.confirmedAt;
  });

  /* ── Aktionsbereich oben: Bestätigen + Stornieren ── */
  var actionSectionHTML = '';
  if (!isFullyConfirmed) {
    actionSectionHTML =
      '<div class="move-dialog-actions">' +
        '<button class="btn btn-primary btn-sm" id="bk-block-confirm-btn">\u2713 Bestätigen</button>' +
        '<button class="btn btn-danger btn-sm" id="bk-block-cancel-btn">Stornieren</button>' +
      '</div>' +
      '<hr class="move-dialog-divider">';
  } else {
    actionSectionHTML =
      '<div class="move-dialog-actions">' +
        '<span class="badge badge-confirmed">\u2713 Bestätigt</span>' +
      '</div>' +
      '<hr class="move-dialog-divider">';
  }

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info"><strong>' + slotCount + ' Slot' + (slotCount !== 1 ? 's' : '') + '</strong>' +
        ' (' + block.start + ' \u2013 ' + block.end + ') \u2014 <strong>' + stuName + '</strong></p>' +

      actionSectionHTML +

      (isFullyConfirmed ? '' :
        '<div class="move-dialog-row">' +
          '<div class="move-dialog-col">' +
            '<label class="form-label">Datum</label>' +
            '<input type="date" id="move-date-input" class="form-select" value="' + block.dateStr + '" />' +
          '</div>' +
          '<div class="move-dialog-col">' +
            '<label class="form-label">Startzeit</label>' +
            '<select id="move-time-select" class="form-select"><option value="">Datum w\u00e4hlen</option></select>' +
          '</div>' +
        '</div>' +
        '<div id="move-check-result" class="move-check-result"></div>' +
        '<div class="move-dialog-btns">' +
          '<button class="btn btn-primary" id="move-check-btn">Verf\u00fcgbarkeit pr\u00fcfen</button>' +
          '<button class="btn btn-primary is-hidden" id="move-confirm-btn">Verschieben</button>' +
          '<button class="btn btn-ghost is-hidden" id="move-cal-btn">Im Kalender anzeigen</button>' +
        '</div>' +

        '<div class="recur-section">' +
          '<button class="btn btn-ghost recur-toggle-btn" id="recur-toggle">' +
            '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 8a6 6 0 0111.46-2.46M14 8a6 6 0 01-11.46 2.46" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M14 2v4h-4M2 14v-4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            ' Regelm\u00e4\u00dfig buchen' +
          '</button>' +
          '<div id="recur-panel" class="recur-panel is-hidden">' +
            '<p class="recur-info">Gleicher Wochentag + gleiche Uhrzeit f\u00fcr die n\u00e4chsten Wochen wiederholen.</p>' +
            '<div class="move-dialog-row">' +
              '<div class="move-dialog-col">' +
                '<label class="form-label">Anzahl Wochen</label>' +
                '<input type="number" id="recur-weeks" class="form-select" min="1" max="52" value="4" />' +
              '</div>' +
            '</div>' +
            '<div id="recur-result" class="recur-result"></div>' +
            '<div class="move-dialog-btns">' +
              '<button class="btn btn-primary" id="recur-check-btn">Verf\u00fcgbarkeit pr\u00fcfen</button>' +
              '<button class="btn btn-primary is-hidden" id="recur-confirm-btn">Verf\u00fcgbare Tage buchen</button>' +
            '</div>' +
          '</div>' +
        '</div>'
      ) +

      '<div class="move-dialog-btns">' +
        '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '</div>' +
    '</div>';

  var result = Modal.show({ title: 'Block bearbeiten', bodyHTML: bodyHTML, footerHTML: '' });

  var cancelBtn = document.getElementById('modal-cancel');
  cancelBtn.addEventListener('click', result.close);

  /* ── Bestätigen ── */
  var confirmBlockBtn = document.getElementById('bk-block-confirm-btn');
  if (confirmBlockBtn) {
    confirmBlockBtn.addEventListener('click', function() {
      result.close();
      /* Warn-Dialog vor Bestätigung */
      var warnHTML =
        '<div class="move-dialog">' +
          '<p class="confirm-dialog-warning">\u26a0 <strong>Achtung:</strong> Diese Aktion kann nicht r\u00fckcg\u00e4ngig gemacht werden.</p>' +
          '<p class="move-dialog-info">Mit der Best\u00e4tigung der Stunde von <strong>' + stuName + '</strong> (' + block.start + ' \u2013 ' + block.end + '):</p>' +
          '<ul class="confirm-dialog-list">' +
            '<li>kann die Stunde <strong>nicht mehr verschoben</strong> werden</li>' +
            '<li>kann die Stunde <strong>nicht mehr storniert</strong> werden</li>' +
            '<li>wird die <strong>Zahlung f\u00fcr die Stunde freigegeben</strong></li>' +
          '</ul>' +
        '</div>';
      var warn = Modal.show({
        title: 'Stunde best\u00e4tigen',
        bodyHTML: warnHTML,
        footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt best\u00e4tigen</button>'
      });
      document.getElementById('modal-cancel').addEventListener('click', warn.close);
      document.getElementById('modal-confirm').addEventListener('click', function() {
        for (var ci = 0; ci < block.bookedSlots.length; ci++) {
          Store.Slots.confirm(block.bookedSlots[ci].slotId);
        }
        if (opts.onConfirmBlock) opts.onConfirmBlock();
        warn.close();
      });
    });
  }

  /* ── Stornieren ── */
  var cancelBlockBtn = document.getElementById('bk-block-cancel-btn');
  if (cancelBlockBtn) {
    cancelBlockBtn.addEventListener('click', function() {
      result.close();
      var warnResult = Modal.show({
        title: 'Buchung stornieren',
        bodyHTML: '<p>Buchung von <strong>' + stuName + '</strong> (' + block.start + ' \u2013 ' + block.end + ') wirklich stornieren?</p>',
        footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button><button class="btn btn-danger" id="modal-confirm">Stornieren</button>'
      });
      document.getElementById('modal-cancel').addEventListener('click', warnResult.close);
      document.getElementById('modal-confirm').addEventListener('click', function() {
        for (var ri = 0; ri < block.bookedSlots.length; ri++) {
          Store.Slots.cancelBooking(block.bookedSlots[ri].slotId);
        }
        if (opts.onCancelBlock) opts.onCancelBlock();
        warnResult.close();
      });
    });
  }

  if (isFullyConfirmed) return; /* Confirmed blocks: no move/recurring logic needed */

  var dateInput   = document.getElementById('move-date-input');
  var timeSelect  = document.getElementById('move-time-select');
  var checkResult = document.getElementById('move-check-result');
  var checkBtn    = document.getElementById('move-check-btn');
  var confirmBtn  = document.getElementById('move-confirm-btn');
  var calBtn      = document.getElementById('move-cal-btn');

  function resetCheck() {
    checkResult.textContent = '';
    checkResult.className = 'move-check-result';
    confirmBtn.classList.add('is-hidden');
    checkBtn.classList.remove('is-hidden');
    var hasInputs = dateInput.value && timeSelect.value;
    calBtn.classList.toggle('is-hidden', !hasInputs);
  }

  function isFreeSlot(s) {
    if (s.status === 'available' || s.status === 'recurring') return true;
    if (pending[s.slotId] && pending[s.slotId].action === 'cancel') return true;
    return false;
  }

  function rebuildTimes() {
    timeSelect.innerHTML = '';
    var dateStr = dateInput.value;
    if (!dateStr) { calBtn.classList.add('is-hidden'); return; }
    var allDay = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var free = allDay.filter(isFreeSlot);
    if (!free.length) {
      var o = document.createElement('option');
      o.value = ''; o.textContent = 'Keine freien Slots';
      timeSelect.appendChild(o);
      return;
    }
    for (var i = 0; i < free.length; i++) {
      var o = document.createElement('option');
      o.value = free[i].slotId;
      o.textContent = free[i].time + ' – ' + Store.slotEndTime(free[i].time);
      timeSelect.appendChild(o);
    }
    resetCheck();
  }

  rebuildTimes();
  dateInput.addEventListener('change', function() { rebuildTimes(); resetCheck(); });
  timeSelect.addEventListener('change', function() {
    resetCheck();
    var hasInputs = dateInput.value && timeSelect.value;
    calBtn.classList.toggle('is-hidden', !hasInputs);
  });

  checkBtn.addEventListener('click', function() {
    var startSlotId = timeSelect.value;
    if (!startSlotId) {
      checkResult.textContent = 'Bitte Datum und Startzeit wählen.';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var dateStr = dateInput.value;
    var allDay  = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var startIdx = -1;
    for (var i = 0; i < allDay.length; i++) {
      if (allDay[i].slotId === startSlotId) { startIdx = i; break; }
    }
    if (startIdx === -1 || startIdx + slotCount > allDay.length) {
      checkResult.textContent = 'Nicht genug Slots ab dieser Zeit (' + slotCount + ' benötigt).';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
    var blocked = [];
    for (var j = 0; j < targetSlots.length; j++) {
      if (!isFreeSlot(targetSlots[j])) blocked.push(targetSlots[j].time);
    }
    if (blocked.length) {
      checkResult.textContent = 'Nicht alle Slots frei. Belegt: ' + blocked.join(', ') + '.';
      checkResult.className = 'move-check-result move-check-fail';
      confirmBtn.classList.add('is-hidden');
      checkBtn.classList.remove('is-hidden');
    } else {
      checkResult.textContent = '\u2713 Alle ' + slotCount + ' Slots frei \u2014 Verschiebung möglich.';
      checkResult.className = 'move-check-result move-check-ok';
      confirmBtn.classList.remove('is-hidden');
      calBtn.classList.remove('is-hidden');
      checkBtn.classList.add('is-hidden');
    }
  });

  confirmBtn.addEventListener('click', function() {
    var startSlotId = timeSelect.value;
    if (!startSlotId) return;
    var dateStr = dateInput.value;
    var allDay  = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var startIdx = -1;
    for (var i = 0; i < allDay.length; i++) {
      if (allDay[i].slotId === startSlotId) { startIdx = i; break; }
    }
    if (startIdx === -1) return;
    var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
    for (var k = 0; k < block.bookedSlots.length; k++) {
      var orig = Store.Slots.all().filter(function(x) { return x.slotId === block.bookedSlots[k].slotId; })[0];
      if (orig) pending[orig.slotId] = { action: 'cancel', originalSlot: orig, newStudentId: null };
    }
    for (var m = 0; m < targetSlots.length; m++) {
      var tgt = Store.Slots.all().filter(function(x) { return x.slotId === targetSlots[m].slotId; })[0];
      if (tgt) pending[tgt.slotId] = { action: 'book', originalSlot: tgt, newStudentId: stuId, extraStudents: [] };
    }
    opts.onConfirm(pending);
    result.close();
    Toast.info('Block-Verschiebung vorgemerkt \u2014 Dr\u00fcck Save zum Best\u00e4tigen.');
  });

  calBtn.addEventListener('click', function() {
    opts.onCalJump(dateInput.value, result);
  });

  cancelBtn.addEventListener('click', result.close);

  /* ── Recurring booking logic ──────────────────────────── */
  var recurToggle  = document.getElementById('recur-toggle');
  var recurPanel   = document.getElementById('recur-panel');
  var recurWeeks   = document.getElementById('recur-weeks');
  var recurResult  = document.getElementById('recur-result');
  var recurCheckBtn   = document.getElementById('recur-check-btn');
  var recurConfirmBtn = document.getElementById('recur-confirm-btn');
  var recurData = null; // stores the check results

  recurToggle.addEventListener('click', function() {
    var isOpen = !recurPanel.classList.contains('is-hidden');
    recurPanel.classList.toggle('is-hidden', isOpen);
    recurToggle.classList.toggle('active', !isOpen);
  });

  function fmtDateLocal(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var dd = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + dd;
  }

  function getWeekDates(dateObj) {
    var d = new Date(dateObj);
    var dow = d.getDay(); // 0=Sun
    var monday = new Date(d);
    monday.setDate(d.getDate() - ((dow + 6) % 7)); // back to Monday
    var dates = [];
    for (var i = 0; i < 7; i++) {
      var day = new Date(monday);
      day.setDate(monday.getDate() + i);
      dates.push(day);
    }
    return dates; // [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
  }

  function formatWeekday(dateObj) {
    return dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  recurCheckBtn.addEventListener('click', function() {
    var weeks = parseInt(recurWeeks.value, 10);
    if (!weeks || weeks < 1) {
      recurResult.innerHTML = '<p class="move-check-fail">Bitte Anzahl Wochen angeben.</p>';
      return;
    }

    // Source: current block date + time range
    var sourceDate = new Date(block.dateStr + 'T00:00:00');
    var startTime  = block.start;

    recurData = [];
    recurResult.innerHTML = '';

    for (var w = 1; w <= weeks; w++) {
      var targetDate = new Date(sourceDate);
      targetDate.setDate(sourceDate.getDate() + (w * 7));
      var targetDateStr = fmtDateLocal(targetDate);

      // Materialise recurring slots for that week
      var weekDates = getWeekDates(targetDate);
      Store.Recurring.materialiseWeek(teacherId, weekDates);

      // Check slot availability
      var allDay = Store.Slots.byTeacherDate(teacherId, targetDateStr)
        .sort(function(a, b) { return a.time.localeCompare(b.time); });

      // Find consecutive free slots starting at startTime
      var startIdx = -1;
      for (var i = 0; i < allDay.length; i++) {
        if (allDay[i].time === startTime) { startIdx = i; break; }
      }

      var entry = { date: targetDate, dateStr: targetDateStr, week: w, available: false, reason: '', slots: [] };

      if (startIdx === -1) {
        entry.reason = 'Keine Slots an diesem Tag';
      } else if (startIdx + slotCount > allDay.length) {
        entry.reason = 'Nicht genug Slots (' + slotCount + ' benötigt)';
      } else {
        var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
        var blocked = [];
        for (var j = 0; j < targetSlots.length; j++) {
          var ts = targetSlots[j];
          if (!isFreeSlot(ts)) {
            var reason = ts.status === 'timeout' ? 'Timeout'
              : (ts.status === 'booked' ? 'Gebucht (' + (ts.studentId || '?') + ')' : ts.status);
            blocked.push(ts.time + ' \u2013 ' + reason);
          }
        }
        if (blocked.length) {
          entry.reason = blocked.join(', ');
        } else {
          entry.available = true;
          entry.slots = targetSlots;
        }
      }
      recurData.push(entry);
    }

    // Render results
    var availCount = recurData.filter(function(e) { return e.available; }).length;
    var html = '<div class="recur-summary">' + availCount + ' von ' + weeks + ' Wochen verfügbar</div>';
    html += '<div class="recur-list">';
    for (var r = 0; r < recurData.length; r++) {
      var e = recurData[r];
      var icon = e.available ? '\u2713' : '\u2717';
      var cls  = e.available ? 'recur-row-ok' : 'recur-row-fail';
      html += '<div class="recur-row ' + cls + '">'
        + '<span class="recur-row-icon">' + icon + '</span>'
        + '<span class="recur-row-date">Woche ' + e.week + ': ' + formatWeekday(e.date) + '</span>'
        + (e.reason ? '<span class="recur-row-reason">' + e.reason + '</span>' : '')
        + '</div>';
    }
    html += '</div>';
    recurResult.innerHTML = html;

    if (availCount > 0) {
      recurConfirmBtn.classList.remove('is-hidden');
      recurConfirmBtn.textContent = availCount + ' verfügbare Tage buchen';
      recurCheckBtn.classList.add('is-hidden');
    } else {
      recurConfirmBtn.classList.add('is-hidden');
      recurCheckBtn.classList.remove('is-hidden');
    }
  });

  recurConfirmBtn.addEventListener('click', function() {
    if (!recurData) return;
    var booked = 0;
    for (var r = 0; r < recurData.length; r++) {
      var e = recurData[r];
      if (!e.available || !e.slots.length) continue;
      for (var s = 0; s < e.slots.length; s++) {
        var tgt = Store.Slots.all().filter(function(x) { return x.slotId === e.slots[s].slotId; })[0];
        if (tgt) {
          pending[tgt.slotId] = { action: 'book', originalSlot: tgt, newStudentId: stuId, extraStudents: [] };
        }
      }
      booked++;
    }
    opts.onConfirm(pending);
    result.close();
    Toast.info(booked + ' Wochen vorgemerkt \u2014 Dr\u00fcck Save zum Best\u00e4tigen.');
  });
}

window.openMoveBlockDialogShared = openMoveBlockDialogShared;

window.Toast = Toast;
window.Modal = Modal;
window.Icons = Icons;

/* ═══════════════════════════════════════════════════════════════
   SHARED UTILITIES — used by both teacher.js and student.js
   Exported as window globals so both can access
═══════════════════════════════════════════════════════════════ */

function fmtDate(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}
window.fmtDate = fmtDate;

/* ── Shared filter helpers — eine Logik für alle drei Tabs ── */
function _applyTimeFilter(slots, timeFilter, today) {
  if (timeFilter === 'past')     return slots.filter(function(s) { return s.date <  today; });
  if (timeFilter === 'upcoming') return slots.filter(function(s) { return s.date >= today; });
  return slots;
}
window._applyTimeFilter = _applyTimeFilter;

/* Apply optional date range filter after time filter */
function _applyDateRangeFilter(slots) {
  var from = bookingsFilter.dateFrom;
  var to   = bookingsFilter.dateTo;
  if (!from && !to) return slots;
  return slots.filter(function(s) {
    if (from && s.date < from) return false;
    if (to   && s.date > to)   return false;
    return true;
  });
}
window._applyDateRangeFilter = _applyDateRangeFilter;

function getStickyOffset() {
  var navbar = document.querySelector('.navbar');
  var dayNav = document.getElementById('day-nav-bar');
  var offset = 0;
  if (navbar) offset += navbar.offsetHeight;
  if (dayNav && dayNav.classList.contains('is-sticky')) offset += dayNav.offsetHeight;
  return offset + 8;
}
window.getStickyOffset = getStickyOffset;

function getCurrentSectionIndex(targets) {
  var offset = getStickyOffset();
  var scrollY = window.scrollY + offset + 10;
  var best = 0;
  for (var i = 0; i < targets.length; i++) {
    var top = targets[i].getBoundingClientRect().top + window.scrollY;
    if (top <= scrollY) best = i;
  }
  return best;
}
window.getCurrentSectionIndex = getCurrentSectionIndex;

/* ── Shared sort + date-range row ─────────────────────────
   Renders: [↑↓ Sort]  [Von ____ Bis ____]  [✕ Reset]
   onRerender: function to call after any change            */
function _buildSortDateRangeRow(onRerender) {
  var row = document.createElement('div');
  row.className = 'bookings-sort-date-row';

  /* Sort button */
  var sortBtn = document.createElement('button');
  sortBtn.className = 'btn btn-secondary btn-sm sort-btn-shared';
  sortBtn.setAttribute('aria-label', allBookingsSortAsc ? 'Älteste zuerst' : 'Neueste zuerst');
  sortBtn.innerHTML =
    '<span class="sort-icon-asc"' + (allBookingsSortAsc ? '' : ' style="display:none"') + '>' +
      '<svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M7 2v10M3 8l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '</span>' +
    '<span class="sort-icon-desc"' + (!allBookingsSortAsc ? '' : ' style="display:none"') + '>' +
      '<svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M7 12V2M3 6l4-4 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '</span>';
  sortBtn.addEventListener('click', function() {
    allBookingsSortAsc = !allBookingsSortAsc;
    onRerender();
  });
  row.appendChild(sortBtn);

  /* Date-range: Von */
  var fromLbl = document.createElement('label');
  fromLbl.className = 'date-range-label';
  fromLbl.textContent = 'Von';
  var fromInput = document.createElement('input');
  fromInput.type = 'date';
  fromInput.className = 'date-range-input';
  fromInput.value = bookingsFilter.dateFrom;
  fromInput.addEventListener('change', function() {
    _setFilter('dateFrom', fromInput.value);
    onRerender();
  });

  /* Date-range: Bis */
  var toLbl = document.createElement('label');
  toLbl.className = 'date-range-label';
  toLbl.textContent = 'Bis';
  var toInput = document.createElement('input');
  toInput.type = 'date';
  toInput.className = 'date-range-input';
  toInput.value = bookingsFilter.dateTo;
  toInput.addEventListener('change', function() {
    _setFilter('dateTo', toInput.value);
    onRerender();
  });

  /* Reset button — only visible when a date is set */
  var resetBtn = document.createElement('button');
  resetBtn.className = 'btn btn-ghost btn-sm date-range-reset' + (bookingsFilter.dateFrom || bookingsFilter.dateTo ? '' : ' is-hidden');
  resetBtn.textContent = '✕';
  resetBtn.setAttribute('aria-label', 'Datumsfilter zurücksetzen');
  resetBtn.addEventListener('click', function() {
    _setFilter('dateFrom', '');
    _setFilter('dateTo', '');
    onRerender();
  });

  row.appendChild(fromLbl);
  row.appendChild(fromInput);
  row.appendChild(toLbl);
  row.appendChild(toInput);
  row.appendChild(resetBtn);
  return row;
}
window._buildSortDateRangeRow = _buildSortDateRangeRow;

/* Shared student filter row — custom dropdown that calls onRerender on change */
function _buildStudentFilterRow(onRerender) {
  var myStudents = AppService.getSelectionsByTeacherSync
    ? AppService.getSelectionsByTeacherSync(Auth.current().uid)
        .map(function(sel) { return AppService.getUserSync(sel.studentId); }).filter(Boolean)
    : [];

  var row = document.createElement('div');
  row.className = 'day-bookings-filter-row';
  var lbl = document.createElement('span');
  lbl.className = 'day-bookings-filter-label';
  lbl.textContent = 'Schüler';

  var ddWrap = document.createElement('div');
  ddWrap.className = 'custom-dropdown day-bookings-student-dd';
  var trigger = document.createElement('button');
  trigger.type = 'button';
  trigger.className = 'custom-dropdown-trigger';
  trigger.setAttribute('aria-haspopup', 'listbox');
  trigger.setAttribute('aria-expanded', 'false');
  var labelSpan = document.createElement('span');
  labelSpan.className = 'custom-dropdown-label';
  trigger.innerHTML = '';
  trigger.appendChild(labelSpan);
  trigger.insertAdjacentHTML('beforeend', '<svg class="custom-dropdown-chevron" width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>');

  var list = document.createElement('ul');
  list.className = 'custom-dropdown-list';
  list.setAttribute('role', 'listbox');

  var options = [{ value: 'all', text: 'Alle Schüler' }];
  for (var i = 0; i < myStudents.length; i++) {
    options.push({ value: myStudents[i].uid, text: ProfileStore.getDisplayName(myStudents[i].uid) });
  }

  function setValue(val) {
    _setFilter('student', val);
    var sel = options.filter(function(o) { return o.value === val; })[0] || options[0];
    labelSpan.textContent = sel.text;
    list.querySelectorAll('.custom-dropdown-item').forEach(function(el) {
      el.classList.toggle('is-active', el.getAttribute('data-value') === val);
    });
    list.classList.remove('is-open');
    trigger.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    onRerender();
  }

  options.forEach(function(opt) {
    var li = document.createElement('li');
    li.className = 'custom-dropdown-item' + (opt.value === bookingsFilter.student ? ' is-active' : '');
    li.setAttribute('role', 'option');
    li.setAttribute('data-value', opt.value);
    li.textContent = opt.text;
    li.addEventListener('click', function(e) { e.stopPropagation(); setValue(opt.value); });
    list.appendChild(li);
  });

  var cur = options.filter(function(o) { return o.value === bookingsFilter.student; })[0] || options[0];
  labelSpan.textContent = cur.text;

  trigger.addEventListener('click', function(e) {
    e.stopPropagation();
    var open = list.classList.contains('is-open');
    list.classList.toggle('is-open', !open);
    trigger.classList.toggle('is-open', !open);
    trigger.setAttribute('aria-expanded', !open ? 'true' : 'false');
  });

  ddWrap.appendChild(trigger);
  ddWrap.appendChild(list);
  row.appendChild(lbl);
  row.appendChild(ddWrap);
  return row;
}
window._buildStudentFilterRow = _buildStudentFilterRow;

/* navDay / navMonth — shared core, render callback injected by caller */
function _navDayShared(delta, renderFn) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setDate(d.getDate() + delta);
  selectedDate = d;
  if (d.getFullYear() !== viewYear || d.getMonth() !== viewMonth) {
    viewYear  = d.getFullYear();
    viewMonth = d.getMonth();
  }
  updateDayNavBar();
  renderCalendar();
  renderFn();
}
window._navDayShared = _navDayShared;

function _navMonthShared(delta, renderFn) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setMonth(d.getMonth() + delta);
  selectedDate = d;
  viewYear  = d.getFullYear();
  viewMonth = d.getMonth();
  updateDayNavBar();
  renderCalendar();
  renderFn();
}
window._navMonthShared = _navMonthShared;

/* checkDayNavSticky — shared, containerId injected per-file */
function checkDayNavStickyShared(containerId) {
  var bar      = document.getElementById('day-nav-bar');
  var sentinel = document.getElementById('day-nav-sentinel');
  if (!bar || !sentinel || !bar.classList.contains('is-visible')) return;
  var navbarH = 52;
  var rect = sentinel.getBoundingClientRect();
  var shouldBeSticky = rect.top < navbarH;
  if (shouldBeSticky === window._dayNavStickyActive) return;
  window._dayNavStickyActive = shouldBeSticky;
  bar.classList.toggle('is-sticky', shouldBeSticky);
  if (shouldBeSticky) {
    var parent = document.getElementById(containerId);
    if (parent) {
      var pr = parent.getBoundingClientRect();
      bar.style.left  = pr.left + 'px';
      bar.style.width = pr.width + 'px';
      bar.style.right = 'auto';
    }
    sentinel.style.height = bar.offsetHeight + 'px';
  } else {
    bar.style.left  = '';
    bar.style.width = '';
    bar.style.right = '';
    sentinel.style.height = '0';
  }
}
window.checkDayNavStickyShared = checkDayNavStickyShared;

/* updateDayNavBar — identical in both files */
function updateDayNavBar() {
  var bar   = document.getElementById('day-nav-bar');
  var label = document.getElementById('day-nav-label');
  if (!bar || !label) return;
  if (!selectedDate) {
    bar.classList.remove('is-visible');
    bar.classList.remove('is-sticky');
    window._dayNavStickyActive = false;
    return;
  }
  bar.classList.add('is-visible');
  label.textContent = selectedDate.toLocaleDateString('de-DE', {
    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
  });
}
window.updateDayNavBar = updateDayNavBar;

/* _setFilter — shared by teacher.js and student.js */
function _setFilter(key, val) { bookingsFilter[key] = val; }
window._setFilter = _setFilter;

/* jumpSection — shared, calls local getSectionJumpTargets via window */
function jumpSection(delta) {
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var next    = idx + delta;
  if (next < 0 || next >= targets.length) return;
  var target  = targets[next];
  var offset  = getStickyOffset();
  var top     = target.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top: top, behavior: 'smooth' });
  setTimeout(updateJumpBtns, 400);
}
window.jumpSection = jumpSection;

/* updateJumpBtns — shared core, visibilityExtra passed by each file's local wrapper */
function _updateJumpBtnsShared(visibilityExtra) {
  var jumper  = document.getElementById('section-jumper');
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var upBtn   = document.getElementById('jump-up');
  var downBtn = document.getElementById('jump-down');
  if (!upBtn || !downBtn || !jumper) return;
  var navbarH = (document.querySelector('.navbar') || {}).offsetHeight || 0;
  var isVisible = window.scrollY > navbarH || visibilityExtra;
  jumper.classList.toggle('is-visible', isVisible);
  upBtn.classList.toggle('is-dimmed', idx <= 0);
  downBtn.classList.toggle('is-dimmed', idx >= targets.length - 1);
}
window._updateJumpBtnsShared = _updateJumpBtnsShared;

/* prevMonth/nextMonth shared cores */
function _prevMonthShared(extraRenderFn) {
  viewMonth--;
  if (viewMonth < 0) { viewMonth = 11; viewYear--; }
  renderCalendar();
  if (extraRenderFn) extraRenderFn();
}
function _nextMonthShared(extraRenderFn) {
  viewMonth++;
  if (viewMonth > 11) { viewMonth = 0; viewYear++; }
  renderCalendar();
  if (extraRenderFn) extraRenderFn();
}
window._prevMonthShared = _prevMonthShared;
window._nextMonthShared = _nextMonthShared;

/* ══════════════════════════════════════════════════════════
   SHARED BOOKING BLOCK FUNCTIONS
   Used by both teacher.js and student.js
══════════════════════════════════════════════════════════ */

/**
 * mergeBookingBlocks — shared merge for teacher (groupField='studentId')
 * and student (groupField='teacherId').
 * Returns blocks with: dateStr, today, start, end, bookedSlots,
 *   hasPending, isFullyConfirmed, plus whatever resolveParty() returns merged in.
 *
 * opts.groupField   — 'studentId' | 'teacherId'
 * opts.resolveParty — function(slot) → party object merged into block
 */
function mergeBookingBlocks(dateStr, bookedSlots, today, opts) {
  var groupField   = opts.groupField;
  var resolveParty = opts.resolveParty || function() { return {}; };
  var blocks = [];

  var sorted = bookedSlots.slice().sort(function(a, b) {
    return (a[groupField] || '').localeCompare(b[groupField] || '') || a.time.localeCompare(b.time);
  });

  var i = 0;
  while (i < sorted.length) {
    var s   = sorted[i];
    var end = AppService.slotEndTime(s.time);
    var grp = [s];
    var j   = i + 1;
    while (j < sorted.length) {
      var next = sorted[j];
      if (next[groupField] === s[groupField] && next.time <= end) {
        var nextEnd = AppService.slotEndTime(next.time);
        if (nextEnd > end) end = nextEnd;
        grp.push(next);
        j++;
      } else { break; }
    }
    var block = {
      dateStr:          dateStr,
      today:            today,
      start:            s.time,
      end:              end,
      bookedSlots:      grp,
      hasPending:       grp.some(function(x) { return !!x._pending; }),
      isFullyConfirmed: grp.every(function(x) { return !!x.confirmedAt; })
    };
    var party = resolveParty(s);
    for (var k in party) block[k] = party[k];
    blocks.push(block);
    i = j;
  }
  blocks.sort(function(a, b) { return a.start.localeCompare(b.start); });
  return blocks;
}
window.mergeBookingBlocks = mergeBookingBlocks;

/**
 * fmtPrice — shared price formatter. Returns "€12,50" or "" if no price.
 */
function fmtPrice(amount) {
  var n = parseFloat(amount);
  if (!amount || isNaN(n) || n <= 0) return '';
  return '\u20ac' + n.toFixed(2).replace('.', ',');
}
window.fmtPrice = fmtPrice;

/**
 * buildBookingBlock — shared block renderer for teacher and student.
 *
 * opts.showDate        — bool
 * opts.isPast          — bool
 * opts.simpleDetail    — bool (teacher only)
 * opts.expandedBlocks  — object (keyed store for open state)
 * opts.blockKeyFn      — function(block) → string key
 * opts.nameFn          — function(block) → display name string
 * opts.onConfirmBlock  — function(block) → opens confirm dialog
 * opts.onEditBlock     — function(block) | null
 * opts.onReleaseBlock  — function(block) | null (teacher past confirmed)
 * opts.populateDetail  — function(detail, block) populates expanded content
 */
function buildBookingBlock(block, opts) {
  var showDate       = opts.showDate !== false;
  var isPast         = !!opts.isPast;
  var expandedBlocks = opts.expandedBlocks;
  var blockKey       = opts.blockKeyFn(block);
  var isOpen         = !!expandedBlocks[blockKey];
  var displayName    = opts.nameFn(block);

  var hasPending       = !!block.hasPending;
  var isFullyConfirmed = !!block.isFullyConfirmed;

  var wrapper = document.createElement('div');
  wrapper.className = 'all-booking-block-wrapper';

  var header = document.createElement('div');
  header.className = 'all-booking-block-header'
    + (isPast       ? ' all-booking-block-past' : '')
    + (hasPending   ? ' block-pending' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'all-booking-block-time';
  if (showDate) {
    var dateObj   = new Date(block.dateStr + 'T00:00:00');
    var dateLabel = dateObj.toLocaleDateString('en-GB', { weekday:'short', day:'numeric', month:'short' });
    timeEl.textContent = dateLabel + '  ' + block.start + ' \u2013 ' + block.end;
  } else {
    timeEl.textContent = block.start + ' \u2013 ' + block.end;
  }

  var nameEl = document.createElement('span');
  nameEl.className = 'all-booking-block-student';
  nameEl.textContent = displayName;

  var chevron = document.createElement('span');
  chevron.className = 'all-booking-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  /* Row 1: time + price total + chevron */
  var row1 = document.createElement('div');
  row1.className = 'all-booking-block-row1';
  row1.appendChild(timeEl);
  if (opts.priceFn) {
    var totalPrice = opts.priceFn(block);
    if (totalPrice) {
      var priceEl = document.createElement('span');
      priceEl.className = 'all-booking-block-total';
      priceEl.textContent = totalPrice;
      row1.appendChild(priceEl);
    }
  }
  row1.appendChild(chevron);
  header.appendChild(row1);

  /* Row 2: name + action buttons */
  var row2 = document.createElement('div');
  row2.className = 'all-booking-block-row2';
  row2.appendChild(nameEl);

  if (isFullyConfirmed) {
    var badge = document.createElement('span');
    badge.className = 'badge badge-confirmed';
    badge.textContent = '\u2713 Bestätigt';
    row2.appendChild(badge);
    if (isPast && opts.onReleaseBlock) {
      var releaseBtn = document.createElement('button');
      releaseBtn.className = 'btn btn-ghost btn-sm all-booking-release-btn';
      releaseBtn.textContent = '\u21a9 Freigeben';
      (function(b) { releaseBtn.addEventListener('click', function(e) { e.stopPropagation(); opts.onReleaseBlock(b); }); })(block);
      row2.appendChild(releaseBtn);
    }
  } else {
    var confirmBtn = document.createElement('button');
    confirmBtn.className = 'btn btn-ghost btn-sm all-booking-confirm-btn';
    confirmBtn.textContent = '\u2713 Bestätigen';
    (function(b) { confirmBtn.addEventListener('click', function(e) { e.stopPropagation(); opts.onConfirmBlock(b); }); })(block);
    row2.appendChild(confirmBtn);
  }

  if (!isPast && !isFullyConfirmed && opts.onEditBlock) {
    var editBtn = document.createElement('button');
    editBtn.className = 'btn btn-ghost btn-sm all-booking-move-all-btn';
    editBtn.setAttribute('aria-label', 'Block bearbeiten');
    editBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11.5 2.5a1.414 1.414 0 012 2L5 13H2v-3L11.5 2.5z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    (function(b) { editBtn.addEventListener('click', function(e) { e.stopPropagation(); opts.onEditBlock(b); }); })(block);
    row2.appendChild(editBtn);
  }

  header.appendChild(row2);

  var detail = document.createElement('div');
  detail.className = 'all-booking-block-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) opts.populateDetail(detail, block);

  function toggle() {
    if (expandedBlocks[blockKey]) {
      /* Clicking open block → close it */
      delete expandedBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      /* Close all other open blocks in the same container */
      var container = wrapper.parentNode;
      if (container) {
        var siblings = container.querySelectorAll('.all-booking-block-detail.is-open');
        for (var si = 0; si < siblings.length; si++) {
          var sibDetail  = siblings[si];
          var sibWrapper = sibDetail.parentNode;
          if (sibWrapper && sibWrapper !== wrapper) {
            sibDetail.classList.remove('is-open');
            sibDetail.innerHTML = '';
            var sibChevron = sibWrapper.querySelector('.all-booking-chevron');
            if (sibChevron) sibChevron.classList.remove('is-open');
          }
        }
        /* Clear expandedBlocks for all keys belonging to this container's role */
        Object.keys(expandedBlocks).forEach(function(k) { delete expandedBlocks[k]; });
      }
      expandedBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      opts.populateDetail(detail, block);
      if (opts.onExpand) opts.onExpand();
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}
window.buildBookingBlock = buildBookingBlock;

/**
 * populateBookingDetail — shared detail renderer.
 *
 * opts.pendingMap   — pendingBookings (teacher) | pendingDayChanges (student)
 * opts.getSlots     — function(block) → array of all day slots
 * opts.showFreeSlots — bool — whether to show free slots (teacher free-accordion: true; student block detail: context-dependent)
 * opts.onAction     — function() called after any state mutation (re-render hook)
 * opts.onConfirmSlot — function(slotId) opens per-slot confirm dialog
 * opts.onAddSlot    — function(slot) | null — if null, + Add button not shown
 * opts.stuId        — uid to filter booked slots (null = show all booked)
 */
function populateBookingDetail(detail, block, opts) {
  detail.innerHTML = '';
  var pendingMap   = opts.pendingMap;
  var today        = block.today || fmtDate(new Date());
  var stuId        = opts.stuId !== undefined ? opts.stuId : null;
  var showFree     = opts.showFreeSlots !== false;

  var allDateSlots = opts.getSlots(block)
    .sort(function(a, b) { return a.time.localeCompare(b.time); });

  var seenIds = {};
  var display = allDateSlots.filter(function(s) {
    if (seenIds[s.slotId]) return false;
    var include = false;
    if (s.status === 'booked' && (stuId === null || s.studentId === stuId)) include = true;
    if (showFree && (s.status === 'available' || s.status === 'recurring') && !s.studentId) include = true;
    if (pendingMap[s.slotId]) include = true;
    if (include) seenIds[s.slotId] = true;
    return include;
  });

  if (!display.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.style.padding = 'var(--sp-3)';
    empty.textContent = 'Keine Slots an diesem Tag.';
    detail.appendChild(empty);
    return;
  }

  for (var i = 0; i < display.length; i++) {
    var origSlot  = display[i];
    var isPending = !!pendingMap[origSlot.slotId];
    var pendingObj = pendingMap[origSlot.slotId];
    var isBooked  = (origSlot.status === 'booked' && (stuId === null || origSlot.studentId === stuId))
                  || (isPending && pendingObj.action === 'book');
    var isSlotPast   = origSlot.date < today;
    var isConfirmed  = !!origSlot.confirmedAt;

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row'
      + (isBooked ? '' : ' all-booking-slot-available')
      + (isPending ? ' slot-pending' : '');

    var timeEl = document.createElement('span');
    timeEl.className = 'all-booking-slot-time';
    timeEl.textContent = origSlot.time + ' \u2013 ' + AppService.slotEndTime(origSlot.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'all-booking-slot-status';
    statusEl.textContent = isBooked
      ? (isPending && pendingObj.action === 'cancel' ? 'Storniert' : 'Gebucht')
      : 'Frei';
    /* "Gebucht" label commented out — price display makes it redundant
    if (isBooked && !(isPending && pendingObj.action === 'cancel')) {
      statusEl.textContent = '';  // hidden — price shown instead
    }
    */
    if (isBooked && !(isPending && pendingObj.action === 'cancel')) {
      statusEl.textContent = '';
    }

    var btnGroup = document.createElement('div');
    btnGroup.className = 'all-booking-slot-btns';

    if (isBooked) {
      if (isConfirmed) {
        var cBadge = document.createElement('span');
        cBadge.className = 'badge badge-confirmed';
        cBadge.textContent = '\u2713 Bestätigt';
        btnGroup.appendChild(cBadge);
      } else {
        if (opts.onConfirmSlot) {
          var confirmSlotBtn = document.createElement('button');
          confirmSlotBtn.className = 'btn btn-ghost btn-sm';
          confirmSlotBtn.textContent = '\u2713';
          confirmSlotBtn.title = 'Bestätigen';
          (function(s) {
            confirmSlotBtn.addEventListener('click', function(e) { e.stopPropagation(); opts.onConfirmSlot(s.slotId); });
          })(origSlot);
          btnGroup.appendChild(confirmSlotBtn);
        }
        if (!isSlotPast) {
          var cancelBtn = document.createElement('button');
          cancelBtn.className = (isPending && pendingObj.action === 'cancel') ? 'btn btn-ghost btn-sm' : 'btn btn-danger btn-sm';
          cancelBtn.textContent = (isPending && pendingObj.action === 'cancel') ? 'Undo' : 'Cancel';
          (function(s) {
            cancelBtn.addEventListener('click', function(e) {
              e.stopPropagation();
              if (pendingMap[s.slotId] && pendingMap[s.slotId].action === 'cancel') {
                delete pendingMap[s.slotId];
              } else if (pendingMap[s.slotId] && pendingMap[s.slotId].action === 'book') {
                delete pendingMap[s.slotId];
              } else {
                var original = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0];
                pendingMap[s.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
              }
              if (opts.onAction) opts.onAction();
            });
          })(origSlot);
          btnGroup.appendChild(cancelBtn);
        }
      }
    } else if (showFree && opts.onAddSlot && !block.isFullyConfirmed && !isSlotPast) {
      var addBtn = document.createElement('button');
      addBtn.className = isPending ? 'btn btn-ghost btn-sm' : 'btn btn-primary btn-sm';
      addBtn.textContent = isPending ? 'Undo' : '+ Add';
      (function(s) {
        addBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingMap[s.slotId]) {
            delete pendingMap[s.slotId];
          } else {
            opts.onAddSlot(s, pendingMap);
          }
          if (opts.onAction) opts.onAction();
        });
      })(origSlot);
      btnGroup.appendChild(addBtn);
    }

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    if (isBooked && opts.slotPriceFn) {
      var slotPrice = opts.slotPriceFn(origSlot);
      if (slotPrice) {
        var slotPriceEl = document.createElement('span');
        slotPriceEl.className = 'all-booking-slot-price';
        slotPriceEl.textContent = slotPrice;
        row.appendChild(slotPriceEl);
      }
    }
    row.appendChild(btnGroup);
    detail.appendChild(row);
  }
}
window.populateBookingDetail = populateBookingDetail;

/* ══════════════════════════════════════════════════════════
   SHARED BOOKING BADGE / COUNT FUNCTIONS
══════════════════════════════════════════════════════════ */

/**
 * _calcBookingBlockCounts — shared block counter.
 * opts.mergeFn — function(dateStr, slots, today) → blocks array
 */
function _calcBookingBlockCounts(slots, today, opts) {
  var mergeFn    = opts.mergeFn;
  var priceFn    = opts.priceFn || null; /* optional: function(slot) → number */
  var byDate = {};
  for (var i = 0; i < slots.length; i++) {
    var d = slots[i].date;
    if (!byDate[d]) byDate[d] = [];
    byDate[d].push(slots[i]);
  }
  function calcGroup(blockFilterFn) {
    var count = 0;
    var total = 0;
    var dates = Object.keys(byDate);
    for (var di = 0; di < dates.length; di++) {
      var blocks = mergeFn(dates[di], byDate[dates[di]], today);
      blocks.filter(blockFilterFn).forEach(function(b) {
        count++;
        if (priceFn) {
          b.bookedSlots.forEach(function(s) { total += priceFn(s); });
        }
      });
    }
    return { count: count, total: total };
  }
  var g = {
    all:         calcGroup(function()  { return true; }),
    unconfirmed: calcGroup(function(b) { return !b.isFullyConfirmed; }),
    confirmed:   calcGroup(function(b) { return !!b.isFullyConfirmed; })
  };
  return {
    all:              g.all.count,
    unconfirmed:      g.unconfirmed.count,
    confirmed:        g.confirmed.count,
    totalAll:         g.all.total,
    totalUnconfirmed: g.unconfirmed.total,
    totalConfirmed:   g.confirmed.total
  };
}
window._calcBookingBlockCounts = _calcBookingBlockCounts;

/**
 * _updateBookingBadges — shared badge updater.
 * opts.getSlots      — function() → raw booked slot array
 * opts.partyField    — 'studentId' | 'teacherId' (for party filter)
 * opts.mergeFn       — passed to _calcBookingBlockCounts
 * opts.priceFn       — function(slot) → number (locked price per slot)
 * opts.badgePrefix   — '' (teacher) | 'mb-' (student)
 * opts.containerId   — container to scope querySelector, or null for global
 */
function _updateBookingBadges(opts) {
  var today      = fmtDate(new Date());
  var slots      = opts.getSlots();
  var partyField = opts.partyField;

  if (bookingsFilter.student !== 'all') {
    slots = slots.filter(function(s) { return s[partyField] === bookingsFilter.student; });
  }
  slots = _applyTimeFilter(slots, bookingsFilter.time, today);
  slots = _applyDateRangeFilter(slots);

  var counts = _calcBookingBlockCounts(slots, today, {
    mergeFn: opts.mergeFn,
    priceFn: opts.priceFn || null
  });

  var prefix    = opts.badgePrefix || '';
  var container = opts.containerId ? document.getElementById(opts.containerId) : null;

  function setBadge(id, count) {
    var el = container ? container.querySelector('#' + id) : document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    el.classList.remove('is-hidden');
  }
  function setPriceBadge(id, total) {
    var el = container ? container.querySelector('#' + id) : document.getElementById(id);
    if (!el) return;
    el.textContent = total > 0 ? fmtPrice(total) : '';
    el.style.display = total > 0 ? '' : 'none';
  }

  setBadge(prefix + 'all-count-badge',         counts.all);
  setBadge(prefix + 'unconfirmed-count-badge', counts.unconfirmed);
  setBadge(prefix + 'confirmed-count-badge',   counts.confirmed);
  setPriceBadge(prefix + 'all-price-badge',         counts.totalAll);
  setPriceBadge(prefix + 'unconfirmed-price-badge', counts.totalUnconfirmed);
  setPriceBadge(prefix + 'confirmed-price-badge',   counts.totalConfirmed);
}
window._updateBookingBadges = _updateBookingBadges;
