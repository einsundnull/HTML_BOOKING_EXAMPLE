/* ── wallet-panel.js ─────────────────────────────────────────────
   Wiederverwendbares Wallet-Panel.
   Wird in teacher.html (#teacher-wallet-panel)
   und student.html (#student-wallet-panel) gemountet.

   Gemeinsame Logik lebt in wallet-core.js (WalletCore).
   Dieser Consumer kümmert sich ausschliesslich um:
     - HTML-Struktur des Panels rendern (_buildHTML)
     - ID-Namensgebung (containerId-Präfix)
     - Navbar-Badge synchronisieren
     - Öffentliche API: mount() / refresh()

   API:
     WalletPanel.mount(containerId, uid)
     WalletPanel.refresh(uid)   — Kontostand neu laden
──────────────────────────────────────────────────────────────── */

var WalletPanel = (function () {
  'use strict';

  var _i18n        = {};
  var _uid         = null;
  var _wallet      = null;
  var _containerId = null;
  var _core        = null;

  /* ── i18n helper ─────────────────────────────────────────── */
  function _t(key, vars) {
    var str = _i18n[key] || key;
    if (vars) { for (var k in vars) { str = str.replace('{' + k + '}', vars[k]); } }
    return str;
  }

  /* ── Fehler-Handler ──────────────────────────────────────── */
  function _showError(context, err) {
    var msg = (err && err.message) ? err.message : String(err);
    console.error('[WalletPanel][' + context + ']', err);
    if (typeof UI !== 'undefined' && UI.showToast) {
      UI.showToast('[WalletPanel] ' + msg, 'error');
    }
  }

  /* ── ID-Mapping mit containerId-Präfix ───────────────────── */
  /*
   * Alle IDs im Panel tragen den Präfix 'wp-<semanticKey>-<containerId>'
   * damit mehrere Panels auf einer Seite koexistieren können.
   */
  function _getId(key) {
    var map = {
      balance:       'wp-balance-'       + _containerId,
      txList:        'wp-tx-list-'       + _containerId,
      txEmpty:       'wp-tx-empty-'      + _containerId,
      depAmt:        'wp-dep-amt-'       + _containerId,
      depDesc:       'wp-dep-desc-'      + _containerId,
      depBtn:        'wp-dep-btn-'       + _containerId,
      depErr:        'wp-dep-err-'       + _containerId,
      wdAmt:         'wp-wd-amt-'        + _containerId,
      wdDesc:        'wp-wd-desc-'       + _containerId,
      wdBtn:         'wp-wd-btn-'        + _containerId,
      wdErr:         'wp-wd-err-'        + _containerId,
      confirm:       'wp-confirm-'       + _containerId,
      confirmText:   'wp-confirm-text-'  + _containerId,
      confirmOk:     'wp-confirm-ok-'    + _containerId,
      confirmCancel: 'wp-confirm-cancel-'+ _containerId
    };
    return map[key] || key;
  }

  /* ── Navbar-Badge synchronisieren ────────────────────────── */
  function _onBalanceUpdate(wallet) {
    _wallet = wallet;
    var badge = document.getElementById('navbar-wallet-amount');
    if (badge && wallet) badge.textContent = WalletCore.formatAmount(wallet.balance) + ' €';
  }

  /* ── HTML-Struktur des Panels ─────────────────────────────── */
  function _buildHTML() {
    var c = _containerId; /* Kurzreferenz für IDs */
    return (
      '<div class="wallet-mockup-notice">' +
        '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M8 5v4M8 10.5v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
        '<span>' + _t('mockupNote') + '</span>' +
      '</div>' +

      '<div class="wallet-balance-card" aria-live="polite">' +
        '<div>' +
          '<div class="wallet-balance-label">' + _t('balance') + '</div>' +
          '<div>' +
            '<span class="wallet-balance-amount" id="wp-balance-' + c + '">—</span>' +
            '<span class="wallet-balance-currency"> ' + _t('currency') + '</span>' +
          '</div>' +
        '</div>' +
        '<div class="wallet-balance-icon" aria-hidden="true">' +
          '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="2" y="6" width="20" height="14" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M2 10h20" stroke="currentColor" stroke-width="1.5"/><circle cx="17" cy="15" r="1.5" fill="currentColor"/></svg>' +
        '</div>' +
      '</div>' +

      '<div class="wallet-grid">' +

        '<div class="wallet-action-card">' +
          '<div class="wallet-action-title">' +
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="M9 3v12M4 8l5-5 5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            _t('sectionDeposit') +
          '</div>' +
          '<div class="wallet-form-stack">' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-dep-amt-' + c + '">' + _t('labelAmount') + '</label>' +
              '<div class="wallet-amount-wrap">' +
                '<span class="wallet-amount-prefix" aria-hidden="true">€</span>' +
                '<input class="form-input wallet-amount-input" type="number" id="wp-dep-amt-' + c + '" min="0.01" step="0.01" placeholder="' + _t('placeholderAmount') + '" autocomplete="off" />' +
              '</div>' +
              '<span class="wallet-field-error" id="wp-dep-err-' + c + '" role="alert"></span>' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-dep-desc-' + c + '">' + _t('labelDescription') + '</label>' +
              '<input class="form-input" type="text" id="wp-dep-desc-' + c + '" placeholder="' + _t('placeholderDesc') + '" autocomplete="off" />' +
            '</div>' +
            '<button class="btn btn-primary" id="wp-dep-btn-' + c + '" type="button">' +
              '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 2v12M3 7l5-5 5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
              _t('btnDeposit') +
            '</button>' +
          '</div>' +
        '</div>' +

        '<div class="wallet-action-card">' +
          '<div class="wallet-action-title">' +
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="M9 3v12M4 10l5 5 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            _t('sectionWithdraw') +
          '</div>' +
          '<div class="wallet-form-stack">' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-wd-amt-' + c + '">' + _t('labelAmount') + '</label>' +
              '<div class="wallet-amount-wrap">' +
                '<span class="wallet-amount-prefix" aria-hidden="true">€</span>' +
                '<input class="form-input wallet-amount-input" type="number" id="wp-wd-amt-' + c + '" min="0.01" step="0.01" placeholder="' + _t('placeholderAmount') + '" autocomplete="off" />' +
              '</div>' +
              '<span class="wallet-field-error" id="wp-wd-err-' + c + '" role="alert"></span>' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-wd-desc-' + c + '">' + _t('labelDescription') + '</label>' +
              '<input class="form-input" type="text" id="wp-wd-desc-' + c + '" placeholder="' + _t('placeholderDesc') + '" autocomplete="off" />' +
            '</div>' +
            '<button class="btn btn-secondary" id="wp-wd-btn-' + c + '" type="button">' +
              '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 2v12M3 9l5 5 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
              _t('btnWithdraw') +
            '</button>' +
          '</div>' +
        '</div>' +

      '</div>' +

      '<div class="wallet-history-card">' +
        '<div class="wallet-history-header">' +
          '<div class="wallet-history-title">' +
            '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M8 5v3.5l2 1.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            _t('sectionHistory') +
          '</div>' +
        '</div>' +
        '<ul class="wallet-tx-list" id="wp-tx-list-' + c + '" aria-live="polite">' +
          '<li class="wallet-history-empty is-hidden" id="wp-tx-empty-' + c + '">' + _t('historyEmpty') + '</li>' +
        '</ul>' +
      '</div>' +

      '<div class="wallet-confirm-overlay" id="wp-confirm-' + c + '" role="dialog" aria-modal="true" aria-hidden="true">' +
        '<div class="wallet-confirm-dialog">' +
          '<div class="wallet-confirm-title">' + _t('sectionWithdraw') + '</div>' +
          '<div class="wallet-confirm-text" id="wp-confirm-text-' + c + '"></div>' +
          '<div class="wallet-confirm-actions">' +
            '<button class="btn btn-secondary" id="wp-confirm-cancel-' + c + '" type="button">' + _t('confirmCancelBtn') + '</button>' +
            '<button class="btn btn-primary"   id="wp-confirm-ok-' + c + '"     type="button">' + _t('confirmWithdrawBtn') + '</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }

  /* ── Öffentliche API ─────────────────────────────────────── */

  function mount(containerId, uid) {
    _containerId = containerId;
    _uid         = uid;

    var container = document.getElementById(containerId);
    if (!container) {
      console.error('[WalletPanel] Container nicht gefunden:', containerId);
      return;
    }

    WalletCore.loadI18n(function (i18n) {
      _i18n = i18n;
      container.innerHTML = _buildHTML();

      _core = WalletCore.createInstance({
        uid:             _uid,
        i18n:            _i18n,
        getId:           _getId,
        onBalanceUpdate: _onBalanceUpdate,
        onError:         _showError
      });

      _core.bindEvents();
      _core.loadData();
    });
  }

  function refresh(uid) {
    if (uid) _uid = uid;
    /* If panel is already mounted and core exists, reload data in-place.
       If not yet mounted (wallet tab not visited), nothing to update —
       mount() will load fresh data when the tab is opened. */
    if (_core) { _core.loadData(); }
  }

  return {
    mount:   mount,
    refresh: refresh
  };

}());

window.WalletPanel = WalletPanel;
