/* ── wallet.js ───────────────────────────────────────────────────
   Standalone Wallet-Seite (wallet.html).
   Gemeinsame Logik lebt in wallet-core.js (WalletCore).
   Dieser Consumer kümmert sich ausschliesslich um:
     - Auth-Guard + Seiten-Init
     - i18n anwenden (data-i18n Attribute)
     - ID-Mapping für den Standalone-DOM
   Kommuniziert ausschliesslich über AppService.
──────────────────────────────────────────────────────────────── */

(function () {
  'use strict';

  var _i18n = {};

  /* ── i18n helper ─────────────────────────────────────────── */
  function _t(key, vars) {
    var str = _i18n[key] || key;
    if (vars) { for (var k in vars) { str = str.replace('{' + k + '}', vars[k]); } }
    return str;
  }

  /* ── i18n auf DOM anwenden ───────────────────────────────── */
  function _applyI18n() {
    var els = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < els.length; i++) {
      var key = els[i].getAttribute('data-i18n');
      if (_i18n[key]) els[i].textContent = _i18n[key];
    }
    var phEls = document.querySelectorAll('[data-i18n-placeholder]');
    for (var j = 0; j < phEls.length; j++) {
      var phKey = phEls[j].getAttribute('data-i18n-placeholder');
      if (_i18n[phKey]) phEls[j].setAttribute('placeholder', _i18n[phKey]);
    }
  }

  /* ── Fehler-Handler ──────────────────────────────────────── */
  function _showError(context, err) {
    var msg = (err && err.message) ? err.message : String(err);
    console.error('[Wallet][' + context + ']', err);
    var shown = false;
    if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
      try { UI.showToast(context + ': ' + msg, 'error'); shown = true; } catch (e) {}
    }
    if (!shown) {
      var container = document.getElementById('wallet-page') || document.body;
      var existing  = document.getElementById('wallet-inline-error');
      if (existing) existing.remove();
      var div       = document.createElement('div');
      div.id        = 'wallet-inline-error';
      div.className = 'wallet-inline-error';
      div.textContent = context + ': ' + msg;
      container.insertBefore(div, container.firstChild);
      setTimeout(function () { if (div.parentNode) div.remove(); }, 6000);
    }
  }

  /* ── ID-Mapping für den Standalone-DOM ───────────────────── */
  /*
   * wallet.html verwendet diese Element-IDs.
   * WalletCore.createInstance() ruft getId(semanticKey) auf und
   * bekommt die konkrete ID zurück — kein Hardcoding im Core.
   */
  var _ID_MAP = {
    balance:       'wallet-balance-amount',
    txList:        'wallet-tx-list',
    txEmpty:       'wallet-tx-empty',
    depAmt:        'deposit-amount',
    depDesc:       'deposit-desc',
    depBtn:        'btn-deposit',
    depErr:        'deposit-amount-error',
    wdAmt:         'withdraw-amount',
    wdDesc:        'withdraw-desc',
    wdBtn:         'btn-withdraw',
    wdErr:         'withdraw-amount-error',
    confirm:       'wallet-confirm-overlay',
    confirmText:   'wallet-confirm-text',
    confirmOk:     'wallet-confirm-ok',
    confirmCancel: 'wallet-confirm-cancel'
  };

  function _getId(key) { return _ID_MAP[key] || key; }

  /* ── Navbar-Badge nach Saldo-Änderung aktualisieren ─────── */
  function _onBalanceUpdate(wallet) {
    var badge = document.getElementById('navbar-wallet-amount');
    if (badge && wallet) badge.textContent = WalletCore.formatAmount(wallet.balance) + ' €';
  }

  /* ── Init ────────────────────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', function () {
    var user = (typeof Auth !== 'undefined' && typeof Auth.current === 'function') ? Auth.current() : null;
    if (!user) { window.location.href = './index.html'; return; }

    if (typeof Navbar !== 'undefined') Navbar.init('wallet');

    WalletCore.loadI18n(function (i18n) {
      _i18n = i18n;
      _applyI18n();

      var core = WalletCore.createInstance({
        uid:             user.uid,
        i18n:            _i18n,
        getId:           _getId,
        onBalanceUpdate: _onBalanceUpdate,
        onError:         _showError
      });

      core.bindEvents();
      core.loadData();
    });
  });

}());
