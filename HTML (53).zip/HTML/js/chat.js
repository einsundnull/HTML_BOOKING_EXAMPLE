/**
 * chat.js — Chat Panel
 *
 * Objekte:
 *   ChatI18n   — Übersetzungen (Namespace: chat, Deutsch Standard)
 *   ChatStore  — Nachrichten via localStorage (app_chat_messages)
 *   ChatPanel  — Haupt-Objekt: open/close/render/send/delete/edit
 *
 * Regeln:
 *   var only, function(){}, string concatenation, no arrow functions,
 *   no ?. or ??, no template literals, no inline styles
 *
 * Abhängigkeiten (müssen vorher geladen sein):
 *   store.js, auth.js, ui.js
 */

/* ── i18n ─────────────────────────────────────────────── */
var ChatI18n = {
  de: {
    title:             'Nachrichten',
    back:              'Zurück',
    inputPlaceholder:  'Nachricht eingeben...',
    send:              'Senden',
    attach:            'Datei anhängen',
    voice:             'Sprachnachricht',
    lastSeen:          'Zuletzt aktiv',
    today:             'Heute',
    yesterday:         'Gestern',
    edited:            'bearbeitet',
    statusSent:        'Gesendet',
    statusDelivered:   'Empfangen',
    statusRead:        'Gelesen',
    msgDelete:         'Löschen',
    msgEdit:           'Bearbeiten',
    deleteTitle:       'Nachricht löschen',
    deleteBody:        'Diese Nachricht wird unwiderruflich gelöscht.',
    deleteConfirm:     'Löschen',
    deleteCancel:      'Abbrechen',
    bookingProposal:   'Terminvorschlag',
    bookingAccept:     'Annehmen',
    bookingDecline:    'Ablehnen',
    bookingAccepted:   'Angenommen ✓',
    bookingDeclined:   'Abgelehnt',
    noMessages:        'Noch keine Nachrichten',
    noMessagesSub:     'Schreib die erste Nachricht.',
    noChats:           'Keine Gespräche',
    noChatsSub:        'Du hast noch keine Kontakte.',
    editMode:          'Nachricht bearbeiten',
    editCancel:        'Abbrechen',
    errorNoText:       'Bitte eine Nachricht eingeben.',
    errorSend:         'Nachricht konnte nicht gesendet werden.',
    ctxClose:          'Schließen',
    serviceStudentRequest:  'möchte dein Schüler werden.',
    serviceRequestSent:     'Deine Anfrage wurde gesendet. Warte auf Bestätigung.',
    serviceAccepted:        'Du hast {name} als Schüler angenommen.',
    serviceAcceptedStudent: '{name} hat deine Anfrage angenommen.',
    serviceDeclined:        'Du hast die Anfrage von {name} abgelehnt.',
    serviceDeclinedStudent: '{name} hat deine Anfrage abgelehnt.',
    serviceAcceptBtn:       'Annehmen',
    serviceDeclineBtn:      'Ablehnen',
    serviceRequestLabel:    'Schüleranfrage',
    inputLockedPending:     'Warte auf Antwort des Lehrers...',
    inputLockedDeclined:    'Anfrage wurde abgelehnt.',
    serviceDisconnectLabel: 'Verbindung getrennt',
    serviceDisconnected:    '{name} hat die Verbindung getrennt.',
    serviceDisconnectedSlots: 'Folgende Buchungen wurden storniert:',
    serviceDisconnectedNone: 'Keine offenen Buchungen betroffen.',
    serviceDisconnectedTeacher: 'Du hast {name} entfernt.',
    serviceDisconnectedTeacherSlots: 'Folgende Buchungen wurden storniert:'
  },
  t: function(key) {
    return this.de[key] || key;
  }
};

/* ── ChatStore ────────────────────────────────────────── */
var ChatStore = (function() {

  var KEY = 'app_chat_messages';

  function _load() {
    try {
      var raw = localStorage.getItem(KEY);
      return raw ? (JSON.parse(raw) || []) : [];
    } catch(e) {
      _debugLog('ChatStore._load error: ' + e.message);
      return [];
    }
  }

  function _save(data) {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
    } catch(e) {
      _debugLog('ChatStore._save error: ' + e.message);
    }
  }

  /* _uuid() and _now() provided by store.js as window._uuid / window._now */

  function _conversationKey(uidA, uidB) {
    var arr = [uidA, uidB].sort();
    return arr[0] + '_' + arr[1];
  }

  function getConversation(uidA, uidB) {
    var key  = _conversationKey(uidA, uidB);
    var all  = _load();
    var msgs = [];
    for (var i = 0; i < all.length; i++) {
      if (all[i].conversationKey === key) msgs.push(all[i]);
    }
    msgs.sort(function(a, b) { return a.createdAt.localeCompare(b.createdAt); });
    return msgs;
  }

  function getLastMessage(uidA, uidB) {
    var msgs = getConversation(uidA, uidB);
    return msgs.length ? msgs[msgs.length - 1] : null;
  }

  function countUnread(currentUid, partnerUid) {
    var msgs = getConversation(currentUid, partnerUid);
    var n = 0;
    for (var i = 0; i < msgs.length; i++) {
      var m = msgs[i];
      if (m.senderId !== currentUid && m.readStatus !== 'read') n++;
    }
    return n;
  }

  function totalUnread(currentUid) {
    var all = _load();
    var seen = {};
    var n = 0;
    for (var i = 0; i < all.length; i++) {
      var m = all[i];
      if (m.senderId !== currentUid && m.readStatus !== 'read') {
        if (!seen[m.conversationKey]) seen[m.conversationKey] = 0;
        seen[m.conversationKey]++;
        n++;
      }
    }
    return n;
  }

  function send(senderId, receiverId, text, type) {
    type = type || 'text';
    var all = _load();
    var msg = {
      msgId:           _uuid(),
      conversationKey: _conversationKey(senderId, receiverId),
      senderId:        senderId,
      receiverId:      receiverId,
      text:            text,
      type:            type,
      readStatus:      'sent',
      edited:          false,
      deleted:         false,
      createdAt:       _now()
    };
    all.push(msg);
    _save(all);
    return msg;
  }

  function sendBookingProposal(senderId, receiverId, bookingData) {
    var all = _load();
    var msg = {
      msgId:           _uuid(),
      conversationKey: _conversationKey(senderId, receiverId),
      senderId:        senderId,
      receiverId:      receiverId,
      text:            '',
      type:            'booking_proposal',
      bookingData:     bookingData,
      bookingStatus:   'pending',
      readStatus:      'sent',
      edited:          false,
      deleted:         false,
      createdAt:       _now()
    };
    all.push(msg);
    _save(all);
    return msg;
  }

  function markAsRead(currentUid, partnerUid) {
    var key = _conversationKey(currentUid, partnerUid);
    var all = _load();
    for (var i = 0; i < all.length; i++) {
      if (all[i].conversationKey === key && all[i].senderId === partnerUid) {
        all[i].readStatus = 'read';
      }
    }
    _save(all);
  }

  function markAsDelivered(currentUid, partnerUid) {
    var key = _conversationKey(currentUid, partnerUid);
    var all = _load();
    for (var i = 0; i < all.length; i++) {
      if (all[i].conversationKey === key && all[i].senderId === currentUid && all[i].readStatus === 'sent') {
        all[i].readStatus = 'delivered';
      }
    }
    _save(all);
  }

  function deleteMsg(msgId) {
    var all = _load();
    for (var i = 0; i < all.length; i++) {
      if (all[i].msgId === msgId) {
        all[i].deleted   = true;
        all[i].text      = '';
        all[i].deletedAt = _now();
        break;
      }
    }
    _save(all);
  }

  function editMsg(msgId, newText) {
    var all = _load();
    for (var i = 0; i < all.length; i++) {
      if (all[i].msgId === msgId) {
        all[i].text   = newText;
        all[i].edited = true;
        break;
      }
    }
    _save(all);
  }

  function respondBooking(msgId, response) {
    var all = _load();
    for (var i = 0; i < all.length; i++) {
      if (all[i].msgId === msgId) {
        all[i].bookingStatus = response;
        break;
      }
    }
    _save(all);
  }

  function seedDemoMessages(currentUid, partnerUid) {
    var existing = getConversation(currentUid, partnerUid);
    if (existing.length > 0) return;

    var d = new Date();
    d.setDate(d.getDate() - 1);
    var yesterday = d.toISOString().replace(/T.*/, 'T10:12:00.000Z');
    var todayBase = new Date().toISOString().replace(/T.*/, 'T');

    var all = _load();
    var key = _conversationKey(currentUid, partnerUid);

    var demoMsgs = [
      {
        msgId: 'demo_1', conversationKey: key,
        senderId: partnerUid, receiverId: currentUid,
        text: 'Hallo! Hast du am Dienstag Zeit für eine Stunde?',
        type: 'text', readStatus: 'read', edited: false, deleted: false,
        createdAt: yesterday
      },
      {
        msgId: 'demo_2', conversationKey: key,
        senderId: currentUid, receiverId: partnerUid,
        text: 'Ja, das passt mir gut!',
        type: 'text', readStatus: 'delivered', edited: false, deleted: false,
        createdAt: todayBase + '09:05:00.000Z'
      },
      {
        msgId: 'demo_3', conversationKey: key,
        senderId: partnerUid, receiverId: currentUid,
        text: '', type: 'booking_proposal',
        bookingData: {
          date: 'Dienstag, 11. März 2026',
          timeStart: '14:00',
          timeEnd:   '14:30',
          with:      ''
        },
        bookingStatus: 'pending',
        readStatus: 'read', edited: false, deleted: false,
        createdAt: todayBase + '09:08:00.000Z'
      },
      {
        msgId: 'demo_4', conversationKey: key,
        senderId: currentUid, receiverId: partnerUid,
        text: 'Super, bis dann!',
        type: 'text', readStatus: 'sent', edited: true, deleted: false,
        createdAt: todayBase + '09:22:00.000Z'
      }
    ];

    for (var i = 0; i < demoMsgs.length; i++) {
      all.push(demoMsgs[i]);
    }
    _save(all);
  }


  function sendServiceMessage(teacherId, studentId, serviceEvent) {
    var all = _load();
    var key = _conversationKey(teacherId, studentId);
    var msg = {
      msgId:           _uuid(),
      conversationKey: key,
      senderId:        'SYSTEM',
      receiverId:      teacherId,
      text:            '',
      type:            'service',
      isService:       true,
      serviceEvent:    serviceEvent,
      requestStatus:   'pending',
      teacherId:       teacherId,
      studentId:       studentId,
      readStatus:      'sent',
      edited:          false,
      deleted:         false,
      createdAt:       _now()
    };
    all.push(msg);
    _save(all);
    return msg;
  }

  function respondServiceRequest(msgId, response, teacherId, studentId) {
    var all = _load();
    for (var i = 0; i < all.length; i++) {
      if (all[i].msgId === msgId) {
        all[i].requestStatus = response;
        all[i].readStatus    = 'read';
        break;
      }
    }
    _save(all);
  }

  function getRequestStatus(teacherId, studentId) {
    var msgs = getConversation(teacherId, studentId);
    for (var i = msgs.length - 1; i >= 0; i--) {
      if (msgs[i].type === 'service' && msgs[i].serviceEvent === 'student_request') {
        return msgs[i].requestStatus || 'pending';
      }
    }
    return null;
  }

  function hasConversation(uidA, uidB) {
    var msgs = getConversation(uidA, uidB);
    return msgs.length > 0;
  }

  function sendDisconnectMessage(teacherId, studentId, cancelledSlots) {
    var all = _load();
    var key = _conversationKey(teacherId, studentId);
    var msg = {
      msgId:           _uuid(),
      conversationKey: key,
      senderId:        'SYSTEM',
      receiverId:      teacherId,
      text:            '',
      type:            'service',
      isService:       true,
      serviceEvent:    'student_disconnected',
      teacherId:       teacherId,
      studentId:       studentId,
      cancelledSlots:  cancelledSlots || [],
      readStatus:      'sent',
      edited:          false,
      deleted:         false,
      createdAt:       _now()
    };
    all.push(msg);
    _save(all);
    return msg;
  }

  return {
    getConversation:       getConversation,
    getLastMessage:        getLastMessage,
    countUnread:           countUnread,
    totalUnread:           totalUnread,
    send:                  send,
    sendBookingProposal:   sendBookingProposal,
    sendServiceMessage:    sendServiceMessage,
    respondServiceRequest: respondServiceRequest,
    getRequestStatus:      getRequestStatus,
    hasConversation:       hasConversation,
    sendDisconnectMessage: sendDisconnectMessage,
    markAsRead:            markAsRead,
    markAsDelivered:       markAsDelivered,
    deleteMsg:             deleteMsg,
    editMsg:               editMsg,
    respondBooking:        respondBooking,
    seedDemoMessages:      seedDemoMessages
  };
})();

/* ── Debug helper ─────────────────────────────────────── */
function _debugLog(msg) {
  try {
    if (typeof console !== 'undefined' && console.error) {
      console.error('[ChatPanel] ' + msg);
    }
  } catch(e) {}
}

/* ── ChatPanel ────────────────────────────────────────── */
var ChatPanel = (function() {

  var _currentUser    = null;
  var _activePartner  = null;
  var _editingMsgId   = null;
  var _overlay        = null;
  var _panel          = null;
  var _viewList       = null;
  var _viewChat       = null;
  var _contextMenu    = null;
  var _longPressTimer = null;
  var _isOpen         = false;

  /* ── Init ─────────────────────────────────────────── */
  function init(opts) {
    try {
      /* opts.uid allows overriding Auth.current() for pages like profile-view
         where ?uid= is the viewed profile, not the logged-in user */
      if (opts && opts.uid) {
        _currentUser = AppService.getUserSync(opts.uid);
      } else {
        _currentUser = Auth.current();
      }
      if (!_currentUser) return;

      _injectCSS();
      _buildDOM();
      _bindFAB();
      _updateFABBadge();
    } catch(e) {
      _debugLog('init error: ' + e.message);
    }
  }

  function _injectCSS() {
    if (document.getElementById('chat-css')) return;
    var link  = document.createElement('link');
    link.id   = 'chat-css';
    link.rel  = 'stylesheet';
    link.href = './css/chat.css';
    document.head.appendChild(link);
  }

  /* ── Build DOM ────────────────────────────────────── */
  function _buildDOM() {
    _overlay = document.createElement('div');
    _overlay.className = 'chat-overlay';
    _overlay.id        = 'chat-overlay';
    _overlay.addEventListener('click', function() { close(); });

    _panel = document.createElement('div');
    _panel.className = 'chat-panel';
    _panel.id        = 'chat-panel';

    _viewList = document.createElement('div');
    _viewList.className = 'chat-view';
    _viewList.id        = 'chat-view-list';
    _viewList.innerHTML = _buildListHeaderHTML();

    var listBody = document.createElement('div');
    listBody.className = 'chat-list';
    listBody.id        = 'chat-list-body';
    _viewList.appendChild(listBody);

    _viewChat = document.createElement('div');
    _viewChat.className = 'chat-view chat-view-hidden';
    _viewChat.id        = 'chat-view-chat';
    _viewChat.innerHTML = _buildChatHeaderHTML() + _buildInputAreaHTML();

    var messagesDiv = document.createElement('div');
    messagesDiv.className = 'chat-messages';
    messagesDiv.id        = 'chat-messages-body';

    var editIndicator = document.createElement('div');
    editIndicator.className = 'chat-edit-indicator';
    editIndicator.id        = 'chat-edit-indicator';
    editIndicator.innerHTML =
      '<svg width="12" height="12" viewBox="0 0 16 16" fill="none">' +
        '<path d="M11 2l3 3-9 9H2v-3L11 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
      '</svg>' +
      '<span id="chat-edit-indicator-text">' + ChatI18n.t('editMode') + '</span>' +
      '<button class="chat-edit-cancel" id="chat-edit-cancel-btn" aria-label="' + ChatI18n.t('editCancel') + '">' +
        '<svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
      '</button>';

    var inputArea = _viewChat.querySelector('.chat-input-area');
    _viewChat.insertBefore(messagesDiv, inputArea);

    var inputWrap = _viewChat.querySelector('.chat-input-wrap');
    inputWrap.insertBefore(editIndicator, inputWrap.firstChild);

    _panel.appendChild(_viewList);
    _panel.appendChild(_viewChat);

    document.body.appendChild(_overlay);
    document.body.appendChild(_panel);

    _bindListHeader();
    _bindChatHeader();
    _bindInputArea();
  }

  function _buildListHeaderHTML() {
    return '<div class="chat-header" id="chat-list-header">' +
      '<span class="chat-header-title">' + ChatI18n.t('title') + '</span>' +
      '<button class="chat-header-close" id="chat-header-close" aria-label="' + ChatI18n.t('ctxClose') + '">' +
        '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
      '</button>' +
    '</div>';
  }

  function _buildChatHeaderHTML() {
    return '<div class="chat-header" id="chat-conv-header">' +
      '<button class="chat-header-back" id="chat-back-btn" aria-label="' + ChatI18n.t('back') + '">' +
        '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M10 12L6 8l4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '</button>' +
      '<div class="chat-header-avatar" id="chat-partner-avatar"></div>' +
      '<div class="chat-header-info">' +
        '<div class="chat-header-name" id="chat-partner-name"></div>' +
        '<div class="chat-header-status" id="chat-partner-status"></div>' +
      '</div>' +
    '</div>';
  }

  function _buildInputAreaHTML() {
    return '<div class="chat-input-area">' +
      '<div class="chat-input-actions">' +
        '<button class="chat-input-btn" id="chat-btn-attach" title="' + ChatI18n.t('attach') + '" aria-label="' + ChatI18n.t('attach') + '">' +
          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M13.5 8.5l-5.5 5.5a4 4 0 01-5.657-5.657l6-6a2.5 2.5 0 013.535 3.535l-5.5 5.5a1 1 0 01-1.414-1.414l5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
        '</button>' +
        '<button class="chat-input-btn" id="chat-btn-voice" title="' + ChatI18n.t('voice') + '" aria-label="' + ChatI18n.t('voice') + '">' +
          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="5" y="1" width="6" height="9" rx="3" stroke="currentColor" stroke-width="1.5"/><path d="M2 8a6 6 0 0012 0M8 14v2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
        '</button>' +
      '</div>' +
      '<div class="chat-input-wrap">' +
        '<textarea class="chat-textarea" id="chat-textarea" rows="1" placeholder="' + ChatI18n.t('inputPlaceholder') + '" aria-label="' + ChatI18n.t('inputPlaceholder') + '"></textarea>' +
      '</div>' +
      '<button class="chat-send-btn" id="chat-send-btn" aria-label="' + ChatI18n.t('send') + '">' +
        '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M14 8L2 2l3 6-3 6 12-6z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '</button>' +
    '</div>';
  }

  /* ── Bind List Header ─────────────────────────────── */
  function _bindListHeader() {
    var closeBtn = document.getElementById('chat-header-close');
    if (closeBtn) closeBtn.addEventListener('click', function() { close(); });
  }

  /* ── Bind Chat Header ─────────────────────────────── */
  function _bindChatHeader() {
    var backBtn = document.getElementById('chat-back-btn');
    if (backBtn) backBtn.addEventListener('click', function() { _showListView(); });
  }

  /* ── Bind Input Area ──────────────────────────────── */
  function _bindInputArea() {
    var textarea  = document.getElementById('chat-textarea');
    var sendBtn   = document.getElementById('chat-send-btn');
    var cancelBtn = document.getElementById('chat-edit-cancel-btn');
    var attachBtn = document.getElementById('chat-btn-attach');
    var voiceBtn  = document.getElementById('chat-btn-voice');

    if (textarea) {
      textarea.addEventListener('input', function() { _autoGrow(textarea); });
      textarea.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          _handleSend();
        }
      });
    }

    if (sendBtn) sendBtn.addEventListener('click', function() { _handleSend(); });

    if (cancelBtn) cancelBtn.addEventListener('click', function() { _cancelEdit(); });

    if (attachBtn) {
      attachBtn.addEventListener('click', function() {
        Toast.info(ChatI18n.t('attach') + ' — ' + 'Funktion in Entwicklung');
      });
    }

    if (voiceBtn) {
      voiceBtn.addEventListener('click', function() {
        Toast.info(ChatI18n.t('voice') + ' — ' + 'Funktion in Entwicklung');
      });
    }
  }

  function _autoGrow(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
  }

  /* ── FAB ──────────────────────────────────────────── */
  function _bindFAB() {
    var fab = document.getElementById('chat-fab');
    if (!fab) return;
    fab.addEventListener('click', function() {
      if (_isOpen) { close(); } else { open(); }
    });
  }

  function _updateFABBadge() {
    try {
      var fab = document.getElementById('chat-fab');
      if (!fab) return;

      var wrap = fab.parentNode;
      if (!wrap || !wrap.classList.contains('chat-fab-wrap')) {
        var newWrap = document.createElement('div');
        newWrap.className = 'chat-fab-wrap';
        fab.parentNode.insertBefore(newWrap, fab);
        newWrap.appendChild(fab);
        wrap = newWrap;
      }

      var badge = wrap.querySelector('.chat-fab-unread');
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'chat-fab-unread';
        badge.id        = 'chat-fab-unread-badge';
        wrap.appendChild(badge);
      }

      var count = ChatStore.totalUnread(_currentUser.uid);
      badge.textContent = count > 9 ? '9+' : String(count);
      if (count > 0) {
        badge.classList.add('is-visible');
      } else {
        badge.classList.remove('is-visible');
      }
    } catch(e) {
      _debugLog('_updateFABBadge error: ' + e.message);
    }
  }

  /* ── Open / Close ─────────────────────────────────── */
  function open() {
    try {
      _isOpen = true;
      _overlay.classList.add('is-open');
      _panel.classList.add('is-open');
      document.body.classList.add('overlay-open');
      _showListView();
    } catch(e) {
      _debugLog('open error: ' + e.message);
    }
  }

  function close() {
    try {
      _isOpen = false;
      _overlay.classList.remove('is-open');
      _panel.classList.remove('is-open');
      document.body.classList.remove('overlay-open');
      _closeContextMenu();
      _cancelEdit();
      _updateFABBadge();
    } catch(e) {
      _debugLog('close error: ' + e.message);
    }
  }

  /* ── Views ────────────────────────────────────────── */
  function _showListView() {
    try {
      _activePartner = null;
      _viewList.classList.remove('chat-view-hidden');
      _viewChat.classList.add('chat-view-hidden');
      _renderPartnerList();
      _cancelEdit();
    } catch(e) {
      _debugLog('_showListView error: ' + e.message);
    }
  }

  function _showChatView(partner) {
    try {
      _activePartner = partner;
      _viewList.classList.add('chat-view-hidden');
      _viewChat.classList.remove('chat-view-hidden');

      var displayName = ProfileStore.getDisplayName(partner.uid);
      var photo       = ProfileStore.getPhoto(partner.uid);
      var initials    = _initials(displayName);
      var avatarEl    = document.getElementById('chat-partner-avatar');
      var nameEl      = document.getElementById('chat-partner-name');
      var statusEl    = document.getElementById('chat-partner-status');

      if (avatarEl) {
        if (photo) {
          avatarEl.className = 'chat-header-avatar chat-header-avatar-photo';
          avatarEl.textContent = '';
          avatarEl.innerHTML = '<img src="' + photo + '" alt="' + _escapeHTML(displayName) + '" />';
        } else {
          avatarEl.innerHTML   = '';
          avatarEl.textContent = initials;
          avatarEl.className   = 'chat-header-avatar role-' + partner.role;
        }
      }
      if (nameEl) nameEl.textContent = displayName;
      if (statusEl) statusEl.textContent = ChatI18n.t('lastSeen') + ': ' + _fakeLastSeen();

      ChatStore.markAsRead(_currentUser.uid, partner.uid);
      _updateFABBadge();
      _renderMessages();
      _updateInputLock(partner.uid);
      _scrollToBottomRaf();
    } catch(e) {
      _debugLog('_showChatView error: ' + e.message);
    }
  }

  function _updateInputLock(partnerUid) {
    var textarea  = document.getElementById('chat-textarea');
    var sendBtn   = document.getElementById('chat-send-btn');
    var attachBtn = document.getElementById('chat-btn-attach');
    var voiceBtn  = document.getElementById('chat-btn-voice');
    var inputArea = document.querySelector('.chat-input-area');

    if (!textarea) return;

    var status = _getRequestStatus(partnerUid);
    var locked = false;
    var placeholder = ChatI18n.t('inputPlaceholder');

    if (status === 'pending' && _currentUser.role === 'student') {
      locked = true;
      placeholder = ChatI18n.t('inputLockedPending');
    }
    if (status === 'declined') {
      locked = true;
      placeholder = ChatI18n.t('inputLockedDeclined');
    }

    textarea.disabled = locked;
    textarea.placeholder = placeholder;
    if (sendBtn)   sendBtn.disabled   = locked;
    if (attachBtn) attachBtn.disabled = locked;
    if (voiceBtn)  voiceBtn.disabled  = locked;

    if (inputArea) {
      if (locked) {
        inputArea.classList.add('chat-input-locked');
      } else {
        inputArea.classList.remove('chat-input-locked');
      }
    }
  }

  /* ── Render Partner List ──────────────────────────── */
  function _renderPartnerList() {
    try {
      var container = document.getElementById('chat-list-body');
      if (!container) return;
      container.innerHTML = '';

      var partners = _getPartners();

      if (!partners.length) {
        container.innerHTML =
          '<div class="chat-empty">' +
            '<svg width="40" height="40" viewBox="0 0 24 24" fill="none"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '<div class="chat-empty-title">' + ChatI18n.t('noChats') + '</div>' +
            '<div class="chat-empty-sub">' + ChatI18n.t('noChatsSub') + '</div>' +
          '</div>';
        return;
      }

      for (var i = 0; i < partners.length; i++) {
        container.appendChild(_buildListItem(partners[i]));
      }
    } catch(e) {
      _debugLog('_renderPartnerList error: ' + e.message);
    }
  }

  function _getPartners() {
    var role   = _currentUser.role;
    var all    = role === 'teacher'
      ? AppService.getUsersByRoleSync('student')
      : role === 'student'
        ? AppService.getUsersByRoleSync('teacher')
        : AppService.getUsersByRoleSync('teacher').concat(AppService.getUsersByRoleSync('student'));
    var result = [];

    for (var i = 0; i < all.length; i++) {
      var u = all[i];
      if (u.uid === _currentUser.uid) continue;
      if (u.role === 'admin') continue;

      if (role === 'teacher' && u.role === 'student') {
        if (ChatStore.hasConversation(_currentUser.uid, u.uid)) {
          result.push(u);
        }
      }

      if (role === 'student' && u.role === 'teacher') {
        if (ChatStore.hasConversation(_currentUser.uid, u.uid)) {
          result.push(u);
        }
      }
    }
    return result;
  }

  function _getRequestStatus(partnerUid) {
    if (_currentUser.role === 'teacher') {
      return ChatStore.getRequestStatus(_currentUser.uid, partnerUid);
    }
    return ChatStore.getRequestStatus(partnerUid, _currentUser.uid);
  }

  function _isInputLocked(partnerUid) {
    var status = _getRequestStatus(partnerUid);
    if (status === null) return false;
    return status === 'pending' || status === 'declined';
  }

  function _buildListItem(partner) {
    var item = document.createElement('div');
    item.className = 'chat-list-item';

    var lastMsg     = ChatStore.getLastMessage(_currentUser.uid, partner.uid);
    var unread      = ChatStore.countUnread(_currentUser.uid, partner.uid);
    var displayName = ProfileStore.getDisplayName(partner.uid);
    var photo       = ProfileStore.getPhoto(partner.uid);
    var initials    = _initials(displayName);
    var timeStr     = lastMsg ? _formatTime(new Date(lastMsg.createdAt)) : '';

    var preview = '';
    if (lastMsg) {
      if (lastMsg.type === 'booking_proposal') {
        preview = '📅 ' + ChatI18n.t('bookingProposal');
      } else if (lastMsg.type === 'service') {
        preview = '🔔 ' + ChatI18n.t('serviceRequestLabel');
      } else {
        preview = _escapeHTML(lastMsg.text);
      }
    }

    var badgeHTML = '';
    if (unread > 0) {
      badgeHTML = '<span class="chat-list-badge">' + (unread > 9 ? '9+' : unread) + '</span>';
    }

    var avatarHTML = photo
      ? '<div class="chat-list-avatar chat-list-avatar-photo"><img src="' + photo + '" alt="' + _escapeHTML(displayName) + '" /></div>'
      : '<div class="chat-list-avatar role-' + partner.role + '">' + initials + '</div>';

    item.innerHTML =
      avatarHTML +
      '<div class="chat-list-body">' +
        '<div class="chat-list-name-row">' +
          '<span class="chat-list-name">' + _escapeHTML(displayName) + '</span>' +
          '<span class="chat-list-time">' + _escapeHTML(timeStr) + '</span>' +
        '</div>' +
        '<div class="chat-list-name-row">' +
          '<span class="chat-list-preview">' + preview + '</span>' +
          badgeHTML +
        '</div>' +
      '</div>';

    item.addEventListener('click', function() { _showChatView(partner); });
    return item;
  }

  /* ── Render Messages ──────────────────────────────── */
  function _renderMessages() {
    try {
      var container = document.getElementById('chat-messages-body');
      if (!container || !_activePartner) return;
      container.innerHTML = '';

      var msgs = ChatStore.getConversation(_currentUser.uid, _activePartner.uid);

      if (!msgs.length) {
        container.innerHTML =
          '<div class="chat-empty">' +
            '<svg width="36" height="36" viewBox="0 0 24 24" fill="none"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '<div class="chat-empty-title">' + ChatI18n.t('noMessages') + '</div>' +
            '<div class="chat-empty-sub">' + ChatI18n.t('noMessagesSub') + '</div>' +
          '</div>';
        return;
      }

      var lastDateStr = '';

      for (var i = 0; i < msgs.length; i++) {
        var msg     = msgs[i];
        var dateStr = _formatDateLabel(new Date(msg.createdAt));

        if (dateStr !== lastDateStr) {
          container.appendChild(_buildDateDivider(dateStr));
          lastDateStr = dateStr;
        }

        if (msg.type === 'service') {
          container.appendChild(_buildServiceMsg(msg));
        } else if (msg.type === 'booking_proposal') {
          container.appendChild(_buildBookingBubble(msg));
        } else {
          container.appendChild(_buildTextBubble(msg));
        }
      }
    } catch(e) {
      _debugLog('_renderMessages error: ' + e.message);
    }
  }

  function _buildServiceMsg(msg) {
    var wrap = document.createElement('div');
    wrap.className = 'chat-msg-service';
    wrap.setAttribute('data-msg-id', msg.msgId);

    var isTeacher   = _currentUser.role === 'teacher';
    var studentName = '';
    var teacherName = '';

    if (msg.studentId) {
      studentName = ProfileStore.getDisplayName(msg.studentId);
    }
    if (msg.teacherId) {
      teacherName = ProfileStore.getDisplayName(msg.teacherId);
    }

    var innerHTML = '';

    if (msg.serviceEvent === 'student_request') {
      if (isTeacher) {
        var requestStatus = msg.requestStatus || 'pending';
        innerHTML =
          '<div class="chat-service-card">' +
            '<div class="chat-service-label">' +
              '<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M8 1a4 4 0 100 8A4 4 0 008 1zM2 14s-1 0-1-1 1-4 7-4 7 3 7 4-1 1-1 1H2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
              ChatI18n.t('serviceRequestLabel') +
            '</div>' +
            '<div class="chat-service-text">' +
              _escapeHTML(studentName) + ' ' + ChatI18n.t('serviceStudentRequest') +
            '</div>';

        if (requestStatus === 'pending') {
          innerHTML +=
            '<div class="chat-service-actions">' +
              '<button class="btn btn-secondary btn-sm chat-service-decline-btn" data-msg-id="' + msg.msgId + '">' + ChatI18n.t('serviceDeclineBtn') + '</button>' +
              '<button class="btn btn-primary btn-sm chat-service-accept-btn" data-msg-id="' + msg.msgId + '">' + ChatI18n.t('serviceAcceptBtn') + '</button>' +
            '</div>';
        } else if (requestStatus === 'accepted') {
          innerHTML +=
            '<div class="chat-service-status chat-service-status-accepted">' +
              ChatI18n.t('serviceAccepted').replace('{name}', _escapeHTML(studentName)) +
            '</div>';
        } else if (requestStatus === 'declined') {
          innerHTML +=
            '<div class="chat-service-status chat-service-status-declined">' +
              ChatI18n.t('serviceDeclined').replace('{name}', _escapeHTML(studentName)) +
            '</div>';
        }

        innerHTML += '</div>';

      } else {
        var reqStatus = msg.requestStatus || 'pending';
        var statusClass = '';
        var statusText  = '';
        if (reqStatus === 'pending') {
          statusText  = ChatI18n.t('serviceRequestSent');
          statusClass = 'chat-service-status-pending';
        } else if (reqStatus === 'accepted') {
          statusText  = ChatI18n.t('serviceAcceptedStudent').replace('{name}', _escapeHTML(teacherName));
          statusClass = 'chat-service-status-accepted';
        } else if (reqStatus === 'declined') {
          statusText  = ChatI18n.t('serviceDeclinedStudent').replace('{name}', _escapeHTML(teacherName));
          statusClass = 'chat-service-status-declined';
        }
        innerHTML =
          '<div class="chat-service-card">' +
            '<div class="chat-service-label">' +
              '<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M8 1a4 4 0 100 8A4 4 0 008 1zM2 14s-1 0-1-1 1-4 7-4 7 3 7 4-1 1-1 1H2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
              ChatI18n.t('serviceRequestLabel') +
            '</div>' +
            '<div class="chat-service-status ' + statusClass + '">' + statusText + '</div>' +
          '</div>';
      }
    }

    if (msg.serviceEvent === 'student_disconnected') {
      var slots     = msg.cancelledSlots || [];
      var isTeacher = _currentUser.role === 'teacher';
      var nameStr   = isTeacher ? studentName : teacherName;
      var titleText = isTeacher
        ? ChatI18n.t('serviceDisconnected').replace('{name}', _escapeHTML(nameStr))
        : ChatI18n.t('serviceDisconnectedTeacher').replace('{name}', _escapeHTML(nameStr));

      var slotsHTML = '';
      if (slots.length) {
        var slotsLabel = isTeacher
          ? ChatI18n.t('serviceDisconnectedSlots')
          : ChatI18n.t('serviceDisconnectedTeacherSlots');
        slotsHTML = '<div class="chat-service-slots-label">' + slotsLabel + '</div>' +
                    '<ul class="chat-service-slots-list">';
        for (var si = 0; si < slots.length; si++) {
          var sl = slots[si];
          slotsHTML += '<li>' + _escapeHTML(sl.dateLabel) + ' &nbsp;' + _escapeHTML(sl.time) + ' – ' + _escapeHTML(sl.endTime) + '</li>';
        }
        slotsHTML += '</ul>';
      } else {
        slotsHTML = '<div class="chat-service-status chat-service-status-pending">' +
          ChatI18n.t('serviceDisconnectedNone') + '</div>';
      }

      innerHTML =
        '<div class="chat-service-card">' +
          '<div class="chat-service-label">' +
            '<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M10 8H2M2 8l3-3M2 8l3 3M6 4V3a1 1 0 011-1h6a1 1 0 011 1v10a1 1 0 01-1 1H7a1 1 0 01-1-1v-1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            ChatI18n.t('serviceDisconnectLabel') +
          '</div>' +
          '<div class="chat-service-text">' + titleText + '</div>' +
          slotsHTML +
        '</div>';
    }

    wrap.innerHTML = innerHTML;

    var acceptBtn  = wrap.querySelector('.chat-service-accept-btn');
    var declineBtn = wrap.querySelector('.chat-service-decline-btn');

    if (acceptBtn) {
      (function(m) {
        acceptBtn.addEventListener('click', function() {
          _respondServiceRequest(m.msgId, 'accepted', m.teacherId, m.studentId);
        });
      })(msg);
    }
    if (declineBtn) {
      (function(m) {
        declineBtn.addEventListener('click', function() {
          _respondServiceRequest(m.msgId, 'declined', m.teacherId, m.studentId);
        });
      })(msg);
    }

    return wrap;
  }

  function _respondServiceRequest(msgId, response, teacherId, studentId) {
    try {
      ChatStore.respondServiceRequest(msgId, response, teacherId, studentId);
      if (response === 'accepted') {
        /* Create selection only now — after teacher approval */
        AppService.createSelection(studentId, teacherId, function(e) {
          if (e) _debugLog('createSelection error: ' + e.message);
        });
      }
      if (response === 'declined') {
        AppService.deleteSelection(studentId, teacherId, function(e) {
          if (e) _debugLog('deleteSelection error: ' + e.message);
        });
      }
      _renderMessages();
      if (_activePartner) _updateInputLock(_activePartner.uid);
      var sName   = ProfileStore.getDisplayName(studentId);
      var tName   = ProfileStore.getDisplayName(_currentUser.uid);
      if (response === 'accepted') {
        Toast.success(ChatI18n.t('serviceAccepted').replace('{name}', sName));
        EmailService.onRequestAccepted(studentId, tName);
      }
      if (response === 'declined') {
        Toast.info(ChatI18n.t('serviceDeclined').replace('{name}', sName));
        EmailService.onRequestDeclined(studentId, tName);
      }
    } catch(e) {
      _debugLog('_respondServiceRequest error: ' + e.message);
    }
  }

  function _buildDateDivider(label) {
    var el = document.createElement('div');
    el.className = 'chat-date-divider';
    el.innerHTML =
      '<div class="chat-date-divider-line"></div>' +
      '<span class="chat-date-divider-label">' + _escapeHTML(label) + '</span>' +
      '<div class="chat-date-divider-line"></div>';
    return el;
  }

  function _buildTextBubble(msg) {
    var isOut    = msg.senderId === _currentUser.uid;
    var wrap     = document.createElement('div');
    wrap.className = 'chat-msg ' + (isOut ? 'chat-msg-out' : 'chat-msg-in');
    wrap.setAttribute('data-msg-id', msg.msgId);

    var avatarHTML = '';
    if (!isOut) {
      var _partnerPhoto    = ProfileStore.getPhoto(_activePartner.uid);
      var _partnerDisplay  = ProfileStore.getDisplayName(_activePartner.uid);
      if (_partnerPhoto) {
        avatarHTML = '<div class="chat-bubble-avatar chat-bubble-avatar-photo"><img src="' + _partnerPhoto + '" alt="' + _escapeHTML(_partnerDisplay) + '" /></div>';
      } else {
        avatarHTML = '<div class="chat-bubble-avatar role-' + _activePartner.role + '">' + _initials(_partnerDisplay) + '</div>';
      }
    }

    var editedHTML = msg.edited ? '<span class="chat-edited-tag">(' + ChatI18n.t('edited') + ')</span>' : '';
    var statusHTML = isOut ? _buildStatusHTML(msg.readStatus) : '';

    var displayText;
    var metaTime;
    if (msg.deleted) {
      displayText = '<em class="msg-deleted">Nachricht gelöscht</em>';
      var deletedDate = msg.deletedAt ? new Date(msg.deletedAt) : new Date(msg.createdAt);
      metaTime = _formatTime(deletedDate);
    } else {
      displayText = _escapeHTML(msg.text) + editedHTML;
      metaTime    = _formatTime(new Date(msg.createdAt));
    }

    var bubbleHTML =
      '<div class="chat-bubble-wrap">' +
        '<div class="chat-bubble ' + (isOut ? 'chat-bubble-out' : 'chat-bubble-in') + (msg.deleted ? ' chat-bubble-deleted' : '') + '">' +
          displayText +
        '</div>' +
        '<div class="chat-bubble-meta">' +
          '<span class="chat-bubble-time">' + metaTime + '</span>' +
          (msg.deleted ? '' : statusHTML) +
        '</div>' +
      '</div>';
    wrap.innerHTML = avatarHTML + bubbleHTML;

    if (isOut && !msg.deleted) {
      var bubble = wrap.querySelector('.chat-bubble');
      if (bubble) {
        _bindBubbleContextMenu(bubble, msg);
      }
    }

    return wrap;
  }

  function _buildBookingBubble(msg) {
    var isOut   = msg.senderId === _currentUser.uid;
    var wrap    = document.createElement('div');
    wrap.className = 'chat-msg ' + (isOut ? 'chat-msg-out' : 'chat-msg-in');
    wrap.setAttribute('data-msg-id', msg.msgId);

    var avatarHTML = '';
    if (!isOut) {
      var _bPartnerPhoto   = ProfileStore.getPhoto(_activePartner.uid);
      var _bPartnerDisplay = ProfileStore.getDisplayName(_activePartner.uid);
      if (_bPartnerPhoto) {
        avatarHTML = '<div class="chat-bubble-avatar chat-bubble-avatar-photo"><img src="' + _bPartnerPhoto + '" alt="' + _escapeHTML(_bPartnerDisplay) + '" /></div>';
      } else {
        avatarHTML = '<div class="chat-bubble-avatar role-' + _activePartner.role + '">' + _initials(_bPartnerDisplay) + '</div>';
      }
    }

    var bd = msg.bookingData || {};
    var withName = bd.with || ProfileStore.getDisplayName(_activePartner.uid);

    var actionsHTML = '';
    if (msg.bookingStatus === 'pending' && !isOut) {
      actionsHTML =
        '<div class="chat-booking-actions">' +
          '<button class="btn btn-secondary btn-sm chat-booking-decline-btn" data-msg-id="' + msg.msgId + '">' + ChatI18n.t('bookingDecline') + '</button>' +
          '<button class="btn btn-primary btn-sm chat-booking-accept-btn" data-msg-id="' + msg.msgId + '">' + ChatI18n.t('bookingAccept') + '</button>' +
        '</div>';
    } else if (msg.bookingStatus === 'accepted') {
      actionsHTML =
        '<div class="chat-booking-status chat-booking-status-accepted">' +
          ChatI18n.t('bookingAccepted') +
        '</div>';
    } else if (msg.bookingStatus === 'declined') {
      actionsHTML =
        '<div class="chat-booking-status chat-booking-status-declined">' +
          ChatI18n.t('bookingDeclined') +
        '</div>';
    } else if (msg.bookingStatus === 'pending' && isOut) {
      actionsHTML =
        '<div class="chat-booking-status">Ausstehend…</div>';
    }

    var statusHTML = isOut ? _buildStatusHTML(msg.readStatus) : '';

    var bubbleHTML =
      '<div class="chat-bubble-wrap">' +
        '<div class="chat-booking-bubble">' +
          '<div class="chat-booking-header">' +
            '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><rect x="1" y="2" width="14" height="13" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M5 1v2M11 1v2M1 6h14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
            ChatI18n.t('bookingProposal') +
          '</div>' +
          '<div class="chat-booking-body">' +
            '<div class="chat-booking-date">' + _escapeHTML(bd.date || '') + '</div>' +
            '<div class="chat-booking-time">' + _escapeHTML((bd.timeStart || '') + ' – ' + (bd.timeEnd || '') + ' Uhr') + '</div>' +
            '<div class="chat-booking-with">mit ' + _escapeHTML(withName) + '</div>' +
          '</div>' +
          actionsHTML +
        '</div>' +
        '<div class="chat-bubble-meta">' +
          '<span class="chat-bubble-time">' + _formatTime(new Date(msg.createdAt)) + '</span>' +
          statusHTML +
        '</div>' +
      '</div>';

    wrap.innerHTML = avatarHTML + bubbleHTML;

    var acceptBtn  = wrap.querySelector('.chat-booking-accept-btn');
    var declineBtn = wrap.querySelector('.chat-booking-decline-btn');
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function() {
        _respondBooking(msg.msgId, 'accepted');
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function() {
        _respondBooking(msg.msgId, 'declined');
      });
    }

    return wrap;
  }

  function _buildStatusHTML(status) {
    if (status === 'sent') {
      return '<span class="chat-read-status" title="' + ChatI18n.t('statusSent') + '">' +
        '<svg width="14" height="10" viewBox="0 0 14 10" fill="none"><path d="M1 5l4 4L13 1" stroke="var(--neutral-400)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '</span>';
    }
    if (status === 'delivered') {
      return '<span class="chat-read-status" title="' + ChatI18n.t('statusDelivered') + '">' +
        '<svg width="18" height="10" viewBox="0 0 18 10" fill="none"><path d="M1 5l4 4L13 1" stroke="var(--neutral-400)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 5l4 4L18 1" stroke="var(--neutral-400)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '</span>';
    }
    if (status === 'read') {
      return '<span class="chat-read-status" title="' + ChatI18n.t('statusRead') + '">' +
        '<svg width="18" height="10" viewBox="0 0 18 10" fill="none"><path d="M1 5l4 4L13 1" stroke="var(--color-400)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 5l4 4L18 1" stroke="var(--color-400)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '</span>';
    }
    return '';
  }

  /* ── Context Menu ─────────────────────────────────── */
  function _bindBubbleContextMenu(bubble, msg) {
    var pressTimer = null;

    bubble.addEventListener('mousedown', function(e) {
      if (e.button !== 0) return;
      pressTimer = setTimeout(function() {
        _showContextMenu(e.clientX, e.clientY, msg);
      }, 500);
    });

    bubble.addEventListener('mouseup',   function() { clearTimeout(pressTimer); });
    bubble.addEventListener('mouseleave',function() { clearTimeout(pressTimer); });

    bubble.addEventListener('touchstart', function(e) {
      var touch = e.touches[0];
      pressTimer = setTimeout(function() {
        _showContextMenu(touch.clientX, touch.clientY, msg);
      }, 500);
    }, { passive: true });

    bubble.addEventListener('touchend',  function() { clearTimeout(pressTimer); });
    bubble.addEventListener('touchmove', function() { clearTimeout(pressTimer); });

    bubble.addEventListener('contextmenu', function(e) {
      e.preventDefault();
      _showContextMenu(e.clientX, e.clientY, msg);
    });
  }

  function _showContextMenu(x, y, msg) {
    try {
      _closeContextMenu();

      _contextMenu = document.createElement('div');
      _contextMenu.className = 'chat-context-menu';
      _contextMenu.id        = 'chat-context-menu';

      var editBtn = document.createElement('button');
      editBtn.className = 'chat-ctx-btn';
      editBtn.innerHTML =
        '<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M11 2l3 3-9 9H2v-3L11 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
        ChatI18n.t('msgEdit');
      editBtn.addEventListener('click', function() {
        _closeContextMenu();
        _startEdit(msg);
      });

      var divider = document.createElement('div');
      divider.className = 'chat-ctx-divider';

      var delBtn = document.createElement('button');
      delBtn.className = 'chat-ctx-btn chat-ctx-btn-danger';
      delBtn.innerHTML =
        '<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M5 4V2h6v2M6 7v5M10 7v5M3 4l1 10h8l1-10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
        ChatI18n.t('msgDelete');
      delBtn.addEventListener('click', function() {
        _closeContextMenu();
        _confirmDelete(msg.msgId);
      });

      _contextMenu.appendChild(editBtn);
      _contextMenu.appendChild(divider);
      _contextMenu.appendChild(delBtn);

      document.body.appendChild(_contextMenu);

      var menuW = 160;
      var menuH = 90;
      var left  = Math.min(x, window.innerWidth  - menuW - 8);
      var top   = Math.min(y, window.innerHeight - menuH - 8);

      _contextMenu.style.left = left + 'px';
      _contextMenu.style.top  = top  + 'px';

      setTimeout(function() {
        document.addEventListener('click', _closeContextMenu);
        document.addEventListener('keydown', _ctxKeydown);
      }, 10);
    } catch(e) {
      _debugLog('_showContextMenu error: ' + e.message);
    }
  }

  function _ctxKeydown(e) {
    if (e.key === 'Escape') _closeContextMenu();
  }

  function _closeContextMenu() {
    if (_contextMenu) {
      _contextMenu.remove();
      _contextMenu = null;
      document.removeEventListener('click', _closeContextMenu);
      document.removeEventListener('keydown', _ctxKeydown);
    }
  }

  /* ── Delete ───────────────────────────────────────── */
  function _confirmDelete(msgId) {
    try {
      var modal = Modal.show({
        title:      ChatI18n.t('deleteTitle'),
        bodyHTML:   '<p>' + ChatI18n.t('deleteBody') + '</p>',
        footerHTML:
          '<button class="btn btn-secondary" id="chat-del-cancel">' + ChatI18n.t('deleteCancel') + '</button>' +
          '<button class="btn btn-danger"    id="chat-del-confirm">' + ChatI18n.t('deleteConfirm') + '</button>'
      });

      setTimeout(function() {
        var confirmBtn = document.getElementById('chat-del-confirm');
        var cancelBtn  = document.getElementById('chat-del-cancel');
        if (confirmBtn) {
          confirmBtn.addEventListener('click', function() {
            ChatStore.deleteMsg(msgId);
            modal.close();
            _renderMessages();
            _renderPartnerList();
            Toast.success('Nachricht gelöscht');
          });
        }
        if (cancelBtn) {
          cancelBtn.addEventListener('click', function() {
            modal.close();
          });
        }
      }, 50);
    } catch(e) {
      _debugLog('_confirmDelete error: ' + e.message);
    }
  }

  /* ── Edit ─────────────────────────────────────────── */
  function _startEdit(msg) {
    try {
      _editingMsgId = msg.msgId;
      var textarea   = document.getElementById('chat-textarea');
      var indicator  = document.getElementById('chat-edit-indicator');

      if (textarea)  textarea.value = msg.text;
      if (textarea)  _autoGrow(textarea);
      if (textarea)  textarea.focus();
      if (indicator) indicator.classList.add('is-visible');
    } catch(e) {
      _debugLog('_startEdit error: ' + e.message);
    }
  }

  function _cancelEdit() {
    _editingMsgId = null;
    var textarea   = document.getElementById('chat-textarea');
    var indicator  = document.getElementById('chat-edit-indicator');
    if (textarea)  { textarea.value = ''; textarea.style.height = ''; }
    if (indicator) indicator.classList.remove('is-visible');
  }

  /* ── Send ─────────────────────────────────────────── */
  function _handleSend() {
    try {
      var textarea = document.getElementById('chat-textarea');
      if (!textarea) { _debugLog('_handleSend: textarea not found'); return; }
      var text = textarea.value.trim();
      if (!text) return;
      if (!_activePartner) { _debugLog('_handleSend: no active partner'); return; }

      if (_editingMsgId) {
        ChatStore.editMsg(_editingMsgId, text);
        _cancelEdit();
        _renderMessages();
        _scrollToBottomRaf();
        return;
      }

      var msg = ChatStore.send(_currentUser.uid, _activePartner.uid, text, 'text');
      EmailService.onNewMessage(
        _activePartner.uid,
        ProfileStore.getDisplayName(_currentUser.uid),
        text.length > 80 ? text.slice(0, 80) + '…' : text
      );
      textarea.value = '';
      textarea.style.height = 'auto';

      var container = document.getElementById('chat-messages-body');
      if (!container) { _debugLog('_handleSend: messages container not found'); return; }

      var emptyEl = container.querySelector('.chat-empty');
      if (emptyEl) container.innerHTML = '';

      var today = new Date();
      var lastDivider = container.querySelector('.chat-date-divider:last-of-type');
      var needsDivider = true;
      if (lastDivider) {
        var lastLabel = lastDivider.querySelector('.chat-date-divider-label');
        if (lastLabel && lastLabel.textContent === _formatDateLabel(today)) needsDivider = false;
      }
      if (needsDivider && !lastDivider) {
        container.appendChild(_buildDateDivider(_formatDateLabel(today)));
      }

      container.appendChild(_buildTextBubble(msg));
      _scrollToBottomRaf();
    } catch(e) {
      _debugLog('_handleSend error: ' + e.message);
      Toast.error(ChatI18n.t('errorSend'));
    }
  }

  /* ── Booking Response ─────────────────────────────── */
  function _respondBooking(msgId, response) {
    try {
      ChatStore.respondBooking(msgId, response);
      _renderMessages();
      if (response === 'accepted') Toast.success(ChatI18n.t('bookingAccepted'));
      if (response === 'declined') Toast.info(ChatI18n.t('bookingDeclined'));
    } catch(e) {
      _debugLog('_respondBooking error: ' + e.message);
    }
  }

  /* ── Helpers ──────────────────────────────────────── */
  function _scrollToBottom() {
    var container = document.getElementById('chat-messages-body');
    if (container) container.scrollTop = container.scrollHeight;
  }

  function _scrollToBottomRaf() {
    requestAnimationFrame(function() {
      var container = document.getElementById('chat-messages-body');
      if (container) container.scrollTop = container.scrollHeight;
    });
  }

  function _initials(name) {
    if (!name) return '?';
    var parts = name.trim().split(' ');
    if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    return name.slice(0, 2).toUpperCase();
  }

  function _escapeHTML(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function _formatTime(date) {
    try {
      var h = String(date.getHours()).padStart(2, '0');
      var m = String(date.getMinutes()).padStart(2, '0');
      return h + ':' + m;
    } catch(e) { return ''; }
  }

  function _formatDateLabel(date) {
    try {
      var today = new Date();
      var todayStr = today.getFullYear() + '-' +
        String(today.getMonth() + 1).padStart(2, '0') + '-' +
        String(today.getDate()).padStart(2, '0');

      var dateStr = date.getFullYear() + '-' +
        String(date.getMonth() + 1).padStart(2, '0') + '-' +
        String(date.getDate()).padStart(2, '0');

      if (dateStr === todayStr) return ChatI18n.t('today');

      var yesterday = new Date(today);
      yesterday.setDate(today.getDate() - 1);
      var yStr = yesterday.getFullYear() + '-' +
        String(yesterday.getMonth() + 1).padStart(2, '0') + '-' +
        String(yesterday.getDate()).padStart(2, '0');
      if (dateStr === yStr) return ChatI18n.t('yesterday');

      var days = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
      var months = ['Jan.', 'Feb.', 'Mär.', 'Apr.', 'Mai', 'Jun.', 'Jul.', 'Aug.', 'Sep.', 'Okt.', 'Nov.', 'Dez.'];
      return days[date.getDay()] + ', ' + date.getDate() + '. ' + months[date.getMonth()] + ' ' + date.getFullYear();
    } catch(e) { return ''; }
  }

  function _fakeLastSeen() {
    var times = ['09:14', '11:32', '14:55', '08:07', '16:40'];
    return times[Math.floor(Math.random() * times.length)] + ' Uhr';
  }

  /* ── openWith ─────────────────────────────────────── */
  /* Öffnet den Chat direkt mit einem bestimmten Partner */
  function openWith(partnerUid) {
    try {
      if (!_currentUser) return;
      var partner = AppService.getUserSync(partnerUid);
      if (!partner) return;
      _isOpen = true;
      _overlay.classList.add('is-open');
      _panel.classList.add('is-open');
      document.body.classList.add('overlay-open');
      _showChatView(partner);
    } catch(e) {
      _debugLog('openWith error: ' + e.message);
    }
  }

  return {
    init:     init,
    open:     open,
    openWith: openWith,
    close:    close
  };

})();

window.ChatPanel = ChatPanel;
window.ChatStore = ChatStore;
window.ChatI18n  = ChatI18n;
