/**
 * landing.js — Landing Page Logic
 *
 * Verantwortlichkeiten:
 *  - Navbar initialisieren (kein Auth-Guard, public page)
 *  - AuthModal öffnen bei Login-Button und Hero-CTA
 *  - Skiing-Karte → skiing.html navigieren
 *  - Coming-soon Karten: keine Navigation
 *
 * i18n Namespace: landing
 * Regeln: var only, function(){}, string concat, no arrow functions,
 *         no ?. or ??, no template literals, no inline styles
 */

/* ── i18n ───────────────────────────────────────────────── */
var LandingI18n = {
  navLoginBtn:        'Anmelden',
  authModalTitle:     'Willkommen',
  authTabSignIn:      'Sign In',
  authTabSignUp:      'Sign Up',
  signInEmailLabel:   'E-Mail',
  signInEmailPlaceholder: 'deine@email.com',
  signInPasswordLabel: 'Passwort',
  signInPasswordPlaceholder: '••••••••',
  signInSubmit:       'Anmelden',
  signUpNameLabel:    'Vollständiger Name',
  signUpRoleLabel:    'Ich bin…',
  signUpRoleTeacher:  'Lehrer / Instruktor',
  signUpRoleStudent:  'Schüler / Kursteilnehmer',
  signUpDisciplineLabel: 'Beruf / Disziplin',
  signUpDisciplineHint: 'Wird in deinem öffentlichen Profil angezeigt.',
  signUpSuccessTeacher: 'Konto erstellt! Richte jetzt dein Profil ein.',
  signUpSuccessStudent: 'Konto erstellt! Willkommen.',
  errorEmptyName:     'Bitte Namen eingeben.',
  errorEmptyRole:     'Bitte Rolle wählen.',
  errorEmailExists:   'Diese E-Mail ist bereits registriert.',
  errorWeakPassword:  'Passwort muss mindestens 6 Zeichen haben.',
  signUpNamePlaceholder: 'Max Mustermann',
  signUpEmailLabel:   'E-Mail',
  signUpEmailPlaceholder: 'deine@email.com',
  signUpPasswordLabel: 'Passwort',
  signUpPasswordPlaceholder: 'Mindestens 8 Zeichen',
  signUpSubmit:       'Konto erstellen',
  orDivider:          'oder',
  googleSignIn:       'Mit Google anmelden',
  googleSignUp:       'Mit Google registrieren',
  mockupNotice:       'Mockup — Funktion folgt demnächst.',
  errorEmptyEmail:    'Bitte E-Mail-Adresse eingeben.',
  errorEmptyPassword: 'Bitte Passwort eingeben.',
  errorEmptyName:     'Bitte Namen eingeben.',
  signUpNotice:       'Registrierung erfolgt über den Admin-Bereich.',
  comingSoon:         'Demnächst verfügbar'
};

/* ══════════════════════════════════════════════════════════
   AuthModal — Standalone-Objekt
══════════════════════════════════════════════════════════ */
var AuthModal = {

  _overlay: null,
  _activeTab: 'signin',
  _hint: null,

  open: function(initialTab, hint) {
    var self = this;
    self._activeTab = initialTab || 'signin';
    self._hint      = hint || null;

    if (self._overlay) {
      /* Update hint text if modal already open */
      var hintEl = document.getElementById('auth-modal-hint');
      if (hintEl) {
        hintEl.textContent = self._hint || '';
        hintEl.classList.toggle('is-hidden', !self._hint);
      }
      self._setTab(self._activeTab);
      return;
    }

    self._render();
    self._bind();
    self._setTab(self._activeTab);
  },

  close: function() {
    var self = this;
    if (!self._overlay) return;
    self._overlay.remove();
    self._overlay = null;
  },

  _render: function() {
    var self = this;
    var t    = LandingI18n;

    var overlay = document.createElement('div');
    overlay.className  = 'modal-overlay';
    overlay.id         = 'auth-modal-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', t.authModalTitle);

    overlay.innerHTML =
      '<div class="modal auth-modal">' +
        '<div class="modal-header">' +
          '<span class="modal-title">' + t.authModalTitle + '</span>' +
          '<button class="modal-close" id="auth-modal-close" aria-label="Schließen">' +
            '<svg width="16" height="16" viewBox="0 0 16 16" fill="none">' +
              '<path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
            '</svg>' +
          '</button>' +
        '</div>' +
        '<div class="modal-body">' +

          /* Contextual hint (e.g. "Melde dich an, um mit X zu chatten") */
          '<div class="auth-hint' + (self._hint ? '' : ' is-hidden') + '" id="auth-modal-hint">' +
            '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">' +
              '<circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>' +
              '<path d="M8 7v4M8 5v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
            '</svg>' +
            '<span id="auth-modal-hint-text">' + (self._hint ? self._hint : '') + '</span>' +
          '</div>' +

          /* Tab switcher */
          '<div class="auth-tabs" role="tablist">' +
            '<button class="auth-tab-btn" id="auth-tab-signin" role="tab" aria-controls="auth-panel-signin" aria-selected="false">' +
              t.authTabSignIn +
            '</button>' +
            '<button class="auth-tab-btn" id="auth-tab-signup" role="tab" aria-controls="auth-panel-signup" aria-selected="false">' +
              t.authTabSignUp +
            '</button>' +
          '</div>' +

          /* ── Sign In Panel ── */
          '<div class="auth-panel" id="auth-panel-signin" role="tabpanel" aria-labelledby="auth-tab-signin">' +

            '<div class="form-group">' +
              '<label class="form-label" for="signin-email">' + t.signInEmailLabel + '</label>' +
              '<input class="form-input" type="email" id="signin-email" placeholder="' + t.signInEmailPlaceholder + '" autocomplete="email" />' +
            '</div>' +

            '<div class="form-group">' +
              '<label class="form-label" for="signin-password">' + t.signInPasswordLabel + '</label>' +
              '<input class="form-input" type="password" id="signin-password" placeholder="' + t.signInPasswordPlaceholder + '" autocomplete="current-password" />' +
              '<span class="form-error-msg is-hidden" id="signin-error"></span>' +
            '</div>' +

            '<button class="btn btn-primary auth-submit-btn" id="signin-submit">' + t.signInSubmit + '</button>' +

            '<div class="auth-divider">' +
              '<span class="auth-divider-line"></span>' +
              '<span>' + t.orDivider + '</span>' +
              '<span class="auth-divider-line"></span>' +
            '</div>' +

            '<button class="auth-google-btn" id="signin-google">' +
              AuthModal._googleIcon() +
              t.googleSignIn +
            '</button>' +

            '</div>' +

          /* ── Sign Up Panel ── */
          '<div class="auth-panel" id="auth-panel-signup" role="tabpanel" aria-labelledby="auth-tab-signup">' +

            '<div class="form-group">' +
              '<label class="form-label" for="signup-name">' + t.signUpNameLabel + '</label>' +
              '<input class="form-input" type="text" id="signup-name" placeholder="' + t.signUpNamePlaceholder + '" autocomplete="name" />' +
              '<span class="form-error-msg is-hidden" id="signup-e-name"></span>' +
            '</div>' +

            '<div class="form-group">' +
              '<label class="form-label" for="signup-email">' + t.signUpEmailLabel + '</label>' +
              '<input class="form-input" type="email" id="signup-email" placeholder="' + t.signUpEmailPlaceholder + '" autocomplete="email" />' +
              '<span class="form-error-msg is-hidden" id="signup-e-email"></span>' +
            '</div>' +

            '<div class="form-group">' +
              '<label class="form-label" for="signup-password">' + t.signUpPasswordLabel + '</label>' +
              '<input class="form-input" type="password" id="signup-password" placeholder="' + t.signUpPasswordPlaceholder + '" autocomplete="new-password" />' +
              '<span class="form-error-msg is-hidden" id="signup-e-password"></span>' +
            '</div>' +

            '<div class="form-group">' +
              '<label class="form-label" for="signup-role">' + t.signUpRoleLabel + '</label>' +
              '<select class="form-select" id="signup-role">' +
                '<option value="">Rolle wählen…</option>' +
                '<option value="teacher">' + t.signUpRoleTeacher + '</option>' +
                '<option value="student">' + t.signUpRoleStudent + '</option>' +
              '</select>' +
              '<span class="form-error-msg is-hidden" id="signup-e-role"></span>' +
            '</div>' +

            '<div class="form-group is-hidden" id="signup-discipline-group">' +
              '<label class="form-label" for="signup-discipline">' + t.signUpDisciplineLabel + '</label>' +
              '<select class="form-select" id="signup-discipline">' +
                '<option value="">Keine Angabe</option>' +
                '<option value="ski">Ski-Instruktor</option>' +
                '<option value="paragliding">Paragliding-Instruktor</option>' +
                '<option value="diving">Tauch-Instruktor</option>' +
                '<option value="tourguide">Reiseführer</option>' +
              '</select>' +
              '<span class="form-hint">' + t.signUpDisciplineHint + '</span>' +
            '</div>' +

            '<button class="btn btn-primary auth-submit-btn" id="signup-submit">' + t.signUpSubmit + '</button>' +

            '<div class="auth-divider">' +
              '<span class="auth-divider-line"></span>' +
              '<span>' + t.orDivider + '</span>' +
              '<span class="auth-divider-line"></span>' +
            '</div>' +

            '<button class="auth-google-btn" id="signup-google">' +
              AuthModal._googleIcon() +
              t.googleSignUp +
            '</button>' +

          '</div>' +

        '</div>' +
      '</div>';

    document.body.appendChild(overlay);
    self._overlay = overlay;
  },

  _googleIcon: function() {
    return '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">' +
      '<path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.615z" fill="#4285F4"/>' +
      '<path d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.258c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>' +
      '<path d="M3.964 10.707A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.707V4.961H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.039l3.007-2.332z" fill="#FBBC05"/>' +
      '<path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.961L3.964 7.293C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>' +
    '</svg>';
  },

  _bind: function() {
    var self = this;

    /* Close button */
    var closeBtn = document.getElementById('auth-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', function() { self.close(); });

    /* Overlay click outside */
    self._overlay.addEventListener('click', function(e) {
      if (e.target === self._overlay) self.close();
    });

    /* Escape key */
    document.addEventListener('keydown', function authEsc(e) {
      if (e.key === 'Escape') {
        self.close();
        document.removeEventListener('keydown', authEsc);
      }
    });

    /* Tab buttons */
    var tabSignIn = document.getElementById('auth-tab-signin');
    var tabSignUp = document.getElementById('auth-tab-signup');

    if (tabSignIn) tabSignIn.addEventListener('click', function() { self._setTab('signin'); });
    if (tabSignUp) tabSignUp.addEventListener('click', function() { self._setTab('signup'); });

    /* ── Sign In: Email + Password ────────────────── */
    var signinSubmit = document.getElementById('signin-submit');
    if (signinSubmit) {
      signinSubmit.addEventListener('click', function() {
        self._clearSigninError();
        var email = (document.getElementById('signin-email').value || '').trim();
        var pw    = (document.getElementById('signin-password').value || '');
        if (!email) { self._showSigninError(LandingI18n.errorEmptyEmail); return; }
        if (!pw)    { self._showSigninError(LandingI18n.errorEmptyPassword); return; }
        try {
          Auth.loginByEmail(email, pw);
        } catch(e) {
          self._showSigninError(e.message);
        }
      });
    }

    var signinPassword = document.getElementById('signin-password');
    if (signinPassword) {
      signinPassword.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') { signinSubmit && signinSubmit.click(); }
      });
    }

    /* ── Sign In: Google Mock ─────────────────────── */
    var signinGoogle = document.getElementById('signin-google');
    if (signinGoogle) {
      signinGoogle.addEventListener('click', function() {
        self.close();
        _openGooglePicker();
      });
    }

    /* ── Sign Up: role→discipline toggle ─────────────── */
    var signupRole = document.getElementById('signup-role');
    if (signupRole) {
      signupRole.addEventListener('change', function() {
        var grp = document.getElementById('signup-discipline-group');
        if (grp) grp.classList.toggle('is-hidden', this.value !== 'teacher');
        if (this.value !== 'teacher') {
          var disc = document.getElementById('signup-discipline');
          if (disc) disc.value = '';
        }
      });
    }

    /* ── Sign Up: real account creation ──────────────── */
    var signupSubmit = document.getElementById('signup-submit');
    if (signupSubmit) {
      signupSubmit.addEventListener('click', function() {
        self._clearSignupErrors();

        var name       = (document.getElementById('signup-name').value || '').trim();
        var email      = (document.getElementById('signup-email').value || '').trim().toLowerCase();
        var pw         = (document.getElementById('signup-password').value || '');
        var role       = (document.getElementById('signup-role').value || '');
        var discipline = role === 'teacher'
          ? (document.getElementById('signup-discipline').value || '')
          : '';

        var valid = true;
        if (!name)       { self._showSignupError('signup-e-name',     LandingI18n.errorEmptyName);     valid = false; }
        if (!email)      { self._showSignupError('signup-e-email',    LandingI18n.errorEmptyEmail);    valid = false; }
        if (pw.length < 6) { self._showSignupError('signup-e-password', LandingI18n.errorWeakPassword);  valid = false; }
        if (!role)       { self._showSignupError('signup-e-role',     LandingI18n.errorEmptyRole);     valid = false; }
        if (!valid) return;

        /* Check email not already used */
        var existingUsers = Store.Users.all();
        for (var i = 0; i < existingUsers.length; i++) {
          if ((existingUsers[i].email || '').toLowerCase() === email) {
            self._showSignupError('signup-e-email', LandingI18n.errorEmailExists);
            return;
          }
        }

        try {
          var newUser = Store.Users.create({
            name:       name,
            email:      email,
            password:   pw,
            role:       role,
            discipline: discipline
          });
          self.close();
          var msg = role === 'teacher'
            ? LandingI18n.signUpSuccessTeacher
            : LandingI18n.signUpSuccessStudent;
          Toast.show(msg, 'success');

          /* Redirect */
          var target = role === 'teacher'
            ? './profile-edit.html?uid=' + encodeURIComponent(newUser.uid)
            : './student.html?uid='      + encodeURIComponent(newUser.uid);
          setTimeout(function() { window.location.href = target; }, 800);
        } catch(e) {
          self._showSignupError('signup-e-name', e.message);
        }
      });
    }

    var signupGoogle = document.getElementById('signup-google');
    if (signupGoogle) {
      signupGoogle.addEventListener('click', function() {
        self.close();
        _openGooglePicker();
      });
    }
  },

  _showSigninError: function(msg) {
    var el = document.getElementById('signin-error');
    if (el) { el.textContent = msg; el.classList.remove('is-hidden'); }
  },
  _clearSigninError: function() {
    var el = document.getElementById('signin-error');
    if (el) { el.textContent = ''; el.classList.add('is-hidden'); }
  },
  _showSignupError: function(id, msg) {
    var el = document.getElementById(id);
    if (el) { el.textContent = msg; el.classList.remove('is-hidden'); }
  },
  _clearSignupErrors: function() {
    var ids = ['signup-e-name', 'signup-e-email', 'signup-e-password', 'signup-e-role'];
    for (var i = 0; i < ids.length; i++) {
      var el = document.getElementById(ids[i]);
      if (el) { el.textContent = ''; el.classList.add('is-hidden'); }
    }
  },

  _setTab: function(tab) {
    var self = this;
    self._activeTab = tab;

    var tabSignIn  = document.getElementById('auth-tab-signin');
    var tabSignUp  = document.getElementById('auth-tab-signup');
    var panelSignIn = document.getElementById('auth-panel-signin');
    var panelSignUp = document.getElementById('auth-panel-signup');

    if (!tabSignIn || !tabSignUp) return;

    if (tab === 'signin') {
      tabSignIn.classList.add('active');
      tabSignIn.setAttribute('aria-selected', 'true');
      tabSignUp.classList.remove('active');
      tabSignUp.setAttribute('aria-selected', 'false');
      if (panelSignIn) panelSignIn.classList.add('is-active');
      if (panelSignUp) panelSignUp.classList.remove('is-active');
    } else {
      tabSignUp.classList.add('active');
      tabSignUp.setAttribute('aria-selected', 'true');
      tabSignIn.classList.remove('active');
      tabSignIn.setAttribute('aria-selected', 'false');
      if (panelSignUp) panelSignUp.classList.add('is-active');
      if (panelSignIn) panelSignIn.classList.remove('is-active');
    }
  }
};

/* ══════════════════════════════════════════════════════════
   Landing Page Init — only called from landing.html
   AuthModal bleibt global verfügbar für andere Seiten.
══════════════════════════════════════════════════════════ */
var LandingPage = {
  init: function() {
    /* Navbar — kein Auth-Guard, public page */
    Navbar.init('landing', {
      loginBtn: {
        label:   LandingI18n.navLoginBtn,
        onClick: function() { AuthModal.open('signin'); }
      }
    });

  /* Hero CTA */
  var heroCta = document.getElementById('hero-cta-signin');
  if (heroCta) {
    heroCta.addEventListener('click', function() {
      AuthModal.open('signin');
    });
  }

  /* Instructor CTA → SignUp */
  var instructorCta = document.getElementById('instructor-cta');
  if (instructorCta) {
    instructorCta.addEventListener('click', function() {
      AuthModal.open('signup', 'Registriere dich als Instruktor und erstelle dein Lehrerprofil.');
    });
  }

  /* Skiing card → skiing.html */
    var skiCard = document.getElementById('sport-skiing');
    if (skiCard) {
      skiCard.addEventListener('click', function() {
        window.location.href = './skiing.html';
      });

      /* Keyboard support */
      skiCard.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          window.location.href = './skiing.html';
        }
      });
    }

    /* Scroll-to-top button */
    var jumper = document.getElementById('section-jumper');
    var topBtn = document.getElementById('jump-top');

    function _updateLandingScrollBtn() {
      var navH = (document.querySelector('.navbar') || {}).offsetHeight || 52;
      var scrolled = window.scrollY > navH;
      if (jumper) jumper.classList.toggle('is-visible', scrolled);
      if (topBtn) topBtn.classList.toggle('is-hidden-top', !scrolled);
    }

    if (topBtn) {
      topBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }

    window.addEventListener('scroll', _updateLandingScrollBtn);
    _updateLandingScrollBtn();
  }
};


/* ══════════════════════════════════════════════════════════
   Google Account Picker (Landing)
══════════════════════════════════════════════════════════ */
function _openGooglePicker() {
  /* Remove any existing picker */
  var old = document.getElementById('landing-google-picker-overlay');
  if (old) old.remove();

  var accounts = Auth.googleAccounts();

  var overlay = document.createElement('div');
  overlay.id        = 'landing-google-picker-overlay';
  overlay.className = 'google-picker-overlay';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-label', 'Konto wählen');

  var listHTML = '';
  if (!accounts.length) {
    listHTML = '<div class="google-picker-empty">Keine Konten mit E-Mail-Adresse vorhanden.<br>Bitte erst im Admin-Bereich E-Mail-Adressen setzen.</div>';
  } else {
    for (var i = 0; i < accounts.length; i++) {
      var u       = accounts[i];
      var initial = (u.name || u.uid).charAt(0).toUpperCase();
      var roleLabel = u.role === 'teacher' ? 'Lehrer' : 'Schüler';
      listHTML +=
        '<button class="google-picker-item" data-uid="' + _escAttr(u.uid) + '" type="button">' +
          '<span class="google-picker-avatar">' + initial + '</span>' +
          '<span class="google-picker-info">' +
            '<span class="google-picker-name">' + _escHtml(u.name || u.uid) + '</span>' +
            '<span class="google-picker-email">' + _escHtml(u.email) + '</span>' +
          '</span>' +
          '<span class="google-picker-role">' + roleLabel + '</span>' +
        '</button>';
    }
  }

  overlay.innerHTML =
    '<div class="google-picker">' +
      '<div class="google-picker-header">' +
        '<div class="google-picker-logo">' +
          '<svg viewBox="0 0 24 24" width="22" height="22">' +
            '<path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>' +
            '<path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>' +
            '<path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>' +
            '<path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>' +
          '</svg>' +
        '</div>' +
        '<div>' +
          '<div class="google-picker-title">Konto wählen</div>' +
          '<div class="google-picker-sub">Weiter zu BookingSystem</div>' +
        '</div>' +
        '<button class="google-picker-close" id="landing-picker-close" aria-label="Schließen">' +
          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none">' +
            '<path d="M3 3l10 10M13 3L3 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
          '</svg>' +
        '</button>' +
      '</div>' +
      '<div class="google-picker-list">' + listHTML + '</div>' +
      '<div class="google-picker-footer">' +
        '<span class="google-picker-hint">Mock-Login — kein echtes Google-Konto</span>' +
      '</div>' +
    '</div>';

  document.body.appendChild(overlay);

  /* Close handlers */
  document.getElementById('landing-picker-close').addEventListener('click', function() {
    overlay.remove();
  });
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) overlay.remove();
  });

  /* Account click */
  var items = overlay.querySelectorAll('.google-picker-item');
  for (var j = 0; j < items.length; j++) {
    (function(item) {
      item.addEventListener('click', function() {
        overlay.remove();
        Auth.loginByGoogle(item.getAttribute('data-uid'));
      });
    })(items[j]);
  }
}

function _escHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function _escAttr(str) {
  return String(str || '').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

window.AuthModal  = AuthModal;
window.LandingPage = LandingPage;
