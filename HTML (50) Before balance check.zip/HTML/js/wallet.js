/* ── wallet.js ───────────────────────────────────────────────────
   Consumer für die Wallet-Seite.
   Kommuniziert ausschliesslich über AppService.
   i18n Namespace: wallet
──────────────────────────────────────────────────────────── */

(function () {
  'use strict';

  /* ── i18n ────────────────────────────────────────────────── */
  var _i18n = {};

  function _t(key, vars) {
    var str = _i18n[key] || key;
    if (vars) {
      for (var k in vars) {
        str = str.replace('{' + k + '}', vars[k]);
      }
    }
    return str;
  }

  function _loadI18n(callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', './locales/wallet.json');
    xhr.onload = function () {
      try {
        _i18n = JSON.parse(xhr.responseText);
      } catch (e) {
        _showError('i18n (wallet.json konnte nicht geladen werden)', e);
      }
      callback();
    };
    xhr.onerror = function () {
      _showError('i18n', new Error('Netzwerkfehler beim Laden von wallet.json'));
      callback();
    };
    xhr.send();
  }

  function _applyI18n() {
    var els = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < els.length; i++) {
      var key = els[i].getAttribute('data-i18n');
      if (_i18n[key]) els[i].textContent = _i18n[key];
    }
    var phEls = document.querySelectorAll('[data-i18n-placeholder]');
    for (var j = 0; j < phEls.length; j++) {
      var phKey = phEls[j].getAttribute('data-i18n-placeholder');
      if (_i18n[phKey]) phEls[j].setAttribute('placeholder', _i18n[phKey]);
    }
  }

  /* ── Fehler-Dialog ───────────────────────────────────────── */
  function _showError(context, err) {
    var msg = (err && err.message) ? err.message : String(err);
    console.error('[Wallet][' + context + ']', err);
    /* Toast via UI wenn vorhanden, sonst eigenes Element */
    var shown = false;
    if (typeof UI !== 'undefined' && typeof UI.showToast === 'function') {
      try { UI.showToast(context + ': ' + msg, 'error'); shown = true; } catch(e) {}
    }
    if (!shown) {
      var container = document.getElementById('wallet-page') || document.body;
      var existing  = document.getElementById('wallet-inline-error');
      if (existing) existing.remove();
      var div = document.createElement('div');
      div.id = 'wallet-inline-error';
      div.className = 'wallet-inline-error';
      div.textContent = context + ': ' + msg;
      container.insertBefore(div, container.firstChild);
      setTimeout(function() { if (div.parentNode) div.remove(); }, 6000);
    }
  }

  /* ── Auth / UID ──────────────────────────────────────────── */
  function _currentUid() {
    try {
      /* Auth.current() liest UID aus URL-Parameter ?uid=xxx */
      if (typeof Auth !== 'undefined' && typeof Auth.current === 'function') {
        var user = Auth.current();
        if (user && user.uid) return user.uid;
      }
    } catch (e) {
      _showError('_currentUid', e);
    }
    return null;
  }

  /* ── State ───────────────────────────────────────────────── */
  var _wallet = null;
  var _pendingWithdrawAmount  = 0;
  var _pendingWithdrawDesc    = '';

  /* ── Formatierung ────────────────────────────────────────── */
  function _formatAmount(amount) {
    var n = parseFloat(amount);
    if (isNaN(n)) return '0,00';
    return n.toFixed(2).replace('.', ',');
  }

  function _formatDate(iso) {
    try {
      var d = new Date(iso);
      return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
             ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch (e) { return iso || ''; }
  }

  /* ── Balance rendern ─────────────────────────────────────── */
  function _renderBalance(wallet) {
    var el = document.getElementById('wallet-balance-amount');
    if (!el) return;
    el.textContent = _formatAmount(wallet ? wallet.balance : 0);
  }

  /* ── Transaktion-Icon ────────────────────────────────────── */
  var _TX_ICONS = {
    deposit:        '↑',
    withdrawal:     '↓',
    refund:         '↩',
    escrow_hold:    '⏸',
    escrow_release: '▶',
    transfer:       '⇄'
  };

  /* ── Transaktionshistorie rendern ────────────────────────── */
  function _renderHistory(txs) {
    var list  = document.getElementById('wallet-tx-list');
    var empty = document.getElementById('wallet-tx-empty');
    if (!list) return;

    /* Alte Einträge entfernen (ausser empty-Placeholder) */
    var items = list.querySelectorAll('.wallet-tx-item');
    for (var i = 0; i < items.length; i++) { items[i].remove(); }

    if (!txs || txs.length === 0) {
      if (empty) empty.classList.remove('is-hidden');
      return;
    }
    if (empty) empty.classList.add('is-hidden');

    for (var j = 0; j < txs.length; j++) {
      var tx   = txs[j];
      var item = _buildTxItem(tx);
      list.appendChild(item);
    }
  }

  function _buildTxItem(tx) {
    var li = document.createElement('li');
    li.className = 'wallet-tx-item';

    var txType   = tx.type   || 'deposit';
    var txStatus = tx.status || 'completed';

    var typeKey    = 'txType'   + txType.charAt(0).toUpperCase()   + txType.slice(1).replace('_hold','Hold').replace('_release','Release');
    var statusKey  = 'txStatus' + txStatus.charAt(0).toUpperCase() + txStatus.slice(1);
    var typeLabel   = (_i18n[typeKey]   || txType);
    var statusLabel = (_i18n[statusKey] || txStatus);

    var isPositive = (tx.amount || 0) >= 0;
    var amountStr  = (isPositive ? '+' : '') + _formatAmount(tx.amount || 0) + ' €';
    var balanceStr = _formatAmount(tx.balance || 0) + ' €';
    var icon       = _TX_ICONS[txType] || '·';

    li.innerHTML =
      '<div class="wallet-tx-icon ' + tx.type + '" aria-hidden="true">' + icon + '</div>' +
      '<div class="wallet-tx-info">' +
        '<div class="wallet-tx-type">' + _escHtml(typeLabel) + '</div>' +
        (tx.description ? '<div class="wallet-tx-desc">' + _escHtml(tx.description) + '</div>' : '') +
      '</div>' +
      '<div>' +
        '<div class="wallet-tx-date">' + _formatDate(tx.createdAt) + '</div>' +
        '<div class="wallet-tx-balance">' + _escHtml(balanceStr) + '</div>' +
      '</div>' +
      '<div>' +
        '<div class="wallet-tx-amount ' + (isPositive ? 'positive' : 'negative') + '">' + _escHtml(amountStr) + '</div>' +
        '<div style="text-align:right"><span class="wallet-tx-status ' + (tx.status || 'completed') + '">' + _escHtml(statusLabel) + '</span></div>' +
      '</div>';

    return li;
  }

  function _escHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ── Wallet laden ────────────────────────────────────────── */
  function _loadWallet() {
    var uid = _currentUid();
    if (!uid) {
      _showError(_t('errorLoadWallet'), new Error('Nicht angemeldet.'));
      return;
    }

    AppService.getWallet(uid, function (err, wallet) {
      if (err) { _showError(_t('errorLoadWallet'), err); return; }
      _wallet = wallet;
      _renderBalance(_wallet);
    });

    AppService.getTransactions(uid, function (err, txs) {
      if (err) { _showError(_t('historyLoadError'), err); return; }
      _renderHistory(txs);
    });
  }

  /* ── Validierung ─────────────────────────────────────────── */
  function _validateAmount(inputId, errorId) {
    var input = document.getElementById(inputId);
    var errEl = document.getElementById(errorId);
    var val   = input ? parseFloat(input.value) : NaN;

    if (!input || !input.value.trim()) {
      if (errEl) { errEl.textContent = _t('errorAmountRequired'); errEl.classList.add('is-visible'); }
      return false;
    }
    if (isNaN(val) || val < 0.01) {
      if (errEl) { errEl.textContent = _t('errorAmountInvalid'); errEl.classList.add('is-visible'); }
      return false;
    }
    if (errEl) errEl.classList.remove('is-visible');
    return true;
  }

  function _clearError(errorId) {
    var el = document.getElementById(errorId);
    if (el) el.classList.remove('is-visible');
  }

  /* ── Einzahlen ───────────────────────────────────────────── */
  function _handleDeposit() {
    if (!_validateAmount('deposit-amount', 'deposit-amount-error')) return;

    var uid = _currentUid();
    if (!uid) { _showError('Einzahlen', new Error('Nicht angemeldet.')); return; }

    var amount = parseFloat(document.getElementById('deposit-amount').value);
    var desc   = document.getElementById('deposit-desc').value.trim();
    var btn    = document.getElementById('btn-deposit');

    if (btn) btn.disabled = true;

    AppService.deposit(uid, amount, desc, function (err, result) {
      if (btn) btn.disabled = false;
      if (err) {
        _showError(_t('errorDeposit'), err);
        return;
      }
      try {
        _wallet = result.wallet;
        _renderBalance(_wallet);
        var depInput = document.getElementById('deposit-amount');
        var descInput = document.getElementById('deposit-desc');
        if (depInput)  depInput.value  = '';
        if (descInput) descInput.value = '';
        _loadHistory();
      } catch (renderErr) {
        console.error('[Wallet] Render-Fehler nach Einzahlung:', renderErr);
      }
      if (typeof UI !== 'undefined' && UI.showToast) {
        UI.showToast(_t('successDeposit'), 'success');
      }
    });
  }

  /* ── Auszahlen — Confirm-Dialog ──────────────────────────── */
  function _handleWithdrawRequest() {
    if (!_validateAmount('withdraw-amount', 'withdraw-amount-error')) return;

    var amount = parseFloat(document.getElementById('withdraw-amount').value);

    if (_wallet && amount > _wallet.balance) {
      var errEl = document.getElementById('withdraw-amount-error');
      if (errEl) { errEl.textContent = _t('errorInsufficientFunds'); errEl.classList.add('is-visible'); }
      return;
    }

    _pendingWithdrawAmount = amount;
    _pendingWithdrawDesc   = document.getElementById('withdraw-desc').value.trim();

    var text = _t('confirmWithdraw', { amount: _formatAmount(amount) });
    var el   = document.getElementById('wallet-confirm-text');
    if (el) el.textContent = text;

    _openConfirm();
  }

  function _handleWithdrawConfirm() {
    _closeConfirm();

    var uid = _currentUid();
    if (!uid) { _showError('Auszahlen', new Error('Nicht angemeldet.')); return; }

    var btn = document.getElementById('btn-withdraw');
    if (btn) btn.disabled = true;

    AppService.withdraw(uid, _pendingWithdrawAmount, _pendingWithdrawDesc, function (err, result) {
      if (btn) btn.disabled = false;
      if (err) {
        _showError(_t('errorWithdraw'), err);
        return;
      }
      try {
        _wallet = result.wallet;
        _renderBalance(_wallet);
        var wdInput = document.getElementById('withdraw-amount');
        var wdDesc  = document.getElementById('withdraw-desc');
        if (wdInput) wdInput.value = '';
        if (wdDesc)  wdDesc.value  = '';
        _loadHistory();
      } catch (renderErr) {
        console.error('[Wallet] Render-Fehler nach Auszahlung:', renderErr);
      }
      if (typeof UI !== 'undefined' && UI.showToast) {
        UI.showToast(_t('successWithdraw'), 'success');
      }
    });
  }

  /* ── Transaktionshistorie separat nachladen ──────────────── */
  function _loadHistory() {
    var uid = _currentUid();
    if (!uid) return;
    AppService.getTransactions(uid, function (err, txs) {
      if (err) { _showError(_t('historyLoadError'), err); return; }
      _renderHistory(txs);
    });
  }

  /* ── Confirm-Dialog ──────────────────────────────────────── */
  function _openConfirm() {
    var overlay = document.getElementById('wallet-confirm-overlay');
    if (!overlay) return;
    overlay.classList.add('is-open');
    overlay.setAttribute('aria-hidden', 'false');
    document.body.classList.add('overlay-open');
    var okBtn = document.getElementById('wallet-confirm-ok');
    if (okBtn) okBtn.focus();
  }

  function _closeConfirm() {
    var overlay = document.getElementById('wallet-confirm-overlay');
    if (!overlay) return;
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('overlay-open');
  }

  /* ── Event Binding ───────────────────────────────────────── */
  function _bindEvents() {
    var btnDeposit = document.getElementById('btn-deposit');
    if (btnDeposit) btnDeposit.addEventListener('click', _handleDeposit);

    var btnWithdraw = document.getElementById('btn-withdraw');
    if (btnWithdraw) btnWithdraw.addEventListener('click', _handleWithdrawRequest);

    var btnConfirmOk = document.getElementById('wallet-confirm-ok');
    if (btnConfirmOk) btnConfirmOk.addEventListener('click', _handleWithdrawConfirm);

    var btnConfirmCancel = document.getElementById('wallet-confirm-cancel');
    if (btnConfirmCancel) btnConfirmCancel.addEventListener('click', _closeConfirm);

    /* Overlay-Klick schließt Dialog */
    var overlay = document.getElementById('wallet-confirm-overlay');
    if (overlay) {
      overlay.addEventListener('click', function (e) {
        if (e.target === overlay) _closeConfirm();
      });
    }

    /* ESC schließt Dialog */
    document.addEventListener('keydown', function (e) {
      if ((e.key === 'Escape' || e.keyCode === 27)) _closeConfirm();
    });

    /* Error-Reset beim Tippen */
    var depositInput = document.getElementById('deposit-amount');
    if (depositInput) depositInput.addEventListener('input', function () { _clearError('deposit-amount-error'); });

    var withdrawInput = document.getElementById('withdraw-amount');
    if (withdrawInput) withdrawInput.addEventListener('input', function () { _clearError('withdraw-amount-error'); });
  }

  /* ── Init ────────────────────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', function () {
    /* Guard: UID aus URL prüfen */
    var user = (typeof Auth !== 'undefined' && typeof Auth.current === 'function') ? Auth.current() : null;
    if (!user) {
      window.location.href = './index.html';
      return;
    }
    /* Navbar injizieren — erkennt User-Rolle automatisch */
    if (typeof Navbar !== 'undefined') {
      Navbar.init('wallet');
    }
    _loadI18n(function () {
      _applyI18n();
      _bindEvents();
      _loadWallet();
    });
  });

}());
