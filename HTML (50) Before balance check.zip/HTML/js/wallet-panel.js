/* ── wallet-panel.js ─────────────────────────────────────────────
   Wiederverwendbares Wallet-Panel.
   Wird in teacher.html (#teacher-wallet-panel)
   und student.html (#student-wallet-panel) gemountet.

   API:
     WalletPanel.mount(containerId, uid)
     WalletPanel.refresh(uid)   — Kontostand neu laden

   i18n Namespace: wallet (gleiche JSON wie wallet.html)
──────────────────────────────────────────────────────────── */

var WalletPanel = (function () {
  'use strict';

  var _i18n       = {};
  var _i18nLoaded = false;
  var _uid        = null;
  var _wallet     = null;
  var _containerId = null;

  /* ── i18n ──────────────────────────────────────────────── */
  function _t(key, vars) {
    var str = _i18n[key] || key;
    if (vars) {
      for (var k in vars) { str = str.replace('{' + k + '}', vars[k]); }
    }
    return str;
  }

  function _loadI18n(callback) {
    if (_i18nLoaded) { callback(); return; }
    var xhr = new XMLHttpRequest();
    xhr.open('GET', './locales/wallet.json');
    xhr.onload = function () {
      try { _i18n = JSON.parse(xhr.responseText); } catch (e) { _showError('i18n', e); }
      _i18nLoaded = true;
      callback();
    };
    xhr.onerror = function () { _i18nLoaded = true; callback(); };
    xhr.send();
  }

  /* ── Fehlerbehandlung ──────────────────────────────────── */
  function _showError(context, err) {
    var msg = (err && err.message) ? err.message : String(err);
    console.error('[WalletPanel][' + context + ']', err);
    if (typeof UI !== 'undefined' && UI.showToast) {
      UI.showToast('[WalletPanel] ' + msg, 'error');
    }
  }

  /* ── Formatierung ──────────────────────────────────────── */
  function _fmt(amount) {
    var n = parseFloat(amount);
    return isNaN(n) ? '0,00' : n.toFixed(2).replace('.', ',');
  }

  function _fmtDate(iso) {
    try {
      var d = new Date(iso);
      return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
             ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch (e) { return iso || ''; }
  }

  function _escHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ── HTML-Bausteine ────────────────────────────────────── */
  function _buildHTML() {
    var pfx = _containerId.replace(/-/g, '_');
    return (
      /* Mockup-Hinweis */
      '<div class="wallet-mockup-notice">' +
        '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M8 5v4M8 10.5v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>' +
        '<span>' + _t('mockupNote') + '</span>' +
      '</div>' +

      /* Kontostand */
      '<div class="wallet-balance-card" aria-live="polite">' +
        '<div>' +
          '<div class="wallet-balance-label">' + _t('balance') + '</div>' +
          '<div>' +
            '<span class="wallet-balance-amount" id="wp-balance-' + _containerId + '">—</span>' +
            '<span class="wallet-balance-currency"> ' + _t('currency') + '</span>' +
          '</div>' +
        '</div>' +
        '<div class="wallet-balance-icon" aria-hidden="true">' +
          '<svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="2" y="6" width="20" height="14" rx="2" stroke="currentColor" stroke-width="1.5"/><path d="M2 10h20" stroke="currentColor" stroke-width="1.5"/><circle cx="17" cy="15" r="1.5" fill="currentColor"/></svg>' +
        '</div>' +
      '</div>' +

      /* Ein-/Auszahlung */
      '<div class="wallet-grid">' +

        /* Einzahlen */
        '<div class="wallet-action-card">' +
          '<div class="wallet-action-title">' +
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="M9 3v12M4 8l5-5 5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            _t('sectionDeposit') +
          '</div>' +
          '<div class="wallet-form-stack">' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-dep-amt-' + _containerId + '">' + _t('labelAmount') + '</label>' +
              '<div class="wallet-amount-wrap">' +
                '<span class="wallet-amount-prefix" aria-hidden="true">€</span>' +
                '<input class="form-input wallet-amount-input" type="number" id="wp-dep-amt-' + _containerId + '" min="0.01" step="0.01" placeholder="' + _t('placeholderAmount') + '" autocomplete="off" />' +
              '</div>' +
              '<span class="wallet-field-error" id="wp-dep-err-' + _containerId + '" role="alert"></span>' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-dep-desc-' + _containerId + '">' + _t('labelDescription') + '</label>' +
              '<input class="form-input" type="text" id="wp-dep-desc-' + _containerId + '" placeholder="' + _t('placeholderDesc') + '" autocomplete="off" />' +
            '</div>' +
            '<button class="btn btn-primary" id="wp-dep-btn-' + _containerId + '" type="button">' +
              '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 2v12M3 7l5-5 5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
              _t('btnDeposit') +
            '</button>' +
          '</div>' +
        '</div>' +

        /* Auszahlen */
        '<div class="wallet-action-card">' +
          '<div class="wallet-action-title">' +
            '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true"><path d="M9 3v12M4 10l5 5 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            _t('sectionWithdraw') +
          '</div>' +
          '<div class="wallet-form-stack">' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-wd-amt-' + _containerId + '">' + _t('labelAmount') + '</label>' +
              '<div class="wallet-amount-wrap">' +
                '<span class="wallet-amount-prefix" aria-hidden="true">€</span>' +
                '<input class="form-input wallet-amount-input" type="number" id="wp-wd-amt-' + _containerId + '" min="0.01" step="0.01" placeholder="' + _t('placeholderAmount') + '" autocomplete="off" />' +
              '</div>' +
              '<span class="wallet-field-error" id="wp-wd-err-' + _containerId + '" role="alert"></span>' +
            '</div>' +
            '<div class="form-group">' +
              '<label class="form-label" for="wp-wd-desc-' + _containerId + '">' + _t('labelDescription') + '</label>' +
              '<input class="form-input" type="text" id="wp-wd-desc-' + _containerId + '" placeholder="' + _t('placeholderDesc') + '" autocomplete="off" />' +
            '</div>' +
            '<button class="btn btn-secondary" id="wp-wd-btn-' + _containerId + '" type="button">' +
              '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 2v12M3 9l5 5 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
              _t('btnWithdraw') +
            '</button>' +
          '</div>' +
        '</div>' +

      '</div>' + /* /wallet-grid */

      /* Transaktionshistorie */
      '<div class="wallet-history-card">' +
        '<div class="wallet-history-header">' +
          '<div class="wallet-history-title">' +
            '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/><path d="M8 5v3.5l2 1.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            _t('sectionHistory') +
          '</div>' +
        '</div>' +
        '<ul class="wallet-tx-list" id="wp-tx-list-' + _containerId + '" aria-live="polite">' +
          '<li class="wallet-history-empty" id="wp-tx-empty-' + _containerId + '">' + _t('historyEmpty') + '</li>' +
        '</ul>' +
      '</div>' +

      /* Confirm-Dialog */
      '<div class="wallet-confirm-overlay" id="wp-confirm-' + _containerId + '" role="dialog" aria-modal="true" aria-hidden="true">' +
        '<div class="wallet-confirm-dialog">' +
          '<div class="wallet-confirm-title">' + _t('sectionWithdraw') + '</div>' +
          '<div class="wallet-confirm-text" id="wp-confirm-text-' + _containerId + '"></div>' +
          '<div class="wallet-confirm-actions">' +
            '<button class="btn btn-secondary" id="wp-confirm-cancel-' + _containerId + '" type="button">' + _t('confirmCancelBtn') + '</button>' +
            '<button class="btn btn-primary" id="wp-confirm-ok-' + _containerId + '" type="button">' + _t('confirmWithdrawBtn') + '</button>' +
          '</div>' +
        '</div>' +
      '</div>'
    );
  }

  /* ── Balance rendern ────────────────────────────────────── */
  function _renderBalance(wallet) {
    var el = document.getElementById('wp-balance-' + _containerId);
    if (el) el.textContent = _fmt(wallet ? wallet.balance : 0);
    /* Navbar-Badge synchronisieren */
    var badge = document.getElementById('navbar-wallet-amount');
    if (badge && wallet) badge.textContent = _fmt(wallet.balance) + ' €';
  }

  /* ── Transaktionshistorie ───────────────────────────────── */
  var _TX_ICONS = {
    deposit: '↑', withdrawal: '↓', refund: '↩',
    escrow_hold: '⏸', escrow_release: '▶', transfer: '⇄'
  };

  function _renderHistory(txs) {
    var list  = document.getElementById('wp-tx-list-' + _containerId);
    var empty = document.getElementById('wp-tx-empty-' + _containerId);
    if (!list) return;

    var items = list.querySelectorAll('.wallet-tx-item');
    for (var i = 0; i < items.length; i++) { items[i].remove(); }

    if (!txs || txs.length === 0) {
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';

    for (var j = 0; j < txs.length; j++) {
      list.appendChild(_buildTxItem(txs[j]));
    }
  }

  function _buildTxItem(tx) {
    var li        = document.createElement('li');
    li.className  = 'wallet-tx-item';

    var txType   = tx.type   || 'deposit';
    var txStatus = tx.status || 'completed';

    var typeKey    = 'txType'   + txType.charAt(0).toUpperCase()   + txType.slice(1).replace('_hold','Hold').replace('_release','Release');
    var statusKey  = 'txStatus' + txStatus.charAt(0).toUpperCase() + txStatus.slice(1);
    var typeLabel   = (_i18n[typeKey]   || txType);
    var statusLabel = (_i18n[statusKey] || txStatus);

    var isPos  = (tx.amount || 0) >= 0;
    var icon   = _TX_ICONS[txType] || '·';

    li.innerHTML =
      '<div class="wallet-tx-icon ' + tx.type + '" aria-hidden="true">' + icon + '</div>' +
      '<div class="wallet-tx-info">' +
        '<div class="wallet-tx-type">' + _escHtml(typeLabel) + '</div>' +
        (tx.description ? '<div class="wallet-tx-desc">' + _escHtml(tx.description) + '</div>' : '') +
      '</div>' +
      '<div>' +
        '<div class="wallet-tx-date">' + _fmtDate(tx.createdAt) + '</div>' +
        '<div class="wallet-tx-balance">' + _escHtml(_fmt(tx.balance || 0) + ' €') + '</div>' +
      '</div>' +
      '<div>' +
        '<div class="wallet-tx-amount ' + (isPos ? 'positive' : 'negative') + '">' +
          _escHtml((isPos ? '+' : '') + _fmt(tx.amount || 0) + ' €') +
        '</div>' +
        '<div style="text-align:right"><span class="wallet-tx-status ' + (tx.status || 'completed') + '">' + _escHtml(statusLabel) + '</span></div>' +
      '</div>';
    return li;
  }

  /* ── Daten laden ────────────────────────────────────────── */
  function _loadData() {
    AppService.getWallet(_uid, function (err, wallet) {
      if (err) { _showError(_t('errorLoadWallet'), err); return; }
      _wallet = wallet;
      _renderBalance(_wallet);
    });
    AppService.getTransactions(_uid, function (err, txs) {
      if (err) { _showError(_t('historyLoadError'), err); return; }
      _renderHistory(txs);
    });
  }

  /* ── Validierung ────────────────────────────────────────── */
  function _validate(amtId, errId) {
    var input = document.getElementById(amtId);
    var errEl = document.getElementById(errId);
    var val   = input ? parseFloat(input.value) : NaN;
    if (!input || !input.value.trim()) {
      if (errEl) { errEl.textContent = _t('errorAmountRequired'); errEl.classList.add('is-visible'); }
      return false;
    }
    if (isNaN(val) || val < 0.01) {
      if (errEl) { errEl.textContent = _t('errorAmountInvalid'); errEl.classList.add('is-visible'); }
      return false;
    }
    if (errEl) errEl.classList.remove('is-visible');
    return true;
  }

  function _clearErr(errId) {
    var el = document.getElementById(errId);
    if (el) el.classList.remove('is-visible');
  }

  /* ── Einzahlen ──────────────────────────────────────────── */
  function _doDeposit() {
    var amtId  = 'wp-dep-amt-' + _containerId;
    var errId  = 'wp-dep-err-' + _containerId;
    var descId = 'wp-dep-desc-' + _containerId;
    var btnId  = 'wp-dep-btn-' + _containerId;

    if (!_validate(amtId, errId)) return;

    var amount = parseFloat(document.getElementById(amtId).value);
    var desc   = document.getElementById(descId).value.trim();
    var btn    = document.getElementById(btnId);
    if (btn) btn.disabled = true;

    AppService.deposit(_uid, amount, desc, function (err, result) {
      if (btn) btn.disabled = false;
      if (err) { _showError(_t('errorDeposit'), err); return; }
      _wallet = result.wallet;
      _renderBalance(_wallet);
      document.getElementById(amtId).value  = '';
      document.getElementById(descId).value = '';
      _loadHistory();
      if (typeof UI !== 'undefined' && UI.showToast) UI.showToast(_t('successDeposit'), 'success');
    });
  }

  /* ── Auszahlen ──────────────────────────────────────────── */
  var _pendingAmount = 0;
  var _pendingDesc   = '';

  function _requestWithdraw() {
    var amtId  = 'wp-wd-amt-' + _containerId;
    var errId  = 'wp-wd-err-' + _containerId;
    var descId = 'wp-wd-desc-' + _containerId;

    if (!_validate(amtId, errId)) return;

    var amount = parseFloat(document.getElementById(amtId).value);
    if (_wallet && amount > _wallet.balance) {
      var errEl = document.getElementById(errId);
      if (errEl) { errEl.textContent = _t('errorInsufficientFunds'); errEl.classList.add('is-visible'); }
      return;
    }

    _pendingAmount = amount;
    _pendingDesc   = document.getElementById(descId).value.trim();

    var textEl = document.getElementById('wp-confirm-text-' + _containerId);
    if (textEl) textEl.textContent = _t('confirmWithdraw', { amount: _fmt(amount) });
    _openConfirm();
  }

  function _doWithdraw() {
    _closeConfirm();
    var amtId  = 'wp-wd-amt-' + _containerId;
    var descId = 'wp-wd-desc-' + _containerId;
    var btnId  = 'wp-wd-btn-' + _containerId;
    var btn    = document.getElementById(btnId);
    if (btn) btn.disabled = true;

    AppService.withdraw(_uid, _pendingAmount, _pendingDesc, function (err, result) {
      if (btn) btn.disabled = false;
      if (err) { _showError(_t('errorWithdraw'), err); return; }
      _wallet = result.wallet;
      _renderBalance(_wallet);
      document.getElementById(amtId).value  = '';
      document.getElementById(descId).value = '';
      _loadHistory();
      if (typeof UI !== 'undefined' && UI.showToast) UI.showToast(_t('successWithdraw'), 'success');
    });
  }

  function _loadHistory() {
    AppService.getTransactions(_uid, function (err, txs) {
      if (err) { _showError(_t('historyLoadError'), err); return; }
      _renderHistory(txs);
    });
  }

  /* ── Confirm-Dialog ─────────────────────────────────────── */
  function _openConfirm() {
    var el = document.getElementById('wp-confirm-' + _containerId);
    if (!el) return;
    el.classList.add('is-open');
    el.setAttribute('aria-hidden', 'false');
    document.body.classList.add('overlay-open');
  }

  function _closeConfirm() {
    var el = document.getElementById('wp-confirm-' + _containerId);
    if (!el) return;
    el.classList.remove('is-open');
    el.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('overlay-open');
  }

  /* ── Events binden ──────────────────────────────────────── */
  function _bindEvents() {
    var depBtn = document.getElementById('wp-dep-btn-' + _containerId);
    if (depBtn) depBtn.addEventListener('click', _doDeposit);

    var wdBtn = document.getElementById('wp-wd-btn-' + _containerId);
    if (wdBtn) wdBtn.addEventListener('click', _requestWithdraw);

    var okBtn = document.getElementById('wp-confirm-ok-' + _containerId);
    if (okBtn) okBtn.addEventListener('click', _doWithdraw);

    var cancelBtn = document.getElementById('wp-confirm-cancel-' + _containerId);
    if (cancelBtn) cancelBtn.addEventListener('click', _closeConfirm);

    var overlay = document.getElementById('wp-confirm-' + _containerId);
    if (overlay) {
      overlay.addEventListener('click', function (e) { if (e.target === overlay) _closeConfirm(); });
    }

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' || e.keyCode === 27) _closeConfirm();
    });

    var depAmt = document.getElementById('wp-dep-amt-' + _containerId);
    if (depAmt) depAmt.addEventListener('input', function () { _clearErr('wp-dep-err-' + _containerId); });

    var wdAmt = document.getElementById('wp-wd-amt-' + _containerId);
    if (wdAmt) wdAmt.addEventListener('input', function () { _clearErr('wp-wd-err-' + _containerId); });
  }

  /* ── Öffentliche API ────────────────────────────────────── */

  /**
   * Panel in Container mounten.
   * @param {string} containerId  ID des Container-Elements
   * @param {string} uid          User-UID
   */
  function mount(containerId, uid) {
    _containerId = containerId;
    _uid         = uid;

    var container = document.getElementById(containerId);
    if (!container) {
      console.error('[WalletPanel] Container nicht gefunden:', containerId);
      return;
    }

    _loadI18n(function () {
      container.innerHTML = _buildHTML();
      _bindEvents();
      _loadData();
    });
  }

  /**
   * Kontostand neu laden (z.B. nach externer Änderung).
   * @param {string} uid
   */
  function refresh(uid) {
    if (uid) _uid = uid;
    if (_uid) _loadData();
  }

  return {
    mount:   mount,
    refresh: refresh
  };

}());

window.WalletPanel = WalletPanel;
