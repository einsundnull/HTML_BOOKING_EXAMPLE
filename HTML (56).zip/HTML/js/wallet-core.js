/* ── wallet-core.js ───────────────────────────────────────────────
   Gemeinsamer Kern für wallet.js (Standalone-Seite) und
   wallet-panel.js (eingebettetes Panel in teacher/student).

   Stellt bereit:
     WalletCore.createInstance(opts) → Instanz mit allen Shared-Methoden

   Kein direkter DOM-Zugriff hier — alle Element-IDs werden über
   opts.ids(key) vom Aufrufer geliefert (Strategy-Pattern).
   Damit können beide Consumer ihre eigene ID-Namensgebung behalten.

   Architektur-Regel lt. Guideline_Architecture.txt:
   Consumer-Code darf NIEMALS direkt auf Store.* zugreifen.
   Alles läuft über AppService.*(callback).
──────────────────────────────────────────────────────────────── */

var WalletCore = (function () {
  'use strict';

  /* ── Shared TX-Icons ────────────────────────────────────── */
  var TX_ICONS = {
    deposit:          '↑',
    withdrawal:       '↓',
    refund:           '↩',
    cancellation:     '✕',
    escrow_hold:      '⏸',
    escrow_release:   '▶',
    transfer:         '⇄',
    booking:          '✓',
    move:             '↔',
    teacher_cancel:   '✕',
    lesson_confirmed: '★'
  };

  /* ── TX-Typ → i18n key ──────────────────────────────────── */
  function _txTypeKey(txType) {
    /* Convert snake_case to CamelCase suffix: teacher_cancel → TeacherCancel */
    var camel = txType.replace(/_([a-z])/g, function(m, c) { return c.toUpperCase(); });
    return 'txType' + camel.charAt(0).toUpperCase() + camel.slice(1);
  }

  /* ── Shared i18n-Loader ─────────────────────────────────── */
  var _sharedI18n       = {};
  var _sharedI18nLoaded = false;
  var _pendingCallbacks = [];

  function loadI18n(callback) {
    if (_sharedI18nLoaded) { callback(_sharedI18n); return; }
    _pendingCallbacks.push(callback);
    if (_pendingCallbacks.length > 1) return; /* bereits lädt */
    var xhr = new XMLHttpRequest();
    xhr.open('GET', './locales/wallet.json');
    xhr.onload = function () {
      try { _sharedI18n = JSON.parse(xhr.responseText); } catch (e) {
        console.error('[WalletCore] wallet.json parse error', e);
      }
      _sharedI18nLoaded = true;
      for (var i = 0; i < _pendingCallbacks.length; i++) {
        _pendingCallbacks[i](_sharedI18n);
      }
      _pendingCallbacks = [];
    };
    xhr.onerror = function () {
      _sharedI18nLoaded = true;
      for (var i = 0; i < _pendingCallbacks.length; i++) {
        _pendingCallbacks[i](_sharedI18n);
      }
      _pendingCallbacks = [];
    };
    xhr.send();
  }

  /* ── Shared Formatierung ────────────────────────────────── */
  function formatAmount(amount) {
    var n = parseFloat(amount);
    return isNaN(n) ? '0,00' : n.toFixed(2).replace('.', ',');
  }

  function formatDate(iso) {
    try {
      var d = new Date(iso);
      return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' }) +
             ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch (e) { return iso || ''; }
  }

  function escHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /* ── Shared TX-Item-Builder ─────────────────────────────── */
  function buildTxItem(tx, i18n) {
    var li       = document.createElement('li');
    li.className = 'wallet-tx-item';

    var txType   = tx.type   || 'deposit';
    var txStatus = tx.status || 'completed';

    var typeLabel   = (i18n[_txTypeKey(txType)] || txType);
    var statusKey   = 'txStatus' + txStatus.charAt(0).toUpperCase() + txStatus.slice(1);
    var statusLabel = (i18n[statusKey] || txStatus);

    var isPositive = (tx.amount || 0) >= 0;
    var amountStr  = (isPositive ? '+' : '') + formatAmount(tx.amount || 0) + ' €';
    var balanceStr = formatAmount(tx.balance || 0) + ' €';
    var icon       = TX_ICONS[txType] || '·';

    /* Truncate description in list view */
    var descFull  = tx.description || '';
    var descShort = descFull.length > 55 ? descFull.slice(0, 53) + '…' : descFull;

    li.innerHTML =
      '<div class="wallet-tx-icon ' + txType + '" aria-hidden="true">' + icon + '</div>' +
      '<div class="wallet-tx-info">' +
        '<div class="wallet-tx-type">' + escHtml(typeLabel) + '</div>' +
        (descShort ? '<div class="wallet-tx-desc">' + escHtml(descShort) + '</div>' : '') +
        buildTxMetaLine(tx) +
      '</div>' +
      '<div>' +
        '<div class="wallet-tx-date">' + formatDate(tx.createdAt) + '</div>' +
        '<div class="wallet-tx-balance">' + escHtml(balanceStr) + '</div>' +
      '</div>' +
      '<div>' +
        '<div class="wallet-tx-amount ' + (isPositive ? 'positive' : 'negative') + '">' + escHtml(amountStr) + '</div>' +
        '<div style="text-align:right"><span class="wallet-tx-status ' + txStatus + '">' + escHtml(statusLabel) + '</span></div>' +
      '</div>';

    /* Click → open detail sheet */
    li.style.cursor = 'pointer';
    li.addEventListener('click', function() {
      _showTxDetail(tx, i18n);
    });

    return li;
  }

  /* ── Shared TX-Meta-Zeile ───────────────────────────────── */
  function buildTxMetaLine(tx) {
    if (!tx.meta) return '';
    var m = tx.meta;
    var parts = [];

    if (m.slotDate) {
      var d = new Date(m.slotDate + 'T00:00:00');
      var dateLabel = d.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
      parts.push(dateLabel + (m.slotTime ? ' ' + m.slotTime : ''));
    }

    var counterpartId = (m.teacherId && m.teacherId !== tx.uid) ? m.teacherId
                      : (m.studentId && m.studentId !== tx.uid) ? m.studentId : null;
    if (counterpartId && typeof ProfileStore !== 'undefined') {
      var name = ProfileStore.getDisplayName(counterpartId);
      if (name) parts.push(name);
    }

    if (m.cancellationTier) {
      var tierLabels = {
        full_refund:    'Volle Rückerstattung',
        partial:        'Teilrückerstattung',
        forfeit:        'Kein Deposit zurück',
        teacher_cancel: 'Lehrer storniert'
      };
      parts.push(tierLabels[m.cancellationTier] || m.cancellationTier);
    }

    if (m.cancelledAt) {
      var cd = new Date(m.cancelledAt);
      parts.push('Storniert: ' + cd.toLocaleString('de-DE', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
      }));
    }

    if (!parts.length) return '';
    return '<div class="wallet-tx-meta">' + escHtml(parts.join(' · ')) + '</div>';
  }

  /* ── Shared Validierung ─────────────────────────────────── */
  function validateAmount(inputEl, errEl, i18n) {
    if (!inputEl || !inputEl.value.trim()) {
      if (errEl) { errEl.textContent = i18n['errorAmountRequired'] || 'Betrag erforderlich'; errEl.classList.add('is-visible'); }
      return false;
    }
    var val = parseFloat(inputEl.value);
    if (isNaN(val) || val < 0.01) {
      if (errEl) { errEl.textContent = i18n['errorAmountInvalid'] || 'Ungültiger Betrag'; errEl.classList.add('is-visible'); }
      return false;
    }
    if (errEl) errEl.classList.remove('is-visible');
    return true;
  }

  function clearError(errEl) {
    if (errEl) errEl.classList.remove('is-visible');
  }

  /* ── createInstance ─────────────────────────────────────── */
  /*
   * Gibt eine Instanz aller Shared-Methoden zurück, die an
   * den spezifischen DOM-Kontext (uid + ID-Auflösung) gebunden sind.
   *
   * opts.uid          — string, User-UID
   * opts.i18n         — Referenz auf das i18n-Objekt des Aufrufers
   * opts.getId(key)   — function: liefert DOM-Element-ID für semantischen Schlüssel
   *                     Schlüssel: 'balance', 'txList', 'txEmpty',
   *                                'depAmt', 'depDesc', 'depBtn', 'depErr',
   *                                'wdAmt',  'wdDesc',  'wdBtn',  'wdErr',
   *                                'confirm', 'confirmText', 'confirmOk', 'confirmCancel'
   * opts.onBalanceUpdate(wallet) — optional hook nach Saldo-Änderung
   * opts.onError(context, err)  — Fehler-Handler des Aufrufers
   */
  function createInstance(opts) {
    var _uid        = opts.uid;
    var _i18n       = opts.i18n;
    var _getId      = opts.getId;
    var _onBalance  = opts.onBalanceUpdate || function () {};
    var _onError    = opts.onError || function (ctx, err) { console.error('[WalletCore]', ctx, err); };
    var _wallet     = null;
    var _pendingAmt = 0;
    var _pendingDsc = '';

    function _t(key, vars) {
      var str = _i18n[key] || key;
      if (vars) { for (var k in vars) { str = str.replace('{' + k + '}', vars[k]); } }
      return str;
    }

    function _el(key) { return document.getElementById(_getId(key)); }

    /* ── Balance ────────────────────────────────────────── */
    function renderBalance(wallet) {
      _wallet = wallet;
      var el = _el('balance');
      if (el) el.textContent = formatAmount(wallet ? wallet.balance : 0);
      _onBalance(wallet);
    }

    /* ── History ────────────────────────────────────────── */
    function renderHistory(txs) {
      var list  = _el('txList');
      var empty = _el('txEmpty');
      if (!list) return;

      var items = list.querySelectorAll('.wallet-tx-item');
      for (var i = 0; i < items.length; i++) { items[i].remove(); }

      if (!txs || txs.length === 0) {
        if (empty) empty.classList.remove('is-hidden');
        return;
      }
      if (empty) empty.classList.add('is-hidden');
      for (var j = 0; j < txs.length; j++) {
        list.appendChild(buildTxItem(txs[j], _i18n));
      }
    }

    /* ── Daten laden ────────────────────────────────────── */
    function loadData() {
      AppService.getWallet(_uid, function (err, wallet) {
        if (err) { _onError(_t('errorLoadWallet'), err); return; }
        renderBalance(wallet);
      });
      AppService.getTransactions(_uid, function (err, txs) {
        if (err) { _onError(_t('historyLoadError'), err); return; }
        renderHistory(txs);
      });
    }

    function loadHistory() {
      AppService.getTransactions(_uid, function (err, txs) {
        if (err) { _onError(_t('historyLoadError'), err); return; }
        renderHistory(txs);
      });
    }

    /* ── Einzahlen ──────────────────────────────────────── */
    function doDeposit() {
      var inputEl = _el('depAmt');
      var errEl   = _el('depErr');
      if (!validateAmount(inputEl, errEl, _i18n)) return;

      var amount = parseFloat(inputEl.value);
      var desc   = (_el('depDesc') || {}).value || '';
      var btn    = _el('depBtn');
      if (btn) btn.disabled = true;

      AppService.deposit(_uid, amount, desc.trim(), function (err, result) {
        if (btn) btn.disabled = false;
        if (err) { _onError(_t('errorDeposit'), err); return; }
        renderBalance(result.wallet);
        if (inputEl) inputEl.value = '';
        var descEl = _el('depDesc');
        if (descEl) descEl.value = '';
        loadHistory();
        if (typeof UI !== 'undefined' && UI.showToast) UI.showToast(_t('successDeposit'), 'success');
      });
    }

    /* ── Auszahlen (2 Schritte) ─────────────────────────── */
    function requestWithdraw() {
      var inputEl = _el('wdAmt');
      var errEl   = _el('wdErr');
      if (!validateAmount(inputEl, errEl, _i18n)) return;

      var amount = parseFloat(inputEl.value);
      if (_wallet && amount > _wallet.balance) {
        if (errEl) { errEl.textContent = _t('errorInsufficientFunds'); errEl.classList.add('is-visible'); }
        return;
      }
      _pendingAmt = amount;
      _pendingDsc = ((_el('wdDesc') || {}).value || '').trim();

      var textEl = _el('confirmText');
      if (textEl) textEl.textContent = _t('confirmWithdraw', { amount: formatAmount(amount) });
      openConfirm();
    }

    function doWithdraw() {
      closeConfirm();
      var btn = _el('wdBtn');
      if (btn) btn.disabled = true;

      AppService.withdraw(_uid, _pendingAmt, _pendingDsc, function (err, result) {
        if (btn) btn.disabled = false;
        if (err) { _onError(_t('errorWithdraw'), err); return; }
        renderBalance(result.wallet);
        var wdAmtEl = _el('wdAmt');
        if (wdAmtEl) wdAmtEl.value = '';
        var wdDescEl = _el('wdDesc');
        if (wdDescEl) wdDescEl.value = '';
        loadHistory();
        if (typeof UI !== 'undefined' && UI.showToast) UI.showToast(_t('successWithdraw'), 'success');
      });
    }

    /* ── Confirm-Dialog ─────────────────────────────────── */
    function openConfirm() {
      var el = _el('confirm');
      if (!el) return;
      el.classList.add('is-open');
      el.setAttribute('aria-hidden', 'false');
      document.body.classList.add('overlay-open');
      var okBtn = _el('confirmOk');
      if (okBtn) okBtn.focus();
    }

    function closeConfirm() {
      var el = _el('confirm');
      if (!el) return;
      el.classList.remove('is-open');
      el.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('overlay-open');
    }

    /* ── Events binden ──────────────────────────────────── */
    function bindEvents() {
      var depBtn = _el('depBtn');
      if (depBtn) depBtn.addEventListener('click', doDeposit);

      var wdBtn = _el('wdBtn');
      if (wdBtn) wdBtn.addEventListener('click', requestWithdraw);

      var okBtn = _el('confirmOk');
      if (okBtn) okBtn.addEventListener('click', doWithdraw);

      var cancelBtn = _el('confirmCancel');
      if (cancelBtn) cancelBtn.addEventListener('click', closeConfirm);

      var overlay = _el('confirm');
      if (overlay) {
        overlay.addEventListener('click', function (e) {
          if (e.target === overlay) closeConfirm();
        });
      }

      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' || e.keyCode === 27) closeConfirm();
      });

      var depAmtEl = _el('depAmt');
      if (depAmtEl) depAmtEl.addEventListener('input', function () { clearError(_el('depErr')); });

      var wdAmtEl = _el('wdAmt');
      if (wdAmtEl) wdAmtEl.addEventListener('input', function () { clearError(_el('wdErr')); });
    }

    return {
      renderBalance:  renderBalance,
      renderHistory:  renderHistory,
      loadData:       loadData,
      loadHistory:    loadHistory,
      doDeposit:      doDeposit,
      requestWithdraw: requestWithdraw,
      doWithdraw:     doWithdraw,
      openConfirm:    openConfirm,
      closeConfirm:   closeConfirm,
      bindEvents:     bindEvents
    };
  }

  /* ── TX Detail Sheet ────────────────────────────────────── */
  function _showTxDetail(tx, i18n) {
    /* Remove any existing sheet */
    var existing = document.getElementById('wallet-tx-detail-sheet');
    if (existing) existing.remove();

    var m         = tx.meta || {};
    var txType    = tx.type || 'deposit';
    var typeLabel = (i18n[_txTypeKey(txType)] || txType);
    var isPos     = (tx.amount || 0) >= 0;
    var icon      = TX_ICONS[txType] || '·';

    /* ── Helper: build a detail row ── */
    function row(label, value, highlight) {
      if (value === null || value === undefined || value === '') return '';
      return '<div class="wtx-detail-row' + (highlight ? ' highlight' : '') + '">' +
        '<span class="wtx-detail-label">' + escHtml(label) + '</span>' +
        '<span class="wtx-detail-value">' + value + '</span>' +
        '</div>';
    }
    function fmtDt(iso) {
      if (!iso) return '—';
      return new Date(iso).toLocaleString('de-DE', {
        day:'2-digit', month:'2-digit', year:'numeric',
        hour:'2-digit', minute:'2-digit'
      });
    }
    function fmtDate2(iso) {
      if (!iso) return '—';
      return new Date(iso + 'T00:00:00').toLocaleDateString('de-DE', {
        weekday:'short', day:'numeric', month:'short', year:'numeric'
      });
    }
    function name(uid) {
      if (!uid) return null;
      var n = (typeof ProfileStore !== 'undefined') ? ProfileStore.getDisplayName(uid) : null;
      return n ? escHtml(n) + ' <span style="color:#9ca3af;font-size:11px">(' + escHtml(uid) + ')</span>' : escHtml(uid);
    }
    function money(v) {
      if (v === null || v === undefined) return null;
      return escHtml(parseFloat(v).toFixed(2).replace('.', ',') + ' €');
    }

    /* ── Sections ── */
    var secBase = '';
    secBase += row('Typ', escHtml(typeLabel));
    secBase += row('Betrag',
      '<strong style="color:' + (isPos ? '#065f46' : '#991b1b') + '">' +
      escHtml((isPos ? '+' : '') + parseFloat(tx.amount || 0).toFixed(2).replace('.', ',') + ' €') +
      '</strong>', true);
    secBase += row('Saldo danach', money(tx.balance));
    secBase += row('Zeitpunkt', escHtml(fmtDt(tx.createdAt)));
    secBase += row('Status', '<span class="wallet-tx-status ' + escHtml(tx.status || '') + '">' +
      escHtml((i18n['txStatus' + (tx.status || '').charAt(0).toUpperCase() + (tx.status || '').slice(1)] || tx.status || '')) + '</span>');
    secBase += row('Beschreibung', tx.description ? escHtml(tx.description) : null);
    secBase += row('Wallet-Inhaber', name(tx.uid));
    secBase += row('Gegenpartei', name(tx.relatedUid));

    var secSlot = '';
    if (m.slotDate) {
      var timeRange = m.slotTimeStart
        ? escHtml(m.slotTimeStart + (m.slotTimeEnd ? '–' + m.slotTimeEnd : ''))
        : (m.slotTime ? escHtml(m.slotTime) : null);
      secSlot += row('Stundendatum', escHtml(fmtDate2(m.slotDate)));
      secSlot += row('Uhrzeit', timeRange);
      if (m.slotCount && m.slotCount > 1) secSlot += row('Anzahl Slots', escHtml(String(m.slotCount)));
    }
    if (m.oldDate) {
      secSlot += row('Verschoben von', escHtml(fmtDate2(m.oldDate) + (m.oldTime ? ' ' + m.oldTime : '')));
      secSlot += row('Verschoben nach', escHtml(fmtDate2(m.newDate) + (m.newTime ? ' ' + m.newTime : '')));
    }
    secSlot += row('Lehrer', name(m.teacherId));
    secSlot += row('Schüler', name(m.studentId));
    if (m.initiatorRole) secSlot += row('Initiiert durch', escHtml(m.initiatorRole === 'teacher' ? 'Lehrer' : 'Schüler'));

    var secPayment = '';
    if (m.fullAmount != null && m.fullAmount > 0) secPayment += row('Gesamtpreis', money(m.fullAmount), true);
    if (m.depositAmount != null && m.depositAmount > 0) {
      var depLabel = money(m.depositAmount);
      if (m.depositType === 'percent' && m.depositPercent != null) {
        depLabel += ' <span style="color:#9ca3af;font-size:11px">(' + escHtml(String(m.depositPercent)) + '% Deposit)</span>';
      } else if (m.depositType === 'fixed') {
        depLabel += ' <span style="color:#9ca3af;font-size:11px">(Fixbetrag)</span>';
      }
      secPayment += row('Deposit', depLabel);
    }
    if (m.paymentMode) {
      secPayment += row('Zahlungsart', escHtml(m.paymentMode === 'cash_on_site' ? 'Bar vor Ort' : 'Online'));
    }
    if (m.bookedAt) secPayment += row('Gebucht am', escHtml(fmtDt(m.bookedAt)));

    var secCancel = '';
    if (m.cancellationTier) {
      var tierMap = { full_refund:'Volle Rückerstattung', partial:'Teilrückerstattung',
        forfeit:'Kein Deposit zurück', teacher_cancel:'Lehrer storniert', no_escrow:'Kein Escrow' };
      secCancel += row('Stornierungsbedingung', escHtml(tierMap[m.cancellationTier] || m.cancellationTier), true);
    }
    if (m.cancelledAt) secCancel += row('Storniert am', escHtml(fmtDt(m.cancelledAt)));
    if (m.noEscrowReason) {
      var noEscMap = { cash_on_site:'Zahlung bar vor Ort', deposit_unpaid:'Deposit nicht bezahlt' };
      secCancel += row('Grund (kein Escrow)', escHtml(noEscMap[m.noEscrowReason] || m.noEscrowReason));
    }

    var secIds = '';
    secIds += row('TX-ID', '<span style="font-family:monospace;font-size:11px;color:#9ca3af">' + escHtml(tx.txId || '—') + '</span>');
    if (m.escrowId) secIds += row('Escrow-ID', '<span style="font-family:monospace;font-size:11px;color:#9ca3af">' + escHtml(m.escrowId) + '</span>');
    if (m.slotId)   secIds += row('Slot-ID',   '<span style="font-family:monospace;font-size:11px;color:#9ca3af">' + escHtml(m.slotId) + '</span>');

    function section(title, content) {
      if (!content) return '';
      return '<div class="wtx-detail-section"><div class="wtx-detail-section-title">' +
        escHtml(title) + '</div>' + content + '</div>';
    }

    var sheet = document.createElement('div');
    sheet.id  = 'wallet-tx-detail-sheet';
    sheet.className = 'wtx-detail-backdrop';
    sheet.innerHTML =
      '<div class="wtx-detail-panel" role="dialog" aria-modal="true">' +
        '<div class="wtx-detail-handle"></div>' +
        '<div class="wtx-detail-header">' +
          '<div class="wallet-tx-icon ' + escHtml(txType) + '" style="width:40px;height:40px;font-size:18px;flex-shrink:0">' + escHtml(icon) + '</div>' +
          '<div>' +
            '<div style="font-weight:600;font-size:16px">' + escHtml(typeLabel) + '</div>' +
            '<div style="font-size:12px;color:#6b7280">' + escHtml(fmtDt(tx.createdAt)) + '</div>' +
          '</div>' +
          '<button class="wtx-detail-close" id="wtx-close-btn" aria-label="Schließen">✕</button>' +
        '</div>' +
        '<div class="wtx-detail-body">' +
          section('Transaktion', secBase) +
          (secSlot    ? section('Stunde', secSlot)       : '') +
          (secPayment ? section('Zahlung', secPayment)   : '') +
          (secCancel  ? section('Stornierung', secCancel): '') +
          section('IDs', secIds) +
        '</div>' +
      '</div>';

    document.body.appendChild(sheet);

    /* Close handlers */
    function close() {
      sheet.classList.remove('is-open');
      setTimeout(function() { if (sheet.parentNode) sheet.parentNode.removeChild(sheet); }, 300);
    }
    document.getElementById('wtx-close-btn').addEventListener('click', close);
    sheet.addEventListener('click', function(e) { if (e.target === sheet) close(); });
    document.addEventListener('keydown', function esc(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', esc); }
    });

    /* Animate in */
    requestAnimationFrame(function() { sheet.classList.add('is-open'); });
  }

  /* ── Public API ─────────────────────────────────────────── */
  return {
    loadI18n:        loadI18n,
    formatAmount:    formatAmount,
    formatDate:      formatDate,
    escHtml:         escHtml,
    buildTxItem:     buildTxItem,
    buildTxMetaLine: buildTxMetaLine,
    validateAmount:  validateAmount,
    clearError:      clearError,
    createInstance:  createInstance,
    TX_ICONS:        TX_ICONS
  };

}());

window.WalletCore = WalletCore;
