/**
 * app-config.js — Asset-Version & Adapter-Switch
 *
 * Zwei Verantwortlichkeiten (lt. Guideline_Architecture.txt Abschnitt 8):
 *   1. APP_VERSION  — Zentrale Asset-Version (SSOT, R-CACHE-05)
 *   2. AppAdapter   — Adapter-Swap für localStorage ↔ Firestore
 *
 * WICHTIG: Diese Datei wird als ERSTES Script in jeder HTML-Seite geladen.
 * Sie selbst bekommt KEIN ?v= (R-CACHE-04).
 *
 * Bei jeder Änderung an JS- oder CSS-Dateien:
 *   → APP_VERSION erhöhen (Format: YYYY-MM-DD-{increment})
 *   → Niemals manuelles Cache-Leeren fordern (R-CACHE-06)
 *
 * Regeln: var only, function(){}, no arrow functions,
 *         no template literals, no ?. or ??
 */

/* ── Asset-Version ──────────────────────────────────────────
   Bei jeder Änderung erhöhen: YYYY-MM-DD-{increment}       */

var APP_VERSION = '2026-03-19-1';

/* ── Adapter-Switch ─────────────────────────────────────────
   Genau eine Zeile ändern für die Migration:              */

var AppAdapter = LocalStorageAdapter;
/* var AppAdapter = FirestoreAdapter; */

/* ── Firestore-Konfiguration (nur relevant für Produktion) ──
   Beim Wechsel auf FirestoreAdapter hier die Firebase-Config
   eintragen und firebase SDK in den HTML-Dateien einbinden.

var FirebaseConfig = {
  apiKey:            'YOUR_API_KEY',
  authDomain:        'YOUR_PROJECT.firebaseapp.com',
  projectId:         'YOUR_PROJECT_ID',
  storageBucket:     'YOUR_PROJECT.appspot.com',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId:             'YOUR_APP_ID'
};
*/
