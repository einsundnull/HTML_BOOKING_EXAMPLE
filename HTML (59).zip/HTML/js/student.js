/**
 * student.js — Student View
 *
 * Booking via week grid (same layout as teacher).
 * Cell states (student perspective):
 *   gc-available  — green,  clickable → book instantly
 *   gc-mine       — navy,   clickable → cancel
 *   gc-empty      — grey,   not clickable
 */

var currentUser     = null;
var activeView      = 'catalog';
var activeTeacherId = null;

var sgridWeekStart  = null;
var _daySlotsFreeOpen = true; /* free slots accordion open state in calendar day view */

var viewYear        = 0;
var viewMonth       = 0;
var selectedDate    = null;

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START  = '06:00';
var GRID_END    = '22:00';

/* Stored document-level listeners — ermöglicht sauberes removeEventListener */
var _closeTeacherPickerDropdown = null;
var _closeMbTeacherDropdown     = null;
var _pickerMonthBtnsInit        = false;

/* My Bookings — uses shared bookingsFilter + allBookingsSortAsc from teacher.js-compatible globals */
/* bookingsFilter and allBookingsSortAsc are defined here so student.js works standalone */
var bookingsFilter = {
  student:   'all',
  time:      'upcoming',
  confirmed: 'all',
  dateFrom:  '',
  dateTo:    ''
};
var allBookingsSortAsc = true;

/* ── Pending move system (mirrors teacher pendingBookings) ── */
var pendingDayChanges = {};
var expandedStudentBlocks = {};  /* blockKey → true, persists open state across re-renders */

function updateDaySaveBtn() {
  var group = document.getElementById('day-save-group');
  if (!group) return;
  var pendingBook = Object.keys(pendingDayChanges).filter(function(id) {
    return pendingDayChanges[id].action === 'book';
  });
  var count = Object.keys(pendingDayChanges).length;
  group.classList.toggle('is-visible', count > 0);
  var badge = group.querySelector('.save-badge');
  if (badge) badge.textContent = count;

  /* Build pending slots array for affordability check */
  var pendingSlots = pendingBook.map(function(id) {
    var p = pendingDayChanges[id];
    var s = p.originalSlot;
    var price = parseFloat(s.price) || AppService.getTeacherPriceSync(s.teacherId) || 0;
    return { slotId: id, teacherId: s.teacherId, price: price };
  });

  if (!pendingSlots.length) {
    _renderSaveSummary(null);
    return;
  }

  AppService.checkPendingAffordability(pendingSlots, currentUser.uid, function(err, result) {
    if (err) { _renderSaveSummary(null); return; }
    _renderSaveSummary(result, pendingSlots);
  });
}

function _renderSaveSummary(result, pendingSlots) {
  var panel = document.getElementById('day-save-summary');
  if (!panel) return;

  if (!result || !pendingSlots || !pendingSlots.length) {
    panel.innerHTML = '';
    panel.classList.remove('is-visible');
    return;
  }

  panel.classList.add('is-visible');
  panel.innerHTML = '';

  /* Slot lines */
  var lines = document.createElement('div');
  lines.className = 'save-summary-lines';
  pendingSlots.forEach(function(ps) {
    var orig = pendingDayChanges[ps.slotId] && pendingDayChanges[ps.slotId].originalSlot;
    if (!orig) return;
    var line = document.createElement('div');
    line.className = 'save-summary-row';
    var timeSpan = document.createElement('span');
    timeSpan.className = 'save-summary-time';
    timeSpan.textContent = orig.time + ' \u2013 ' + AppService.slotEndTime(orig.time);
    var priceSpan = document.createElement('span');
    priceSpan.className = 'save-summary-price';
    priceSpan.textContent = ps.price > 0 ? fmtPrice(ps.price) : '';
    line.appendChild(timeSpan);
    line.appendChild(priceSpan);
    lines.appendChild(line);
  });
  panel.appendChild(lines);

  /* Total row */
  if (result.totalCost > 0) {
    var totalRow = document.createElement('div');
    totalRow.className = 'save-summary-total';
    var totalLabel = document.createElement('span');
    totalLabel.textContent = 'Gesamt';
    var totalPrice = document.createElement('span');
    totalPrice.className = 'save-summary-price';
    totalPrice.textContent = fmtPrice(result.totalCost);
    totalRow.appendChild(totalLabel);
    totalRow.appendChild(totalPrice);
    panel.appendChild(totalRow);
  }

  /* Warnings */
  if (result.paymentMode !== 'cash_on_site' && result.totalCost > 0) {
    var walletRow = document.createElement('div');
    var walletOk  = result.canAfford;
    walletRow.className = 'save-summary-warning' + (walletOk ? ' save-summary-ok' : ' save-summary-error');
    walletRow.textContent = (walletOk ? '\u2713 ' : '\u26a0 ') +
      'Guthaben: ' + fmtPrice(result.walletBalance) +
      (walletOk ? '' : ' \u2014 Nicht genug');
    panel.appendChild(walletRow);

    if (result.requiresDeposit) {
      var depRow = document.createElement('div');
      var depOk  = result.depositCovered;
      depRow.className = 'save-summary-warning' + (depOk ? ' save-summary-ok' : ' save-summary-warn');
      depRow.textContent = (depOk ? '\u2713 ' : '\u26a0 ') +
        'Deposit: ' + fmtPrice(result.depositAmount) +
        (depOk ? ' gedeckt' : ' \u2014 Guthaben zu gering');
      panel.appendChild(depRow);
    }
  }

  /* Disable Save if wallet insufficient */
  var saveBtn = document.getElementById('day-save-btn');
  if (saveBtn) {
    var block = result.paymentMode !== 'cash_on_site' && !result.canAfford;
    saveBtn.disabled = block;
    saveBtn.classList.toggle('is-blocked', block);
  }
}

function _refreshNavbarWallet(uid) {
  AppService.getWallet(uid, function(err, wallet) {
    var el = document.getElementById('navbar-wallet-amount');
    if (!el) return;
    el.textContent = err ? '—' : (parseFloat(wallet.balance).toFixed(2).replace('.', ',') + ' €');
  });
}

function confirmAndCommit() {
  var pendingBook = Object.keys(pendingDayChanges).filter(function(id) {
    return pendingDayChanges[id].action === 'book';
  });

  if (!pendingBook.length) { commitDayChanges(); return; }

  /* Build cost summary for the dialog */
  var pendingSlots = pendingBook.map(function(id) {
    var p = pendingDayChanges[id];
    var s = p.originalSlot;
    return { slotId: id, teacherId: s.teacherId, price: parseFloat(s.price) || AppService.getTeacherPriceSync(s.teacherId) || 0 };
  });

  AppService.checkPendingAffordability(pendingSlots, currentUser.uid, function(err, result) {
    var totalCost    = result ? result.totalCost    : 0;
    var balance      = result ? result.walletBalance : 0;
    var payMode      = result ? result.paymentMode   : 'instant';
    var reqDeposit   = result ? result.requiresDeposit : false;
    var depositAmt   = result ? result.depositAmount  : 0;
    var balanceAfter = Math.round((balance - (reqDeposit && payMode !== 'cash_on_site' ? depositAmt : 0)) * 100) / 100;

    var rows = pendingSlots.map(function(ps) {
      var orig = pendingDayChanges[ps.slotId] && pendingDayChanges[ps.slotId].originalSlot;
      var timeStr = orig ? (orig.time + ' \u2013 ' + AppService.slotEndTime(orig.time)) : ps.slotId;
      return '<div style="display:flex;justify-content:space-between;padding:2px 0;font-size:13px">' +
        '<span style="font-family:monospace">' + timeStr + '</span>' +
        (ps.price > 0 ? '<span style="font-family:monospace;font-weight:600">' + fmtPrice(ps.price) + '</span>' : '') +
        '</div>';
    }).join('');

    var paymentLine = '';
    if (payMode === 'cash_on_site') {
      paymentLine = '<div style="margin-top:10px;padding:8px;background:#f0fdf4;border-radius:6px;font-size:12px;color:#166534">Bar vor Ort — kein Betrag wird jetzt abgezogen.</div>';
    } else if (reqDeposit && depositAmt > 0) {
      var depOk = balance >= depositAmt;
      paymentLine = '<div style="margin-top:10px;padding:8px;background:' + (depOk ? '#f0fdf4' : '#fee2e2') + ';border-radius:6px;font-size:12px;color:' + (depOk ? '#166534' : '#991b1b') + '">' +
        (depOk ? '\u2713 ' : '\u26a0 ') + 'Deposit <strong>' + fmtPrice(depositAmt) + '</strong> wird von deinem Guthaben abgezogen.<br>' +
        'Guthaben danach: <strong>' + fmtPrice(balanceAfter) + '</strong>' +
        '</div>';
    } else if (totalCost > 0) {
      var fullOk = balance >= totalCost;
      paymentLine = '<div style="margin-top:10px;padding:8px;background:' + (fullOk ? '#f0fdf4' : '#fee2e2') + ';border-radius:6px;font-size:12px;color:' + (fullOk ? '#166534' : '#991b1b') + '">' +
        (fullOk ? '\u2713 ' : '\u26a0 ') + 'Gesamtbetrag <strong>' + fmtPrice(totalCost) + '</strong> wird abgezogen.<br>' +
        'Guthaben danach: <strong>' + fmtPrice(balanceAfter) + '</strong>' +
        '</div>';
    }

    var totalLine = totalCost > 0
      ? '<div style="display:flex;justify-content:space-between;padding:8px 0 4px;border-top:1px solid #e5e7eb;font-weight:700;font-size:14px"><span>Gesamt</span><span>' + fmtPrice(totalCost) + '</span></div>'
      : '';

    var bodyHTML = '<div style="font-size:14px">' + rows + totalLine + paymentLine + '</div>';

    var modal = Modal.show({
      title: pendingBook.length + ' Buchung' + (pendingBook.length !== 1 ? 'en' : '') + ' bestätigen',
      bodyHTML: bodyHTML,
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel-commit">Abbrechen</button>' +
                  '<button class="btn btn-primary" id="modal-confirm-commit">Jetzt buchen</button>'
    });

    document.getElementById('modal-cancel-commit').addEventListener('click', modal.close);
    document.getElementById('modal-confirm-commit').addEventListener('click', function() {
      /* Guard: disable immediately so double-click cannot fire commitDayChanges twice */
      var btn = document.getElementById('modal-confirm-commit');
      if (btn) btn.disabled = true;
      modal.close();
      commitDayChanges();
    });
  });
}

function commitDayChanges() {
  var ids   = Object.keys(pendingDayChanges);
  var saved = {};

  /* ── Callback barrier ───────────────────────────────────────────
     All async ops fire in parallel. pending counts down to zero.
     onAllDone() fires exactly once when every callback has returned,
     then does a single authoritative re-render + wallet refresh.
  ──────────────────────────────────────────────────────────────── */
  var pending = ids.length;
  var errors  = [];

  function onAllDone() {
    /* Detect move pairs: a cancel + book for the same teacher on the same day = reschedule */
    var cancelMap = {};
    var bookMap   = {};
    var sids = Object.keys(saved);
    for (var mi = 0; mi < sids.length; mi++) {
      var mp = saved[sids[mi]];
      if (!mp.originalSlot) continue;
      var tid = mp.originalSlot.teacherId;
      if (mp.action === 'cancel') cancelMap[tid] = mp.originalSlot;
      else if (mp.action === 'book') bookMap[tid]  = mp.originalSlot;
    }
    Object.keys(cancelMap).forEach(function(tid) {
      if (bookMap[tid]) {
        AppService.writeMoveRecord(cancelMap[tid], bookMap[tid], currentUser.uid, 'student', function() {});
      }
    });

    /* Write ONE block booking TX per (teacher, date) group */
    var blockGroups = {};
    var sids2 = Object.keys(saved);
    for (var bi = 0; bi < sids2.length; bi++) {
      var bp = saved[sids2[bi]];
      if (bp.action !== 'book') continue;
      var bSlot = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === sids2[bi]; })[0];
      if (!bSlot) continue;
      var bKey = currentUser.uid + '_' + (bSlot.teacherId || '') + '_' + (bSlot.date || '');
      if (!blockGroups[bKey]) blockGroups[bKey] = { slots: [], escrows: [], stuId: currentUser.uid, tid: bSlot.teacherId };
      blockGroups[bKey].slots.push(bSlot);
    }
    Object.keys(blockGroups).forEach(function(gKey) {
      var g = blockGroups[gKey];
      if (!g.slots.length) return;
      g.slots.sort(function(a, b) { return (a.time || '').localeCompare(b.time || ''); });
      AppService.getEscrowsByStudent(g.stuId, function(err, allEsc) {
        if (!err && allEsc) {
          g.slots.forEach(function(sl) {
            for (var ei = 0; ei < allEsc.length; ei++) {
              if (allEsc[ei].slotId === sl.slotId) { g.escrows.push(allEsc[ei]); break; }
            }
          });
        }
        AppService.writeBlockBookingRecord(g.slots, g.escrows, 'student', function() {});
        AppService.writeBlockEscrowHold(g.slots, g.escrows, function() {});
      });
    });

    pendingDayChanges = {};
    updateDaySaveBtn();
    renderStats();
    _updateMyBookingsBadges();
    renderMyBookingsList();
    renderCalendar();
    renderDaySlots();
    _refreshNavbarWallet(currentUser.uid);
    if (typeof WalletPanel !== 'undefined') WalletPanel.refresh(currentUser.uid);
    if (errors.length) {
      Toast.error(errors[0]);
    } else {
      Toast.success('Gespeichert.');
    }
  }

  if (!pending) { onAllDone(); return; }

  for (var i = 0; i < ids.length; i++) {
    var p = pendingDayChanges[ids[i]];
    saved[ids[i]] = p;
    if (p.action === 'book') {
      (function(sid, stuId, tid) {
        AppService.bookSlotWithEscrowSilent(sid, stuId, tid, function(e) {
          if (e) errors.push(e.message || e);
          if (--pending === 0) onAllDone();
        });
      })(ids[i], p.newStudentId || currentUser.uid, p.originalSlot.teacherId);
    } else {
      (function(sid) {
        /* Skip if slot already cancelled (e.g. from _showCancelPolicyDialog immediate path) */
        var currentSlot = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === sid; })[0];
        if (!currentSlot || currentSlot.status !== 'booked') {
          if (--pending === 0) onAllDone();
          return;
        }
        AppService.cancelSlotWithPolicy(sid, 'student', function(e) {
          if (e) errors.push(e.message || e);
          if (--pending === 0) onAllDone();
        });
      })(ids[i]);
    }
  }

  /* Email notifications fire independently — no barrier needed */
  var emailIds = Object.keys(saved);
  for (var ei = 0; ei < emailIds.length; ei++) {
    var ep  = saved[emailIds[ei]];
    var es  = ep.originalSlot;
    if (!es) continue;
    var teacher = AppService.getUserSync(es.teacherId);
    if (!teacher) continue;
    var dateObj   = new Date(es.date + 'T00:00:00');
    var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    var endTime   = AppService.slotEndTime(es.time);
    if (ep.action === 'book') {
      EmailService.onBookingCreated(teacher.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(teacher.uid),
        studentName: ProfileStore.getDisplayName(currentUser.uid)
      });
    } else {
      EmailService.onBookingCancelled(teacher.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(teacher.uid),
        studentName: ProfileStore.getDisplayName(currentUser.uid)
      });
    }
  }
}

function discardDayChanges() {
  pendingDayChanges = {};
  updateDaySaveBtn();
  renderMyBookingsList();
  renderDaySlots();
  Toast.info('Änderungen verworfen.');
}



/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('student');
  if (!currentUser) return;
  Navbar.init('catalog');

  document.getElementById('nav-catalog').addEventListener('click', function() { switchView('catalog'); });
  document.getElementById('nav-calendar').addEventListener('click', function() { switchView('calendar'); });
  document.getElementById('nav-my-bookings').addEventListener('click', function() { switchView('my-bookings'); });
  document.getElementById('nav-wallet').addEventListener('click', function() { switchView('wallet'); });
  document.getElementById('sgrid-close-btn').addEventListener('click', closeStudentGrid);
  document.getElementById('sgrid-prev-week').addEventListener('click', sgridPrevWeek);
  document.getElementById('sgrid-next-week').addEventListener('click', sgridNextWeek);

  /* Day-nav-bar buttons — same as teacher.js */
  document.getElementById('day-nav-prev').addEventListener('click', function() { navDay(-1); });
  document.getElementById('day-nav-next').addEventListener('click', function() { navDay(1); });
  document.getElementById('day-nav-prev-month').addEventListener('click', function() { navMonth(-1); });
  document.getElementById('day-nav-next-month').addEventListener('click', function() { navMonth(1); });

  var now   = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();

  renderStats();
  switchView('catalog');
});

/* ── View switcher ──────────────────────────────────────── */
function switchView(view) {
  activeView = view;
  document.getElementById('nav-catalog').classList.toggle('active', view === 'catalog');
  document.getElementById('nav-calendar').classList.toggle('active', view === 'calendar');
  document.getElementById('nav-my-bookings').classList.toggle('active', view === 'my-bookings');
  document.getElementById('nav-wallet').classList.toggle('active', view === 'wallet');
  document.getElementById('view-catalog').classList.toggle('view-hidden', view !== 'catalog');
  document.getElementById('view-calendar').classList.toggle('view-hidden', view !== 'calendar');
  document.getElementById('view-my-bookings').classList.toggle('view-hidden', view !== 'my-bookings');
  document.getElementById('view-wallet').classList.toggle('view-hidden', view !== 'wallet');
  if (view === 'catalog')     renderCatalog();
  if (view === 'calendar')    { renderTeacherPicker(); setTimeout(updateJumpBtns, 100); }
  if (view === 'my-bookings') { renderMyBookings(); setTimeout(updateJumpBtns, 200); }
  if (view === 'wallet' && typeof WalletPanel !== 'undefined') {
    WalletPanel.mount('student-wallet-panel', currentUser.uid);
  }
}

/* ── Stats ──────────────────────────────────────────────── */
function renderStats() {
  var selections = AppService.getSelectionsByStudentSync(currentUser.uid);
  var bookings   = AppService.getSlotsByStudentSync(currentUser.uid).filter(function(s) { return s.status === 'booked'; });
  document.getElementById('stat-teachers').textContent = selections.length;
  document.getElementById('stat-bookings').textContent = bookings.length;
}

/* ══════════════════════════════════════════════════════════
   CATALOG
══════════════════════════════════════════════════════════ */
function renderCatalog() {
  var allTeachers  = AppService.getUsersByRoleSync('teacher');
  var mySelections = AppService.getSelectionsByStudentSync(currentUser.uid).map(function(s) { return s.teacherId; });
  var container    = document.getElementById('catalog-grid');
  container.innerHTML = '';

  if (!allTeachers.length) {
    var empty = document.createElement('div');
    empty.className = 'catalog-empty text-muted';
    empty.textContent = 'No teachers available yet.';
    container.appendChild(empty);
    return;
  }

  for (var i = 0; i < allTeachers.length; i++) {
    var reqStatus = ChatStore.getRequestStatus(allTeachers[i].uid, currentUser.uid);
    container.appendChild(buildTeacherCard(allTeachers[i], mySelections, reqStatus));
  }
}

function buildTeacherCard(teacher, mySelections, reqStatus) {
  var isSelected = mySelections.indexOf(teacher.uid) !== -1;
  var isPending  = !isSelected && reqStatus === 'pending';
  var availCount = AppService.getSlotsByTeacherSync(teacher.uid).filter(function(s) { return s.status === 'available'; }).length;

  var card = document.createElement('div');
  card.className = 'card teacher-card' + (isSelected ? ' teacher-card-selected' : '') + (isPending ? ' teacher-card-pending' : '');

  var top = document.createElement('div');
  top.className = 'teacher-card-top';

  var nameWrap = document.createElement('div');
  var name = document.createElement('div');
  name.className = 'teacher-card-name';
  name.textContent = ProfileStore.getDisplayName(teacher.uid);
  var uid = document.createElement('code');
  uid.className = 'uid-badge';
  uid.textContent = teacher.uid;
  nameWrap.appendChild(name);
  nameWrap.appendChild(uid);
  top.appendChild(nameWrap);

  if (isSelected) {
    var badge = document.createElement('span');
    badge.className = 'teacher-selected-badge';
    badge.textContent = 'Selected';
    top.appendChild(badge);
  }

  var avail = document.createElement('div');
  avail.className = 'teacher-card-avail text-muted';
  avail.textContent = availCount + ' available slot' + (availCount !== 1 ? 's' : '');

  var actions = document.createElement('div');
  actions.className = 'teacher-card-actions';

  if (isSelected) {
    var viewBtn = document.createElement('button');
    viewBtn.className = 'btn btn-secondary btn-sm';
    viewBtn.textContent = 'Book lessons';
    (function(tid) { viewBtn.addEventListener('click', function() { openTeacherGrid(tid); }); })(teacher.uid);

    var removeBtn = document.createElement('button');
    removeBtn.className = 'btn btn-ghost btn-sm';
    removeBtn.textContent = 'Remove';
    (function(tid) { removeBtn.addEventListener('click', function() { deselectTeacher(tid); }); })(teacher.uid);

    actions.appendChild(viewBtn);
    actions.appendChild(removeBtn);
  } else if (isPending) {
    var pendingBtn = document.createElement('button');
    pendingBtn.className = 'btn btn-ghost btn-sm';
    pendingBtn.disabled = true;
    pendingBtn.textContent = '⏳ Anfrage ausstehend';
    actions.appendChild(pendingBtn);
  } else {
    var selectBtn = document.createElement('button');
    selectBtn.className = 'btn btn-primary btn-sm';
    selectBtn.textContent = 'Select';
    (function(tid) { selectBtn.addEventListener('click', function() { selectTeacher(tid); }); })(teacher.uid);
    actions.appendChild(selectBtn);
  }

  card.appendChild(top);
  card.appendChild(avail);
  card.appendChild(actions);
  return card;
}

function selectTeacher(teacherId) {
  var teacherName = ProfileStore.getDisplayName(teacherId);
  var studentName = ProfileStore.getDisplayName(currentUser.uid);
  /* Send service request via chat — selection only created after teacher accepts */
  ChatStore.sendServiceMessage(teacherId, currentUser.uid, 'student_request');
  EmailService.onRequestReceived(teacherId, studentName);
  Toast.info(teacherName + ' — Anfrage gesendet. Warte auf Bestätigung.');
  renderCatalog();
}

function deselectTeacher(teacherId) {
  AppService.deleteSelection(currentUser.uid, teacherId, function(e){if(e)Toast.error(e.message||e);});
  Toast.success(ProfileStore.getDisplayName(teacherId) + ' removed.');
  renderStats();
  renderCatalog();
}

function openTeacherGrid(teacherId) {
  activeTeacherId = teacherId;
  /* Pre-select today so day panel loads immediately on calendar open */
  var now = new Date();
  now.setHours(0, 0, 0, 0);
  selectedDate = now;
  switchView('calendar');
}

/* ══════════════════════════════════════════════════════════
   TEACHER PICKER (calendar view top)
══════════════════════════════════════════════════════════ */
function renderTeacherPicker() {
  var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(s) { return AppService.getUserSync(s.teacherId); })
    .filter(function(t) { return t !== null; });

  var calSection = document.getElementById('cal-section');
  var list    = document.getElementById('teacher-picker-list');
  var label   = document.getElementById('teacher-picker-label');
  var trigger = document.getElementById('teacher-picker-trigger');
  var weekBtn = document.getElementById('teacher-picker-week-btn');

  if (!myTeachers.length) {
    if (list)    list.innerHTML = '';
    if (label)   label.textContent = 'Kein Lehrer ausgewählt';
    if (weekBtn) weekBtn.disabled = true;
    calSection.classList.add('view-hidden');
    return;
  }

  if (!activeTeacherId) activeTeacherId = myTeachers[0].uid;

  /* ── Build options list ── */
  var options = [];
  for (var i = 0; i < myTeachers.length; i++) {
    options.push({ value: myTeachers[i].uid, text: ProfileStore.getDisplayName(myTeachers[i].uid) });
  }

  function setTeacher(val) {
    activeTeacherId = val;
    var selected = null;
    for (var j = 0; j < options.length; j++) {
      if (options[j].value === val) { selected = options[j]; break; }
    }
    label.textContent = selected ? selected.text : options[0].text;
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var k = 0; k < items.length; k++) {
      var isActive = items[k].getAttribute('data-value') === val;
      items[k].classList.toggle('is-active', isActive);
      items[k].setAttribute('aria-selected', isActive ? 'true' : 'false');
    }
    closeDropdown();
    renderCalendar();
    renderDaySlots();
  }

  function openDropdown() {
    list.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    trigger.classList.add('is-open');
  }

  function closeDropdown() {
    list.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.classList.remove('is-open');
  }

  /* ── Rebuild list items ── */
  list.innerHTML = '';
  for (var m = 0; m < options.length; m++) {
    (function(opt) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (opt.value === activeTeacherId ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', opt.value);
      li.setAttribute('aria-selected', opt.value === activeTeacherId ? 'true' : 'false');
      li.textContent = opt.text;
      li.addEventListener('click', function() { setTeacher(opt.value); });
      list.appendChild(li);
    })(options[m]);
  }

  /* ── Sync label to current selection ── */
  var curOpt = null;
  for (var n = 0; n < options.length; n++) {
    if (options[n].value === activeTeacherId) { curOpt = options[n]; break; }
  }
  label.textContent = curOpt ? curOpt.text : options[0].text;

  /* ── Toggle open/close — onclick überschreibt statt zu stapeln ── */
  trigger.onclick = function(e) {
    e.stopPropagation();
    if (list.classList.contains('is-open')) { closeDropdown(); } else { openDropdown(); }
  };

  /* ── Close on outside click — alten Listener zuerst entfernen ── */
  if (_closeTeacherPickerDropdown) {
    document.removeEventListener('click', _closeTeacherPickerDropdown);
  }
  _closeTeacherPickerDropdown = function() { closeDropdown(); };
  document.addEventListener('click', _closeTeacherPickerDropdown);

  /* ── Wochenansicht-Button — onclick überschreibt ── */
  weekBtn.disabled = false;
  weekBtn.onclick  = openStudentGrid;

  /* ── Prev/Next-Monat — einmalig binden ── */
  if (!_pickerMonthBtnsInit) {
    _pickerMonthBtnsInit = true;
    document.getElementById('prev-btn').addEventListener('click', prevMonth);
    document.getElementById('next-btn').addEventListener('click', nextMonth);
  }

  /* Pre-select today if no date selected yet */
  if (!selectedDate) {
    var now = new Date();
    now.setHours(0, 0, 0, 0);
    selectedDate = now;
  }

  calSection.classList.remove('view-hidden');
  renderCalendar();
  renderDaySlots();
}

/* Materialise recurring slots for all weeks visible in the current month view.
   Mirrors teacher's materialiseVisibleMonth — uses activeTeacherId instead of currentUser.uid */
function materialiseVisibleMonth(year, month) {
  if (!activeTeacherId) return;
  var first    = new Date(year, month, 1);
  var startDow = first.getDay(); startDow = (startDow === 0) ? 6 : startDow - 1;
  var gridStart = new Date(year, month, 1 - startDow);
  var seen = {};
  for (var d = 0; d < 42; d++) {
    var day = new Date(gridStart);
    day.setDate(gridStart.getDate() + d);
    var dow = day.getDay(); dow = (dow === 0) ? 6 : dow - 1;
    var mon = new Date(day); mon.setDate(day.getDate() - dow);
    var monKey = mon.getFullYear() + '-' + mon.getMonth() + '-' + mon.getDate();
    if (seen[monKey]) continue;
    seen[monKey] = true;
    var weekDates = [];
    for (var w = 0; w < 7; w++) {
      var wd = new Date(mon); wd.setDate(mon.getDate() + w);
      weekDates.push(wd);
    }
    AppService.materialiseWeek(activeTeacherId, weekDates, function(e) {
      if (e) Toast.error(e.message || e);
    });
  }
}

/* ══════════════════════════════════════════════════════════
   STUDENT WEEK GRID OVERLAY
══════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════
   MONTH CALENDAR
══════════════════════════════════════════════════════════ */
function renderCalendar() {
  var calSection = document.getElementById('cal-section');
  if (!calSection) return;

  /* Materialise recurring slots for all visible weeks — same as teacher */
  materialiseVisibleMonth(viewYear, viewMonth);

  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;
  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  /* Normalize TODAY to midnight for correct past/today comparison */
  var todayMidnight = new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate());

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow     = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeDayCell(prevDays - i, true));
  }
  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isPast  = date < todayMidnight;
      var isToday = date.getTime() === todayMidnight.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots   = activeTeacherId ? AppService.getSlotsByTeacherDateSync(activeTeacherId, dateStr) : [];
      var hasAvail  = !isPast && slots.some(function(s) { return s.status === 'available' || s.status === 'recurring'; });
      var hasMyBook = slots.some(function(s) { return s.status === 'booked' && s.studentId === currentUser.uid; });

      var cell = makeDayCell(day, false, isToday, isSel, hasAvail, hasMyBook);
      if (!isPast) {
        cell.setAttribute('tabindex', '0');
        cell.addEventListener('click', function() { selectedDate = date; renderCalendar(); renderDaySlots(); });
        cell.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') { selectedDate = date; renderCalendar(); renderDaySlots(); } });
      }
      grid.appendChild(cell);
    })(d);
  }
  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeDayCell(t, true));
  }
}

function makeDayCell(num, otherMonth, isToday, isSelected, hasAvail, hasMyBook) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth) el.classList.add('other-month');
  if (isToday)    el.classList.add('today');
  if (isSelected) el.classList.add('selected');
  if (hasAvail)   el.classList.add('has-avail');
  if (hasMyBook)  el.classList.add('has-mybook');
  el.textContent = num;
  return el;
}

/* ══════════════════════════════════════════════════════════
   DAY SLOT LIST
══════════════════════════════════════════════════════════ */
function renderDaySlots() {
  updateDayNavBar();
  var container = document.getElementById('day-slots');
  if (!container) return;
  container.innerHTML = '';

  if (!selectedDate || !activeTeacherId) return;

  /* Materialise recurring for selected week — mirrors teacher's renderDayPanel */
  var selMonday = new Date(selectedDate);
  var selDow = selMonday.getDay(); selDow = (selDow === 0) ? 6 : selDow - 1;
  selMonday.setDate(selMonday.getDate() - selDow);
  var selWeekDates = [];
  for (var wi = 0; wi < 7; wi++) {
    var wd = new Date(selMonday); wd.setDate(selMonday.getDate() + wi);
    selWeekDates.push(wd);
  }
  AppService.materialiseWeek(activeTeacherId, selWeekDates, function(e) {
    if (e) Toast.error(e.message || e);
  });

  var dateStr = fmtDate(selectedDate);
  var today   = fmtDate(new Date());
  var isPast  = dateStr < today;

  /* ── Same pipeline as renderMyBookingsList but scoped to one day + one teacher ── */

  /* 1. Booked slots for this student on this day — with pending map applied */
  var storeBooked = AppService.getSlotsByTeacherDateSync(activeTeacherId, dateStr)
    .filter(function(s) { return s.status === 'booked' && s.studentId === currentUser.uid; })
    .map(function(s) {
      var p = pendingDayChanges[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  /* 2. Pending-book slots not yet in Store */
  var pendingBookSlots = Object.keys(pendingDayChanges)
    .filter(function(id) {
      var p = pendingDayChanges[id];
      return p.action === 'book' &&
        p.originalSlot.date === dateStr &&
        p.originalSlot.teacherId === activeTeacherId &&
        !storeBooked.some(function(s) { return s.slotId === id; });
    })
    .map(function(id) {
      var orig = pendingDayChanges[id].originalSlot;
      var s = {}; for (var k in orig) s[k] = orig[k];
      s.status    = 'booked';
      s.studentId = currentUser.uid;
      s._pending  = 'book';
      return s;
    });

  var allBooked = storeBooked.concat(pendingBookSlots);

  /* 3. Merge into blocks — same function as My Bookings */
  var blocks = _mergeStudentBookingBlocks(dateStr, allBooked, today);

  /* 4. Free slots on this day (available, not booked by anyone else) */
  var freeSlots = AppService.getSlotsByTeacherDateSync(activeTeacherId, dateStr)
    .filter(function(s) { return s.status === 'available' && !s.studentId; });

  if (!blocks.length && !freeSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted day-slots-empty';
    empty.textContent = 'Keine Slots an diesem Tag.';
    container.appendChild(empty);
    return;
  }

  /* 5. Free slots accordion — uses populateBookingDetail for in-place amber staging */
  if (freeSlots.length && !isPast) {
    var freeWrapper = document.createElement('div');
    freeWrapper.className = 'all-booking-block-wrapper';
    var freeHeader = document.createElement('div');
    freeHeader.className = 'all-booking-block-header';
    freeHeader.setAttribute('tabindex', '0');
    var freeLabel = document.createElement('span');
    freeLabel.className = 'all-booking-block-time';
    var freeChevron = document.createElement('span');
    freeChevron.className = 'all-booking-chevron';
    freeChevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    freeHeader.appendChild(freeLabel);
    freeHeader.appendChild(freeChevron);
    var freeDetail = document.createElement('div');
    freeDetail.className = 'all-booking-block-detail';
    freeDetail.style.padding = 'var(--sp-1) var(--sp-3)';
    if (_daySlotsFreeOpen) {
      freeDetail.classList.add('is-open');
      freeChevron.classList.add('is-open');
    }
    var _freeDayTeacherId = activeTeacherId;
    var _freeDayDateStr   = dateStr;
    var _freeDayToday     = today;
    function _updateFreeLabel() {
      var pbc = freeSlots.filter(function(s) {
        return pendingDayChanges[s.slotId] && pendingDayChanges[s.slotId].action === 'book';
      }).length;
      var n = freeSlots.length - pbc;
      freeLabel.textContent = n + ' freie Slot' + (n !== 1 ? 's' : '');
    }
    function _repopulateFree() {
      _updateFreeLabel();
      var freeBlock = {
        dateStr: _freeDayDateStr, today: _freeDayToday,
        start: freeSlots[0].time,
        end: AppService.slotEndTime(freeSlots[freeSlots.length - 1].time),
        bookedSlots: [], hasPending: false, isFullyConfirmed: false,
        teacherId: _freeDayTeacherId
      };
      populateBookingDetail(freeDetail, freeBlock, {
        pendingMap:    pendingDayChanges,
        getSlots:      function() { return AppService.getSlotsByTeacherDateSync(_freeDayTeacherId, _freeDayDateStr); },
        showFreeSlots: true,
        stuId:         currentUser.uid,
        onConfirmSlot: null,
        onAddSlot:     function(s, map) {
          map[s.slotId] = { action: 'book', originalSlot: s, newStudentId: currentUser.uid };
        },
        onCancelSlot:  function(s, map, onAction) {
          /* Show policy/refund warning dialog — same as in booked-block detail */
          var endTime     = AppService.slotEndTime(s.time);
          var teacherName = ProfileStore.getDisplayName(_freeDayTeacherId);
          var _savedTeacherId = _freeDayTeacherId;
          var _savedDateStr   = _freeDayDateStr;
          _showCancelPolicyDialog(s, map, function() {
            updateDaySaveBtn();
            _updateMyBookingsBadges();
            renderMyBookingsList();
            var allSlots = AppService.getSlotsByTeacherDateSync(_savedTeacherId, _savedDateStr)
              .filter(function(sl) { return sl.status === 'booked' && sl.studentId === currentUser.uid; });
            if (allSlots.length) {
              allSlots.sort(function(a, b) { return a.time.localeCompare(b.time); });
              var newKey = _savedDateStr + '-' + allSlots[0].time + '-' + _savedTeacherId;
              expandedStudentBlocks[newKey] = true;
            }
            _repopulateFree();
            renderDaySlots();
          }, teacherName, s.time, endTime, s.date);
        },
        onAction: function() {
          updateDaySaveBtn();
          _updateMyBookingsBadges();
          renderMyBookingsList();
          _repopulateFree();
        }
      });
    }
    _repopulateFree();
    (function(hdr, det, chv) {
      function toggle() {
        var open = det.classList.contains('is-open');
        det.classList.toggle('is-open', !open);
        chv.classList.toggle('is-open', !open);
        _daySlotsFreeOpen = !open;
      }
      hdr.addEventListener('click', toggle);
      hdr.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });
    })(freeHeader, freeDetail, freeChevron);
    freeWrapper.appendChild(freeHeader);
    freeWrapper.appendChild(freeDetail);
    container.appendChild(freeWrapper);
  }

  /* 6. Render booked blocks — auto-expand blocks with pending changes */
  for (var bi = 0; bi < blocks.length; bi++) {
    var blk = blocks[bi];
    if (blk.hasPending) {
      var blockKey = blk.dateStr + '-' + blk.start + '-' + blk.teacherId;
      expandedStudentBlocks[blockKey] = true;
    }
    container.appendChild(_buildStudentBookingBlock(blk, isPast));
  }
}


var _closeSgridTeacherDropdown = null;

function openStudentGrid() {
  if (!activeTeacherId) return;

  /* Start on current week (Monday) */
  if (!sgridWeekStart) {
    var monday = new Date(TODAY);
    var dow = monday.getDay();
    dow = (dow === 0) ? 6 : dow - 1;
    monday.setDate(monday.getDate() - dow);
    sgridWeekStart = monday;
  }

  _buildSgridTeacherDropdown();

  document.getElementById('student-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  _sgridMaterialiseAndRender();
}

function _buildSgridTeacherDropdown() {
  var list    = document.getElementById('sgrid-teacher-list');
  var label   = document.getElementById('sgrid-teacher-name');
  var trigger = document.getElementById('sgrid-teacher-trigger');
  if (!list || !label || !trigger) return;

  var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(sel) { return AppService.getUserSync(sel.teacherId); })
    .filter(Boolean);

  if (!myTeachers.length) {
    label.textContent = 'Kein Lehrer';
    return;
  }

  /* Ensure activeTeacherId is valid */
  if (!activeTeacherId || !myTeachers.some(function(t) { return t.uid === activeTeacherId; })) {
    activeTeacherId = myTeachers[0].uid;
  }

  function sgridSetTeacher(uid) {
    activeTeacherId = uid;
    label.textContent = ProfileStore.getDisplayName(uid);
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var k = 0; k < items.length; k++) {
      var active = items[k].getAttribute('data-value') === uid;
      items[k].classList.toggle('is-active', active);
      items[k].setAttribute('aria-selected', active ? 'true' : 'false');
    }
    list.classList.remove('is-open');
    trigger.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    renderStudentGrid();
  }

  /* Rebuild list */
  list.innerHTML = '';
  for (var i = 0; i < myTeachers.length; i++) {
    (function(teacher) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (teacher.uid === activeTeacherId ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', teacher.uid);
      li.setAttribute('aria-selected', teacher.uid === activeTeacherId ? 'true' : 'false');
      li.textContent = ProfileStore.getDisplayName(teacher.uid);
      li.addEventListener('click', function(e) {
        e.stopPropagation();
        sgridSetTeacher(teacher.uid);
      });
      list.appendChild(li);
    })(myTeachers[i]);
  }

  label.textContent = ProfileStore.getDisplayName(activeTeacherId);

  trigger.onclick = function(e) {
    e.stopPropagation();
    var isOpen = list.classList.contains('is-open');
    list.classList.toggle('is-open', !isOpen);
    trigger.classList.toggle('is-open', !isOpen);
    trigger.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
  };

  document.removeEventListener('click', _closeSgridTeacherDropdown);
  _closeSgridTeacherDropdown = function() {
    list.classList.remove('is-open');
    trigger.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
  };
  document.addEventListener('click', _closeSgridTeacherDropdown);
}

function closeStudentGrid() {
  document.getElementById('student-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  renderStats();
}

function sgridPrevWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() - 7);
  _sgridMaterialiseAndRender();
}

function sgridNextWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() + 7);
  _sgridMaterialiseAndRender();
}

/* Materialise ALL selected teachers for current week, then render */
function _sgridMaterialiseAndRender() {
  var weekDates  = getSgridWeekDates();
  var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(sel) { return AppService.getUserSync(sel.teacherId); })
    .filter(Boolean);

  var total   = myTeachers.length;
  var done    = 0;
  if (!total) { renderStudentGrid(); return; }

  myTeachers.forEach(function(t) {
    AppService.materialiseWeek(t.uid, weekDates, function(e) {
      if (e) Toast.error(e.message || e);
      done++;
      if (done === total) renderStudentGrid();
    });
  });
}

/* ── Week grid render ───────────────────────────────────── */
function renderStudentGrid() {
  var weekDates = getSgridWeekDates();
  var times     = AppService.slotTimesInRange(GRID_START, GRID_END);

  document.getElementById('sgrid-week-label').textContent = sgridWeekRangeLabel(weekDates);

  // Pre-build slot lookup for ALL selected teachers: "tid|date|time" → slot
  var myTeacherIds = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(sel) { return sel.teacherId; });
  var allSlots = AppService.getAllSlotsSync();
  var slotMap  = {};
  for (var si = 0; si < allSlots.length; si++) {
    var s = allSlots[si];
    if (myTeacherIds.indexOf(s.teacherId) !== -1) {
      slotMap[s.teacherId + '|' + s.date + '|' + s.time] = s;
    }
  }

  var container = document.getElementById('sgrid-content');
  container.innerHTML = '';

  var table = document.createElement('table');
  table.className = 'slot-grid-table';

  // ── thead ──
  var thead = document.createElement('thead');
  var hrow  = document.createElement('tr');
  var thTime = document.createElement('th');
  thTime.className = 'grid-th-time';
  thTime.textContent = 'Time';
  hrow.appendChild(thTime);

  for (var d = 0; d < weekDates.length; d++) {
    var wd      = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var th = document.createElement('th');
    th.className = 'grid-th-day';
    if (isToday) th.classList.add('grid-th-today');
    var nameSpan = document.createElement('span');
    nameSpan.className = 'grid-day-name';
    nameSpan.textContent = DAY_NAMES[d];
    var numSpan = document.createElement('span');
    numSpan.className = 'grid-day-num';
    if (isToday) numSpan.classList.add('grid-day-today');
    numSpan.textContent = wd.getDate();
    th.appendChild(nameSpan);
    th.appendChild(numSpan);
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // ── tbody ──
  var tbody = document.createElement('tbody');

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    var tr   = document.createElement('tr');
    var tdTime = document.createElement('td');
    tdTime.className = 'grid-td-time';
    tdTime.textContent = time;
    tr.appendChild(tdTime);

    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var isPastDay   = cellDate < TODAY;

      // Active teacher slot
      var slot         = slotMap[activeTeacherId + '|' + cellDateStr + '|' + time] || null;
      var pendingEntry = slot ? pendingDayChanges[slot.slotId] : null;

      // Check if another selected teacher has this student booked here
      var otherSlot = null;
      for (var ti = 0; ti < myTeacherIds.length; ti++) {
        if (myTeacherIds[ti] === activeTeacherId) continue;
        var os = slotMap[myTeacherIds[ti] + '|' + cellDateStr + '|' + time];
        if (os && os.status === 'booked' && os.studentId === currentUser.uid) {
          otherSlot = os;
          break;
        }
      }

      var cellClass;
      var isClickable = false;

      if (isPastDay) {
        cellClass = otherSlot ? 'gc-other' : 'gc-empty';
      } else if (!slot || slot.status === 'disabled' || slot.status === 'timeout') {
        if (pendingEntry && pendingEntry.action === 'book') {
          cellClass   = 'gc-available gc-pending';
          isClickable = true;
        } else {
          cellClass = otherSlot ? 'gc-other' : 'gc-empty';
        }
      } else if (slot.status === 'available' || slot.status === 'recurring') {
        if (pendingEntry && pendingEntry.action === 'book') {
          cellClass = 'gc-mine gc-pending';
        } else {
          cellClass = otherSlot ? 'gc-other' : 'gc-available';
        }
        isClickable = !otherSlot;
      } else if (slot.status === 'booked' && slot.studentId === currentUser.uid) {
        cellClass   = (pendingEntry && pendingEntry.action === 'cancel') ? 'gc-available gc-pending' : 'gc-mine';
        isClickable = true;
      } else {
        cellClass = otherSlot ? 'gc-other' : 'gc-empty';
      }

      var td   = document.createElement('td');
      td.className = 'grid-td-cell';
      var cell = document.createElement('div');
      cell.className      = 'grid-cell ' + cellClass;
      cell.dataset.date   = cellDateStr;
      cell.dataset.time   = time;
      cell.dataset.slotid = slot ? slot.slotId : '';

      if (isClickable) cell.addEventListener('click', onStudentCellClick);

      td.appendChild(cell);
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  container.appendChild(table);
}

function onStudentCellClick(e) {
  var cell   = e.currentTarget;
  var date   = cell.dataset.date;
  var time   = cell.dataset.time;
  var slotId = cell.dataset.slotid;
  var isMine = cell.classList.contains('gc-mine');

  /* Get the real slot */
  var slot = slotId
    ? AppService.getAllSlotsSync().filter(function(x) { return x.slotId === slotId; })[0]
    : AppService.slotExistsSync(activeTeacherId, date, time);

  if (!slot) return;

  var pendingEntry = pendingDayChanges[slot.slotId];
  var teacherName  = ProfileStore.getDisplayName(activeTeacherId);
  var endTime      = AppService.slotEndTime(time);

  if (isMine || (pendingEntry && pendingEntry.action === 'cancel')) {

    /* Staged book — clicking again just undoes it, no dialog needed */
    if (pendingEntry && pendingEntry.action === 'book') {
      delete pendingDayChanges[slot.slotId];
      updateDaySaveBtn();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderStudentGrid();
      return;
    }

    /* Booked (or staged cancel) — show popover with info + Stornieren/Undo */
    if (slot.confirmedAt && !pendingEntry) {
      Toast.error('Best\u00E4tigte Buchungen k\u00F6nnen nicht storniert werden.');
      return;
    }
    var isStaged = !!(pendingEntry && pendingEntry.action === 'cancel');
    var result = Modal.show({
      title: isStaged ? 'Stornierung vorgemerkt' : 'Buchung',
      bodyHTML:
        '<div class="move-dialog">' +
          '<p class="move-dialog-info"><strong>' + teacherName + '</strong></p>' +
          '<p>' + time + ' \u2013 ' + endTime + ' &nbsp;&bull;&nbsp; ' + date + '</p>' +
          (isStaged ? '<p class="confirm-dialog-warning" style="margin-top:8px">\u26a0 Stornierung vorgemerkt \u2014 noch nicht gespeichert.</p>' : '') +
        '</div>',
      footerHTML:
        '<button class="btn btn-ghost" id="modal-cancel">Schlie\u00dfen</button>' +
        (slot.confirmedAt
          ? ''
          : '<button class="btn ' + (isStaged ? 'btn-ghost' : 'btn-danger') + '" id="modal-action">' +
            (isStaged ? 'Undo' : 'Stornieren') + '</button>')
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    var actionBtn = document.getElementById('modal-action');
    if (actionBtn) {
      actionBtn.addEventListener('click', function() {
        if (isStaged) {
          /* Undo staged cancel */
          delete pendingDayChanges[slot.slotId];
          updateDaySaveBtn();
          _updateMyBookingsBadges();
          renderMyBookingsList();
          renderStudentGrid();
          result.close();
        } else {
          /* Show policy dialog directly — single click, no intermediate step */
          result.close();
          _showCancelPolicyDialog(slot, pendingDayChanges, function() {
            updateDaySaveBtn();
            _updateMyBookingsBadges();
            renderMyBookingsList();
            renderStudentGrid();
          }, teacherName, time, endTime, date);
        }
      });
    }

  } else if (slot.status === 'available' || slot.status === 'recurring') {
    /* Free slot — undo or show confirm dialog */
    if (pendingEntry && pendingEntry.action === 'book') {
      /* Undo staged book */
      delete pendingDayChanges[slot.slotId];
      updateDaySaveBtn();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderStudentGrid();
    } else {
      /* Confirm dialog before staging */
      var bookResult = Modal.show({
        title: 'Slot buchen?',
        bodyHTML:
          '<div class="move-dialog">' +
            '<p class="move-dialog-info"><strong>' + teacherName + '</strong></p>' +
            '<p>' + time + ' \u2013 ' + endTime + ' &nbsp;&bull;&nbsp; ' + date + '</p>' +
          '</div>',
        footerHTML:
          '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
          '<button class="btn btn-primary" id="modal-action">Buchen</button>'
      });
      document.getElementById('modal-cancel').addEventListener('click', bookResult.close);
      document.getElementById('modal-action').addEventListener('click', function() {
        pendingDayChanges[slot.slotId] = { action: 'book', originalSlot: slot, newStudentId: currentUser.uid };
        updateDaySaveBtn();
        _updateMyBookingsBadges();
        renderMyBookingsList();
        renderStudentGrid();
        bookResult.close();
      });
    }
  }
}

/* ── Helpers ────────────────────────────────────────────── */
function getSgridWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(sgridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function sgridWeekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

/* ════════════════════════════════════════════════════════
   DAY NAV BAR — ported from teacher.js, renderDayPanel → renderDaySlots
═══════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════
   MY BOOKINGS
══════════════════════════════════════════════════════════ */
function renderMyBookings() {
  /* ── Teacher dropdown — mirrors teacher's student dropdown in All Bookings ── */
  var mbTeacherList    = document.getElementById('mb-teacher-list');
  var mbTeacherLabel   = document.getElementById('mb-teacher-label');
  var mbTeacherTrigger = document.getElementById('mb-teacher-trigger');

  if (mbTeacherList && mbTeacherLabel && mbTeacherTrigger) {
    var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
      .map(function(s) { return AppService.getUserSync(s.teacherId); })
      .filter(Boolean);

    var mbOptions = [{ value: 'all', text: 'Alle Lehrer' }];
    for (var ti = 0; ti < myTeachers.length; ti++) {
      mbOptions.push({ value: myTeachers[ti].uid, text: ProfileStore.getDisplayName(myTeachers[ti].uid) });
    }

    function mbSetTeacher(val) {
      _setFilter('student', val);
      var sel = mbOptions.filter(function(o) { return o.value === val; })[0] || mbOptions[0];
      mbTeacherLabel.textContent = sel.text;
      var items = mbTeacherList.querySelectorAll('.custom-dropdown-item');
      for (var k = 0; k < items.length; k++) {
        items[k].classList.toggle('is-active', items[k].getAttribute('data-value') === val);
      }
      mbTeacherList.classList.remove('is-open');
      mbTeacherTrigger.classList.remove('is-open');
      mbTeacherTrigger.setAttribute('aria-expanded', 'false');
      _updateMyBookingsBadges();
      renderMyBookingsList();
    }

    mbTeacherList.innerHTML = '';
    for (var oi = 0; oi < mbOptions.length; oi++) {
      (function(opt) {
        var li = document.createElement('li');
        li.className = 'custom-dropdown-item' + (opt.value === bookingsFilter.student ? ' is-active' : '');
        li.setAttribute('role', 'option');
        li.setAttribute('data-value', opt.value);
        li.setAttribute('aria-selected', opt.value === bookingsFilter.student ? 'true' : 'false');
        li.textContent = opt.text;
        li.addEventListener('click', function(e) { e.stopPropagation(); mbSetTeacher(opt.value); });
        mbTeacherList.appendChild(li);
      })(mbOptions[oi]);
    }

    var curOpt = mbOptions.filter(function(o) { return o.value === bookingsFilter.student; })[0] || mbOptions[0];
    mbTeacherLabel.textContent = curOpt.text;

    mbTeacherTrigger.onclick = function(e) {
      e.stopPropagation();
      var isOpen = mbTeacherList.classList.contains('is-open');
      mbTeacherList.classList.toggle('is-open', !isOpen);
      mbTeacherTrigger.classList.toggle('is-open', !isOpen);
      mbTeacherTrigger.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
    };
    document.removeEventListener('click', _closeMbTeacherDropdown);
    _closeMbTeacherDropdown = function() {
      mbTeacherList.classList.remove('is-open');
      mbTeacherTrigger.classList.remove('is-open');
      mbTeacherTrigger.setAttribute('aria-expanded', 'false');
    };
    document.addEventListener('click', _closeMbTeacherDropdown);
  }

  /* ── Sort + Date-Range row — shared with teacher ── */
  var sortDateContainer = document.getElementById('mb-sort-date-row');
  if (sortDateContainer) {
    sortDateContainer.innerHTML = '';
    sortDateContainer.appendChild(_buildSortDateRangeRow(function() {
      renderMyBookingsList();
    }));
  }

  /* ── Zeitfilter-Buttons ── */
  var timeBtns = document.querySelectorAll('.mb-time-btn');
  for (var t = 0; t < timeBtns.length; t++) {
    timeBtns[t].classList.toggle('active', timeBtns[t].id === 'mb-filter-' + bookingsFilter.time);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('time', btn.id.replace('mb-filter-', ''));
        allBookingsSortAsc = (bookingsFilter.time !== 'past');
        for (var j = 0; j < timeBtns.length; j++) timeBtns[j].classList.remove('active');
        btn.classList.add('active');
        _updateMyBookingsBadges();
        renderMyBookingsList();
      };
    })(timeBtns[t]);
  }

  /* ── Statusfilter-Buttons ── */
  var confirmBtns = document.querySelectorAll('.mb-confirm-btn');
  for (var ci = 0; ci < confirmBtns.length; ci++) {
    confirmBtns[ci].classList.toggle('active', confirmBtns[ci].dataset.confirm === bookingsFilter.confirmed);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('confirmed', btn.dataset.confirm);
        for (var cj = 0; cj < confirmBtns.length; cj++) confirmBtns[cj].classList.remove('active');
        btn.classList.add('active');
        _updateMyBookingsBadges();
        renderMyBookingsList();
      };
    })(confirmBtns[ci]);
  }

  _updateMyBookingsBadges();
  renderMyBookingsList();
}

/* Student wrapper for shared badge updater */
function _updateMyBookingsBadges() {
  _updateBookingBadges({
    getSlots:    function() {
      return AppService.getSlotsByStudentSync(currentUser.uid)
        .filter(function(s) { return s.status === 'booked'; });
    },
    partyField:  'teacherId',
    mergeFn:     _mergeStudentBookingBlocks,
    priceFn:     function(s) { return parseFloat(s.price) || 0; },
    badgePrefix: 'mb-',
    containerId: null
  });
}

function renderMyBookingsList() {
  var container = document.getElementById('my-bookings-list');
  if (!container) return;
  container.innerHTML = '';

  var today = fmtDate(new Date());

  /* Mirror teacher renderAllBookingsList:
     - Keep status=booked slots from Store
     - Map pending-cancel to _pending='cancel' WITHOUT changing status (so they stay visible)
     - Add pending-book slots that aren't yet in Store */
  var storeBooked = AppService.getSlotsByStudentSync(currentUser.uid)
    .filter(function(s) { return s.status === 'booked'; })
    .map(function(s) {
      var p = pendingDayChanges[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  /* Also include pending-book slots not yet in Store */
  var pendingBookSlots = Object.keys(pendingDayChanges)
    .filter(function(id) {
      var p = pendingDayChanges[id];
      return p.action === 'book' &&
        !storeBooked.some(function(s) { return s.slotId === id; });
    })
    .map(function(id) {
      var s = {}; for (var k in pendingDayChanges[id].originalSlot) s[k] = pendingDayChanges[id].originalSlot[k];
      s.status    = 'booked';
      s.studentId = currentUser.uid;
      s._pending  = 'book';
      return s;
    });

  var slots = storeBooked.concat(pendingBookSlots);

  /* Teacher filter */
  if (bookingsFilter.student !== 'all') {
    slots = slots.filter(function(s) { return s.teacherId === bookingsFilter.student; });
  }

  slots = _applyTimeFilter(slots, bookingsFilter.time, today);
  slots = _applyDateRangeFilter(slots);

  if (bookingsFilter.confirmed === 'confirmed')   slots = slots.filter(function(s) { return !!s.confirmedAt; });
  else if (bookingsFilter.confirmed === 'unconfirmed') slots = slots.filter(function(s) { return !s.confirmedAt; });

  var emptyReasons = {
    past:     'Keine vergangenen Buchungen.',
    upcoming: 'Keine kommenden Buchungen.',
    all:      'Keine Buchungen gefunden.'
  };

  if (!slots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = emptyReasons[bookingsFilter.time] || 'Keine Buchungen gefunden.';
    container.appendChild(empty);
    return;
  }

  slots.sort(function(a, b) {
    return a.date.localeCompare(b.date) || a.time.localeCompare(b.time);
  });

  /* Gruppe nach Datum */
  var byDate    = {};
  var dateOrder = [];
  for (var i = 0; i < slots.length; i++) {
    var s = slots[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  if (!allBookingsSortAsc) { dateOrder.reverse(); }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr   = dateOrder[d];
    var dateSlots = byDate[dateStr];
    var isPast    = dateStr < today;

    /* ── Datum-Headline (wie Teacher) ── */
    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider' + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    container.appendChild(divider);

    /* ── Blöcke: konsekutive Slots desselben Lehrers zusammenfassen ── */
    var blocks = _mergeStudentBookingBlocks(dateStr, dateSlots, today);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(_buildStudentBookingBlock(blocks[b], isPast));
    }
  }
}

/* Fasst aufeinanderfolgende Slots desselben Lehrers zu einem Block zusammen */
/* Student wrapper — merges by teacherId, resolves teacher display name */
function _mergeStudentBookingBlocks(dateStr, slots, today) {
  return mergeBookingBlocks(dateStr, slots, today, {
    groupField:   'teacherId',
    resolveParty: function(s) { return { teacherId: s.teacherId }; }
  });
}

/* Student wrapper for shared buildBookingBlock */
function _buildStudentBookingBlock(block, isPast) {
  return buildBookingBlock(block, {
    showDate:       false,
    isPast:         isPast,
    expandedBlocks: expandedStudentBlocks,
    blockKeyFn:     function(b) { return b.dateStr + '-' + b.start + '-' + b.teacherId; },
    nameFn:         function(b) { return ProfileStore.getDisplayName(b.teacherId); },
    priceFn:        function(b) {
      var lockedPrice = b.bookedSlots && b.bookedSlots[0] && b.bookedSlots[0].price;
      var price = parseFloat(lockedPrice) || 0;
      if (!price || isNaN(price)) return '';
      return fmtPrice(price * b.bookedSlots.length);
    },
    onConfirmBlock: function(b) { _openStudentConfirmBlockDialog(b); },
    onEditBlock:    function(b) { _openStudentEditBlockDialog(b); },
    onReleaseBlock: null,
    onExpand:       function() { _daySlotsFreeOpen = false; },
    populateDetail: function(det, b) { _populateStudentBlockDetail(det, b, isPast); }
  });
}

/* Student wrapper for shared populateBookingDetail */
function _populateStudentBlockDetail(detail, block, isPast) {
  var teacherName = ProfileStore.getDisplayName(block.teacherId);
  populateBookingDetail(detail, block, {
    pendingMap:    pendingDayChanges,
    getSlots:      function(b) { return AppService.getSlotsByTeacherDateSync(b.teacherId, b.dateStr); },
    showFreeSlots: !block.isFullyConfirmed && !isPast,
    stuId:         currentUser.uid,
    onConfirmSlot: function(slotId) { _openStudentConfirmDialog(slotId); },
    slotPriceFn:   function(slot) { return fmtPrice(slot.price); },
    onAddSlot:     function(s, map) {
      map[s.slotId] = { action: 'book', originalSlot: s, newStudentId: currentUser.uid };
    },
    onCancelSlot:  function(s, map, onAction) {
      var endTime = AppService.slotEndTime(s.time);
      /* Save the block's key so we can re-open it after renderDaySlots rebuilds the DOM.
         The block may shrink (cancelled slot removed) so the start time could shift —
         we persist the TEACHER+DATE so any surviving block for this teacher/day reopens. */
      var _savedTeacherId = block.teacherId;
      var _savedDateStr   = block.dateStr;
      _showCancelPolicyDialog(s, map, function() {
        updateDaySaveBtn();
        _updateMyBookingsBadges();
        renderMyBookingsList();
        /* Re-open the surviving block for this teacher/date after full re-render */
        var allSlots = AppService.getSlotsByTeacherDateSync(_savedTeacherId, _savedDateStr)
          .filter(function(sl) { return sl.status === 'booked' && sl.studentId === currentUser.uid; });
        if (allSlots.length) {
          allSlots.sort(function(a, b) { return a.time.localeCompare(b.time); });
          var newKey = _savedDateStr + '-' + allSlots[0].time + '-' + _savedTeacherId;
          expandedStudentBlocks[newKey] = true;
        }
        renderDaySlots();
      }, teacherName, s.time, endTime, s.date);
    },
    onAction: function() {
      updateDaySaveBtn();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderDaySlots();  /* rebuild so amber/undo state reflects correctly */
    }
  });
}
function _openStudentConfirmBlockDialog(block) {
  var teacherName = ProfileStore.getDisplayName(block.teacherId);
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">⚠ <strong>Achtung:</strong> Diese Aktion kann nicht rückgängig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Bestätigung deiner Buchung bei <strong>' + teacherName + '</strong> (' + block.start + ' – ' + block.end + '):</p>' +
      '<ul class="confirm-dialog-list">' +
        '<li>kann die Buchung <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung für diese Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';
  var result = Modal.show({
    title: 'Buchung bestätigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
                '<button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    result.close();
    AppService.confirmBlock(block.bookedSlots, function(e) {
      if (e) { Toast.error('Fehler bei der Bestätigung: ' + (e.message || e)); return; }
      Toast.success('Buchung bestätigt.');
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      if (typeof WalletPanel !== 'undefined') WalletPanel.refresh(currentUser.uid);
    });
  });
}

/* Student Edit Block Dialog — reuses openMoveBlockDialogShared from ui.js */
function _openStudentEditBlockDialog(block) {
  /* Use displayName override so teacher name shows correctly regardless of profile state */
  var teacherName = ProfileStore.getDisplayName(block.teacherId);

  /* Build block with student field for compatibility with openMoveBlockDialogShared */
  var studentBlock = {};
  for (var k in block) studentBlock[k] = block[k];
  studentBlock.student = { uid: currentUser.uid }; /* needed for slot lookup context */

  openMoveBlockDialogShared({
    block:        studentBlock,
    teacherId:    block.teacherId,
    actorRole:    'student',
    pendingMap:   pendingDayChanges,  /* wire student pending system */
    stuId:        currentUser.uid,
    displayName:  teacherName,        /* override: show teacher name, not student name */
    onConfirmBlock: function() {
      pendingDayChanges = {};
      updateDaySaveBtn();
      _updateMyBookingsBadges();
      renderMyBookingsList();
    },
    onCancelBlock: function() {
      pendingDayChanges = {};
      updateDaySaveBtn();
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderCalendar();
      renderDaySlots();  /* refresh day view so cancelled slots are no longer shown */
      /* WalletPanel.refresh and navbar update are handled inside
         _showCancelBlockPolicyDialog before onAction fires — no duplicate call here */
    },
    onConfirm: function() {
      updateDaySaveBtn();
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderCalendar();
      renderDaySlots();
    },
    onCalJump: function(dateStr) {
      if (!dateStr) return;
      var d = new Date(dateStr + 'T00:00:00');
      d.setHours(0,0,0,0);
      selectedDate = d;
      viewYear  = d.getFullYear();
      viewMonth = d.getMonth();
      switchView('calendar');
    }
  });
}

/* Block-Level Stornierung (alle Slots des Blocks) */
function _openStudentConfirmDialog(slotId) {
  var slot = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === slotId; })[0];
  if (!slot) return;
  var teacherName = ProfileStore.getDisplayName(slot.teacherId);
  var endTime     = AppService.slotEndTime(slot.time);

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">\u26a0 <strong>Achtung:</strong> Diese Aktion kann nicht r\u00FCckg\u00E4ngig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Best\u00E4tigung deiner Buchung bei <strong>' + teacherName + '</strong> (' + slot.time + ' \u2013 ' + endTime + '):</p>' +
      '<ul class="confirm-dialog-list">' +
        '<li>kann die Buchung <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung f\u00FCr diese Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';

  var result = Modal.show({
    title: 'Buchung best\u00E4tigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>'
             + '<button class="btn btn-primary" id="modal-confirm">Jetzt best\u00E4tigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      AppService.confirmSlot(slotId, function(e){if(e)Toast.error(e.message||e);});
      Toast.success('Buchung best\u00E4tigt.');
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      result.close();
    } catch (e) {
      Toast.error('Fehler bei der Best\u00E4tigung: ' + e.message);
      result.close();
    }
  });
}

function getSectionJumpTargets() {
  if (activeView === 'my-bookings') {
    var dividers = document.querySelectorAll('#view-my-bookings .all-bookings-day-divider');
    var pageTop  = document.querySelector('.page-header') || document.getElementById('view-my-bookings');
    if (dividers.length) return [pageTop].concat(Array.prototype.slice.call(dividers)).filter(Boolean);
    return [pageTop].filter(Boolean);
  }
  if (activeView === 'calendar') {
    return [
      document.querySelector('.page-header'),
      document.getElementById('cal-section'),
      document.getElementById('day-slots-wrapper')
    ].filter(Boolean);
  }
  return [document.querySelector('.page-header')].filter(Boolean);
}

/* Thin wrappers — call shared ui.js implementations with local render functions */
function navDay(delta)   { _navDayShared(delta, renderDaySlots); }
function navMonth(delta) { _navMonthShared(delta, renderDaySlots); }
function checkDayNavSticky() { checkDayNavStickyShared('day-slots-wrapper'); }

function updateJumpBtns() { _updateJumpBtnsShared((activeView === 'my-bookings' || activeView === 'calendar') && getSectionJumpTargets().length > 1); }

function prevMonth() { _prevMonthShared(renderDaySlots); }
function nextMonth() { _nextMonthShared(renderDaySlots); }
