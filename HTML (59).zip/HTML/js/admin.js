/**
 * admin.js — Admin View Logic
 *
 * Regeln: var only, function(){}, no arrow, no template literals,
 *         no ?. or ??, kein inline-style — classList only.
 */

var currentUser      = null;
var activeTab        = 'teacher';
var activeMainTab    = 'users';
var activeEscrowFilter = 'held';

window.addEventListener('load', function() {
  currentUser = Auth.require('admin');
  if (!currentUser) return;
  Navbar.init('admin');

  /* ── Haupt-Tabs (Benutzer / Zahlungen) ── */
  var mainTabBtns = document.querySelectorAll('.admin-tab-btn');
  for (var m = 0; m < mainTabBtns.length; m++) {
    (function(btn) {
      btn.addEventListener('click', function() {
        activeMainTab = btn.dataset.mainTab;
        for (var i = 0; i < mainTabBtns.length; i++) { mainTabBtns[i].classList.remove('active'); }
        btn.classList.add('active');
        document.getElementById('admin-tab-users').style.display    = activeMainTab === 'users'    ? '' : 'none';
        document.getElementById('admin-tab-payments').style.display = activeMainTab === 'payments' ? '' : 'none';
        document.getElementById('admin-tab-audit').style.display    = activeMainTab === 'audit'    ? '' : 'none';
        if (activeMainTab === 'payments') renderEscrows();
        if (activeMainTab === 'audit')    renderAuditLog();
      });
    })(mainTabBtns[m]);
  }

  /* ── User-Tab-Wechsel (Lehrer / Schüler) ── */
  var tabBtns = document.querySelectorAll('.segmented-btn');
  for (var t = 0; t < tabBtns.length; t++) {
    (function(btn) {
      btn.addEventListener('click', function() {
        activeTab = btn.dataset.tab;
        for (var i = 0; i < tabBtns.length; i++) { tabBtns[i].classList.remove('active'); }
        btn.classList.add('active');
        renderTable();
      });
    })(tabBtns[t]);
  }

  /* ── Escrow-Filter-Chips ── */
  var escrowFilters = document.querySelectorAll('[data-escrow-filter]');
  for (var ef = 0; ef < escrowFilters.length; ef++) {
    (function(chip) {
      chip.addEventListener('click', function() {
        activeEscrowFilter = chip.dataset.escrowFilter;
        for (var i = 0; i < escrowFilters.length; i++) { escrowFilters[i].classList.remove('active'); }
        chip.classList.add('active');
        renderEscrows();
      });
    })(escrowFilters[ef]);
  }

  /* ── Escrow Aktualisieren ── */
  var refreshBtn = document.getElementById('escrow-refresh-btn');
  if (refreshBtn) refreshBtn.addEventListener('click', renderEscrows);

  /* ── Disziplin-Gruppe toggle ── */
  _bindAdminDropdowns();

  var createForm = document.getElementById('create-form');
  if (createForm) createForm.addEventListener('submit', handleCreate);

  renderStats();
  renderTable();
});

/* ── Custom Dropdown Binding (Admin) ──────────────────── */
function _bindAdminDropdowns() {
  var dropdowns = document.querySelectorAll('.custom-dropdown[data-dropdown-id]');

  function _closeAll(except) {
    var open = document.querySelectorAll('.custom-dropdown-trigger.is-open');
    for (var i = 0; i < open.length; i++) {
      if (open[i] === except) continue;
      open[i].classList.remove('is-open');
      open[i].setAttribute('aria-expanded', 'false');
      var ddId = open[i].getAttribute('data-dropdown-trigger');
      var lst  = document.querySelector('[data-dropdown-list="' + ddId + '"]');
      if (lst) lst.classList.remove('is-open');
    }
  }

  for (var d = 0; d < dropdowns.length; d++) {
    (function(dd) {
      var ddId    = dd.getAttribute('data-dropdown-id');
      var trigger = dd.querySelector('.custom-dropdown-trigger');
      var list    = dd.querySelector('.custom-dropdown-list');
      var label   = dd.querySelector('.custom-dropdown-label');
      if (!trigger || !list || !label) return;

      /* Init value */
      dd.setAttribute('data-dropdown-value', '');

      trigger.addEventListener('click', function(e) {
        e.stopPropagation();
        var isOpen = trigger.classList.contains('is-open');
        _closeAll(trigger);
        trigger.classList.toggle('is-open', !isOpen);
        trigger.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
        list.classList.toggle('is-open', !isOpen);
      });

      var items = list.querySelectorAll('.custom-dropdown-item');
      for (var i = 0; i < items.length; i++) {
        (function(item) {
          item.addEventListener('click', function(e) {
            e.stopPropagation();
            var val = item.getAttribute('data-value');
            var allItems = list.querySelectorAll('.custom-dropdown-item');
            for (var j = 0; j < allItems.length; j++) {
              allItems[j].classList.remove('is-active');
              allItems[j].setAttribute('aria-selected', 'false');
            }
            item.classList.add('is-active');
            item.setAttribute('aria-selected', 'true');
            label.textContent = item.textContent;
            dd.setAttribute('data-dropdown-value', val || '');
            trigger.classList.remove('is-open');
            trigger.setAttribute('aria-expanded', 'false');
            list.classList.remove('is-open');

            /* Disziplin-Gruppe ein-/ausblenden wenn Rolle gewählt */
            if (ddId === 'f-role') {
              var grp = document.getElementById('discipline-group');
              if (grp) grp.classList.toggle('is-hidden', val !== 'teacher');
              if (val !== 'teacher') {
                var discDd = document.getElementById('dd-discipline');
                if (discDd) {
                  discDd.setAttribute('data-dropdown-value', '');
                  var discLabel = discDd.querySelector('.custom-dropdown-label');
                  if (discLabel) discLabel.textContent = 'Fachbereich wählen…';
                  var discItems = discDd.querySelectorAll('.custom-dropdown-item');
                  for (var k = 0; k < discItems.length; k++) {
                    discItems[k].classList.remove('is-active');
                    discItems[k].setAttribute('aria-selected', 'false');
                  }
                }
              }
            }
          });
        })(items[i]);
      }
    })(dropdowns[d]);
  }

  document.addEventListener('click', function(e) {
    /* Nur schließen wenn Klick außerhalb aller Dropdowns */
    var target = e.target;
    while (target && target !== document) {
      if (target.classList && target.classList.contains('custom-dropdown')) return;
      target = target.parentNode;
    }
    _closeAll(null);
  });
}

function _getAdminDropdownVal(id) {
  var dd = document.querySelector('[data-dropdown-id="' + id + '"]');
  return dd ? (dd.getAttribute('data-dropdown-value') || '') : '';
}

function _resetAdminDropdown(id, placeholder) {
  var dd = document.querySelector('[data-dropdown-id="' + id + '"]');
  if (!dd) return;
  dd.setAttribute('data-dropdown-value', '');
  var lbl = dd.querySelector('.custom-dropdown-label');
  if (lbl) lbl.textContent = placeholder;
  var items = dd.querySelectorAll('.custom-dropdown-item');
  for (var i = 0; i < items.length; i++) {
    items[i].classList.remove('is-active');
    items[i].setAttribute('aria-selected', 'false');
  }
}

/* ── CREATE ───────────────────────────────────────────── */
function handleCreate(e) {
  e.preventDefault();
  var uid        = document.getElementById('f-uid').value.trim();
  var name       = document.getElementById('f-name').value.trim();
  var email      = document.getElementById('f-email') ? document.getElementById('f-email').value.trim() : '';
  var role       = _getAdminDropdownVal('f-role');
  var password   = document.getElementById('f-password') ? document.getElementById('f-password').value : '';
  var discipline = role === 'teacher' ? _getAdminDropdownVal('f-discipline') : '';

  _clearErrors();
  var valid = true;
  if (!uid)  { _showError('e-uid',  'UID ist erforderlich.');  valid = false; }
  if (!name) { _showError('e-name', 'Name ist erforderlich.'); valid = false; }
  if (!role) { _showError('e-role', 'Rolle wählen.');          valid = false; }
  if (!valid) return;

  AppService.createUser({
    uid: uid, name: name, role: role,
    email: email, discipline: discipline, password: password
  }, function(err, newUser) {
    if (err) { Toast.error(err.message); return; }
    var roleLabel = role === 'teacher' ? 'Lehrer' : 'Schüler';
    Toast.success(roleLabel + ' <strong>' + (newUser ? newUser.name : name) + '</strong> erstellt.');
    e.target.reset();
    /* Dropdowns zurücksetzen */
    _resetAdminDropdown('f-role', 'Rolle wählen…');
    _resetAdminDropdown('f-discipline', 'Fachbereich wählen…');
    var grp = document.getElementById('discipline-group');
    if (grp) grp.classList.add('is-hidden');
    /* Tabelle auf neue Rolle wechseln */
    activeTab = role;
    var tabBtns = document.querySelectorAll('.segmented-btn');
    for (var i = 0; i < tabBtns.length; i++) {
      tabBtns[i].classList.toggle('active', tabBtns[i].dataset.tab === role);
    }
    renderStats();
    renderTable();
  });
}

/* ── EDIT ─────────────────────────────────────────────── */
function handleEdit(uid) {
  var user = AppService.getUserSync(uid);
  if (!user) return;

  var tpl = document.getElementById('tpl-edit-modal');
  var body = document.importNode(tpl.content, true);
  var wrapper = document.createElement('div');
  wrapper.appendChild(body);

  var nameInput  = wrapper.querySelector('#edit-name');
  var emailInput = wrapper.querySelector('#edit-email');
  var discInput  = wrapper.querySelector('#edit-discipline');
  var discGroup  = wrapper.querySelector('#edit-discipline-group');

  nameInput.value  = user.name  || '';
  emailInput.value = user.email || '';
  discInput.value  = user.discipline || '';

  /* Disziplin nur für Lehrer anzeigen */
  if (discGroup) {
    discGroup.classList.toggle('is-hidden', user.role !== 'teacher');
  }

  var result = Modal.show({
    title: 'Benutzer bearbeiten — ' + uid,
    bodyHTML: wrapper.innerHTML,
    footerHTML:
      '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '<button class="btn btn-primary" id="modal-save">Speichern</button>'
  });

  /* Werte nach Modal-Injection lesen */
  document.getElementById('edit-name').value  = user.name  || '';
  document.getElementById('edit-email').value = user.email || '';
  document.getElementById('edit-password').value  = '';
  document.getElementById('edit-discipline').value = user.discipline || '';

  document.getElementById('modal-cancel').addEventListener('click', result.close);

  document.getElementById('modal-save').addEventListener('click', function() {
    var newName  = document.getElementById('edit-name').value.trim();
    var newEmail = document.getElementById('edit-email').value.trim();
    var newPw    = document.getElementById('edit-password').value;
    var newDisc  = user.role === 'teacher'
      ? document.getElementById('edit-discipline').value.trim()
      : '';

    var errEl = document.getElementById('edit-e-name');
    if (!newName) {
      if (errEl) { errEl.textContent = 'Name ist erforderlich.'; errEl.classList.remove('is-hidden'); }
      return;
    }
    if (errEl) { errEl.textContent = ''; errEl.classList.add('is-hidden'); }

    AppService.updateUser(uid, { name: newName, email: newEmail, discipline: newDisc, password: newPw }, function(err) {
      if (err) { Toast.error(err.message); return; }
      Toast.success('Benutzer <strong>' + newName + '</strong> aktualisiert.');
      renderStats();
      renderTable();
      result.close();
    });
  });
}

/* ── DELETE ───────────────────────────────────────────── */
function handleDelete(uid) {
  var user = AppService.getUserSync(uid);
  if (!user) return;

  var displayName = ProfileStore.getDisplayName(user.uid);
  var result = Modal.show({
    title: 'Benutzer löschen',
    bodyHTML:
      '<p><strong>' + displayName + '</strong> (' + uid + ') wirklich löschen?</p>' +
      '<p class="text-muted">Alle Buchungen und Auswahlen werden ebenfalls entfernt.</p>',
    footerHTML:
      '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '<button class="btn btn-danger" id="modal-confirm">Löschen</button>'
  });

  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    AppService.deleteUser(uid, function(err) {
      if (err) { Toast.error(err.message); result.close(); return; }
      Toast.success('Benutzer <strong>' + displayName + '</strong> gelöscht.');
      renderStats();
      renderTable();
      result.close();
    });
  });
}

/* ── STATS ────────────────────────────────────────────── */
function renderStats() {
  var teachers = AppService.getUsersByRoleSync('teacher').length;
  var students = AppService.getUsersByRoleSync('student').length;
  var bookings = AppService.getAllSlotsSync().filter(function(s) { return s.status === 'booked'; }).length;
  document.getElementById('stat-teachers').textContent = teachers;
  document.getElementById('stat-students').textContent = students;
  document.getElementById('stat-bookings').textContent = bookings;

  /* Offene Escrows zählen */
  try {
    var raw = localStorage.getItem('app_escrow');
    var escrows = raw ? JSON.parse(raw) : [];
    var open = escrows.filter(function(e) { return e.depositStatus === 'held'; }).length;
    var el = document.getElementById('stat-escrows');
    if (el) el.textContent = open;
  } catch(e) {}
}

/* ── TABLE ────────────────────────────────────────────── */
function renderTable() {
  var users = AppService.getUsersByRoleSync(activeTab);
  var tbody = document.getElementById('user-tbody');

  if (!users.length) {
    tbody.innerHTML =
      '<tr><td colspan="5" class="table-empty-cell">Noch keine ' +
      (activeTab === 'teacher' ? 'Lehrer' : 'Schüler') +
      ' vorhanden.</td></tr>';
    return;
  }

  var rows = '';
  for (var i = 0; i < users.length; i++) {
    var u = users[i];
    var bookingCount = activeTab === 'teacher'
      ? AppService.getSlotsByTeacherSync(u.uid).length
      : AppService.getSlotsByStudentSync(u.uid).length;
    var selCount = activeTab === 'teacher'
      ? AppService.getSelectionsByTeacherSync(u.uid).length
      : AppService.getSelectionsByStudentSync(u.uid).length;

    var discBadge = (activeTab === 'teacher' && u.discipline)
      ? '<span class="admin-discipline-badge">' + _esc(_disciplineLabel(u.discipline)) + '</span>'
      : '';

    var emailBadge = u.email
      ? '<span class="admin-email-badge">' + _esc(u.email) + '</span>'
      : '';

    var infoText = activeTab === 'teacher'
      ? selCount + ' Schüler · ' + bookingCount + ' Slots'
      : selCount + ' Lehrer · ' + bookingCount + ' Buchungen';

    rows +=
      '<tr>' +
      '<td><code class="uid-badge">' + _esc(u.uid) + '</code></td>' +
      '<td class="td-name">' +
        '<span class="admin-user-name">' + _esc(ProfileStore.getDisplayName(u.uid)) + '</span>' +
        (discBadge ? '<br>' + discBadge : '') +
        (u.email ? '<br><span class="admin-email-badge">' + _esc(u.email) + '</span>' : '') +
      '</td>' +
      '<td class="td-meta">' + infoText + '</td>' +
      '<td class="admin-actions">' +
        '<a href="./user-detail.html?uid=' + _esc(u.uid) + '" class="btn btn-secondary btn-sm">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>' +
            '<path d="M8 7v4M8 5.5v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
          '</svg>' +
          ' Detail' +
        '</a>' +
        '<button class="btn btn-secondary btn-sm" onclick="handleEdit(\'' + _esc(u.uid) + '\')">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<path d="M11.5 2.5a2 2 0 012.8 2.8L5 14.5l-4 1 1-4 9.5-9z"' +
            ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>' +
          ' Bearbeiten' +
        '</button>' +
        '<button class="btn btn-danger btn-sm" onclick="handleDelete(\'' + _esc(u.uid) + '\')">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4"' +
            ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>' +
          ' Löschen' +
        '</button>' +
      '</td>' +
      '</tr>';
  }
  tbody.innerHTML = rows;
}

/* ── ESCROW PANEL ─────────────────────────────────────── */
function renderEscrows() {
  var container = document.getElementById('escrow-list');
  var empty     = document.getElementById('escrow-empty');
  if (!container) return;

  AppService.getAllEscrows(function(err, escrows) {
    if (err) { console.error('[Admin] Escrows:', err); return; }

    /* Sort newest first */
    escrows = escrows.slice().sort(function(a, b) {
      return new Date(b.createdAt) - new Date(a.createdAt);
    });

    /* Filter */
    var filtered = escrows.filter(function(e) {
      if (activeEscrowFilter === 'held')     return e.depositStatus === 'held' || e.depositStatus === 'unpaid' || e.depositStatus === 'refund_requested';
      if (activeEscrowFilter === 'released') return e.depositStatus === 'released' || e.depositStatus === 'refunded' || e.depositStatus === 'forfeited';
      return true;
    });

    /* Update escrow counter — pending = held + refund_requested */
    var heldCount = escrows.filter(function(e) {
      return e.depositStatus === 'held' || e.depositStatus === 'refund_requested';
    }).length;
    var statEl = document.getElementById('stat-escrows');
    if (statEl) statEl.textContent = heldCount;

    /* Clear list */
    var items = container.querySelectorAll('.admin-escrow-row');
    for (var i = 0; i < items.length; i++) { items[i].remove(); }

    if (!filtered.length) {
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';

    for (var j = 0; j < filtered.length; j++) {
      container.appendChild(_buildEscrowRow(filtered[j]));
    }
  });
}

var _ESCROW_STATUS = {
  unpaid:           { label: 'Nicht bezahlt',          cls: 'wallet-tx-status pending' },
  held:             { label: 'Ausstehend',              cls: 'wallet-tx-status pending' },
  released:         { label: 'Freigegeben → Lehrer',   cls: 'wallet-tx-status completed' },
  refund_requested: { label: 'Erstattung beantragt',   cls: 'wallet-tx-status pending' },
  refunded:         { label: 'Erstattet → Schüler',    cls: 'wallet-tx-status completed' },
  forfeited:        { label: 'Einbehalten → Lehrer',   cls: 'wallet-tx-status completed' }
};

function _buildEscrowRow(esc) {
  var row = document.createElement('div');
  row.className = 'admin-escrow-row wallet-tx-item';
  row.style.cursor = 'pointer';

  var status    = esc.depositStatus || 'unpaid';
  var statusCfg = _ESCROW_STATUS[status] || { label: status, cls: 'wallet-tx-status' };
  var fmt = function(n) {
    var v = parseFloat(n);
    return (isNaN(v) ? '0,00' : v.toFixed(2).replace('.', ',')) + ' €';
  };
  var fmtDate = function(iso) {
    if (!iso) return '—';
    try {
      var d = new Date(iso);
      return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' })
        + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch(e) { return iso; }
  };

  var teacherName = ProfileStore.getDisplayName(esc.teacherId) || esc.teacherId || '—';
  var studentName = ProfileStore.getDisplayName(esc.studentId) || esc.studentId || '—';

  /* "New" badge — created within last 24h */
  var isNew = esc.createdAt && (Date.now() - new Date(esc.createdAt).getTime()) < 86400000;
  var newBadge = isNew ? '<span class="badge badge-new" style="background:#f59e0b;color:#fff;font-size:10px;padding:1px 6px;border-radius:10px;margin-left:6px">NEU</span>' : '';

  /* Slot date/time display */
  var slotLabel = esc.slotDate
    ? (esc.slotDate + (esc.slotTime ? ' ' + esc.slotTime : ''))
    : ('Slot: ' + (esc.slotId || '—').slice(0, 12) + '…');

  /* Deposit type label */
  var depositLabel = esc.depositType === 'percent'
    ? esc.depositPercent + '% Deposit'
    : esc.depositType === 'fixed'
    ? 'Fixbetrag Deposit'
    : 'Deposit';

  row.innerHTML =
    '<div class="wallet-tx-icon escrow_hold" aria-hidden="true">⏸</div>' +
    '<div class="wallet-tx-info">' +
      '<div class="wallet-tx-type">' + _esc(studentName) + ' → ' + _esc(teacherName) + newBadge + '</div>' +
      '<div class="wallet-tx-desc">' + _esc(slotLabel) + ' · ' + _esc(depositLabel) + '</div>' +
      '<div class="wallet-tx-desc" style="color:#9ca3af;font-size:11px">Gebucht: ' + fmtDate(esc.createdAt) + '</div>' +
    '</div>' +
    '<div class="wallet-tx-right">' +
      '<div class="wallet-tx-amount positive">' + _esc(fmt(esc.depositAmount)) + '</div>' +
      '<span class="' + statusCfg.cls + '">' + _esc(statusCfg.label) + '</span>' +
    '</div>';

  /* Click → detail modal */
  row.addEventListener('click', function(e) {
    if (e.target.closest('button') || e.target.closest('a')) return;
    _showEscrowDetailModal(esc, studentName, teacherName, fmt, fmtDate, depositLabel);
  });

  /* Release button only for 'held' */
  if (status === 'held') {
    var releaseBtn = document.createElement('button');
    releaseBtn.className = 'btn btn-primary btn-sm admin-release-btn';
    releaseBtn.textContent = '▶ Freigeben';
    (function(escrow, btn) {
      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        var result = Modal.show({
          title: 'Zahlung freigeben',
          bodyHTML:
            '<div class="move-dialog">' +
              '<p class="move-dialog-info">Deposit von <strong>' + _esc(studentName) + '</strong>' +
              ' in Höhe von <strong>' + _esc(fmt(escrow.depositAmount)) + '</strong>' +
              ' an <strong>' + _esc(teacherName) + '</strong> freigeben?</p>' +
              '<p class="move-dialog-info">Der Betrag wird sofort dem Lehrer-Wallet gutgeschrieben.</p>' +
            '</div>',
          footerHTML:
            '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
            '<button class="btn btn-primary" id="modal-confirm">Jetzt freigeben</button>'
        });
        document.getElementById('modal-cancel').addEventListener('click', result.close);
        document.getElementById('modal-confirm').addEventListener('click', function() {
          AppService.adminReleaseEscrow(escrow.escrowId, currentUser.uid, function(releaseErr) {
            result.close();
            if (releaseErr) { Toast.error('Fehler: ' + releaseErr.message); return; }
            Toast.success('Zahlung erfolgreich freigegeben.');
            renderEscrows();
            renderStats();
          });
        });
      });
    })(esc, releaseBtn);
    var rightCol = row.querySelector('.wallet-tx-right');
    if (rightCol) rightCol.appendChild(releaseBtn);
  }

  return row;
}

function _showEscrowDetailModal(esc, studentName, teacherName, fmt, fmtDate, depositLabel) {
  var status    = esc.depositStatus || 'unpaid';
  var statusCfg = _ESCROW_STATUS[status] || { label: status, cls: '' };
  var slotLabel = esc.slotDate
    ? (esc.slotDate + (esc.slotTime ? ' ' + esc.slotTime : ''))
    : (esc.slotId || '—');

  Modal.show({
    title: 'Escrow-Details',
    bodyHTML:
      '<div class="move-dialog" style="font-size:14px;line-height:1.8">' +
        '<table style="width:100%;border-collapse:collapse">' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Status</td>' +
              '<td><span class="' + _esc(statusCfg.cls) + '">' + _esc(statusCfg.label) + '</span></td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Schüler</td><td>' + _esc(studentName) + '</td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Lehrer</td><td>' + _esc(teacherName) + '</td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Stunde</td><td>' + _esc(slotLabel) + '</td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Deposit</td><td><strong>' + _esc(fmt(esc.depositAmount)) + '</strong> (' + _esc(depositLabel) + ')</td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Gesamtpreis</td><td>' + _esc(fmt(esc.fullAmount)) + '</td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Zahlungsmodus</td><td>' + _esc(esc.paymentMode || '—') + '</td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Gebucht am</td><td>' + _esc(fmtDate(esc.createdAt)) + '</td></tr>' +
          (esc.depositPaidAt ? '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Bezahlt am</td><td>' + _esc(fmtDate(esc.depositPaidAt)) + '</td></tr>' : '') +
          (esc.releasedAt    ? '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Abgeschlossen am</td><td>' + _esc(fmtDate(esc.releasedAt)) + '</td></tr>' : '') +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Escrow-ID</td><td style="font-size:11px;font-family:monospace">' + _esc(esc.escrowId || '—') + '</td></tr>' +
          '<tr><td style="color:#6b7280;padding:2px 8px 2px 0">Slot-ID</td><td style="font-size:11px;font-family:monospace">' + _esc(esc.slotId || '—') + '</td></tr>' +
        '</table>' +
      '</div>',
    footerHTML: '<button class="btn btn-ghost" id="modal-close-escrow">Schließen</button>'
  });
  var closeBtn = document.getElementById('modal-close-escrow');
  if (closeBtn) closeBtn.addEventListener('click', function() {
    var overlay = document.getElementById('modal-overlay');
    if (overlay) overlay.remove();
  });
}

/* ── Discipline label map ────────────────────────────── */
var DISCIPLINE_LABELS = {
  'ski':         'Ski-Instruktor',
  'paragliding': 'Paragliding-Instruktor',
  'diving':      'Tauch-Instruktor',
  'tourguide':   'Reiseführer'
};

function _disciplineLabel(key) {
  return DISCIPLINE_LABELS[key] || key;
}

/* ── Helpers ──────────────────────────────────────────── */
function _showError(id, msg) {
  var el = document.getElementById(id);
  if (el) { el.textContent = msg; el.classList.remove('is-hidden'); }
}

function _clearErrors() {
  var ids = ['e-uid', 'e-name', 'e-role'];
  for (var i = 0; i < ids.length; i++) {
    var el = document.getElementById(ids[i]);
    if (el) { el.textContent = ''; el.classList.add('is-hidden'); }
  }
}

function _esc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/* ══════════════════════════════════════════════════════
   AUDIT LOG
   Vollständige Buchungs- und Zahlungshistorie aller User.
   Filterbar nach: Name/UID, Rolle, Typ, Datum, Stundendatum
══════════════════════════════════════════════════════ */

var _auditAllTxs    = [];   /* loaded once, filtered client-side */
var _auditFiltered  = [];   /* currently visible rows */

var _AUDIT_TYPE_LABELS = {
  booking:          'Buchung',
  move:             'Verschiebung',
  cancellation:     'Stornierung',
  teacher_cancel:   'Lehrer-Storno',
  escrow_hold:      'Deposit hinterlegt',
  refund:           'Rückerstattung',
  escrow_release:   'Deposit freigegeben',
  lesson_confirmed: 'Stunde bestätigt',
  deposit:          'Einzahlung',
  withdrawal:       'Auszahlung',
  transfer:         'Transfer'
};

var _AUDIT_TYPE_COLORS = {
  booking:          '#1d4ed8',
  move:             '#7c3aed',
  cancellation:     '#b45309',
  teacher_cancel:   '#dc2626',
  escrow_hold:      '#0369a1',
  refund:           '#059669',
  escrow_release:   '#047857',
  lesson_confirmed: '#15803d',
  deposit:          '#166534',
  withdrawal:       '#9a3412',
  transfer:         '#6b7280'
};

function renderAuditLog() {
  /* Wire up controls once */
  if (!document.getElementById('audit-search')._wired) {
    document.getElementById('audit-search')._wired = true;

    var debounce = null;
    function onFilterChange() {
      clearTimeout(debounce);
      debounce = setTimeout(_auditApplyFilters, 120);
    }

    document.getElementById('audit-search').addEventListener('input', onFilterChange);
    document.getElementById('audit-filter-role').addEventListener('change', onFilterChange);
    document.getElementById('audit-filter-type').addEventListener('change', onFilterChange);
    document.getElementById('audit-date-from').addEventListener('change', onFilterChange);
    document.getElementById('audit-date-to').addEventListener('change', onFilterChange);
    document.getElementById('audit-slot-date').addEventListener('change', onFilterChange);

    document.getElementById('audit-clear-btn').addEventListener('click', function() {
      document.getElementById('audit-search').value       = '';
      document.getElementById('audit-filter-role').value  = 'all';
      document.getElementById('audit-filter-type').value  = 'all';
      document.getElementById('audit-date-from').value    = '';
      document.getElementById('audit-date-to').value      = '';
      document.getElementById('audit-slot-date').value    = '';
      _auditApplyFilters();
    });

    document.getElementById('audit-refresh-btn').addEventListener('click', _auditLoad);

    document.getElementById('audit-export-btn').addEventListener('click', _auditExportCSV);
  }

  _auditLoad();
}

function _auditLoad() {
  var tbody = document.getElementById('audit-tbody');
  tbody.innerHTML = '<tr><td colspan="13" class="table-empty-cell">Lade…</td></tr>';

  AppService.getAllTransactions({}, function(err, txs) {
    if (err) {
      tbody.innerHTML = '<tr><td colspan="13" class="table-empty-cell">Fehler: ' + _esc(err.message) + '</td></tr>';
      return;
    }
    /* Sort newest first */
    txs.sort(function(a, b) { return (b.createdAt || '').localeCompare(a.createdAt || ''); });
    _auditAllTxs = txs;
    _auditApplyFilters();
  });
}

function _auditApplyFilters() {
  var query     = (document.getElementById('audit-search').value || '').trim().toLowerCase();
  var roleF     = document.getElementById('audit-filter-role').value;
  var typeF     = document.getElementById('audit-filter-type').value;
  var dateFrom  = document.getElementById('audit-date-from').value;
  var dateTo    = document.getElementById('audit-date-to').value;
  var slotDate  = document.getElementById('audit-slot-date').value;

  /* Build uid→role map from current user list for role filter */
  var teachers = AppService.getUsersByRoleSync('teacher');
  var students = AppService.getUsersByRoleSync('student');
  var roleMap  = {};
  teachers.forEach(function(u) { roleMap[u.uid] = 'teacher'; });
  students.forEach(function(u) { roleMap[u.uid] = 'student'; });

  _auditFiltered = _auditAllTxs.filter(function(tx) {
    /* Role filter */
    if (roleF !== 'all' && roleMap[tx.uid] !== roleF) return false;

    /* Type filter */
    if (typeF !== 'all' && tx.type !== typeF) return false;

    /* TX date range */
    if (dateFrom && tx.createdAt && tx.createdAt.slice(0,10) < dateFrom) return false;
    if (dateTo   && tx.createdAt && tx.createdAt.slice(0,10) > dateTo)   return false;

    /* Slot date filter */
    if (slotDate && tx.meta && tx.meta.slotDate && tx.meta.slotDate !== slotDate) return false;
    if (slotDate && (!tx.meta || !tx.meta.slotDate)) return false;

    /* Name / UID search — match against uid, relatedUid, displayNames */
    if (query) {
      var uidMatch      = tx.uid && tx.uid.toLowerCase().indexOf(query) !== -1;
      var relMatch      = tx.relatedUid && tx.relatedUid.toLowerCase().indexOf(query) !== -1;
      var nameMatch     = ProfileStore.getDisplayName(tx.uid).toLowerCase().indexOf(query) !== -1;
      var relNameMatch  = tx.relatedUid && ProfileStore.getDisplayName(tx.relatedUid).toLowerCase().indexOf(query) !== -1;
      var descMatch     = tx.description && tx.description.toLowerCase().indexOf(query) !== -1;
      if (!uidMatch && !relMatch && !nameMatch && !relNameMatch && !descMatch) return false;
    }

    return true;
  });

  _auditRender();
}

function _auditRender() {
  var tbody   = document.getElementById('audit-tbody');
  var summary = document.getElementById('audit-summary');
  var txs     = _auditFiltered;

  /* Summary bar */
  if (txs.length > 0) {
    var totalIn  = 0;
    var totalOut = 0;
    txs.forEach(function(tx) {
      if (tx.amount > 0) totalIn  += tx.amount;
      if (tx.amount < 0) totalOut += tx.amount;
    });
    summary.style.display = '';
    summary.textContent   = txs.length + ' Einträge  ·  ' +
      'Zuflüsse: +' + totalIn.toFixed(2).replace('.', ',') + ' €  ·  ' +
      'Abflüsse: ' + totalOut.toFixed(2).replace('.', ',') + ' €';
  } else {
    summary.style.display = 'none';
  }

  if (!txs.length) {
    tbody.innerHTML = '<tr><td colspan="13" class="table-empty-cell">Keine Einträge für diese Filterauswahl.</td></tr>';
    return;
  }

  var rows = '';
  for (var i = 0; i < txs.length; i++) {
    var tx      = txs[i];
    var meta    = tx.meta || {};
    var typeLabel = _AUDIT_TYPE_LABELS[tx.type] || tx.type;
    var typeColor = _AUDIT_TYPE_COLORS[tx.type] || '#6b7280';
    var typeBadge = '<span style="font-size:10px;padding:2px 7px;border-radius:20px;font-weight:600;background:' + typeColor + '1a;color:' + typeColor + ';border:1px solid ' + typeColor + '33">' + _esc(typeLabel) + '</span>';

    var amt      = typeof tx.amount === 'number' ? tx.amount : 0;
    var amtFmt   = amt === 0 ? '—' : (amt > 0 ? '+' : '') + amt.toFixed(2).replace('.', ',') + ' €';
    var amtColor = amt > 0 ? '#15803d' : amt < 0 ? '#dc2626' : '#6b7280';

    var bal      = typeof tx.balance === 'number' ? tx.balance : null;
    var balFmt   = bal !== null ? bal.toFixed(2).replace('.', ',') + ' €' : '—';

    var slotDt   = '';
    if (meta.slotDate) {
      var sdt  = new Date(meta.slotDate + 'T00:00:00');
      slotDt   = sdt.toLocaleDateString('de-DE', { day:'numeric', month:'short', year:'2-digit' });
      if (meta.slotTime) slotDt += ' ' + meta.slotTime;
    } else if (meta.oldDate) {
      slotDt   = meta.oldDate + ' ' + (meta.oldTime || '') + ' → ' + (meta.newDate || '') + ' ' + (meta.newTime || '');
    }

    var depFmt  = '';
    if (meta.depositAmount > 0) {
      depFmt = meta.depositAmount.toFixed(2).replace('.', ',') + ' €';
      if (meta.depositType === 'percent') depFmt += ' (' + meta.depositPercent + '%)';
      else if (meta.depositType === 'fixed') depFmt += ' (fix)';
    } else {
      depFmt = '—';
    }

    var fullAmtFmt = meta.fullAmount > 0 ? meta.fullAmount.toFixed(2).replace('.', ',') + ' €' : '—';

    var payMode  = meta.paymentMode === 'cash_on_site' ? 'Bar' : meta.paymentMode === 'instant' ? 'Online' : (meta.paymentMode || '—');

    var tier     = meta.cancellationTier ? _esc(meta.cancellationTier) : '—';

    var tsFormatted = tx.createdAt
      ? new Date(tx.createdAt).toLocaleString('de-DE', { day:'2-digit', month:'2-digit', year:'2-digit', hour:'2-digit', minute:'2-digit' })
      : '—';

    var userName    = _esc(ProfileStore.getDisplayName(tx.uid));
    var userRole    = { teacher:'Lehrer', student:'Schüler', admin:'Admin' }[AppService.getUserSync(tx.uid) ? AppService.getUserSync(tx.uid).role : ''] || '—';
    var counterpart = tx.relatedUid ? _esc(ProfileStore.getDisplayName(tx.relatedUid)) : '—';

    rows += '<tr style="cursor:pointer" onclick="_auditToggleDetail(this,' + i + ')">' +
      '<td style="font-family:monospace;font-size:11px;color:#6b7280">' + tsFormatted + '</td>' +
      '<td><strong>' + userName + '</strong><br><span style="font-size:10px;color:#9ca3af">' + _esc(tx.uid) + '</span></td>' +
      '<td><span style="font-size:11px;color:#6b7280">' + userRole + '</span></td>' +
      '<td>' + typeBadge + '</td>' +
      '<td style="text-align:right;font-family:monospace;color:' + amtColor + ';font-weight:600">' + amtFmt + '</td>' +
      '<td style="text-align:right;font-family:monospace;font-size:12px;color:#6b7280">' + balFmt + '</td>' +
      '<td style="font-size:12px">' + _esc(slotDt) + '</td>' +
      '<td style="font-size:12px">' + counterpart + '</td>' +
      '<td style="text-align:right;font-family:monospace;font-size:12px">' + fullAmtFmt + '</td>' +
      '<td style="font-size:12px">' + depFmt + '</td>' +
      '<td style="font-size:12px">' + payMode + '</td>' +
      '<td style="font-size:12px">' + tier + '</td>' +
      '<td style="font-size:11px;color:#6b7280;max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + _esc(tx.description || '') + '</td>' +
    '</tr>' +
    '<tr class="audit-detail-row" data-audit-idx="' + i + '" style="display:none"><td colspan="13">' +
      _auditDetailHTML(tx) + '</td></tr>';
  }

  tbody.innerHTML = rows;
}

function _auditToggleDetail(row, idx) {
  /* Don't toggle if click was on a button inside the row */
  var nextRow = row.nextElementSibling;
  if (!nextRow || !nextRow.classList.contains('audit-detail-row')) return;
  nextRow.style.display = nextRow.style.display === 'none' ? '' : 'none';
}

function _auditDetailHTML(tx) {
  var meta = tx.meta || {};
  var rows = '';
  var fields = [
    ['TX-ID',             tx.txId],
    ['Wallet-Inhaber',    tx.uid],
    ['Gegenpartei-UID',   tx.relatedUid || '—'],
    ['Slot-ID',           meta.slotId || '—'],
    ['Escrow-ID',         meta.escrowId || '—'],
    ['Stundendatum',      meta.slotDate || '—'],
    ['Stundenuhrzeit',    meta.slotTime || '—'],
    ['Teacher-UID',       meta.teacherId || '—'],
    ['Schüler-UID',       meta.studentId || '—'],
    ['Gesamtpreis',       meta.fullAmount != null ? meta.fullAmount.toFixed(2).replace('.', ',') + ' €' : '—'],
    ['Deposit-Betrag',    meta.depositAmount != null ? meta.depositAmount.toFixed(2).replace('.', ',') + ' €' : '—'],
    ['Deposit-Typ',       meta.depositType || '—'],
    ['Deposit-Prozent',   meta.depositPercent != null ? meta.depositPercent + '%' : '—'],
    ['Deposit erforderlich', meta.requiresDeposit != null ? (meta.requiresDeposit ? 'Ja' : 'Nein') : '—'],
    ['Zahlungsmodus',     meta.paymentMode || '—'],
    ['Storno-Tier',       meta.cancellationTier || '—'],
    ['Storniert um',      meta.cancelledAt || '—'],
    ['Gebucht um',        meta.bookedAt || '—'],
    ['Verschoben von',    meta.oldDate ? (meta.oldDate + ' ' + (meta.oldTime || '')) : '—'],
    ['Verschoben nach',   meta.newDate ? (meta.newDate + ' ' + (meta.newTime || '')) : '—'],
    ['Initiator-Rolle',   meta.initiatorRole || '—'],
    ['No-Escrow-Grund',   meta.noEscrowReason || '—']
  ];
  fields.forEach(function(f) {
    rows += '<tr><td style="font-size:11px;color:#6b7280;padding:2px 8px;white-space:nowrap">' +
      _esc(f[0]) + '</td><td style="font-size:11px;font-family:monospace;padding:2px 8px">' +
      _esc(String(f[1])) + '</td></tr>';
  });
  return '<div style="background:#f9fafb;padding:8px 16px;border-top:1px solid #e5e7eb">' +
    '<table style="border-collapse:collapse">' + rows + '</table></div>';
}

function _auditExportCSV() {
  var txs = _auditFiltered;
  if (!txs.length) { Toast.info('Keine Daten zum Exportieren.'); return; }

  var header = ['Zeitpunkt','UID','Name','Rolle','Typ','Betrag','Saldo',
    'Stundendatum','Stundenuhrzeit','Gegenpartei-UID','Gegenpartei-Name',
    'Gesamtpreis','Deposit','Deposit-Typ','Deposit-%','Zahlungsmodus',
    'Storno-Tier','Slot-ID','Escrow-ID','Beschreibung'].join(';');

  var lines = [header];
  txs.forEach(function(tx) {
    var meta = tx.meta || {};
    var user = AppService.getUserSync(tx.uid);
    var counterUser = tx.relatedUid ? AppService.getUserSync(tx.relatedUid) : null;
    lines.push([
      tx.createdAt || '',
      tx.uid || '',
      ProfileStore.getDisplayName(tx.uid),
      user ? user.role : '',
      tx.type || '',
      typeof tx.amount === 'number' ? tx.amount.toFixed(2).replace('.', ',') : '',
      typeof tx.balance === 'number' ? tx.balance.toFixed(2).replace('.', ',') : '',
      meta.slotDate || (meta.oldDate || ''),
      meta.slotTime || (meta.oldTime || ''),
      tx.relatedUid || '',
      counterUser ? ProfileStore.getDisplayName(tx.relatedUid) : '',
      meta.fullAmount != null ? meta.fullAmount.toFixed(2).replace('.', ',') : '',
      meta.depositAmount != null ? meta.depositAmount.toFixed(2).replace('.', ',') : '',
      meta.depositType || '',
      meta.depositPercent != null ? meta.depositPercent : '',
      meta.paymentMode || '',
      meta.cancellationTier || '',
      meta.slotId || '',
      meta.escrowId || '',
      (tx.description || '').replace(/;/g, ',')
    ].map(function(v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(';'));
  });

  var csv  = lines.join('\r\n');
  var blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href   = url;
  a.download = 'audit-log-' + new Date().toISOString().slice(0,10) + '.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  Toast.success(txs.length + ' Einträge exportiert.');
}
