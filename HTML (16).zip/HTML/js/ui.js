/**
 * ui.js — Shared UI Utilities
 * Toast, Modal, Icons — ohne const/let/arrow für maximale Kompatibilität.
 */

/* ── Toast ────────────────────────────────────────────── */
var Toast = (function() {
  var container = null;

  function getContainer() {
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    return container;
  }

  function show(message, type, duration) {
    type     = type     || 'success';
    duration = duration || 4000;

    var el = document.createElement('div');
    el.className = 'toast' + (type === 'error' ? ' toast-error' : type === 'info' ? ' toast-info' : '');

    var iconColor = type === 'success' ? '#4d7aa0' : '#e74c3c';
    var iconPath  = type === 'success'
      ? '<circle cx="8" cy="8" r="7" stroke="' + iconColor + '" stroke-width="1.5"/><path d="M5 8l2 2 4-4" stroke="' + iconColor + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
      : '<circle cx="8" cy="8" r="7" stroke="' + iconColor + '" stroke-width="1.5"/><path d="M8 5v3M8 11v.5" stroke="' + iconColor + '" stroke-width="1.5" stroke-linecap="round"/>';

    el.innerHTML = '<svg class="toast-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">' + iconPath + '</svg>'
      + '<div><span>' + message + '</span></div>';

    getContainer().appendChild(el);
    setTimeout(function() {
      el.classList.add('toast-exit');
      el.addEventListener('animationend', function() { el.remove(); });
    }, duration);
  }

  return {
    success: function(msg) { show(msg, 'success'); },
    error:   function(msg) { show(msg, 'error'); },
    info:    function(msg) { show(msg, 'info'); }
  };
})();

/* ── Modal ────────────────────────────────────────────── */
var Modal = {
  show: function(opts) {
    var title      = opts.title      || '';
    var bodyHTML   = opts.bodyHTML   || '';
    var footerHTML = opts.footerHTML || '';

    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML =
      '<div class="modal" role="dialog" aria-modal="true">'
        + '<div class="modal-header">'
          + '<span class="modal-title">' + title + '</span>'
          + '<button class="modal-close" aria-label="Close">'
            + '<svg width="16" height="16" viewBox="0 0 16 16" fill="none">'
            + '<path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>'
            + '</svg>'
          + '</button>'
        + '</div>'
        + '<div class="modal-body">' + bodyHTML + '</div>'
        + (footerHTML ? '<div class="modal-footer">' + footerHTML + '</div>' : '')
      + '</div>';

    document.body.appendChild(overlay);

    function close() { overlay.remove(); }

    overlay.querySelector('.modal-close').addEventListener('click', close);
    overlay.addEventListener('click', function(e) { if (e.target === overlay) close(); });
    document.addEventListener('keydown', function esc(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', esc); }
    });

    return { overlay: overlay, close: close };
  }
};

/* ── Icons ────────────────────────────────────────────── */
var Icons = {
  trash: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  plus:  '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>'
};


/* ── Shared Move Block Dialog ────────────────────────────
   opts = {
     block:        { dateStr, start, end, bookedSlots:[{slotId}], student:{uid,name} }
     teacherId:    string
     pendingMap:   object  (pendingBookings or pendingDayChanges)
     stuId:        string|null
     onConfirm:    function(pendingMap) — called after staging, before close
     onCalJump:    function(dateStr, result) — navigate to calendar
   }
──────────────────────────────────────────────────────── */
function openMoveBlockDialogShared(opts) {
  var block     = opts.block;
  var teacherId = opts.teacherId;
  var pending   = opts.pendingMap;
  var stuId     = opts.stuId;
  var stuName   = ProfileStore.getDisplayName(block.student ? block.student.uid : (opts && opts.stuId ? opts.stuId : '?'));
  var slotCount = block.bookedSlots.length;

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info">Move <strong>' + slotCount + ' Slot' + (slotCount !== 1 ? 's' : '') + '</strong>' +
        ' (' + block.start + ' – ' + block.end + ') für <strong>' + stuName + '</strong></p>' +
      '<div class="move-dialog-row">' +
        '<div class="move-dialog-col">' +
          '<label class="form-label">Datum</label>' +
          '<input type="date" id="move-date-input" class="form-select" value="' + block.dateStr + '" />' +
        '</div>' +
        '<div class="move-dialog-col">' +
          '<label class="form-label">Startzeit</label>' +
          '<select id="move-time-select" class="form-select"><option value="">Datum wählen</option></select>' +
        '</div>' +
      '</div>' +
      '<div id="move-check-result" class="move-check-result"></div>' +
      '<div class="move-dialog-btns">' +
        '<button class="btn btn-primary" id="move-check-btn">Verfügbarkeit prüfen</button>' +
        '<button class="btn btn-primary is-hidden" id="move-confirm-btn">Verschieben</button>' +
        '<button class="btn btn-ghost is-hidden" id="move-cal-btn">Im Kalender anzeigen</button>' +
      '</div>' +

      /* ── Recurring section ── */
      '<div class="recur-section">' +
        '<button class="btn btn-ghost recur-toggle-btn" id="recur-toggle">' +
          '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 8a6 6 0 0111.46-2.46M14 8a6 6 0 01-11.46 2.46" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M14 2v4h-4M2 14v-4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
          ' Regelmäßig buchen' +
        '</button>' +
        '<div id="recur-panel" class="recur-panel is-hidden">' +
          '<p class="recur-info">Gleicher Wochentag + gleiche Uhrzeit für die nächsten Wochen wiederholen.</p>' +
          '<div class="move-dialog-row">' +
            '<div class="move-dialog-col">' +
              '<label class="form-label">Anzahl Wochen</label>' +
              '<input type="number" id="recur-weeks" class="form-select" min="1" max="52" value="4" />' +
            '</div>' +
          '</div>' +
          '<div id="recur-result" class="recur-result"></div>' +
          '<div class="move-dialog-btns">' +
            '<button class="btn btn-primary" id="recur-check-btn">Verfügbarkeit prüfen</button>' +
            '<button class="btn btn-primary is-hidden" id="recur-confirm-btn">Verfügbare Tage buchen</button>' +
          '</div>' +
        '</div>' +
      '</div>' +

      '<div class="move-dialog-btns">' +
        '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '</div>' +
    '</div>';

  var result = Modal.show({ title: 'Block verschieben', bodyHTML: bodyHTML, footerHTML: '' });

  var dateInput   = document.getElementById('move-date-input');
  var timeSelect  = document.getElementById('move-time-select');
  var checkResult = document.getElementById('move-check-result');
  var checkBtn    = document.getElementById('move-check-btn');
  var confirmBtn  = document.getElementById('move-confirm-btn');
  var calBtn      = document.getElementById('move-cal-btn');
  var cancelBtn   = document.getElementById('modal-cancel');

  function resetCheck() {
    checkResult.textContent = '';
    checkResult.className = 'move-check-result';
    confirmBtn.classList.add('is-hidden');
    checkBtn.classList.remove('is-hidden');
    var hasInputs = dateInput.value && timeSelect.value;
    calBtn.classList.toggle('is-hidden', !hasInputs);
  }

  function isFreeSlot(s) {
    if (s.status === 'available' || s.status === 'recurring') return true;
    if (pending[s.slotId] && pending[s.slotId].action === 'cancel') return true;
    return false;
  }

  function rebuildTimes() {
    timeSelect.innerHTML = '';
    var dateStr = dateInput.value;
    if (!dateStr) { calBtn.classList.add('is-hidden'); return; }
    var allDay = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var free = allDay.filter(isFreeSlot);
    if (!free.length) {
      var o = document.createElement('option');
      o.value = ''; o.textContent = 'Keine freien Slots';
      timeSelect.appendChild(o);
      return;
    }
    for (var i = 0; i < free.length; i++) {
      var o = document.createElement('option');
      o.value = free[i].slotId;
      o.textContent = free[i].time + ' – ' + Store.slotEndTime(free[i].time);
      timeSelect.appendChild(o);
    }
    resetCheck();
  }

  rebuildTimes();
  dateInput.addEventListener('change', function() { rebuildTimes(); resetCheck(); });
  timeSelect.addEventListener('change', function() {
    resetCheck();
    var hasInputs = dateInput.value && timeSelect.value;
    calBtn.classList.toggle('is-hidden', !hasInputs);
  });

  checkBtn.addEventListener('click', function() {
    var startSlotId = timeSelect.value;
    if (!startSlotId) {
      checkResult.textContent = 'Bitte Datum und Startzeit wählen.';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var dateStr = dateInput.value;
    var allDay  = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var startIdx = -1;
    for (var i = 0; i < allDay.length; i++) {
      if (allDay[i].slotId === startSlotId) { startIdx = i; break; }
    }
    if (startIdx === -1 || startIdx + slotCount > allDay.length) {
      checkResult.textContent = 'Nicht genug Slots ab dieser Zeit (' + slotCount + ' benötigt).';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
    var blocked = [];
    for (var j = 0; j < targetSlots.length; j++) {
      if (!isFreeSlot(targetSlots[j])) blocked.push(targetSlots[j].time);
    }
    if (blocked.length) {
      checkResult.textContent = 'Nicht alle Slots frei. Belegt: ' + blocked.join(', ') + '.';
      checkResult.className = 'move-check-result move-check-fail';
      confirmBtn.classList.add('is-hidden');
      checkBtn.classList.remove('is-hidden');
    } else {
      checkResult.textContent = '\u2713 Alle ' + slotCount + ' Slots frei \u2014 Verschiebung möglich.';
      checkResult.className = 'move-check-result move-check-ok';
      confirmBtn.classList.remove('is-hidden');
      calBtn.classList.remove('is-hidden');
      checkBtn.classList.add('is-hidden');
    }
  });

  confirmBtn.addEventListener('click', function() {
    var startSlotId = timeSelect.value;
    if (!startSlotId) return;
    var dateStr = dateInput.value;
    var allDay  = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var startIdx = -1;
    for (var i = 0; i < allDay.length; i++) {
      if (allDay[i].slotId === startSlotId) { startIdx = i; break; }
    }
    if (startIdx === -1) return;
    var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
    for (var k = 0; k < block.bookedSlots.length; k++) {
      var orig = Store.Slots.all().filter(function(x) { return x.slotId === block.bookedSlots[k].slotId; })[0];
      if (orig) pending[orig.slotId] = { action: 'cancel', originalSlot: orig, newStudentId: null };
    }
    for (var m = 0; m < targetSlots.length; m++) {
      var tgt = Store.Slots.all().filter(function(x) { return x.slotId === targetSlots[m].slotId; })[0];
      if (tgt) pending[tgt.slotId] = { action: 'book', originalSlot: tgt, newStudentId: stuId, extraStudents: [] };
    }
    opts.onConfirm(pending);
    result.close();
    Toast.info('Block-Verschiebung vorgemerkt \u2014 Dr\u00fcck Save zum Best\u00e4tigen.');
  });

  calBtn.addEventListener('click', function() {
    opts.onCalJump(dateInput.value, result);
  });

  cancelBtn.addEventListener('click', result.close);

  /* ── Recurring booking logic ──────────────────────────── */
  var recurToggle  = document.getElementById('recur-toggle');
  var recurPanel   = document.getElementById('recur-panel');
  var recurWeeks   = document.getElementById('recur-weeks');
  var recurResult  = document.getElementById('recur-result');
  var recurCheckBtn   = document.getElementById('recur-check-btn');
  var recurConfirmBtn = document.getElementById('recur-confirm-btn');
  var recurData = null; // stores the check results

  recurToggle.addEventListener('click', function() {
    var isOpen = !recurPanel.classList.contains('is-hidden');
    recurPanel.classList.toggle('is-hidden', isOpen);
    recurToggle.classList.toggle('active', !isOpen);
  });

  function fmtDateLocal(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var dd = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + dd;
  }

  function getWeekDates(dateObj) {
    var d = new Date(dateObj);
    var dow = d.getDay(); // 0=Sun
    var monday = new Date(d);
    monday.setDate(d.getDate() - ((dow + 6) % 7)); // back to Monday
    var dates = [];
    for (var i = 0; i < 7; i++) {
      var day = new Date(monday);
      day.setDate(monday.getDate() + i);
      dates.push(day);
    }
    return dates; // [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
  }

  function formatWeekday(dateObj) {
    return dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  recurCheckBtn.addEventListener('click', function() {
    var weeks = parseInt(recurWeeks.value, 10);
    if (!weeks || weeks < 1) {
      recurResult.innerHTML = '<p class="move-check-fail">Bitte Anzahl Wochen angeben.</p>';
      return;
    }

    // Source: current block date + time range
    var sourceDate = new Date(block.dateStr + 'T00:00:00');
    var startTime  = block.start;

    recurData = [];
    recurResult.innerHTML = '';

    for (var w = 1; w <= weeks; w++) {
      var targetDate = new Date(sourceDate);
      targetDate.setDate(sourceDate.getDate() + (w * 7));
      var targetDateStr = fmtDateLocal(targetDate);

      // Materialise recurring slots for that week
      var weekDates = getWeekDates(targetDate);
      Store.Recurring.materialiseWeek(teacherId, weekDates);

      // Check slot availability
      var allDay = Store.Slots.byTeacherDate(teacherId, targetDateStr)
        .sort(function(a, b) { return a.time.localeCompare(b.time); });

      // Find consecutive free slots starting at startTime
      var startIdx = -1;
      for (var i = 0; i < allDay.length; i++) {
        if (allDay[i].time === startTime) { startIdx = i; break; }
      }

      var entry = { date: targetDate, dateStr: targetDateStr, week: w, available: false, reason: '', slots: [] };

      if (startIdx === -1) {
        entry.reason = 'Keine Slots an diesem Tag';
      } else if (startIdx + slotCount > allDay.length) {
        entry.reason = 'Nicht genug Slots (' + slotCount + ' benötigt)';
      } else {
        var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
        var blocked = [];
        for (var j = 0; j < targetSlots.length; j++) {
          var ts = targetSlots[j];
          if (!isFreeSlot(ts)) {
            var reason = ts.status === 'timeout' ? 'Timeout'
              : (ts.status === 'booked' ? 'Gebucht (' + (ts.studentId || '?') + ')' : ts.status);
            blocked.push(ts.time + ' \u2013 ' + reason);
          }
        }
        if (blocked.length) {
          entry.reason = blocked.join(', ');
        } else {
          entry.available = true;
          entry.slots = targetSlots;
        }
      }
      recurData.push(entry);
    }

    // Render results
    var availCount = recurData.filter(function(e) { return e.available; }).length;
    var html = '<div class="recur-summary">' + availCount + ' von ' + weeks + ' Wochen verfügbar</div>';
    html += '<div class="recur-list">';
    for (var r = 0; r < recurData.length; r++) {
      var e = recurData[r];
      var icon = e.available ? '\u2713' : '\u2717';
      var cls  = e.available ? 'recur-row-ok' : 'recur-row-fail';
      html += '<div class="recur-row ' + cls + '">'
        + '<span class="recur-row-icon">' + icon + '</span>'
        + '<span class="recur-row-date">Woche ' + e.week + ': ' + formatWeekday(e.date) + '</span>'
        + (e.reason ? '<span class="recur-row-reason">' + e.reason + '</span>' : '')
        + '</div>';
    }
    html += '</div>';
    recurResult.innerHTML = html;

    if (availCount > 0) {
      recurConfirmBtn.classList.remove('is-hidden');
      recurConfirmBtn.textContent = availCount + ' verfügbare Tage buchen';
      recurCheckBtn.classList.add('is-hidden');
    } else {
      recurConfirmBtn.classList.add('is-hidden');
      recurCheckBtn.classList.remove('is-hidden');
    }
  });

  recurConfirmBtn.addEventListener('click', function() {
    if (!recurData) return;
    var booked = 0;
    for (var r = 0; r < recurData.length; r++) {
      var e = recurData[r];
      if (!e.available || !e.slots.length) continue;
      for (var s = 0; s < e.slots.length; s++) {
        var tgt = Store.Slots.all().filter(function(x) { return x.slotId === e.slots[s].slotId; })[0];
        if (tgt) {
          pending[tgt.slotId] = { action: 'book', originalSlot: tgt, newStudentId: stuId, extraStudents: [] };
        }
      }
      booked++;
    }
    opts.onConfirm(pending);
    result.close();
    Toast.info(booked + ' Wochen vorgemerkt \u2014 Dr\u00fcck Save zum Best\u00e4tigen.');
  });
}

window.openMoveBlockDialogShared = openMoveBlockDialogShared;

window.Toast = Toast;
window.Modal = Modal;
window.Icons = Icons;
