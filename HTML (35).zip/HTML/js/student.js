/**
 * student.js — Student View
 *
 * Booking via week grid (same layout as teacher).
 * Cell states (student perspective):
 *   gc-available  — green,  clickable → book instantly
 *   gc-mine       — navy,   clickable → cancel
 *   gc-empty      — grey,   not clickable
 */

var currentUser     = null;
var activeView      = 'catalog';
var activeTeacherId = null;

var sgridWeekStart  = null;

var viewYear        = 0;
var viewMonth       = 0;
var selectedDate    = null;

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START  = '06:00';
var GRID_END    = '22:00';

/* Stored document-level listeners — ermöglicht sauberes removeEventListener */
var _closeTeacherPickerDropdown = null;
var _pickerMonthBtnsInit        = false;

/* My Bookings — Filterzustand */
var myBookingsTimeFilter    = 'upcoming'; /* 'past' | 'upcoming' | 'all' */
var myBookingsConfirmFilter = 'all';      /* 'all' | 'unconfirmed' | 'confirmed' */
var myBookingsSortAsc       = true;       /* true = älteste zuerst */
var _myBookingsSortBtnInit  = false;

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('student');
  if (!currentUser) return;
  Navbar.init('catalog');

  document.getElementById('nav-catalog').addEventListener('click', function() { switchView('catalog'); });
  document.getElementById('nav-calendar').addEventListener('click', function() { switchView('calendar'); });
  document.getElementById('nav-my-bookings').addEventListener('click', function() { switchView('my-bookings'); });
  document.getElementById('nav-wallet').addEventListener('click', function() { switchView('wallet'); });
  document.getElementById('sgrid-close-btn').addEventListener('click', closeStudentGrid);
  document.getElementById('sgrid-prev-week').addEventListener('click', sgridPrevWeek);
  document.getElementById('sgrid-next-week').addEventListener('click', sgridNextWeek);

  var now   = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();

  renderStats();
  switchView('catalog');
});

/* ── View switcher ──────────────────────────────────────── */
function switchView(view) {
  activeView = view;
  document.getElementById('nav-catalog').classList.toggle('active', view === 'catalog');
  document.getElementById('nav-calendar').classList.toggle('active', view === 'calendar');
  document.getElementById('nav-my-bookings').classList.toggle('active', view === 'my-bookings');
  document.getElementById('nav-wallet').classList.toggle('active', view === 'wallet');
  document.getElementById('view-catalog').classList.toggle('view-hidden', view !== 'catalog');
  document.getElementById('view-calendar').classList.toggle('view-hidden', view !== 'calendar');
  document.getElementById('view-my-bookings').classList.toggle('view-hidden', view !== 'my-bookings');
  document.getElementById('view-wallet').classList.toggle('view-hidden', view !== 'wallet');
  if (view === 'catalog')     renderCatalog();
  if (view === 'calendar')    renderTeacherPicker();
  if (view === 'my-bookings') renderMyBookings();
  if (view === 'wallet' && typeof WalletPanel !== 'undefined') {
    WalletPanel.mount('student-wallet-panel', currentUser.uid);
  }
}

/* ── Stats ──────────────────────────────────────────────── */
function renderStats() {
  var selections = Store.Selections.byStudent(currentUser.uid);
  var bookings   = Store.Slots.byStudent(currentUser.uid).filter(function(s) { return s.status === 'booked'; });
  document.getElementById('stat-teachers').textContent = selections.length;
  document.getElementById('stat-bookings').textContent = bookings.length;
}

/* ══════════════════════════════════════════════════════════
   CATALOG
══════════════════════════════════════════════════════════ */
function renderCatalog() {
  var allTeachers  = Store.Users.byRole('teacher');
  var mySelections = Store.Selections.byStudent(currentUser.uid).map(function(s) { return s.teacherId; });
  var container    = document.getElementById('catalog-grid');
  container.innerHTML = '';

  if (!allTeachers.length) {
    var empty = document.createElement('div');
    empty.className = 'catalog-empty text-muted';
    empty.textContent = 'No teachers available yet.';
    container.appendChild(empty);
    return;
  }

  for (var i = 0; i < allTeachers.length; i++) {
    container.appendChild(buildTeacherCard(allTeachers[i], mySelections));
  }
}

function buildTeacherCard(teacher, mySelections) {
  var isSelected = mySelections.indexOf(teacher.uid) !== -1;
  var availCount = Store.Slots.byTeacher(teacher.uid).filter(function(s) { return s.status === 'available'; }).length;

  var card = document.createElement('div');
  card.className = 'card teacher-card' + (isSelected ? ' teacher-card-selected' : '');

  var top = document.createElement('div');
  top.className = 'teacher-card-top';

  var nameWrap = document.createElement('div');
  var name = document.createElement('div');
  name.className = 'teacher-card-name';
  name.textContent = ProfileStore.getDisplayName(teacher.uid);
  var uid = document.createElement('code');
  uid.className = 'uid-badge';
  uid.textContent = teacher.uid;
  nameWrap.appendChild(name);
  nameWrap.appendChild(uid);
  top.appendChild(nameWrap);

  if (isSelected) {
    var badge = document.createElement('span');
    badge.className = 'teacher-selected-badge';
    badge.textContent = 'Selected';
    top.appendChild(badge);
  }

  var avail = document.createElement('div');
  avail.className = 'teacher-card-avail text-muted';
  avail.textContent = availCount + ' available slot' + (availCount !== 1 ? 's' : '');

  var actions = document.createElement('div');
  actions.className = 'teacher-card-actions';

  if (isSelected) {
    var viewBtn = document.createElement('button');
    viewBtn.className = 'btn btn-secondary btn-sm';
    viewBtn.textContent = 'Book lessons';
    (function(tid) { viewBtn.addEventListener('click', function() { openTeacherGrid(tid); }); })(teacher.uid);

    var removeBtn = document.createElement('button');
    removeBtn.className = 'btn btn-ghost btn-sm';
    removeBtn.textContent = 'Remove';
    (function(tid) { removeBtn.addEventListener('click', function() { deselectTeacher(tid); }); })(teacher.uid);

    actions.appendChild(viewBtn);
    actions.appendChild(removeBtn);
  } else {
    var selectBtn = document.createElement('button');
    selectBtn.className = 'btn btn-primary btn-sm';
    selectBtn.textContent = 'Select';
    (function(tid) { selectBtn.addEventListener('click', function() { selectTeacher(tid); }); })(teacher.uid);
    actions.appendChild(selectBtn);
  }

  card.appendChild(top);
  card.appendChild(avail);
  card.appendChild(actions);
  return card;
}

function selectTeacher(teacherId) {
  Store.Selections.create(currentUser.uid, teacherId);
  Toast.success(ProfileStore.getDisplayName(teacherId) + ' added to your teachers.');
  renderStats();
  renderCatalog();
}

function deselectTeacher(teacherId) {
  Store.Selections.delete(currentUser.uid, teacherId);
  Toast.success(ProfileStore.getDisplayName(teacherId) + ' removed.');
  renderStats();
  renderCatalog();
}

function openTeacherGrid(teacherId) {
  activeTeacherId = teacherId;
  selectedDate    = null;
  switchView('calendar');
}

/* ══════════════════════════════════════════════════════════
   TEACHER PICKER (calendar view top)
══════════════════════════════════════════════════════════ */
function renderTeacherPicker() {
  var myTeachers = Store.Selections.byStudent(currentUser.uid)
    .map(function(s) { return Store.Users.byUid(s.teacherId); })
    .filter(function(t) { return t !== null; });

  var calSection = document.getElementById('cal-section');
  var list    = document.getElementById('teacher-picker-list');
  var label   = document.getElementById('teacher-picker-label');
  var trigger = document.getElementById('teacher-picker-trigger');
  var weekBtn = document.getElementById('teacher-picker-week-btn');

  if (!myTeachers.length) {
    if (list)    list.innerHTML = '';
    if (label)   label.textContent = 'Kein Lehrer ausgewählt';
    if (weekBtn) weekBtn.disabled = true;
    calSection.classList.add('view-hidden');
    return;
  }

  if (!activeTeacherId) activeTeacherId = myTeachers[0].uid;

  /* ── Build options list ── */
  var options = [];
  for (var i = 0; i < myTeachers.length; i++) {
    options.push({ value: myTeachers[i].uid, text: ProfileStore.getDisplayName(myTeachers[i].uid) });
  }

  function setTeacher(val) {
    activeTeacherId = val;
    var selected = null;
    for (var j = 0; j < options.length; j++) {
      if (options[j].value === val) { selected = options[j]; break; }
    }
    label.textContent = selected ? selected.text : options[0].text;
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var k = 0; k < items.length; k++) {
      var isActive = items[k].getAttribute('data-value') === val;
      items[k].classList.toggle('is-active', isActive);
      items[k].setAttribute('aria-selected', isActive ? 'true' : 'false');
    }
    closeDropdown();
    renderCalendar();
    renderDaySlots();
  }

  function openDropdown() {
    list.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    trigger.classList.add('is-open');
  }

  function closeDropdown() {
    list.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.classList.remove('is-open');
  }

  /* ── Rebuild list items ── */
  list.innerHTML = '';
  for (var m = 0; m < options.length; m++) {
    (function(opt) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (opt.value === activeTeacherId ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', opt.value);
      li.setAttribute('aria-selected', opt.value === activeTeacherId ? 'true' : 'false');
      li.textContent = opt.text;
      li.addEventListener('click', function() { setTeacher(opt.value); });
      list.appendChild(li);
    })(options[m]);
  }

  /* ── Sync label to current selection ── */
  var curOpt = null;
  for (var n = 0; n < options.length; n++) {
    if (options[n].value === activeTeacherId) { curOpt = options[n]; break; }
  }
  label.textContent = curOpt ? curOpt.text : options[0].text;

  /* ── Toggle open/close — onclick überschreibt statt zu stapeln ── */
  trigger.onclick = function(e) {
    e.stopPropagation();
    if (list.classList.contains('is-open')) { closeDropdown(); } else { openDropdown(); }
  };

  /* ── Close on outside click — alten Listener zuerst entfernen ── */
  if (_closeTeacherPickerDropdown) {
    document.removeEventListener('click', _closeTeacherPickerDropdown);
  }
  _closeTeacherPickerDropdown = function() { closeDropdown(); };
  document.addEventListener('click', _closeTeacherPickerDropdown);

  /* ── Wochenansicht-Button — onclick überschreibt ── */
  weekBtn.disabled = false;
  weekBtn.onclick  = openStudentGrid;

  /* ── Prev/Next-Monat — einmalig binden ── */
  if (!_pickerMonthBtnsInit) {
    _pickerMonthBtnsInit = true;
    document.getElementById('prev-btn').addEventListener('click', prevMonth);
    document.getElementById('next-btn').addEventListener('click', nextMonth);
  }

  calSection.classList.remove('view-hidden');
  renderCalendar();
  renderDaySlots();
}

/* ══════════════════════════════════════════════════════════
   STUDENT WEEK GRID OVERLAY
══════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════
   MONTH CALENDAR
══════════════════════════════════════════════════════════ */
function renderCalendar() {
  var calSection = document.getElementById('cal-section');
  if (!calSection) return;

  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;
  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow     = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeDayCell(prevDays - i, true));
  }
  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isPast  = date < TODAY;
      var isToday = date.getTime() === TODAY.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots   = activeTeacherId ? Store.Slots.byTeacherDate(activeTeacherId, dateStr) : [];
      var hasAvail  = !isPast && slots.some(function(s) { return s.status === 'available' || s.status === 'recurring'; });
      var hasMyBook = slots.some(function(s) { return s.status === 'booked' && s.studentId === currentUser.uid; });

      var cell = makeDayCell(day, false, isToday, isSel, hasAvail, hasMyBook);
      if (!isPast) {
        cell.setAttribute('tabindex', '0');
        cell.addEventListener('click', function() { selectedDate = date; renderCalendar(); renderDaySlots(); });
        cell.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') { selectedDate = date; renderCalendar(); renderDaySlots(); } });
      }
      grid.appendChild(cell);
    })(d);
  }
  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeDayCell(t, true));
  }
}

function makeDayCell(num, otherMonth, isToday, isSelected, hasAvail, hasMyBook) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth) el.classList.add('other-month');
  if (isToday)    el.classList.add('today');
  if (isSelected) el.classList.add('selected');
  if (hasAvail)   el.classList.add('has-avail');
  if (hasMyBook)  el.classList.add('has-mybook');
  el.textContent = num;
  return el;
}

function prevMonth() {
  viewMonth--;
  if (viewMonth < 0) { viewMonth = 11; viewYear--; }
  renderCalendar();
  renderDaySlots();
}
function nextMonth() {
  viewMonth++;
  if (viewMonth > 11) { viewMonth = 0; viewYear++; }
  renderCalendar();
  renderDaySlots();
}

/* ══════════════════════════════════════════════════════════
   DAY SLOT LIST
══════════════════════════════════════════════════════════ */
function renderDaySlots() {
  var container = document.getElementById('day-slots');
  if (!container) return;
  container.innerHTML = '';

  if (!selectedDate || !activeTeacherId) return;

  var dateStr = fmtDate(selectedDate);
  var slots   = Store.Slots.byTeacherDate(activeTeacherId, dateStr);
  var label   = selectedDate.toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' });

  var card = document.createElement('div');
  card.className = 'card day-slots-card';

  var heading = document.createElement('div');
  heading.className = 'day-slots-heading';
  heading.textContent = label;
  card.appendChild(heading);

  // Filter visible slots
  var visible = slots.filter(function(s) {
    if (s.status === 'available' || s.status === 'recurring') return true;
    if (s.status === 'booked' && s.studentId === currentUser.uid) return true;
    return false;
  });

  if (!visible.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted day-slots-empty';
    empty.textContent = 'No available slots on this day.';
    card.appendChild(empty);
    container.appendChild(card);
    return;
  }

  var list = document.createElement('div');
  list.className = 'day-slot-list';

  for (var i = 0; i < visible.length; i++) {
    list.appendChild(buildDaySlotRow(visible[i]));
  }
  card.appendChild(list);
  container.appendChild(card);
}

function buildDaySlotRow(slot) {
  var isMine = slot.status === 'booked' && slot.studentId === currentUser.uid;
  var row = document.createElement('div');
  row.className = 'day-slot-row' + (isMine ? ' day-slot-row-mine' : '');

  var timeEl = document.createElement('span');
  timeEl.className = 'day-slot-time';
  timeEl.textContent = slot.time + ' \u2013 ' + Store.slotEndTime(slot.time);

  if (isMine) {
    var isPastSlot  = slot.date < fmtDate(new Date());
    var isConfirmed = !!slot.confirmedAt;

    row.appendChild(timeEl);

    if (isConfirmed) {
      /* Bestätigt: nur Badge, keine weiteren Aktionen */
      var badge = document.createElement('span');
      badge.className = 'badge badge-confirmed';
      badge.textContent = '\u2713 Best\u00E4tigt';
      row.appendChild(badge);
    } else {
      /* Unbestätigt: Bestätigen + ggf. Stornieren */
      var confirmBtn = document.createElement('button');
      confirmBtn.className = 'btn btn-ghost btn-sm';
      confirmBtn.textContent = '\u2713 Best\u00E4tigen';
      (function(s) {
        confirmBtn.addEventListener('click', function() {
          _openStudentConfirmDialog(s.slotId);
        });
      })(slot);
      row.appendChild(confirmBtn);

      if (!isPastSlot) {
        var cancelBtn = document.createElement('button');
        cancelBtn.className = 'btn btn-danger btn-sm';
        cancelBtn.textContent = 'Stornieren';
        (function(s) {
          cancelBtn.addEventListener('click', function() { cancelDaySlot(s.slotId, s.time); });
        })(slot);
        row.appendChild(cancelBtn);
      }
    }
  } else {
    var bookBtn = document.createElement('button');
    bookBtn.className = 'btn btn-primary btn-sm';
    bookBtn.textContent = 'Buchen';
    (function(s) {
      bookBtn.addEventListener('click', function() { bookDaySlot(s.slotId); });
    })(slot);
    row.appendChild(timeEl);
    row.appendChild(bookBtn);
  }
  return row;
}

function bookDaySlot(slotId) {
  Store.Slots.update(slotId, { status: 'booked', studentId: currentUser.uid });
  Toast.success('Slot gebucht.');
  renderStats();
  renderCalendar();
  renderDaySlots();
}

function cancelDaySlot(slotId, time) {
  /* Sicherheitsprüfung: bestätigte Slots dürfen nicht storniert werden */
  var slot = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
  if (slot && slot.confirmedAt) {
    Toast.error('Best\u00E4tigte Buchungen k\u00F6nnen nicht storniert werden.');
    return;
  }
  var result = Modal.show({
    title: 'Buchung stornieren',
    bodyHTML: '<p>Buchung um <strong>' + time + '</strong> wirklich stornieren?</p>',
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button><button class="btn btn-danger" id="modal-confirm">Stornieren</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    Store.Slots.cancelBooking(slotId);
    Toast.success('Buchung storniert.');
    renderStats();
    renderCalendar();
    renderDaySlots();
    result.close();
  });

}

function openStudentGrid() {
  if (!activeTeacherId) return;

  // Start on current week (Monday)
  if (!sgridWeekStart) {
    var monday = new Date(TODAY);
    var dow = monday.getDay();
    dow = (dow === 0) ? 6 : dow - 1;
    monday.setDate(monday.getDate() - dow);
    sgridWeekStart = monday;
  }

  var teacher = Store.Users.byUid(activeTeacherId);
  document.getElementById('sgrid-teacher-name').textContent = ProfileStore.getDisplayName(activeTeacherId);

  document.getElementById('student-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  renderStudentGrid();
}

function closeStudentGrid() {
  document.getElementById('student-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  renderStats();
}

function sgridPrevWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() - 7);
  renderStudentGrid();
}

function sgridNextWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() + 7);
  renderStudentGrid();
}

/* ── Week grid render ───────────────────────────────────── */
function renderStudentGrid() {
  var weekDates = getSgridWeekDates();

  // Materialise recurring rules for this week so all days show correct slots
  if (activeTeacherId) {
    Store.Recurring.materialiseWeek(activeTeacherId, weekDates);
  }

  var times = Store.slotTimesInRange(GRID_START, GRID_END);

  // Update week label
  document.getElementById('sgrid-week-label').textContent = sgridWeekRangeLabel(weekDates);

  var container = document.getElementById('sgrid-content');
  container.innerHTML = '';

  var table = document.createElement('table');
  table.className = 'slot-grid-table';

  // ── thead ──
  var thead = document.createElement('thead');
  var hrow  = document.createElement('tr');

  var thTime = document.createElement('th');
  thTime.className = 'grid-th-time';
  thTime.textContent = 'Time';
  hrow.appendChild(thTime);

  for (var d = 0; d < weekDates.length; d++) {
    var wd      = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var isPast  = wd < TODAY;

    var th = document.createElement('th');
    th.className = 'grid-th-day';
    if (isToday) th.classList.add('grid-th-today');

    var nameSpan = document.createElement('span');
    nameSpan.className = 'grid-day-name';
    nameSpan.textContent = DAY_NAMES[d];

    var numSpan = document.createElement('span');
    numSpan.className = 'grid-day-num';
    if (isToday) numSpan.classList.add('grid-day-today');
    numSpan.textContent = wd.getDate();

    th.appendChild(nameSpan);
    th.appendChild(numSpan);
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // ── tbody ──
  var tbody = document.createElement('tbody');

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    var tr   = document.createElement('tr');

    var tdTime = document.createElement('td');
    tdTime.className = 'grid-td-time';
    tdTime.textContent = time;
    tr.appendChild(tdTime);

    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var isPastDay   = cellDate < TODAY;
      var slot        = Store.Slots.exists(activeTeacherId, cellDateStr, time);

      // Determine cell state from student's perspective
      var cellClass;
      var isClickable = false;

      if (!slot || slot.status === 'disabled' || slot.status === 'timeout' || isPastDay) {
        cellClass = 'gc-empty';
      } else if (slot.status === 'available' || slot.status === 'recurring') {
        cellClass = 'gc-available';
        isClickable = true;
      } else if (slot.status === 'booked' && slot.studentId === currentUser.uid) {
        cellClass = 'gc-mine';
        isClickable = true;
      } else {
        // booked by someone else
        cellClass = 'gc-empty';
      }

      var td   = document.createElement('td');
      td.className = 'grid-td-cell';

      var cell = document.createElement('div');
      cell.className = 'grid-cell ' + cellClass;
      cell.dataset.date   = cellDateStr;
      cell.dataset.time   = time;
      cell.dataset.slotid = slot ? slot.slotId : '';

      if (isClickable) {
        cell.addEventListener('click', onStudentCellClick);
      }

      td.appendChild(cell);
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  container.appendChild(table);
}

function onStudentCellClick(e) {
  var cell   = e.currentTarget;
  var date   = cell.dataset.date;
  var time   = cell.dataset.time;
  var slotId = cell.dataset.slotid;
  var isMine = cell.classList.contains('gc-mine');

  if (isMine) {
    /* Sicherheitsprüfung: bestätigte Slots dürfen nicht storniert werden */
    var existingSlot = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
    if (existingSlot && existingSlot.confirmedAt) {
      Toast.error('Best\u00E4tigte Buchungen k\u00F6nnen nicht storniert werden.');
      return;
    }
    var result = Modal.show({
      title: 'Buchung stornieren',
      bodyHTML: '<p>Buchung um <strong>' + time + ' \u2013 ' + Store.slotEndTime(time) + '</strong> am ' + date + ' wirklich stornieren?</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button><button class="btn btn-danger" id="modal-confirm">Stornieren</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      Store.Slots.cancelBooking(slotId);
      Toast.success('Buchung storniert.');
      renderStats();
      renderStudentGrid();
      result.close();
    });
  } else {
    var slot = Store.Slots.exists(activeTeacherId, date, time);
    if (!slot) return;
    Store.Slots.update(slot.slotId, { status: 'booked', studentId: currentUser.uid });
    Toast.success('Gebucht: ' + time + ' \u2013 ' + Store.slotEndTime(time));
    renderStats();
    renderStudentGrid();
  }
}

/* ── Helpers ────────────────────────────────────────────── */
function getSgridWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(sgridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function sgridWeekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function fmtDate(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}

/* ══════════════════════════════════════════════════════════
   MY BOOKINGS
══════════════════════════════════════════════════════════ */
function renderMyBookings() {
  /* ── Sort-Button (einmalig verdrahten) ── */
  if (!_myBookingsSortBtnInit) {
    _myBookingsSortBtnInit = true;
    var sortBtn = document.getElementById('mb-sort-btn');
    if (sortBtn) {
      sortBtn.onclick = function() {
        myBookingsSortAsc = !myBookingsSortAsc;
        _updateMyBookingsSortBtn();
        renderMyBookingsList();
      };
    }
  }
  _updateMyBookingsSortBtn();

  /* ── Zeitfilter-Buttons ── */
  var timeBtns = document.querySelectorAll('.mb-time-btn');
  for (var t = 0; t < timeBtns.length; t++) {
    timeBtns[t].classList.toggle('active', timeBtns[t].id === 'mb-filter-' + myBookingsTimeFilter);
    (function(btn) {
      btn.onclick = function() {
        myBookingsTimeFilter = btn.id.replace('mb-filter-', '');
        myBookingsSortAsc = (myBookingsTimeFilter !== 'past');
        for (var j = 0; j < timeBtns.length; j++) timeBtns[j].classList.remove('active');
        btn.classList.add('active');
        _updateMyBookingsSortBtn();
        renderMyBookingsList();
      };
    })(timeBtns[t]);
  }

  /* ── Statusfilter-Buttons ── */
  var confirmBtns = document.querySelectorAll('.mb-confirm-btn');
  for (var ci = 0; ci < confirmBtns.length; ci++) {
    confirmBtns[ci].classList.toggle('active', confirmBtns[ci].dataset.confirm === myBookingsConfirmFilter);
    (function(btn) {
      btn.onclick = function() {
        myBookingsConfirmFilter = btn.dataset.confirm;
        for (var cj = 0; cj < confirmBtns.length; cj++) confirmBtns[cj].classList.remove('active');
        btn.classList.add('active');
        renderMyBookingsList();
      };
    })(confirmBtns[ci]);
  }

  _updateMyBookingsUnconfirmedBadge();
  renderMyBookingsList();
}

function _updateMyBookingsSortBtn() {
  var sortBtn = document.getElementById('mb-sort-btn');
  if (!sortBtn) return;
  sortBtn.setAttribute('aria-label', myBookingsSortAsc ? 'Aelteste zuerst — umkehren' : 'Neueste zuerst — umkehren');
  sortBtn.querySelector('.sort-icon-asc').classList.toggle('is-hidden', !myBookingsSortAsc);
  sortBtn.querySelector('.sort-icon-desc').classList.toggle('is-hidden', myBookingsSortAsc);
}

function _updateMyBookingsUnconfirmedBadge() {
  var badge = document.getElementById('mb-unconfirmed-count-badge');
  if (!badge) return;
  var today = fmtDate(new Date());
  var count = Store.Slots.byStudent(currentUser.uid).filter(function(s) {
    return s.status === 'booked' && !s.confirmedAt && s.date >= today;
  }).length;
  badge.textContent = count;
  badge.classList.toggle('is-hidden', count === 0);
}

function renderMyBookingsList() {
  var container = document.getElementById('my-bookings-list');
  if (!container) return;
  container.innerHTML = '';

  var today = fmtDate(new Date());

  var slots = Store.Slots.byStudent(currentUser.uid).filter(function(s) {
    return s.status === 'booked';
  });

  if (myBookingsTimeFilter === 'past') {
    slots = slots.filter(function(s) { return s.date < today; });
  } else if (myBookingsTimeFilter === 'upcoming') {
    slots = slots.filter(function(s) { return s.date >= today; });
  }

  if (myBookingsConfirmFilter === 'confirmed') {
    slots = slots.filter(function(s) { return !!s.confirmedAt; });
  } else if (myBookingsConfirmFilter === 'unconfirmed') {
    slots = slots.filter(function(s) { return !s.confirmedAt; });
  }

  var emptyReasons = {
    past:     'Keine vergangenen Buchungen.',
    upcoming: 'Keine kommenden Buchungen.',
    all:      'Keine Buchungen gefunden.'
  };

  if (!slots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = emptyReasons[myBookingsTimeFilter] || 'Keine Buchungen gefunden.';
    container.appendChild(empty);
    return;
  }

  slots.sort(function(a, b) {
    return a.date.localeCompare(b.date) || a.time.localeCompare(b.time);
  });

  /* Gruppe nach Datum */
  var byDate    = {};
  var dateOrder = [];
  for (var i = 0; i < slots.length; i++) {
    var s = slots[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  if (!myBookingsSortAsc) { dateOrder.reverse(); }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr   = dateOrder[d];
    var dateSlots = byDate[dateStr];
    var isPast    = dateStr < today;

    /* ── Datum-Headline (wie Teacher) ── */
    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider' + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    container.appendChild(divider);

    /* ── Blöcke: konsekutive Slots desselben Lehrers zusammenfassen ── */
    var blocks = _mergeStudentBookingBlocks(dateStr, dateSlots, today);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(_buildStudentBookingBlock(blocks[b], isPast));
    }
  }
}

/* Fasst aufeinanderfolgende Slots desselben Lehrers zu einem Block zusammen */
function _mergeStudentBookingBlocks(dateStr, slots, today) {
  var blocks = [];
  var i = 0;
  while (i < slots.length) {
    var s       = slots[i];
    var end     = Store.slotEndTime(s.time);
    var grp     = [s];
    var j       = i + 1;

    while (j < slots.length) {
      var next = slots[j];
      if (next.teacherId === s.teacherId && next.time === end) {
        end = Store.slotEndTime(next.time);
        grp.push(next);
        j++;
      } else { break; }
    }

    var isFullyConfirmed = grp.every(function(x) { return !!x.confirmedAt; });
    blocks.push({
      dateStr:          dateStr,
      today:            today,
      teacherId:        s.teacherId,
      start:            s.time,
      end:              end,
      bookedSlots:      grp,
      isFullyConfirmed: isFullyConfirmed
    });
    i = j;
  }
  return blocks;
}

function _buildStudentBookingBlock(block, isPast) {
  var teacherName      = ProfileStore.getDisplayName(block.teacherId);
  var isFullyConfirmed = block.isFullyConfirmed;

  var wrapper = document.createElement('div');
  wrapper.className = 'all-booking-block-wrapper';

  /* ── Header ── */
  var header = document.createElement('div');
  header.className = 'all-booking-block-header' + (isPast ? ' all-booking-block-past' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'all-booking-block-time';
  timeEl.textContent = block.start + ' – ' + block.end;

  var teacherEl = document.createElement('span');
  teacherEl.className = 'all-booking-block-student';
  teacherEl.textContent = teacherName;

  var chevron = document.createElement('span');
  chevron.className = 'all-booking-chevron';
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  header.appendChild(timeEl);
  header.appendChild(teacherEl);

  if (isFullyConfirmed) {
    /* Bestätigt: Badge */
    var confirmedBadge = document.createElement('span');
    confirmedBadge.className = 'badge badge-confirmed';
    confirmedBadge.textContent = '✓ Bestätigt';
    header.appendChild(confirmedBadge);
  } else if (!isPast) {
    /* Unbestätigt + zukünftig: Bestätigen */
    var confirmBtn = document.createElement('button');
    confirmBtn.className = 'btn btn-ghost btn-sm all-booking-confirm-btn';
    confirmBtn.textContent = '✓ Bestätigen';
    (function(b) {
      confirmBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        _openStudentConfirmBlockDialog(b);
      });
    })(block);
    header.appendChild(confirmBtn);

    /* Stornieren */
    var cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn btn-danger btn-sm';
    cancelBtn.textContent = 'Stornieren';
    (function(b) {
      cancelBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        _cancelBookingBlock(b);
      });
    })(block);
    header.appendChild(cancelBtn);
  }

  header.appendChild(chevron);

  /* ── Detail-Panel ── */
  var detail = document.createElement('div');
  detail.className = 'all-booking-block-detail';

  function toggle() {
    var isOpen = detail.classList.contains('is-open');
    detail.classList.toggle('is-open', !isOpen);
    chevron.classList.toggle('is-open', !isOpen);
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
  });

  /* Detail-Inhalt: ein Row pro Slot */
  for (var i = 0; i < block.bookedSlots.length; i++) {
    var slot        = block.bookedSlots[i];
    var isConfirmed = !!slot.confirmedAt;
    var isSlotPast  = slot.date < block.today;

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row';

    var slotTime = document.createElement('span');
    slotTime.className = 'all-booking-slot-time';
    slotTime.textContent = slot.time + ' – ' + Store.slotEndTime(slot.time);

    var slotStatus = document.createElement('span');
    slotStatus.className = 'all-booking-slot-status';
    slotStatus.textContent = isConfirmed ? 'Bestätigt' : 'Unbestätigt';

    var btnGroup = document.createElement('div');
    btnGroup.className = 'all-booking-slot-btns';

    if (isConfirmed) {
      var sBadge = document.createElement('span');
      sBadge.className = 'badge badge-confirmed';
      sBadge.textContent = '✓';
      btnGroup.appendChild(sBadge);
    } else if (!isSlotPast) {
      var sConfirmBtn = document.createElement('button');
      sConfirmBtn.className = 'btn btn-ghost btn-sm';
      sConfirmBtn.textContent = '✓';
      sConfirmBtn.title = 'Bestätigen';
      (function(sid) {
        sConfirmBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          _openStudentConfirmDialog(sid);
        });
      })(slot.slotId);
      btnGroup.appendChild(sConfirmBtn);

      var sCancelBtn = document.createElement('button');
      sCancelBtn.className = 'btn btn-danger btn-sm';
      sCancelBtn.textContent = 'Stornieren';
      (function(s) {
        sCancelBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          _cancelBookingFromList(s.slotId, s.time, s.date);
        });
      })(slot);
      btnGroup.appendChild(sCancelBtn);
    }

    row.appendChild(slotTime);
    row.appendChild(slotStatus);
    row.appendChild(btnGroup);
    detail.appendChild(row);
  }

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

/* Block-Level Bestätigungs-Dialog (alle Slots des Blocks auf einmal) */
function _openStudentConfirmBlockDialog(block) {
  var teacherName = ProfileStore.getDisplayName(block.teacherId);
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">⚠ <strong>Achtung:</strong> Diese Aktion kann nicht rückgängig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Bestätigung deiner Buchung bei <strong>' + teacherName + '</strong> (' + block.start + ' – ' + block.end + '):</p>' +
      '<ul class="confirm-dialog-list">' +
        '<li>kann die Buchung <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung für diese Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';
  var result = Modal.show({
    title: 'Buchung bestätigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
                '<button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      for (var ci = 0; ci < block.bookedSlots.length; ci++) {
        Store.Slots.confirm(block.bookedSlots[ci].slotId);
      }
      Toast.success('Buchung bestätigt.');
      renderStats();
      _updateMyBookingsUnconfirmedBadge();
      renderMyBookingsList();
      result.close();
    } catch (e) {
      Toast.error('Fehler bei der Bestätigung: ' + e.message);
      result.close();
    }
  });
}

/* Block-Level Stornierung (alle Slots des Blocks) */
function _cancelBookingBlock(block) {
  var teacherName = ProfileStore.getDisplayName(block.teacherId);
  var result = Modal.show({
    title: 'Buchung stornieren',
    bodyHTML: '<p>Buchung bei <strong>' + teacherName + '</strong> (' + block.start + ' – ' + block.end + ') wirklich stornieren?</p>',
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button>' +
                '<button class="btn btn-danger" id="modal-confirm">Stornieren</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      for (var ri = 0; ri < block.bookedSlots.length; ri++) {
        Store.Slots.cancelBooking(block.bookedSlots[ri].slotId);
      }
      Toast.success('Buchung storniert.');
      renderStats();
      _updateMyBookingsUnconfirmedBadge();
      renderMyBookingsList();
      result.close();
    } catch (e) {
      Toast.error('Fehler beim Stornieren: ' + e.message);
      result.close();
    }
  });
}

function _openStudentConfirmDialog(slotId) {
  var slot = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
  if (!slot) return;
  var teacherName = ProfileStore.getDisplayName(slot.teacherId);
  var endTime     = Store.slotEndTime(slot.time);

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">\u26a0 <strong>Achtung:</strong> Diese Aktion kann nicht r\u00FCckg\u00E4ngig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Best\u00E4tigung deiner Buchung bei <strong>' + teacherName + '</strong> (' + slot.time + ' \u2013 ' + endTime + '):</p>' +
      '<ul class="confirm-dialog-list">' +
        '<li>kann die Buchung <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung f\u00FCr diese Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';

  var result = Modal.show({
    title: 'Buchung best\u00E4tigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>'
             + '<button class="btn btn-primary" id="modal-confirm">Jetzt best\u00E4tigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      Store.Slots.confirm(slotId);
      Toast.success('Buchung best\u00E4tigt.');
      renderStats();
      _updateMyBookingsUnconfirmedBadge();
      renderMyBookingsList();
      result.close();
    } catch (e) {
      Toast.error('Fehler bei der Best\u00E4tigung: ' + e.message);
      result.close();
    }
  });
}

function _cancelBookingFromList(slotId, time, date) {
  /* Sicherheitsprüfung: bestätigte Slots dürfen nicht storniert werden */
  var slot = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
  if (slot && slot.confirmedAt) {
    Toast.error('Best\u00E4tigte Buchungen k\u00F6nnen nicht storniert werden.');
    return;
  }

  var parts     = date.split('-');
  var dateObj   = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' });

  var result = Modal.show({
    title: 'Buchung stornieren',
    bodyHTML: '<p>Buchung am <strong>' + dateLabel + '</strong> um <strong>' + time + '</strong> wirklich stornieren?</p>',
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button>'
             + '<button class="btn btn-danger" id="modal-confirm">Stornieren</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      Store.Slots.cancelBooking(slotId);
      Toast.success('Buchung storniert.');
      renderStats();
      _updateMyBookingsUnconfirmedBadge();
      renderMyBookingsList();
      result.close();
    } catch (e) {
      Toast.error('Fehler beim Stornieren: ' + e.message);
      result.close();
    }
  });
}


/* ── Cross-tab sync: re-render when another tab changes data ── */
if (Store.onChange) {
  Store.onChange(function(e) {
    if (e.key === 'app_slots' || e.key === 'app_selections' || e.key === 'app_users') {
      renderStats();
      renderCatalog();
      if (activeView === 'my-bookings') renderMyBookings();
      if (activeTeacherId) {
        renderCalendar();
        renderDaySlots();
      }
    }
  });
}
