/**
 * skiing-catalog.js — Skiing Teacher Catalog
 *
 * Lädt alle Teacher aus Store.Users, kombiniert mit ProfileStore-Daten,
 * rendert Karten mit Collapse/Expand-Verhalten.
 * Buchen-Button: eingeloggte User → teacher.html, nicht eingeloggte → AuthModal.
 *
 * i18n Namespace: skiing-catalog (Deutsch Standard)
 * Regeln: var only, function(){}, string concat, no arrow functions,
 *         no ?. or ??, no template literals, no inline styles
 *
 * Wiederverwendung:
 *   - pv-* CSS-Klassen aus profile.css (Sections, Terrain, Certs, Specs)
 *   - AuthModal aus landing.js
 *   - Navbar.init(page, options) aus navbar.js
 */

/* ── i18n ───────────────────────────────────────────────── */
var CatalogI18n = {
  subtitle:          ' Lehrer verfügbar',
  subtitleNone:      'Keine Lehrer gefunden',
  experienceYears:   'Jahre Erfahrung',
  pricePerHalf:      'pro 30 Min.',
  expandBtn:         'Profil anzeigen',
  collapseBtn:       'Schließen',
  bookBtn:           'Lehrer buchen',
  bookHintLoggedIn:  'Du wirst zum Buchungskalender weitergeleitet.',
  bookHintGuest:     'Melde dich an, um zu buchen.',
  emptyState:        'Kein Lehrer gefunden.',
  resetFilters:      'Filter zurücksetzen',
  noBio:             'Kein Profil-Text vorhanden.',
  sectionAbout:      'Über mich',
  loginToBook:       'Anmelden um zu buchen'
};

/* ── State ──────────────────────────────────────────────── */
var _allTeachers     = [];   /* [{user, profile}] */
var _filteredTeachers = [];
var _expandedUid     = null; /* only one open at a time */
var _filterLevel     = '';
var _filterLesson    = '';

/* ── Init ───────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', function() {
  Navbar.init('catalog', {
    loginBtn: {
      label:   'Anmelden',
      onClick: function() { AuthModal.open('signin'); }
    }
  });

  _loadTeachers();
  _bindFilters();
  _bindResetBtn();
  _render();

  /* Cards + jump buttons bound ONCE — not inside _render() */
  _bindCards();
  _bindJumpBtns();
  updateCatalogJumpBtns();
  _updateFabForExpanded(); /* sets neutral FAB state on load */
});

/* ── Load all teachers ──────────────────────────────────── */
function _loadTeachers() {
  var teachers = Store.Users.byRole('teacher');
  _allTeachers = [];
  for (var i = 0; i < teachers.length; i++) {
    var user    = teachers[i];
    var profile = ProfileStore.getOrDefault(user.uid);
    _allTeachers.push({ user: user, profile: profile });
  }
}

/* ── Filter logic ───────────────────────────────────────── */
function _applyFilters() {
  _filteredTeachers = [];
  for (var i = 0; i < _allTeachers.length; i++) {
    var t = _allTeachers[i];
    var p = t.profile;

    /* Level filter */
    if (_filterLevel) {
      var levels = p.levels || [];
      var hasLevel = false;
      for (var l = 0; l < levels.length; l++) {
        if (levels[l] === _filterLevel) { hasLevel = true; break; }
      }
      if (!hasLevel) continue;
    }

    /* Lesson filter */
    if (_filterLesson) {
      var types = p.lessonTypes || [];
      var hasType = false;
      for (var lt = 0; lt < types.length; lt++) {
        if (types[lt] === _filterLesson) { hasType = true; break; }
      }
      if (!hasType) continue;
    }

    _filteredTeachers.push(t);
  }
}

/* ── Render ─────────────────────────────────────────────── */
function _render() {
  _applyFilters();

  var grid  = document.getElementById('catalog-grid');
  var empty = document.getElementById('catalog-empty');
  var sub   = document.getElementById('catalog-subtitle');
  if (!grid) return;

  /* Subtitle */
  if (sub) {
    sub.textContent = _filteredTeachers.length > 0
      ? _filteredTeachers.length + CatalogI18n.subtitle
      : CatalogI18n.subtitleNone;
  }

  /* Empty state */
  if (!_filteredTeachers.length) {
    grid.innerHTML = '';
    if (empty) empty.classList.remove('is-hidden');
    return;
  }
  if (empty) empty.classList.add('is-hidden');

  /* Rebuild grid */
  grid.innerHTML = '';
  for (var i = 0; i < _filteredTeachers.length; i++) {
    var card = _buildCard(_filteredTeachers[i], i);
    grid.appendChild(card);
  }

  /* Update jump buttons after every render */
  setTimeout(updateCatalogJumpBtns, 50);
}

/* ── Build Card DOM ─────────────────────────────────────── */
function _buildCard(teacher, idx) {
  var user    = teacher.user;
  var p       = teacher.profile;
  var uid     = user.uid;
  var isOpen  = (_expandedUid === uid);

  var card = document.createElement('div');
  card.className = 'tc-card' + (isOpen ? ' is-expanded' : '');
  card.setAttribute('data-uid', uid);

  card.innerHTML = _buildSummaryHTML(p, uid, isOpen) +
    _buildPreviewHTML(p, isOpen) +
    _buildDetailHTML(p, uid);

  return card;
}

/* ── Summary (always visible) ───────────────────────────── */
function _buildSummaryHTML(p, uid, isOpen) {
  var photoHTML = p.photo
    ? '<img class="tc-avatar" src="' + _esc(p.photo) + '" alt="' + _esc(p.name) + '">'
    : '<div class="tc-avatar-placeholder">' +
        '<svg width="22" height="22" viewBox="0 0 24 24" fill="none">' +
          '<path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z"' +
          ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
        '</svg>' +
      '</div>';

  var locationHTML = p.location
    ? '<span class="tc-summary-location">' +
        '<svg width="11" height="11" viewBox="0 0 16 16" fill="none">' +
          '<path d="M8 1a5 5 0 015 5c0 3.5-5 9-5 9S3 9.5 3 6a5 5 0 015-5z"' +
          ' stroke="currentColor" stroke-width="1.5"/>' +
          '<circle cx="8" cy="6" r="1.5" stroke="currentColor" stroke-width="1.5"/>' +
        '</svg>' +
        _esc(p.location) +
      '</span>'
    : '';

  var expHTML = p.experienceYears
    ? '<span class="tc-summary-exp">' + _esc(p.experienceYears) + ' J.</span>'
    : '';

  var priceHTML = p.pricePerHalfHour
    ? '<span class="tc-summary-price">€' + _esc(p.pricePerHalfHour) + ' / 30min</span>'
    : '';

  var langMap = { de: 'DE', en: 'EN', fr: 'FR', it: 'IT', es: 'ES', ru: 'RU', ja: 'JA', zh: 'ZH' };
  var langsHTML = '';
  if (p.languages && p.languages.length) {
    for (var i = 0; i < p.languages.length; i++) {
      langsHTML += '<span class="pv-lang-badge">' + _esc(langMap[p.languages[i]] || p.languages[i].toUpperCase()) + '</span>';
    }
  }

  var expandBtnLabel = isOpen ? CatalogI18n.collapseBtn : CatalogI18n.expandBtn;

  return '<div class="tc-summary" data-uid="' + _esc(uid) + '">' +
    photoHTML +
    '<div class="tc-summary-info">' +
      '<p class="tc-summary-name">' + _esc(p.name || user.name || uid) + '</p>' +
      '<div class="tc-summary-meta">' +
        locationHTML +
        expHTML +
        priceHTML +
      '</div>' +
      (langsHTML ? '<div class="tc-summary-langs">' + langsHTML + '</div>' : '') +
    '</div>' +
    '<button class="tc-chat-btn" data-chat-uid="' + _esc(uid) + '" aria-label="Chat mit ' + _esc(p.name || uid) + '">' +
      '<svg width="14" height="14" viewBox="0 0 20 20" fill="none">' +
        '<path d="M2 4a2 2 0 012-2h12a2 2 0 012 2v9a2 2 0 01-2 2H6l-4 3V4z"' +
        ' stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>' +
      '</svg>' +
    '</button>' +
    '<button class="tc-expand-btn" data-uid="' + _esc(uid) + '" aria-label="' + _esc(expandBtnLabel) + '" aria-expanded="' + (isOpen ? 'true' : 'false') + '">' +
      '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">' +
        '<path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
      '</svg>' +
    '</button>' +
  '</div>';
}

/* ── Preview (bio + chips, hidden when expanded) ────────── */
function _buildPreviewHTML(p, isOpen) {
  if (isOpen) return '';

  var bioHTML = '';
  if (p.bio) {
    bioHTML = '<p class="tc-preview-bio">' + _esc(p.bio) + '</p>';
  }

  var specMap = {
    kids: 'Kinder', freeride: 'Freeride', freestyle: 'Freestyle',
    racing: 'Racing', anxiety: 'Angst-Training', adaptive: 'Adaptive',
    snowboard: 'Snowboard', telemark: 'Telemark',
    firstaid: 'Erste Hilfe', avalanche: 'Lawinenkurs'
  };

  var chipsHTML = '';
  var specs = p.specializations || [];
  var maxChips = 3;
  for (var i = 0; i < specs.length && i < maxChips; i++) {
    chipsHTML += '<span class="tc-preview-chip">' + _esc(specMap[specs[i]] || specs[i]) + '</span>';
  }
  if (specs.length > maxChips) {
    chipsHTML += '<span class="tc-preview-chip-more">+' + (specs.length - maxChips) + '</span>';
  }

  if (!bioHTML && !chipsHTML) return '';

  return '<div class="tc-preview">' +
    bioHTML +
    (chipsHTML ? '<div class="tc-preview-specs">' + chipsHTML + '</div>' : '') +
  '</div>';
}

/* ── Detail (expanded only) ─────────────────────────────── */
function _buildDetailHTML(p, uid) {
  var aboutHTML = p.bio
    ? '<div class="pv-section">' +
        '<h2 class="pv-section-title">' + CatalogI18n.sectionAbout + '</h2>' +
        '<p class="pv-bio">' + _esc(p.bio) + '</p>' +
      '</div>'
    : '';

  var teachingHTML = _buildTeachingSection(p);
  var terrainHTML  = _buildTerrainSection(p);
  var certsHTML    = _buildCertsSection(p);
  var specsHTML    = _buildSpecsSection(p);
  var contactHTML  = _buildContactSection(p);

  /* Two-col grid for teaching + terrain */
  var gridHTML = '';
  if (teachingHTML || terrainHTML) {
    gridHTML = '<div class="tc-detail-grid">' +
      (teachingHTML || '') +
      (terrainHTML  || '') +
    '</div>';
  }

  /* Full-width: specs + certs */
  var fullHTML = '';
  if (specsHTML) fullHTML += '<div class="tc-detail-full">' + specsHTML + '</div>';
  if (certsHTML) fullHTML += '<div class="tc-detail-full">' + certsHTML + '</div>';
  if (contactHTML) fullHTML += '<div class="tc-detail-full">' + contactHTML + '</div>';

  /* Book CTA */
  var user       = Auth.current();
  var isLoggedIn = !!user;
  var bookHint   = isLoggedIn ? CatalogI18n.bookHintLoggedIn : CatalogI18n.bookHintGuest;
  var bookLabel  = isLoggedIn ? CatalogI18n.bookBtn : CatalogI18n.loginToBook;

  var ctaHTML = '<div class="tc-book-row">' +
    '<span class="tc-book-hint">' + _esc(bookHint) + '</span>' +
    '<button class="btn btn-primary tc-book-btn" data-book-uid="' + _esc(uid) + '">' +
      '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">' +
        '<rect x="1" y="2" width="14" height="13" rx="2" stroke="currentColor" stroke-width="1.5"/>' +
        '<path d="M5 1v2M11 1v2M1 6h14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
      '</svg>' +
      _esc(bookLabel) +
    '</button>' +
  '</div>';

  return '<div class="tc-detail">' +
    (aboutHTML ? '<div class="tc-detail-full">' + aboutHTML + '</div>' : '') +
    gridHTML +
    fullHTML +
    ctaHTML +
  '</div>';
}

/* ── Section builders (reuse ProfileView logic) ─────────── */
function _buildTeachingSection(p) {
  var rows = [];
  var ltMap  = { private: 'Einzelunterricht', group: 'Gruppenunterricht', private_group: 'Privatgruppe' };
  var audMap = { kids: 'Kinder', teens: 'Jugendliche', adults: 'Erwachsene', seniors: 'Senioren' };
  var lvMap  = { beginner: 'Anfänger', intermediate: 'Mittelstufe', advanced: 'Fortgeschritten', expert: 'Experten' };

  if (p.lessonTypes && p.lessonTypes.length) {
    var labels = [];
    for (var i = 0; i < p.lessonTypes.length; i++) labels.push(ltMap[p.lessonTypes[i]] || p.lessonTypes[i]);
    rows.push(['Unterrichtsart', labels.join(', ')]);
  }
  if (p.audience && p.audience.length) {
    var audLabels = [];
    for (var j = 0; j < p.audience.length; j++) audLabels.push(audMap[p.audience[j]] || p.audience[j]);
    rows.push(['Zielgruppe', audLabels.join(', ')]);
  }
  if (p.levels && p.levels.length) {
    var lvLabels = [];
    for (var k = 0; k < p.levels.length; k++) lvLabels.push(lvMap[p.levels[k]] || p.levels[k]);
    rows.push(['Level', lvLabels.join(', ')]);
  }
  if (p.ageFrom || p.ageTo) rows.push(['Altersbereich', (p.ageFrom || '?') + ' – ' + (p.ageTo || '?') + ' J.']);
  if (p.maxGroupSize) rows.push(['Max. Gruppe', p.maxGroupSize + ' Personen']);

  if (!rows.length) return '';

  var html = '<div class="pv-section"><h2 class="pv-section-title">Unterricht</h2><div class="pv-detail-list">';
  for (var r = 0; r < rows.length; r++) {
    html += '<div class="pv-detail-row">' +
      '<span class="pv-detail-label">' + _esc(rows[r][0]) + '</span>' +
      '<span class="pv-detail-value">' + _esc(rows[r][1]) + '</span>' +
    '</div>';
  }
  return html + '</div></div>';
}

function _buildTerrainSection(p) {
  if (!p.terrain || !p.terrain.length) return '';
  var map = {
    green: { emoji: '🟢', label: 'Grüne Pisten',    sub: 'Anfänger'       },
    blue:  { emoji: '🔵', label: 'Blaue Pisten',    sub: 'Intermediate'   },
    red:   { emoji: '🔴', label: 'Rote Pisten',     sub: 'Fortgeschritten' },
    black: { emoji: '⚫', label: 'Schwarze Pisten', sub: 'Experten'       }
  };
  var html = '<div class="pv-section"><h2 class="pv-section-title">Terrain &amp; Pisten</h2><div class="pv-terrain-row">';
  for (var i = 0; i < p.terrain.length; i++) {
    var t = map[p.terrain[i]];
    if (!t) continue;
    html += '<div class="pv-terrain-badge">' +
      '<span class="pv-terrain-emoji">' + t.emoji + '</span>' +
      '<span class="pv-terrain-label">' + t.label + '</span>' +
      '<span class="pv-terrain-sub">' + t.sub + '</span>' +
    '</div>';
  }
  return html + '</div></div>';
}

function _buildCertsSection(p) {
  if (!p.certifications || !p.certifications.length) return '';
  var orgMap = { isia: 'ISIA', basi: 'BASI', psia: 'PSIA', csia: 'CSIA', dsv: 'DSV/DSLV', other: 'Sonstige' };
  var html = '<div class="pv-section"><h2 class="pv-section-title">Zertifikate</h2><div class="pv-cert-list">';
  for (var i = 0; i < p.certifications.length; i++) {
    var c = p.certifications[i];
    if (!c.org && !c.level) continue;
    html += '<div class="pv-cert-item">' +
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none">' +
        '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"' +
        ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
      '</svg>' +
      '<span class="pv-cert-org">' + _esc(orgMap[c.org] || c.org) + '</span>' +
      '<span class="pv-cert-level">Level ' + _esc(c.level) + '</span>' +
      (c.year ? '<span class="pv-cert-year">' + _esc(c.year) + '</span>' : '') +
    '</div>';
  }
  return html + '</div></div>';
}

function _buildSpecsSection(p) {
  if (!p.specializations || !p.specializations.length) return '';
  var specMap = {
    kids: 'Kinderunterricht', freeride: 'Freeride / Off-piste',
    freestyle: 'Freestyle / Park', racing: 'Renntraining',
    anxiety: 'Angst-Training', adaptive: 'Adaptive Skiing',
    snowboard: 'Snowboard', telemark: 'Telemark',
    firstaid: 'Erste Hilfe', avalanche: 'Lawinenkurs'
  };
  var html = '<div class="pv-section"><h2 class="pv-section-title">Spezialisierungen</h2><div class="pv-spec-chips">';
  for (var i = 0; i < p.specializations.length; i++) {
    html += '<span class="pv-spec-chip">' + _esc(specMap[p.specializations[i]] || p.specializations[i]) + '</span>';
  }
  return html + '</div></div>';
}

function _buildContactSection(p) {
  var items = [];
  if (p.emailVisible && p.email) {
    items.push('<a class="pv-contact-link" href="mailto:' + _esc(p.email) + '">' +
      '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 3h12a1 1 0 011 1v8a1 1 0 01-1 1H2a1 1 0 01-1-1V4a1 1 0 011-1zM1 4l7 5 7-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      _esc(p.email) + '</a>');
  }
  if (p.phoneVisible && p.phone) {
    items.push('<a class="pv-contact-link" href="tel:' + _esc(p.phone) + '">' +
      '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M14 10.67v2a1.33 1.33 0 01-1.45 1.33A13.2 13.2 0 016.99 12 12.98 12.98 0 012 7.01 13.2 13.2 0 01.01 3.45 1.33 1.33 0 011.33 2h2a1.33 1.33 0 011.33 1.14c.084.64.24 1.267.467 1.87a1.33 1.33 0 01-.3 1.4L3.83 7.4a10.65 10.65 0 005.77 5.77l1-.01a1.33 1.33 0 011.4-.3c.603.227 1.23.383 1.87.467A1.33 1.33 0 0114 10.67z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      _esc(p.phone) + '</a>');
  }
  if (!items.length) return '';
  return '<div class="pv-section"><h2 class="pv-section-title">Kontakt</h2><div class="pv-contact-list">' + items.join('') + '</div></div>';
}

/* ── Bind card interactions ─────────────────────────────── */
function _bindCards() {
  var grid = document.getElementById('catalog-grid');
  if (!grid) return;

  /* Summary click (delegate) */
  grid.addEventListener('click', function(e) {
    /* Chat button on summary */
    var chatBtn = e.target.closest('.tc-chat-btn');
    if (chatBtn) {
      e.stopPropagation();
      var chatUid = chatBtn.getAttribute('data-chat-uid');
      _handleChat(chatUid);
      return;
    }

    /* Expand/collapse toggle button */
    var expandBtn = e.target.closest('.tc-expand-btn');
    if (expandBtn) {
      var uid = expandBtn.getAttribute('data-uid');
      _toggleCard(uid);
      return;
    }

    /* Click on summary row → toggle (open or close) */
    var summary = e.target.closest('.tc-summary');
    if (summary && !e.target.closest('.tc-expand-btn')) {
      var uid = summary.getAttribute('data-uid');
      _toggleCard(uid);
      return;
    }

    /* Book button */
    var bookBtn = e.target.closest('[data-book-uid]');
    if (bookBtn) {
      var bookUid = bookBtn.getAttribute('data-book-uid');
      _handleBook(bookUid);
    }
  });
}

function _toggleCard(uid) {
  if (_expandedUid === uid) {
    _expandedUid = null;
  } else {
    _expandedUid = uid;
  }
  _render();
  _updateFabForExpanded();

  /* Scroll expanded card into view */
  if (_expandedUid) {
    setTimeout(function() {
      var card = document.querySelector('.tc-card.is-expanded');
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 50);
  }
}

function _handleChat(teacherUid) {
  var user = Auth.current();
  if (!user) {
    /* Find teacher name for hint */
    var teacher = Store.Users.byUid(teacherUid);
    var name    = teacher ? ProfileStore.getDisplayName(teacherUid) : 'dem Lehrer';
    AuthModal.open('signin', 'Melde dich an, um mit ' + name + ' Kontakt aufzunehmen.');
    return;
  }
  /* Logged in — open chat directly with this teacher */
  if (typeof ChatPanel !== 'undefined' && ChatPanel.openWith) {
    ChatPanel.openWith(teacherUid);
  }
}

function _updateFabForExpanded() {
  var fab = document.getElementById('chat-fab');
  if (!fab) return;

  if (_expandedUid) {
    var name = ProfileStore.getDisplayName(_expandedUid);
    fab.setAttribute('aria-label', 'Chat mit ' + name);
    fab.classList.add('tc-fab-active');

    /* Replace FAB click handler */
    var newFab = fab.cloneNode(true);
    fab.parentNode.replaceChild(newFab, newFab.parentNode.querySelector('#chat-fab') || fab);
    /* Re-query after potential DOM swap */
    var activeFab = document.getElementById('chat-fab');
    if (activeFab) {
      activeFab.setAttribute('aria-label', 'Chat mit ' + name);
      activeFab.classList.add('tc-fab-active');
      activeFab.onclick = function() { _handleChat(_expandedUid); };
    }
  } else {
    var neutralFab = document.getElementById('chat-fab');
    if (neutralFab) {
      neutralFab.setAttribute('aria-label', 'Chat');
      neutralFab.classList.remove('tc-fab-active');
      neutralFab.onclick = function() {
        var user = Auth.current();
        if (!user) { AuthModal.open('signin'); return; }
        if (typeof ChatPanel !== 'undefined') ChatPanel.open();
      };
    }
  }
}

function _handleBook(teacherUid) {
  var user = Auth.current();
  if (!user) {
    AuthModal.open('signin');
    return;
  }
  /* Logged in: navigate to teacher page with teacher uid as context */
  window.location.href = './teacher.html?uid=' + encodeURIComponent(user.uid) + '&teacherUid=' + encodeURIComponent(teacherUid);
}

/* ── Bind filter chips ──────────────────────────────────── */
function _bindFilters() {
  var filters = document.getElementById('catalog-filters');
  if (!filters) return;

  filters.addEventListener('click', function(e) {
    var chip = e.target.closest('.catalog-chip');
    if (!chip) return;

    var filterType = chip.getAttribute('data-filter');
    var value      = chip.getAttribute('data-value');

    /* Update active chip in group */
    var group = chip.closest('.catalog-filter-chips');
    if (group) {
      var chips = group.querySelectorAll('.catalog-chip');
      for (var i = 0; i < chips.length; i++) chips[i].classList.remove('active');
      chip.classList.add('active');
    }

    if (filterType === 'level')  _filterLevel  = value;
    if (filterType === 'lesson') _filterLesson = value;

    _expandedUid = null; /* close expanded card on filter change */
    _render();
  });
}

function _bindResetBtn() {
  var btn = document.getElementById('catalog-reset-filters');
  if (!btn) return;
  btn.addEventListener('click', function() {
    _filterLevel  = '';
    _filterLesson = '';
    _expandedUid  = null;

    /* Reset chip UI */
    var chips = document.querySelectorAll('.catalog-chip');
    for (var i = 0; i < chips.length; i++) {
      chips[i].classList.remove('active');
      if (chips[i].getAttribute('data-value') === '') chips[i].classList.add('active');
    }
    _render();
  });
}

/* ── Helpers ────────────────────────────────────────────── */
function _esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/* ── Section Jump ───────────────────────────────────────── */
/*
 * Jump targets:
 *   - When a card is expanded: all .tc-summary elements (one per card)
 *   - When nothing expanded: jumper hidden (page too short)
 * Top button: always visible once scrollY > navbar height
 */

function _getCatalogJumpTargets() {
  if (!_expandedUid) return [];
  /* All card summaries = one jump target per teacher card */
  var summaries = document.querySelectorAll('.tc-summary');
  return Array.prototype.slice.call(summaries);
}

function _getNavbarHeight() {
  var navbar = document.querySelector('.navbar');
  return navbar ? navbar.offsetHeight : 52;
}

function _getCurrentJumpIndex(targets) {
  var navH   = _getNavbarHeight();
  var scrollY = window.scrollY + navH + 10;
  var best = 0;
  for (var i = 0; i < targets.length; i++) {
    var top = targets[i].getBoundingClientRect().top + window.scrollY;
    if (top <= scrollY) best = i;
  }
  return best;
}

function updateCatalogJumpBtns() {
  var jumper  = document.getElementById('section-jumper');
  var upBtn   = document.getElementById('jump-up');
  var downBtn = document.getElementById('jump-down');
  var topBtn  = document.getElementById('jump-top');
  if (!jumper) return;

  var targets  = _getCatalogJumpTargets();
  var navH     = _getNavbarHeight();
  var hasCards = targets.length > 1;
  var scrolled = window.scrollY > navH;

  /* Show jumper if cards are expandable-navigable OR page is scrolled */
  jumper.classList.toggle('is-visible', hasCards || scrolled);

  if (upBtn && downBtn) {
    var idx = _getCurrentJumpIndex(targets);
    upBtn.classList.toggle('is-dimmed', !hasCards || idx <= 0);
    downBtn.classList.toggle('is-dimmed', !hasCards || idx >= targets.length - 1);
    /* Hide up/down entirely when no expanded card */
    upBtn.style.display   = hasCards ? '' : 'none';
    downBtn.style.display = hasCards ? '' : 'none';
  }

  if (topBtn) {
    topBtn.classList.toggle('is-hidden-top', !scrolled);
  }
}

function _jumpCatalogSection(delta) {
  var targets = _getCatalogJumpTargets();
  if (!targets.length) return;
  var idx  = _getCurrentJumpIndex(targets);
  var next = idx + delta;
  if (next < 0 || next >= targets.length) return;
  var navH = _getNavbarHeight();
  var top  = targets[next].getBoundingClientRect().top + window.scrollY - navH - 8;
  window.scrollTo({ top: top, behavior: 'smooth' });
  setTimeout(updateCatalogJumpBtns, 400);
}

function _bindJumpBtns() {
  var upBtn  = document.getElementById('jump-up');
  var downBtn = document.getElementById('jump-down');
  var topBtn  = document.getElementById('jump-top');
  var chatFab = document.getElementById('chat-fab');

  if (upBtn)   upBtn.addEventListener('click',   function() { _jumpCatalogSection(-1); });
  if (downBtn) downBtn.addEventListener('click',  function() { _jumpCatalogSection(1);  });
  if (topBtn)  topBtn.addEventListener('click',   function() { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  if (chatFab) chatFab.addEventListener('click',  function() { /* placeholder — chat not implemented on catalog yet */ });

  window.addEventListener('scroll', updateCatalogJumpBtns);
}
