/**
 * teacher.js — Teacher View Logic
 *
 * Grid modes: 'available' | 'timeout'
 * Recurring slots: materialised on-demand per week from app_recurring
 * No inline styles — all classes from teacher.css
 */

var currentUser  = null;
var viewYear     = 0;
var viewMonth    = 0;
var selectedDate = new Date(); /* Heute vorausgewählt */

var gridWeekStart = null;
var gridMode      = 'available'; // 'available' | 'timeout'
var gridPending   = {};          // { "date|time": 'available'|'timeout'|'disabled'|'remove-recurring' }

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START = '06:00';
var GRID_END   = '22:00';

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('teacher');
  if (!currentUser) return;
  Navbar.init('teacher');

  var now   = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();

  document.getElementById('prev-btn').addEventListener('click', prevMonth);
  document.getElementById('next-btn').addEventListener('click', nextMonth);
  document.getElementById('grid-close-btn').addEventListener('click', closeSlotGrid);
  document.getElementById('grid-save-btn').addEventListener('click', saveSlotGrid);
  document.getElementById('grid-prev-week').addEventListener('click', gridPrevWeek);
  document.getElementById('grid-next-week').addEventListener('click', gridNextWeek);
  document.getElementById('mode-btn-available').addEventListener('click', function() { setGridMode('available'); });
  document.getElementById('mode-btn-timeout').addEventListener('click', function() { setGridMode('timeout'); });

  renderStudentList();
  renderCalendar();
  renderDayPanel();

  // Main view tabs
  document.getElementById('nav-schedule').addEventListener('click', function() { switchTeacherView('schedule'); });
  document.getElementById('nav-all-bookings').addEventListener('click', function() { switchTeacherView('all-bookings'); });
  document.getElementById('nav-wallet').addEventListener('click', function() { switchTeacherView('wallet'); });

  // Day panel sub-tabs
  document.getElementById('day-tab-availability').addEventListener('click', function() { switchDayTab('availability'); });
  document.getElementById('day-tab-bookings').addEventListener('click', function() { switchDayTab('bookings'); });
});

var activeDayTab = 'availability';

function switchDayTab(tab) {
  activeDayTab = tab;
  document.getElementById('day-tab-availability').classList.toggle('active', tab === 'availability');
  document.getElementById('day-tab-bookings').classList.toggle('active', tab === 'bookings');
  renderDayPanel();
}

var activeTeacherView = 'schedule';
var allBookingsFilter  = 'all';
var allBookingsTimeFilter = 'upcoming';
var allBookingsSortAsc = true; /* true = oldest→newest, false = newest→oldest */
var allBookingsConfirmFilter = 'all'; /* 'all' | 'unconfirmed' | 'confirmed' */

/* Day-Panel Buchungen-Tab — eigene Filter-States */
var dayBookingsFilter        = 'all';     /* studentId | 'all' */
var dayBookingsTimeFilter    = 'upcoming'; /* 'past' | 'upcoming' | 'all' */
var dayBookingsConfirmFilter = 'all';     /* 'all' | 'unconfirmed' | 'confirmed' */
var _closeBookingDropdown = null; /* outside-click handler for custom dropdown */
var _bookingsSortBtnInit  = false; /* ensures sort button handler is wired only once */
var expandedAllBlocks  = {};

/* ── Shared filter helpers — eine Logik für alle drei Tabs ── */
function _applyTimeFilter(slots, timeFilter, today) {
  if (timeFilter === 'past')     return slots.filter(function(s) { return s.date <  today; });
  if (timeFilter === 'upcoming') return slots.filter(function(s) { return s.date >= today; });
  return slots;
}

function _applyConfirmFilter(slots, confirmFilter) {
  if (confirmFilter === 'confirmed')   return slots.filter(function(s) { return !!s.confirmedAt; });
  if (confirmFilter === 'unconfirmed') return slots.filter(function(s) { return !s.confirmedAt;  });
  return slots;
}

/* Pending booking changes — staged, not yet written to Store
   { slotId: { action:'book'|'cancel', originalSlot:{...}, newStudentId:uid|null } } */
var pendingBookings = {};

/* Return effective slot — pending overrides Store */
function getEffectiveTeacherSlot(storeSlot) {
  var p = pendingBookings[storeSlot.slotId];
  if (!p) return storeSlot;
  var s = {}; for (var k in storeSlot) s[k] = storeSlot[k];
  if (p.action === 'book') {
    s.status    = 'booked';
    s.studentId = p.newStudentId;
    s._pending  = 'book';
  } else {
    s.status    = storeSlot.baseStatus || 'available';
    s.studentId = null;
    s._pending  = 'cancel';
  }
  return s;
}

function switchTeacherView(view) {
  activeTeacherView = view;
  document.getElementById('nav-schedule').classList.toggle('active', view === 'schedule');
  document.getElementById('nav-all-bookings').classList.toggle('active', view === 'all-bookings');
  document.getElementById('nav-wallet').classList.toggle('active', view === 'wallet');
  document.getElementById('view-schedule').classList.toggle('view-hidden', view !== 'schedule');
  document.getElementById('view-all-bookings').classList.toggle('view-hidden', view !== 'all-bookings');
  document.getElementById('view-wallet').classList.toggle('view-hidden', view !== 'wallet');
  if (view === 'all-bookings') {
    var bar = document.getElementById('day-nav-bar');
    if (bar) { bar.classList.remove('is-sticky'); }
    renderAllBookings();
    setTimeout(updateJumpBtns, 200);
  }
  if (view === 'schedule') {
    updateDayNavBar();
    setTimeout(updateJumpBtns, 100);
  }
  if (view === 'wallet') {
    if (typeof WalletPanel !== 'undefined') {
      WalletPanel.mount('teacher-wallet-panel', currentUser.uid);
    }
  }
}

/* ══════════════════════════════════════════════════════════
   STUDENT LIST
══════════════════════════════════════════════════════════ */

// Track which student rows are expanded
var expandedStudents = {};

/* ── My Students filter state ── */
var studentListFilter = { time: 'upcoming', confirmed: 'all' };

function renderStudentList() {
  var selections = Store.Selections.byTeacher(currentUser.uid);
  var container  = document.getElementById('student-list');
  document.getElementById('stat-students').textContent = selections.length;

  if (!selections.length) {
    container.innerHTML = '<p class="text-muted" style="padding:var(--sp-3) var(--sp-4)">Noch keine Schüler.</p>';
    return;
  }

  container.innerHTML = '';
  var today = fmtDate(new Date());

  /* ── Filter toolbar ── */
  var toolbar = document.createElement('div');
  toolbar.className = 'student-filter-toolbar';

  /* Time filter */
  var timeRow = document.createElement('div');
  timeRow.className = 'student-filter-row';
  var timeBtns = [
    { key: 'past',     label: 'Vergangen' },
    { key: 'upcoming', label: 'Kommende' },
    { key: 'all',      label: 'Alle' }
  ];
  timeBtns.forEach(function(t) {
    var btn = document.createElement('button');
    btn.className = 'filter-chip' + (studentListFilter.time === t.key ? ' active' : '');
    btn.textContent = t.label;
    btn.addEventListener('click', function() {
      studentListFilter.time = t.key;
      renderStudentList();
    });
    timeRow.appendChild(btn);
  });

  /* Confirmed filter */
  var confRow = document.createElement('div');
  confRow.className = 'student-filter-row';
  var confBtns = [
    { key: 'all',         label: 'Alle' },
    { key: 'unconfirmed', label: 'Unbestätigt' },
    { key: 'confirmed',   label: 'Bestätigt \u2713' }
  ];
  confBtns.forEach(function(c) {
    var btn = document.createElement('button');
    btn.className = 'filter-chip' + (studentListFilter.confirmed === c.key ? ' active' : '');
    btn.textContent = c.label;
    btn.addEventListener('click', function() {
      studentListFilter.confirmed = c.key;
      renderStudentList();
    });
    confRow.appendChild(btn);
  });

  toolbar.appendChild(timeRow);
  toolbar.appendChild(confRow);
  container.appendChild(toolbar);

  /* ── Per-student rows ── */
  var frag = document.createDocumentFragment();
  var anyVisible = false;

  for (var i = 0; i < selections.length; i++) {
    var student = Store.Users.byUid(selections[i].studentId);
    if (!student) continue;

    var allSlots = Store.Slots.byStudent(student.uid)
      .filter(function(s) { return s.teacherId === currentUser.uid && s.status === 'booked'; })
      .sort(function(a, b) { return a.date.localeCompare(b.date) || a.time.localeCompare(b.time); });

    var filtered = _applyTimeFilter(allSlots, studentListFilter.time, today);
    filtered = _applyConfirmFilter(filtered, studentListFilter.confirmed);

    if (!filtered.length) continue;
    anyVisible = true;
    frag.appendChild(buildStudentRow(student, filtered));
  }

  if (!anyVisible) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.style.padding = 'var(--sp-3) var(--sp-4)';
    empty.textContent = 'Keine Buchungen für diesen Filter.';
    container.appendChild(empty);
    return;
  }

  container.appendChild(frag);
}

function buildStudentRow(student, bookedSlots) {
  var isOpen     = !!expandedStudents[student.uid];
  var today      = fmtDate(new Date());
  /* mergeAllBookingBlocks erwartet dateStr — wir zählen über alle Tage */
  var byDate = {};
  for (var si = 0; si < bookedSlots.length; si++) {
    var sd = bookedSlots[si].date;
    if (!byDate[sd]) byDate[sd] = [];
    byDate[sd].push(bookedSlots[si]);
  }
  var blockCount = 0;
  var dates = Object.keys(byDate);
  for (var di = 0; di < dates.length; di++) {
    blockCount += mergeAllBookingBlocks(dates[di], byDate[dates[di]], today).length;
  }

  var wrapper = document.createElement('div');
  wrapper.className = 'student-row-wrapper';

  var header = document.createElement('div');
  header.className = 'student-row' + (isOpen ? ' student-row-open' : '');
  header.setAttribute('tabindex', '0');

  var info = document.createElement('div');
  info.className = 'student-row-info';

  var name = document.createElement('div');
  name.className = 'student-name';
  name.textContent = ProfileStore.getDisplayName(student.uid);

  var count = document.createElement('div');
  count.className = 'student-count text-muted';
  count.textContent = blockCount + ' Block' + (blockCount !== 1 ? 's' : '');

  info.appendChild(name);
  info.appendChild(count);

  var right = document.createElement('div');
  right.className = 'student-row-right';
  var uid = document.createElement('code');
  uid.className = 'uid-badge';
  uid.textContent = student.uid;
  var chevron = document.createElement('span');
  chevron.className = 'student-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  right.appendChild(uid);
  right.appendChild(chevron);

  header.appendChild(info);
  header.appendChild(right);

  var detail = document.createElement('div');
  detail.className = 'student-booking-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) populateStudentBookings(detail, student, bookedSlots);

  function toggle() {
    if (expandedStudents[student.uid]) {
      delete expandedStudents[student.uid];
      header.classList.remove('student-row-open');
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedStudents[student.uid] = true;
      header.classList.add('student-row-open');
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateStudentBookings(detail, student, bookedSlots);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

/**
 * Merge consecutive booked slots (same date, consecutive times) into blocks.
 * Returns [{ date, start, end, slotIds[] }]
 */

function populateStudentBookings(detail, student, bookedSlots) {
  detail.innerHTML = '';

  if (!bookedSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted student-bookings-empty';
    empty.textContent = 'Noch keine Buchungen.';
    detail.appendChild(empty);
    return;
  }

  var today = fmtDate(new Date());

  /* Group by date */
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < bookedSlots.length; i++) {
    var d = bookedSlots[i].date;
    if (!byDate[d]) { byDate[d] = []; dateOrder.push(d); }
    byDate[d].push(bookedSlots[i]);
  }
  dateOrder.sort();

  for (var di = 0; di < dateOrder.length; di++) {
    var dateStr = dateOrder[di];
    var isPast  = dateStr < today;

    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider student-date-divider'
      + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    detail.appendChild(divider);

    /* mergeAllBookingBlocks — selbe Logik wie All Bookings und Day Panel */
    var blocks = mergeAllBookingBlocks(dateStr, byDate[dateStr], today);
    for (var bi = 0; bi < blocks.length; bi++) {
      detail.appendChild(buildAllBookingBlock(blocks[bi], {
        showDate: false, isPast: isPast, simpleDetail: true
      }));
    }
  }
}

/* buildBookingBlockRow removed — now uses buildBookingBlock */

/* ══════════════════════════════════════════════════════════
   CALENDAR
══════════════════════════════════════════════════════════ */
function materialiseVisibleMonth(year, month) {
  // Find all Mondays in the visible calendar grid (can span prev/next month)
  var first    = new Date(year, month, 1);
  var startDow = first.getDay(); startDow = (startDow === 0) ? 6 : startDow - 1;
  // First Monday shown = first day of month minus startDow days
  var gridStart = new Date(year, month, 1 - startDow);
  // Calendar shows up to 6 weeks = 42 days
  var seen = {};
  for (var d = 0; d < 42; d++) {
    var day = new Date(gridStart);
    day.setDate(gridStart.getDate() + d);
    // Get Monday of this day's week
    var dow = day.getDay(); dow = (dow === 0) ? 6 : dow - 1;
    var mon = new Date(day); mon.setDate(day.getDate() - dow);
    var monKey = mon.getFullYear() + '-' + mon.getMonth() + '-' + mon.getDate();
    if (seen[monKey]) continue;
    seen[monKey] = true;
    var weekDates = [];
    for (var w = 0; w < 7; w++) {
      var wd = new Date(mon); wd.setDate(mon.getDate() + w);
      weekDates.push(wd);
    }
    Store.Recurring.materialiseWeek(currentUser.uid, weekDates);
  }
}

function renderCalendar() {
  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;

  // Week view button — add once
  var calHeader = document.getElementById('cal-header-actions');
  if (calHeader && !document.getElementById('week-view-btn')) {
    var wvBtn = document.createElement('button');
    wvBtn.id = 'week-view-btn';
    wvBtn.className = 'btn btn-secondary btn-sm';
    wvBtn.textContent = 'Week view';
    wvBtn.addEventListener('click', openSlotGrid);
    calHeader.appendChild(wvBtn);
  }

  // Materialise recurring slots for every week visible this month
  materialiseVisibleMonth(viewYear, viewMonth);

  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeCell(prevDays - i, true));
  }

  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isToday = date.getTime() === TODAY.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots      = Store.Slots.byTeacherDate(currentUser.uid, dateStr);
      var hasAny     = slots.length > 0;
      var hasBook    = slots.some(function(s) { return s.status === 'booked'; });
      var hasTimeout = slots.some(function(s) { return s.status === 'timeout'; });

      var cell = makeCell(day, false, isToday, isSel, hasAny, hasBook, hasTimeout);
      cell.addEventListener('click', function() { selectDate(date); });
      cell.setAttribute('tabindex', '0');
      cell.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') selectDate(date);
      });
      grid.appendChild(cell);
    })(d);
  }

  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeCell(t, true));
  }

  updateStats();
}

function makeCell(num, otherMonth, isToday, isSelected, hasSlots, hasBooked, hasTimeout) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth)  el.classList.add('other-month');
  if (isToday)     el.classList.add('today');
  if (isSelected)  el.classList.add('selected');
  if (hasSlots)    el.classList.add('has-slots');
  if (hasBooked)   el.classList.add('has-booked');
  if (hasTimeout)  el.classList.add('has-timeout');
  el.textContent = num;
  return el;
}

function selectDate(date) {
  selectedDate = date;
  renderCalendar();
  renderDayPanel();
}

function prevMonth() {
  viewMonth--;
  if (viewMonth < 0) { viewMonth = 11; viewYear--; }
  renderCalendar();
}
function nextMonth() {
  viewMonth++;
  if (viewMonth > 11) { viewMonth = 0; viewYear++; }
  renderCalendar();
}

/* ══════════════════════════════════════════════════════════
   DAY PANEL
══════════════════════════════════════════════════════════ */
var _dayNavStickyActive = false;

function checkDayNavSticky() {
  var bar      = document.getElementById('day-nav-bar');
  var sentinel = document.getElementById('day-nav-sentinel');
  if (!bar || !sentinel || !bar.classList.contains('is-visible')) return;
  var navbarH = 52;
  var rect = sentinel.getBoundingClientRect();
  var shouldBeSticky = rect.top < navbarH;
  if (shouldBeSticky === _dayNavStickyActive) return;
  _dayNavStickyActive = shouldBeSticky;
  bar.classList.toggle('is-sticky', shouldBeSticky);
  if (shouldBeSticky) {
    var parent = document.getElementById('section-daypanel');
    if (parent) {
      var pr = parent.getBoundingClientRect();
      bar.style.left  = pr.left + 'px';
      bar.style.width = pr.width + 'px';
      bar.style.right = 'auto';
    }
    sentinel.style.height = bar.offsetHeight + 'px';
  } else {
    bar.style.left  = '';
    bar.style.width = '';
    bar.style.right = '';
    sentinel.style.height = '0';
  }
}

function updateDayNavBar() {
  var bar      = document.getElementById('day-nav-bar');
  var label    = document.getElementById('day-nav-label');
  if (!bar || !label) return;

  if (!selectedDate) {
    bar.classList.remove('is-visible');
    bar.classList.remove('is-sticky');
    _dayNavStickyActive = false;
    return;
  }

  bar.classList.add('is-visible');
  label.textContent = selectedDate.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

  checkDayNavSticky();
}

function navDay(delta) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setDate(d.getDate() + delta);
  selectedDate = d;
  if (d.getFullYear() !== viewYear || d.getMonth() !== viewMonth) {
    viewYear  = d.getFullYear();
    viewMonth = d.getMonth();
  }
  updateDayNavBar();
  renderCalendar();
  renderDayPanel();
}

function navMonth(delta) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setMonth(d.getMonth() + delta);
  selectedDate = d;
  viewYear  = d.getFullYear();
  viewMonth = d.getMonth();
  updateDayNavBar();
  renderCalendar();
  renderDayPanel();
}

function renderDayPanel() {
  updateDayNavBar();
  var panel = document.getElementById('day-panel');
  panel.innerHTML = '';

  if (!selectedDate) {
    var hint = document.createElement('p');
    hint.className = 'text-muted day-panel-empty';
    hint.textContent = 'Select a day.';
    panel.appendChild(hint);
    return;
  }

  var dateStr = fmtDate(selectedDate);

  // Materialise recurring for the week of selected date
  var selMonday = new Date(selectedDate);
  var selDow = selMonday.getDay(); selDow = (selDow === 0) ? 6 : selDow - 1;
  selMonday.setDate(selMonday.getDate() - selDow);
  var selWeekDates = [];
  for (var wi = 0; wi < 7; wi++) { var wd = new Date(selMonday); wd.setDate(wd.getDate() + wi); selWeekDates.push(wd); }
  Store.Recurring.materialiseWeek(currentUser.uid, selWeekDates);

  var slots   = Store.Slots.byTeacherDate(currentUser.uid, dateStr);
  var label   = selectedDate.toLocaleDateString('de-DE', { weekday:'long', day:'numeric', month:'long', year:'numeric' });

  var header = document.createElement('div');
  header.className = 'day-panel-header';
  var lbl = document.createElement('div');
  lbl.className = 'day-panel-label';
  lbl.textContent = label;
  header.appendChild(lbl);

  // "Add slots" button only in availability tab
  if (activeDayTab === 'availability') {
    var btn = document.createElement('button');
    btn.className = 'btn btn-primary btn-sm';
    btn.id = 'add-slot-btn';
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Add slots';
    btn.addEventListener('click', openSlotGrid);
    header.appendChild(btn);
  }
  panel.appendChild(header);

  if (!slots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted day-panel-empty';
    empty.textContent = activeDayTab === 'availability'
      ? 'Keine Slots für diesen Tag. Klicke auf "+ Add slots" um welche hinzuzufügen.'
      : 'Keine Slots für diesen Tag.';
    panel.appendChild(empty);
    return;
  }

  if (activeDayTab === 'availability') {
    renderAvailabilityPanel(panel, slots);
  } else {
    renderBookingsPanel(panel, slots, dateStr);
  }
}

/* ── Tab 1: Verfügbarkeit ───────────────────────────────── */
function renderAvailabilityPanel(panel, slots) {
  for (var i = 0; i < slots.length; i++) {
    panel.appendChild(buildAvailabilityCard(slots[i]));
  }
}

function buildAvailabilityCard(slot) {
  var base = slot.baseStatus || slot.status;

  var modClass = base === 'disabled' ? ' avail-row-disabled'
               : base === 'timeout'  ? ' avail-row-timeout'
               : '';

  var row = document.createElement('div');
  row.className = 'avail-row' + modClass;

  /* Zeit */
  var timeEl = document.createElement('span');
  timeEl.className = 'avail-row-time';
  timeEl.textContent = slot.time + ' \u2013 ' + Store.slotEndTime(slot.time);

  /* Status-Label */
  var statusEl = document.createElement('span');
  statusEl.className = 'avail-row-status';
  var statusLabels = { available: 'Frei', disabled: 'Deaktiviert', timeout: 'Timeout', booked: 'Gebucht', recurring: 'Frei' };
  statusEl.textContent = statusLabels[base] || base;

  /* Aktions-Buttons */
  var actions = document.createElement('div');
  actions.className = 'avail-row-actions';

  if (base === 'available' || base === 'recurring') {
    var disableBtn = document.createElement('button');
    disableBtn.className = 'btn btn-ghost btn-sm';
    disableBtn.textContent = 'Deaktivieren';
    (function(s) {
      disableBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        var d = new Date(s.date + 'T00:00:00');
        var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
        Store.Slots.setAvailability(s.slotId, 'disabled');
        Store.Recurring.deleteByTeacherDayTime(currentUser.uid, dow, s.time);
        renderDayPanel(); renderCalendar();
      });
    })(slot);
    actions.appendChild(disableBtn);

    var timeoutBtn = document.createElement('button');
    timeoutBtn.className = 'btn btn-ghost btn-sm';
    timeoutBtn.textContent = 'Timeout';
    (function(s) {
      timeoutBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        var current = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
        if (current && current.studentId) {
          var sName  = ProfileStore.getDisplayName(current.studentId);
          var result = Modal.show({
            title: 'Slot ist gebucht',
            bodyHTML: '<p>Dieser Slot ist gebucht von <strong>' + sName + '</strong>. Timeout setzt die Buchung zurück.</p>',
            footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button><button class="btn btn-danger" id="modal-confirm">Buchung stornieren & Timeout setzen</button>'
          });
          document.getElementById('modal-cancel').addEventListener('click', result.close);
          (function(sid) {
            document.getElementById('modal-confirm').addEventListener('click', function() {
              Store.Slots.cancelBooking(sid);
              Store.Slots.setAvailability(sid, 'timeout');
              renderDayPanel(); renderCalendar(); renderStudentList();
              result.close();
            });
          })(s.slotId);
        } else {
          Store.Slots.setAvailability(s.slotId, 'timeout');
          renderDayPanel(); renderCalendar();
        }
      });
    })(slot);
    actions.appendChild(timeoutBtn);

  } else if (base === 'disabled' || base === 'timeout') {
    var enableBtn = document.createElement('button');
    enableBtn.className = 'btn btn-ghost btn-sm';
    enableBtn.textContent = 'Aktivieren';
    (function(s) {
      enableBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        var d = new Date(s.date + 'T00:00:00');
        var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
        Store.Slots.setAvailability(s.slotId, 'available');
        Store.Recurring.create(currentUser.uid, dow, s.time);
        renderDayPanel(); renderCalendar();
      });
    })(slot);
    actions.appendChild(enableBtn);
  }

  /* Löschen-Icon */
  var delBtn = document.createElement('button');
  delBtn.className = 'btn btn-ghost btn-sm';
  delBtn.setAttribute('aria-label', 'Slot löschen');
  delBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  (function(s) {
    delBtn.addEventListener('click', function(e) { e.stopPropagation(); deleteSlot(s.slotId); });
  })(slot);
  actions.appendChild(delBtn);

  row.appendChild(timeEl);
  row.appendChild(statusEl);
  row.appendChild(actions);
  return row;
}

/* ── Tab 2: Buchungen ───────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   BOOKINGS PANEL (Tab 2)
══════════════════════════════════════════════════════════ */

// Currently open booking form slot id
var openBookFormSlotId = null;

function renderBookingsPanel(panel, slots, dateStr) {
  var today  = fmtDate(new Date());
  var isPast = dateStr < today;

  /* Effective + deduplicate */
  var seen = {};
  var effective = [];
  for (var ei = 0; ei < slots.length; ei++) {
    var eff = getEffectiveTeacherSlot(slots[ei]);
    if (!seen[eff.slotId]) { seen[eff.slotId] = true; effective.push(eff); }
  }

  var allBooked = effective.filter(function(s) { return !!s.studentId; });
  var freeSlots = effective.filter(function(s) { return !s.studentId; });

  /* Filter bar */
  var filterWrap = document.createElement('div');
  filterWrap.className = 'day-bookings-filters';

  /* Student picker — only if >1 student */
  var myStudentUids = Store.Selections.byTeacher(currentUser.uid).map(function(sel) { return sel.studentId; });
  var myStudents    = myStudentUids.map(function(uid) { return Store.Users.byUid(uid); }).filter(Boolean);

  if (myStudents.length > 1) {
    var studentRow = document.createElement('div');
    studentRow.className = 'day-bookings-filter-row';
    var studentLbl = document.createElement('span');
    studentLbl.className = 'day-bookings-filter-label';
    studentLbl.textContent = 'Schüler';

    var ddWrap = document.createElement('div');
    ddWrap.className = 'custom-dropdown day-bookings-student-dd';
    var ddTrigger = document.createElement('button');
    ddTrigger.type = 'button';
    ddTrigger.className = 'custom-dropdown-trigger';
    ddTrigger.setAttribute('aria-haspopup', 'listbox');
    ddTrigger.setAttribute('aria-expanded', 'false');
    var ddLabelSpan = document.createElement('span');
    ddLabelSpan.className = 'custom-dropdown-label';
    var ddChevronEl = document.createElement('span');
    ddChevronEl.innerHTML = '<svg class="custom-dropdown-chevron" width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    ddTrigger.appendChild(ddLabelSpan);
    ddTrigger.appendChild(ddChevronEl);
    var ddList = document.createElement('ul');
    ddList.className = 'custom-dropdown-list';
    ddList.setAttribute('role', 'listbox');

    var ddOptions = [{ value: 'all', text: 'Alle Schüler' }];
    for (var si = 0; si < myStudents.length; si++) {
      ddOptions.push({ value: myStudents[si].uid, text: ProfileStore.getDisplayName(myStudents[si].uid) });
    }

    function setStudentFilter(val) {
      dayBookingsFilter = val;
      var sel = ddOptions.filter(function(o) { return o.value === val; })[0] || ddOptions[0];
      ddLabelSpan.textContent = sel.text;
      var items = ddList.querySelectorAll('.custom-dropdown-item');
      for (var k = 0; k < items.length; k++) {
        items[k].classList.toggle('is-active', items[k].getAttribute('data-value') === val);
      }
      ddList.classList.remove('is-open');
      ddTrigger.classList.remove('is-open');
      ddTrigger.setAttribute('aria-expanded', 'false');
      renderDayPanel();
    }

    for (var di = 0; di < ddOptions.length; di++) {
      (function(opt) {
        var li = document.createElement('li');
        li.className = 'custom-dropdown-item' + (opt.value === dayBookingsFilter ? ' is-active' : '');
        li.setAttribute('role', 'option');
        li.setAttribute('data-value', opt.value);
        li.textContent = opt.text;
        li.addEventListener('click', function(e) { e.stopPropagation(); setStudentFilter(opt.value); });
        ddList.appendChild(li);
      })(ddOptions[di]);
    }
    var curSel = ddOptions.filter(function(o) { return o.value === dayBookingsFilter; })[0] || ddOptions[0];
    ddLabelSpan.textContent = curSel.text;

    ddTrigger.addEventListener('click', function(e) {
      e.stopPropagation();
      var isOpen = ddList.classList.contains('is-open');
      ddList.classList.toggle('is-open', !isOpen);
      ddTrigger.classList.toggle('is-open', !isOpen);
      ddTrigger.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
    });
    document.addEventListener('click', function() {
      ddList.classList.remove('is-open');
      ddTrigger.classList.remove('is-open');
      ddTrigger.setAttribute('aria-expanded', 'false');
    });

    ddWrap.appendChild(ddTrigger);
    ddWrap.appendChild(ddList);
    studentRow.appendChild(studentLbl);
    studentRow.appendChild(ddWrap);
    filterWrap.appendChild(studentRow);
  }

  /* Time filter */
  var timeRow = document.createElement('div');
  timeRow.className = 'booking-time-filter';
  var timeOpts = [
    { val: 'past',     label: 'Vergangen' },
    { val: 'upcoming', label: 'Kommende'  },
    { val: 'all',      label: 'Alle'      }
  ];
  for (var ti = 0; ti < timeOpts.length; ti++) {
    (function(opt) {
      var btn = document.createElement('button');
      btn.className = 'booking-time-btn' + (opt.val === dayBookingsTimeFilter ? ' active' : '');
      btn.textContent = opt.label;
      btn.addEventListener('click', function() { dayBookingsTimeFilter = opt.val; renderDayPanel(); });
      timeRow.appendChild(btn);
    })(timeOpts[ti]);
  }
  filterWrap.appendChild(timeRow);

  /* Einheitliche Filter-Pipeline — erst filtern, dann aus dem Ergebnis zählen */
  /* Student-Filter */
  var baseFiltered = allBooked.slice();
  if (dayBookingsFilter !== 'all') {
    baseFiltered = baseFiltered.filter(function(s) { return s.studentId === dayBookingsFilter; });
  }
  /* Zeit-Filter */
  baseFiltered = _applyTimeFilter(baseFiltered, dayBookingsTimeFilter, today);

  /* Blockzahlen aus derselben gefilterten Basis — exakt was unten angezeigt wird */
  var allBlocks    = mergeAllBookingBlocks(dateStr, baseFiltered, today);
  var unconfBlocks = mergeAllBookingBlocks(dateStr, _applyConfirmFilter(baseFiltered, 'unconfirmed'), today);
  var confBlocks   = mergeAllBookingBlocks(dateStr, _applyConfirmFilter(baseFiltered, 'confirmed'),   today);

  /* Confirm filter buttons */
  var confirmRow = document.createElement('div');
  confirmRow.className = 'booking-confirm-filter';
  var confirmOpts = [
    { val: 'all',         label: 'Alle',             count: allBlocks.length },
    { val: 'unconfirmed', label: 'Unbestätigt',       count: unconfBlocks.length },
    { val: 'confirmed',   label: 'Bestätigt \u2713', count: confBlocks.length }
  ];
  for (var ci = 0; ci < confirmOpts.length; ci++) {
    (function(opt) {
      var btn = document.createElement('button');
      btn.className = 'booking-confirm-btn' + (opt.val === dayBookingsConfirmFilter ? ' active' : '');
      btn.setAttribute('data-confirm', opt.val);
      if (opt.count > 0) {
        btn.innerHTML = opt.label + ' <span class="booking-confirm-count">' + opt.count + '</span>';
      } else {
        btn.textContent = opt.label;
      }
      btn.addEventListener('click', function() { dayBookingsConfirmFilter = opt.val; renderDayPanel(); });
      confirmRow.appendChild(btn);
    })(confirmOpts[ci]);
  }
  filterWrap.appendChild(confirmRow);
  panel.appendChild(filterWrap);

  /* Anzeigefilter: Bestätigt-Filter auf die bereits gefilterte Basis anwenden */
  var filtered = _applyConfirmFilter(baseFiltered, dayBookingsConfirmFilter);

  /* Free slots accordion */
  if (freeSlots.length && !isPast) {
    var freeWrapper = document.createElement('div');
    freeWrapper.className = 'all-booking-block-wrapper';
    var freeHeader = document.createElement('div');
    freeHeader.className = 'all-booking-block-header';
    var freeLabel = document.createElement('span');
    freeLabel.className = 'all-booking-block-time';
    freeLabel.textContent = freeSlots.length + ' freie Slot' + (freeSlots.length !== 1 ? 's' : '');
    var freeChevron = document.createElement('span');
    freeChevron.className = 'all-booking-chevron';
    freeChevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    freeHeader.appendChild(freeLabel);
    freeHeader.appendChild(freeChevron);
    var freeDetail = document.createElement('div');
    freeDetail.className = 'all-booking-block-detail';
    freeDetail.style.padding = 'var(--sp-1) var(--sp-3)';
    for (var fj = 0; fj < freeSlots.length; fj++) {
      var efs = getEffectiveTeacherSlot(freeSlots[fj]);
      var fRow2 = document.createElement('div');
      fRow2.className = 'all-booking-slot-row';
      var fTime2 = document.createElement('span');
      fTime2.className = 'all-booking-slot-time';
      fTime2.textContent = efs.time + ' \u2013 ' + Store.slotEndTime(efs.time);
      var fStatus2 = document.createElement('span');
      fStatus2.className = 'all-booking-slot-status';
      fStatus2.textContent = 'Frei';
      var fBtns2 = document.createElement('div');
      fBtns2.className = 'all-booking-slot-btns';
      var bookBtn2 = document.createElement('button');
      bookBtn2.className = 'btn btn-primary btn-sm';
      bookBtn2.textContent = '+ Buchen';
      (function(s, aSlots) {
        bookBtn2.addEventListener('click', function() { buildBookingForm(s, dateStr, aSlots); });
      })(freeSlots[fj], slots);
      fBtns2.appendChild(bookBtn2);
      fRow2.appendChild(fTime2);
      fRow2.appendChild(fStatus2);
      fRow2.appendChild(fBtns2);
      freeDetail.appendChild(fRow2);
    }
    freeHeader.setAttribute('tabindex', '0');
    (function(hdr, det, chv) {
      function toggle() { var open = det.classList.contains('is-open'); det.classList.toggle('is-open', !open); chv.classList.toggle('is-open', !open); }
      hdr.addEventListener('click', toggle);
      hdr.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });
    })(freeHeader, freeDetail, freeChevron);
    freeWrapper.appendChild(freeHeader);
    freeWrapper.appendChild(freeDetail);
    panel.appendChild(freeWrapper);
  }

  /* Booked blocks */
  if (!filtered.length) {
    var emptyMsg = document.createElement('p');
    emptyMsg.className = 'text-muted';
    emptyMsg.style.padding = 'var(--sp-3) 0';
    emptyMsg.textContent = 'Keine Buchungen für diese Filterauswahl.';
    panel.appendChild(emptyMsg);
    return;
  }

  var blocks = mergeAllBookingBlocks(dateStr, filtered, today);
  for (var b = 0; b < blocks.length; b++) {
    panel.appendChild(buildAllBookingBlock(blocks[b], { showDate: false, isPast: isPast }));
  }
}


function buildBookingForm(startSlot, dateStr, allSlots) {
  /* Opens as a proper Modal instead of inline expansion */
  var selections = Store.Selections.byTeacher(currentUser.uid);
  var students   = selections.map(function(s) { return Store.Users.byUid(s.studentId); }).filter(Boolean);

  if (!students.length) {
    Modal.show({
      title: 'Buchung erstellen',
      bodyHTML: '<p class="move-dialog-info">Keine Schüler zugewiesen.</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Schließen</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', function() {
      openBookFormSlotId = null; renderDayPanel();
    });
    return null;
  }

  /* Build student checkboxes HTML */
  var stuHTML = '';
  for (var i = 0; i < students.length; i++) {
    var name = ProfileStore.getDisplayName(students[i].uid);
    stuHTML += '<label class="booking-form-check-row">'
      + '<input type="checkbox" class="booking-form-checkbox bk-modal-stu-cb" value="' + students[i].uid + '">'
      + '<span>' + name + '</span></label>';
  }

  /* Build unbooked slots for time selectors */
  var allUnbooked = allSlots.filter(function(s) { return !s.studentId; });
  var fromOpts = '';
  for (var f = 0; f < allUnbooked.length; f++) {
    var sel = allUnbooked[f].time === startSlot.time ? ' selected' : '';
    fromOpts += '<option value="' + allUnbooked[f].time + '"' + sel + '>' + allUnbooked[f].time + '</option>';
  }

  var bodyHTML =
    '<div class="move-dialog">' +
      '<div class="booking-form-label">Schüler</div>' +
      '<div class="booking-form-students">' + stuHTML + '</div>' +
      '<div class="booking-form-time-row">' +
        '<div class="booking-form-time-col">' +
          '<div class="booking-form-label">Von</div>' +
          '<select class="form-select booking-form-until" id="bk-from-sel">' + fromOpts + '</select>' +
        '</div>' +
        '<div class="booking-form-time-col">' +
          '<div class="booking-form-label">Bis</div>' +
          '<select class="form-select booking-form-until" id="bk-until-sel"></select>' +
        '</div>' +
      '</div>' +
    '</div>';

  var result = Modal.show({
    title: 'Buchung erstellen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>'
              + '<button class="btn btn-primary" id="modal-confirm">Buchen</button>'
  });

  /* Wire up Until select dynamically */
  var fromSel  = document.getElementById('bk-from-sel');
  var untilSel = document.getElementById('bk-until-sel');

  function rebuildUntil() {
    untilSel.innerHTML = '';
    var fromTime = fromSel.value;
    var idx = -1;
    for (var x = 0; x < allUnbooked.length; x++) { if (allUnbooked[x].time === fromTime) { idx = x; break; } }
    if (idx < 0) return;
    var prevEnd = Store.slotEndTime(allUnbooked[idx].time);
    var d0 = document.createElement('option');
    d0.value = allUnbooked[idx].time; d0.textContent = prevEnd;
    untilSel.appendChild(d0);
    for (var jj = idx + 1; jj < allUnbooked.length; jj++) {
      if (allUnbooked[jj].time === prevEnd) {
        prevEnd = Store.slotEndTime(allUnbooked[jj].time);
        var oo = document.createElement('option');
        oo.value = allUnbooked[jj].time; oo.textContent = prevEnd;
        untilSel.appendChild(oo);
      } else { break; }
    }
  }
  rebuildUntil();
  fromSel.addEventListener('change', rebuildUntil);

  document.getElementById('modal-cancel').addEventListener('click', function() {
    openBookFormSlotId = null;
    renderDayPanel();
    result.close();
  });

  document.getElementById('modal-confirm').addEventListener('click', function() {
    var checkedBoxes = document.querySelectorAll('.bk-modal-stu-cb:checked');
    var selectedUids = [];
    for (var k = 0; k < checkedBoxes.length; k++) { selectedUids.push(checkedBoxes[k].value); }
    if (!selectedUids.length) { Toast.error('Bitte mindestens einen Schüler auswählen.'); return; }
    var fromTime = fromSel.value;
    var fromSlot = allSlots.filter(function(s) { return s.time === fromTime; })[0] || startSlot;
    var untilTime = untilSel.value;
    openBookFormSlotId = null;
    result.close();
    executeBooking(fromSlot, untilTime, selectedUids, dateStr, allSlots);
  });

  return null; /* Modal handles display — no inline element returned */
}

function executeBooking(startSlot, untilTime, studentUids, dateStr, allSlots) {
  // Get all slots from start up to and including untilTime
  // Use effective state (pending overrides) for conflict detection
  var range = allSlots.filter(function(s) {
    return s.time >= startSlot.time && s.time <= untilTime;
  }).map(function(s) { return getEffectiveTeacherSlot(s); });

  // Check for conflicts (already booked by someone else)
  var conflicts = range.filter(function(s) {
    return s.studentId && studentUids.indexOf(s.studentId) === -1;
  });

  if (conflicts.length) {
    var conflictNames = conflicts.map(function(s) {
      var stu = Store.Users.byUid(s.studentId);
      return s.time + ' (booked by ' + ProfileStore.getDisplayName(s.studentId) + ')';
    }).join(', ');

    var result = Modal.show({
      title: 'Booking conflict',
      bodyHTML: '<p>The following slots are already booked:</p><p><strong>' + conflictNames + '</strong></p><p>Overwrite these bookings?</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Cancel</button><button class="btn btn-danger" id="modal-confirm">Overwrite</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      commitBooking(range, studentUids);
      result.close();
    });
  } else {
    commitBooking(range, studentUids);
  }
}

function commitBooking(slots, studentUids) {
  for (var i = 0; i < slots.length; i++) {
    var slot = slots[i];
    var original = Store.Slots.all().filter(function(s) { return s.slotId === slot.slotId; })[0];
    pendingBookings[slot.slotId] = {
      action:       'book',
      originalSlot: original,
      newStudentId: studentUids[0],
      extraStudents: studentUids.slice(1)
    };
  }
  openBookFormSlotId = null;
  updateBookingSaveBtn();
  Toast.info('Booking staged — press Save to confirm.');
  renderDayPanel();
  renderCalendar();
  renderStudentList();
}

function cancelBookingFromPanel(slot) {
  var original = Store.Slots.all().filter(function(s) { return s.slotId === slot.slotId; })[0];
  var existing = pendingBookings[slot.slotId];
  if (existing) {
    delete pendingBookings[slot.slotId];
    updateBookingSaveBtn();
    renderDayPanel();
    renderCalendar();
    renderStudentList();
    return;
  }
  pendingBookings[slot.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
  updateBookingSaveBtn();
  renderDayPanel();
  renderCalendar();
  renderStudentList();
}

function updateBookingSaveBtn() {
  var group = document.getElementById('booking-fab-group');
  if (!group) return;
  var count = Object.keys(pendingBookings).length;
  group.classList.toggle('is-visible', count > 0);
  var badge = group.querySelector('.save-badge');
  if (badge) badge.textContent = count;
}

function discardBookingChanges() {
  pendingBookings = {};
  openBookFormSlotId = null;
  updateBookingSaveBtn();
  renderDayPanel();
  Toast.info('Changes dismissed.');
}

function saveBookingChanges() {
  var ids = Object.keys(pendingBookings);
  var savedChanges = {};
  for (var i = 0; i < ids.length; i++) {
    var p = pendingBookings[ids[i]];
    savedChanges[ids[i]] = p;
    if (p.action === 'book') {
      Store.Slots.bookSlot(ids[i], p.newStudentId);
      // Extra students — create new slots
      if (p.extraStudents && p.extraStudents.length) {
        var orig = p.originalSlot;
        for (var j = 0; j < p.extraStudents.length; j++) {
          Store.Slots.create({
            teacherId:  orig.teacherId,
            studentId:  p.extraStudents[j],
            date:       orig.date,
            time:       orig.time,
            status:     'booked',
            baseStatus: 'available'
          });
        }
      }
    } else {
      Store.Slots.cancelBooking(ids[i]);
    }
  }
  var emailIds = Object.keys(savedChanges || {});
  for (var ei = 0; ei < emailIds.length; ei++) {
    var ep    = savedChanges[emailIds[ei]];
    var es    = ep.originalSlot;
    var stu   = Store.Users.byUid(ep.action === 'book' ? ep.newStudentId : es.studentId);
    if (!stu) continue;
    var dateObj   = new Date(es.date + 'T00:00:00');
    var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    var endTime   = Store.slotEndTime(es.time);
    if (ep.action === 'book') {
      EmailService.onBookingCreated(stu.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(currentUser.uid),
        studentName: ProfileStore.getDisplayName(stu.uid)
      });
    } else {
      EmailService.onBookingCancelled(stu.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(currentUser.uid),
        studentName: ProfileStore.getDisplayName(stu.uid)
      });
    }
  }
  pendingBookings = {};
  updateBookingSaveBtn();
  renderDayPanel();
  renderCalendar();
  renderStudentList();
  renderAllBookingsList();
  Toast.success('Bookings saved.');
}

function deleteSlot(slotId) {
  Store.Slots.delete(slotId);
  Toast.success('Slot removed.');
  renderDayPanel();
  renderCalendar();
}

/* ══════════════════════════════════════════════════════════
   SLOT GRID OVERLAY
══════════════════════════════════════════════════════════ */
function openSlotGrid() {
  if (!selectedDate) return;

  var monday = new Date(selectedDate);
  var dow = monday.getDay();
  dow = (dow === 0) ? 6 : dow - 1;
  monday.setDate(monday.getDate() - dow);
  gridWeekStart = monday;
  gridPending   = {};

  // Materialise recurring for this week
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());

  document.getElementById('slot-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  setGridMode('available');
  renderGridTable();
}

function closeSlotGrid() {
  document.getElementById('slot-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  gridPending = {};
  renderCalendar();
  renderDayPanel();
}

function saveSlotGrid() {
  flushGridPending();
  Toast.success('Slots saved.');
  renderCalendar();
  renderDayPanel();
  // Re-render grid to reflect saved state
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridPrevWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() - 7);
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridNextWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() + 7);
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function setGridMode(mode) {
  gridMode = mode;
  var btnAvail   = document.getElementById('mode-btn-available');
  var btnTimeout = document.getElementById('mode-btn-timeout');
  btnAvail.className   = 'grid-mode-btn' + (mode === 'available' ? ' active-available' : '');
  btnTimeout.className = 'grid-mode-btn' + (mode === 'timeout'   ? ' active-timeout'   : '');
}

/* ── Grid table render ────────────────────────────────────── */
function renderGridTable() {
  var weekDates = getWeekDates();
  var times     = Store.slotTimesInRange(GRID_START, GRID_END);

  // Update week label
  document.getElementById('grid-week-label').textContent = weekRangeLabel(weekDates);

  var container = document.getElementById('slot-grid-content');
  container.innerHTML = '';

  var table = document.createElement('table');
  table.className = 'slot-grid-table';

  // ── thead ──
  var thead = document.createElement('thead');
  var hrow  = document.createElement('tr');

  var thTime = document.createElement('th');
  thTime.className = 'grid-th-time';
  thTime.textContent = 'Time';
  hrow.appendChild(thTime);

  for (var d = 0; d < weekDates.length; d++) {
    var wd      = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var isSel   = selectedDate && wd.getTime() === selectedDate.getTime();

    var th = document.createElement('th');
    th.className = 'grid-th-day';
    if (isToday) th.classList.add('grid-th-today');
    if (isSel)   th.classList.add('grid-th-selected');

    var nameSpan = document.createElement('span');
    nameSpan.className = 'grid-day-name';
    nameSpan.textContent = DAY_NAMES[d];

    var numSpan = document.createElement('span');
    numSpan.className = 'grid-day-num';
    if (isToday) numSpan.classList.add('grid-day-today');
    numSpan.textContent = wd.getDate();

    th.appendChild(nameSpan);
    th.appendChild(numSpan);
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // ── tbody ──
  var tbody = document.createElement('tbody');

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    var tr   = document.createElement('tr');

    var tdTime = document.createElement('td');
    tdTime.className = 'grid-td-time';
    tdTime.textContent = time;
    tr.appendChild(tdTime);

    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var dayOfWeek   = dd; // 0=Mon
      var slot        = Store.Slots.exists(currentUser.uid, cellDateStr, time);
      var recurring   = Store.Recurring.exists(currentUser.uid, dayOfWeek, time);

      // Determine display status
      var status = slot ? slot.status : (recurring ? 'recurring' : 'none');
      var pendingKey = cellDateStr + '|' + time;
      if (gridPending[pendingKey] !== undefined) {
        status = gridPending[pendingKey];
      }

      var td   = document.createElement('td');
      td.className = 'grid-td-cell';

      var cell = document.createElement('div');
      cell.className = 'grid-cell';
      cell.dataset.date      = cellDateStr;
      cell.dataset.time      = time;
      cell.dataset.dayofweek = String(dayOfWeek);
      cell.dataset.booked    = (status === 'booked') ? '1' : '0';

      if (status === 'available' || status === 'recurring') {
        if (slot && slot.releasedAt) {
          cell.classList.add('gc-released');
        } else {
          cell.classList.add('gc-available');
        }
      }
      else if (status === 'booked')    cell.classList.add('gc-booked');
      else if (status === 'timeout')   cell.classList.add('gc-timeout');
      else                             cell.classList.add('gc-empty');

      if (status !== 'booked') {
        cell.addEventListener('click', onGridCellClick);
      }

      td.appendChild(cell);
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  container.appendChild(table);
}

function onGridCellClick(e) {
  var cell       = e.currentTarget;
  var date       = cell.dataset.date;
  var time       = cell.dataset.time;
  var dayOfWeek  = parseInt(cell.dataset.dayofweek, 10);
  var key        = date + '|' + time;

  var isAvailable = cell.classList.contains('gc-available') || cell.classList.contains('gc-recurring');
  var isTimeout   = cell.classList.contains('gc-timeout');
  var isEmpty     = cell.classList.contains('gc-empty');

  if (gridMode === 'available') {
    if (isAvailable) {
      // Toggle off — available (=recurring) → disabled, remove recurring rule
      gridPending[key] = 'disabled';
      cell.className = 'grid-cell gc-empty';
    } else if (isTimeout || isEmpty) {
      // Toggle on — always creates recurring rule
      gridPending[key] = 'available';
      cell.className = 'grid-cell gc-available';
    }
  } else if (gridMode === 'timeout') {
    if (isAvailable || cell.classList.contains('gc-recurring')) {
      // Check if booked
      var existingSlot = Store.Slots.exists(currentUser.uid, date, time);
      if (existingSlot && existingSlot.studentId) {
        // Warning: slot is booked
        var student = Store.Users.byUid(existingSlot.studentId);
        var sName   = ProfileStore.getDisplayName(existingSlot.studentId);
        var result  = Modal.show({
          title: 'Slot is booked',
          bodyHTML: '<p>This slot is booked by <strong>' + sName + '</strong>. Setting timeout will cancel their lesson.</p>',
          footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Keep booking</button><button class="btn btn-danger" id="modal-confirm">Cancel lesson & set timeout</button>'
        });
        document.getElementById('modal-cancel').addEventListener('click', result.close);
        (function(k, c, sid) {
          document.getElementById('modal-confirm').addEventListener('click', function() {
            Store.Slots.cancelBooking(sid);
            Store.Slots.setAvailability(sid, 'timeout');
            gridPending[k] = 'timeout';
            c.className = 'grid-cell gc-timeout';
            renderCalendar();
            renderStudentList();
            result.close();
          });
        })(key, cell, existingSlot.slotId);
      } else {
        gridPending[key] = 'timeout';
        cell.className = 'grid-cell gc-timeout';
      }
    } else if (isTimeout) {
      // Remove timeout — restore to available/recurring
      var rec2 = Store.Recurring.exists(currentUser.uid, dayOfWeek, time);
      gridPending[key] = rec2 ? 'available' : 'available-no-recurring';
      cell.className = 'grid-cell gc-' + (rec2 ? 'recurring' : 'available');
    }
  }
}

function flushGridPending() {
  var keys = Object.keys(gridPending);
  for (var i = 0; i < keys.length; i++) {
    var key    = keys[i];
    var parts  = key.split('|');
    var date   = parts[0];
    var time   = parts[1];
    var action = gridPending[key];

    // Get dayOfWeek from date string
    var d = new Date(date + 'T00:00:00');
    var dow = d.getDay();
    dow = (dow === 0) ? 6 : dow - 1;

    var existing = Store.Slots.exists(currentUser.uid, date, time);

    if (action === 'available-new-recurring' || action === 'available' || action === 'available-no-recurring') {
      // available always means recurring
      Store.Recurring.create(currentUser.uid, dow, time);
      if (existing) Store.Slots.setAvailability(existing.slotId, 'available');
      else Store.Slots.create({ teacherId: currentUser.uid, date: date, time: time, status: 'available', baseStatus: 'available' });

    } else if (action === 'timeout') {
      // timeout = one-time unavailable, recurring rule stays
      if (existing) Store.Slots.setAvailability(existing.slotId, 'timeout');
      else Store.Slots.create({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout', baseStatus: 'timeout' });

    } else if (action === 'disabled') {
      // disabled = permanently off, remove recurring rule
      Store.Recurring.deleteByTeacherDayTime(currentUser.uid, dow, time);
      if (existing && !existing.studentId) Store.Slots.delete(existing.slotId);

    } else if (action === 'timeout-disabled') {
      // Keep recurring rule, but mark this specific week's slot as timeout
      if (existing) Store.Slots.setAvailability(existing.slotId, 'timeout');
      else Store.Slots.create({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout' });
    }
  }
  gridPending = {};
}

/* ── Helpers ──────────────────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   ALL BOOKINGS VIEW
══════════════════════════════════════════════════════════ */

function updateBookingSortBtn() {
  var sortBtn = document.getElementById('bookings-sort-btn');
  if (!sortBtn) return;
  sortBtn.setAttribute('aria-label', allBookingsSortAsc ? 'Älteste zuerst — umkehren' : 'Neueste zuerst — umkehren');
  sortBtn.querySelector('.sort-icon-asc').classList.toggle('is-hidden', !allBookingsSortAsc);
  sortBtn.querySelector('.sort-icon-desc').classList.toggle('is-hidden', allBookingsSortAsc);
}

function renderAllBookings() {
  var selections = Store.Selections.byTeacher(currentUser.uid);
  var students   = selections.map(function(s) { return Store.Users.byUid(s.studentId); }).filter(Boolean);

  /* ── Build custom dropdown options ── */
  var list    = document.getElementById('bookings-student-list');
  var label   = document.getElementById('bookings-student-label');
  var trigger = document.getElementById('bookings-student-trigger');
  if (!list || !label || !trigger) return;

  var options = [{ value: 'all', text: 'Alle Schüler' }];
  for (var i = 0; i < students.length; i++) {
    options.push({ value: students[i].uid, text: ProfileStore.getDisplayName(students[i].uid) });
  }

  function setFilter(val) {
    allBookingsFilter = val;
    var selected = options.filter(function(o) { return o.value === val; })[0] || options[0];
    label.textContent = selected.text;
    /* Update active state */
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var j = 0; j < items.length; j++) {
      items[j].classList.toggle('is-active', items[j].getAttribute('data-value') === val);
      items[j].setAttribute('aria-selected', items[j].getAttribute('data-value') === val ? 'true' : 'false');
    }
    closeDropdown();
    renderAllBookingsList();
  }

  function openDropdown() {
    list.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    trigger.classList.add('is-open');
  }

  function closeDropdown() {
    list.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.classList.remove('is-open');
  }

  /* Rebuild list items */
  list.innerHTML = '';
  for (var k = 0; k < options.length; k++) {
    (function(opt) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (opt.value === allBookingsFilter ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', opt.value);
      li.setAttribute('aria-selected', opt.value === allBookingsFilter ? 'true' : 'false');
      li.textContent = opt.text;
      li.addEventListener('click', function() { setFilter(opt.value); });
      list.appendChild(li);
    })(options[k]);
  }

  /* Sync label to current filter */
  var cur = options.filter(function(o) { return o.value === allBookingsFilter; })[0] || options[0];
  label.textContent = cur.text;

  /* Toggle open/close */
  trigger.onclick = function(e) {
    e.stopPropagation();
    if (list.classList.contains('is-open')) { closeDropdown(); } else { openDropdown(); }
  };

  /* Close on outside click — rebind each time to avoid stale refs */
  document.removeEventListener('click', _closeBookingDropdown);
  _closeBookingDropdown = function() { closeDropdown(); };
  document.addEventListener('click', _closeBookingDropdown);

  // Time filter buttons — scoped to all-bookings view
  var timeBtns = document.querySelectorAll('#view-all-bookings .booking-time-btn');
  for (var t = 0; t < timeBtns.length; t++) {
    timeBtns[t].classList.toggle('active', timeBtns[t].id === 'filter-' + allBookingsTimeFilter);
    (function(btn) {
      btn.onclick = function() {
        allBookingsTimeFilter = btn.id.replace('filter-', '');
        // Smart default: past → newest-first (desc), upcoming/all → oldest-first (asc)
        allBookingsSortAsc = (allBookingsTimeFilter !== 'past');
        for (var j = 0; j < timeBtns.length; j++) timeBtns[j].classList.remove('active');
        btn.classList.add('active');
        updateBookingSortBtn();
        renderAllBookingsList();
      };
    })(timeBtns[t]);
  }

  // Sort button wired once only — prevents stacking handlers on each tab switch
  if (!_bookingsSortBtnInit) {
    _bookingsSortBtnInit = true;
    var sortBtn = document.getElementById('bookings-sort-btn');
    if (sortBtn) {
      sortBtn.onclick = function() {
        allBookingsSortAsc = !allBookingsSortAsc;
        updateBookingSortBtn();
        renderAllBookingsList();
      };
    }
  }
  updateBookingSortBtn();

  // Confirm filter tabs — scoped to all-bookings view
  var confirmBtns = document.querySelectorAll('#view-all-bookings .booking-confirm-btn');
  for (var ci = 0; ci < confirmBtns.length; ci++) {
    confirmBtns[ci].classList.toggle('active', confirmBtns[ci].dataset.confirm === allBookingsConfirmFilter);
    (function(btn) {
      btn.onclick = function() {
        allBookingsConfirmFilter = btn.dataset.confirm;
        for (var cj = 0; cj < confirmBtns.length; cj++) confirmBtns[cj].classList.remove('active');
        btn.classList.add('active');
        renderAllBookingsList();
      };
    })(confirmBtns[ci]);
  }
  _updateAllBookingsBadges();

  renderAllBookingsList();
}

/* Berechnet Blockzahlen (merged) für alle drei Confirm-Filter.
 * Wird von All Bookings und Day Panel gleichermaßen verwendet. */
function _calcBlockCounts(slots, today) {
  var byDate = {};
  for (var i = 0; i < slots.length; i++) {
    var d = slots[i].date;
    if (!byDate[d]) byDate[d] = [];
    byDate[d].push(slots[i]);
  }
  function countBlocks(filterFn) {
    var total = 0;
    var dates = Object.keys(byDate);
    for (var di = 0; di < dates.length; di++) {
      var filtered = byDate[dates[di]].filter(filterFn);
      total += mergeAllBookingBlocks(dates[di], filtered, today).length;
    }
    return total;
  }
  return {
    all:         countBlocks(function() { return true; }),
    unconfirmed: countBlocks(function(s) { return !s.confirmedAt; }),
    confirmed:   countBlocks(function(s) { return !!s.confirmedAt; })
  };
}

function _updateAllBookingsBadges() {
  var today = fmtDate(new Date());

  /* Dieselbe Filter-Pipeline wie renderAllBookingsList */
  var slots = Store.Slots.byTeacher(currentUser.uid)
    .filter(function(s) { return s.status === 'booked' && s.studentId; });

  if (allBookingsFilter !== 'all') {
    slots = slots.filter(function(s) { return s.studentId === allBookingsFilter; });
  }
  slots = _applyTimeFilter(slots, allBookingsTimeFilter, today);

  /* Zählung direkt aus mergeAllBookingBlocks — exakt wie die Anzeige */
  var counts = _calcBlockCounts(slots, today);

  function _setBadge(id, count) {
    var container = document.getElementById('view-all-bookings');
    var el = container ? container.querySelector('#' + id) : document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    el.classList.toggle('is-hidden', count === 0);
  }
  _setBadge('all-count-badge',         counts.all);
  _setBadge('unconfirmed-count-badge', counts.unconfirmed);
  _setBadge('confirmed-count-badge',   counts.confirmed);
}

function renderAllBookingsList() {
  var container = document.getElementById('all-bookings-list');
  container.innerHTML = '';

  var today = fmtDate(new Date()); /* FIX: defined here, passed to sub-functions via block.today */

  var allSlots = Store.Slots.byTeacher(currentUser.uid)
    .filter(function(s) {
      return s.status === 'booked' && s.studentId;
    })
    .map(function(s) {
      var p = pendingBookings[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  // Filter by student
  if (allBookingsFilter !== 'all') {
    allSlots = allSlots.filter(function(s) { return s.studentId === allBookingsFilter; });
  }

  allSlots = _applyTimeFilter(allSlots, allBookingsTimeFilter, today);
  allSlots = _applyConfirmFilter(allSlots, allBookingsConfirmFilter);

  var emptyReasons = {
    past: 'Keine vergangenen Buchungen.',
    upcoming: 'Keine kommenden Buchungen.',
    all: 'Keine Buchungen gefunden.'
  };
  if (!allSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = emptyReasons[allBookingsTimeFilter] || 'Keine Buchungen gefunden.';
    container.appendChild(empty);
    return;
  }

  // Always sort ascending for correct merging — direction only affects display order
  allSlots.sort(function(a, b) {
    return a.date.localeCompare(b.date) || a.time.localeCompare(b.time);
  });

  // Group by date
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < allSlots.length; i++) {
    var s = allSlots[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  if (!allBookingsSortAsc) { dateOrder.reverse(); }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr   = dateOrder[d];
    var dateSlots = byDate[dateStr];
    var isPast    = dateStr < today;

    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider' + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
    container.appendChild(divider);

    var blocks = mergeAllBookingBlocks(dateStr, dateSlots, today);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(buildAllBookingBlock(blocks[b], { showDate: false, isPast: isPast }));
    }
  }
  _updateAllBookingsBadges();
  setTimeout(updateJumpBtns, 50);
}

/**
 * Merge consecutive booked slots of the same student into blocks.
 * Also include available slots between booked ones for display when expanded.
 */
function mergeAllBookingBlocks(dateStr, bookedSlots, today) {
  var blocks = [];

  /* Sort by studentId first, then time — so same-student slots are adjacent */
  var sorted = bookedSlots.slice().sort(function(a, b) {
    return (a.studentId || '').localeCompare(b.studentId || '') || a.time.localeCompare(b.time);
  });

  var i = 0;
  while (i < sorted.length) {
    var s       = sorted[i];
    var student = Store.Users.byUid(s.studentId);
    var end     = Store.slotEndTime(s.time);
    var grp     = [s];
    var j       = i + 1;

    /* Merge consecutive OR overlapping slots of same student.
     * next.time <= end covers: exact continuation (==) and overlap/duplicate (<). */
    while (j < sorted.length) {
      var next = sorted[j];
      if (next.studentId === s.studentId && next.time <= end) {
        var nextEnd = Store.slotEndTime(next.time);
        if (nextEnd > end) end = nextEnd;
        grp.push(next);
        j++;
      } else { break; }
    }

    var blockHasPending     = grp.some(function(x) { return !!x._pending; });
    var blockFullyConfirmed = grp.every(function(x) { return !!x.confirmedAt; });
    blocks.push({
      dateStr:          dateStr,
      today:            today,
      student:          student,
      start:            s.time,
      end:              end,
      bookedSlots:      grp,
      hasPending:       blockHasPending,
      isFullyConfirmed: blockFullyConfirmed
    });
    i = j;
  }

  /* Re-sort blocks by start time for display */
  blocks.sort(function(a, b) { return a.start.localeCompare(b.start); });

  return blocks;
}

function buildAllBookingBlock(block, options) {
  var showDate     = !options || options.showDate !== false;
  var isPast       = !!(options && options.isPast);
  var simpleDetail = !!(options && options.simpleDetail);
  var blockKey = block.dateStr + '-' + block.start + '-' + (block.student ? block.student.uid : 'x');
  var isOpen   = !!expandedAllBlocks[blockKey];
  var studentName = ProfileStore.getDisplayName(block.student ? block.student.uid : '?');

  var hasPending = !!block.hasPending;
  var isFullyConfirmed = !!block.isFullyConfirmed;
  var wrapper = document.createElement('div');
  wrapper.className = 'all-booking-block-wrapper';

  // Header
  var header = document.createElement('div');
  header.className = 'all-booking-block-header'
    + (isPast ? ' all-booking-block-past' : '')
    + (hasPending ? ' block-pending' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'all-booking-block-time';
  var dateObj = new Date(block.dateStr + 'T00:00:00');
  if (showDate) {
    var dateLabel = dateObj.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
    timeEl.textContent = dateLabel + '  ' + block.start + ' \u2013 ' + block.end;
  } else {
    timeEl.textContent = block.start + ' \u2013 ' + block.end;
  }

  var studentEl = document.createElement('span');
  studentEl.className = 'all-booking-block-student';
  studentEl.textContent = studentName;

  var chevron = document.createElement('span');
  chevron.className = 'all-booking-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  header.appendChild(timeEl);
  header.appendChild(studentEl);

  // Confirmed badge OR confirm button
  if (isFullyConfirmed) {
    var confirmedBadge = document.createElement('span');
    confirmedBadge.className = 'badge badge-confirmed';
    confirmedBadge.textContent = '✓ Bestätigt';
    header.appendChild(confirmedBadge);

    // Release button — only for past confirmed blocks
    if (isPast) {
      var releaseBtn = document.createElement('button');
      releaseBtn.className = 'btn btn-ghost btn-sm all-booking-release-btn';
      releaseBtn.textContent = '↩ Freigeben';
      (function(b) {
        releaseBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          _openReleaseDialog(b);
        });
      })(block);
      header.appendChild(releaseBtn);
    }
  } else {
    var confirmAllBtn = document.createElement('button');
    confirmAllBtn.className = 'btn btn-ghost btn-sm all-booking-confirm-btn';
    confirmAllBtn.textContent = '✓ Bestätigen';
    (function(b) {
      confirmAllBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        _openConfirmDialog(b);
      });
    })(block);
    header.appendChild(confirmAllBtn);
  }

  /* Bearbeiten-Button (Move/Cancel/Recurring) — future, unconfirmed blocks only */
  if (!isPast && !isFullyConfirmed) {
    var moveAllBtn = document.createElement('button');
    moveAllBtn.className = 'btn btn-ghost btn-sm all-booking-move-all-btn';
    moveAllBtn.setAttribute('aria-label', 'Block bearbeiten');
    moveAllBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11.5 2.5a1.414 1.414 0 012 2L5 13H2v-3L11.5 2.5z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    (function(b) {
      moveAllBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        openMoveBlockDialog(b);
      });
    })(block);
    header.appendChild(moveAllBtn);
  }

  // Detail panel
  var detail = document.createElement('div');
  detail.className = 'all-booking-block-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) {
    if (simpleDetail) populateSimpleBlockDetail(detail, block);
    else populateAllBookingDetail(detail, block);
  }

  function toggle() {
    if (expandedAllBlocks[blockKey]) {
      delete expandedAllBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedAllBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      if (simpleDetail) populateSimpleBlockDetail(detail, block);
      else populateAllBookingDetail(detail, block);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

function populateAllBookingDetail(detail, block) {
  detail.innerHTML = '';
  var stuId = block.student ? block.student.uid : null;
  var today = block.today || fmtDate(new Date()); /* FIX: today passed via block, fallback safe */

  var allDateSlots = Store.Slots.byTeacherDate(currentUser.uid, block.dateStr)
    .sort(function(a, b) { return a.time.localeCompare(b.time); });

  var display = allDateSlots.filter(function(s) {
    if (s.status === 'booked' && s.studentId === stuId) return true;
    if ((s.status === 'available' || s.status === 'recurring') && !s.studentId) return true;
    if (pendingBookings[s.slotId]) return true;
    return false;
  });

  if (!display.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.style.padding = 'var(--sp-3)';
    empty.textContent = 'No slots available on this day.';
    detail.appendChild(empty);
    return;
  }

  for (var i = 0; i < display.length; i++) {
    var origSlot   = display[i];
    var isPending  = !!pendingBookings[origSlot.slotId];
    var pendingObj = pendingBookings[origSlot.slotId];
    var isBooked   = (origSlot.status === 'booked' && origSlot.studentId === stuId)
                   || (isPending && pendingObj.action === 'book');

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row' + (isBooked ? '' : ' all-booking-slot-available') + (isPending ? ' slot-pending' : '');

    var timeEl = document.createElement('span');
    timeEl.className = 'all-booking-slot-time';
    timeEl.textContent = origSlot.time + ' – ' + Store.slotEndTime(origSlot.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'all-booking-slot-status';
    statusEl.textContent = isBooked ? 'Gebucht' : 'Frei';

    var btnGroup = document.createElement('div');
    btnGroup.className = 'all-booking-slot-btns';

    if (isBooked) {
      var isSlotPast = origSlot.date < today;
      var isConfirmed = !!origSlot.confirmedAt;

      if (isConfirmed) {
        var cBadge = document.createElement('span');
        cBadge.className = 'badge badge-confirmed';
        cBadge.textContent = '✓ Bestätigt';
        btnGroup.appendChild(cBadge);
        /* confirmed: no cancel, no move */
      } else {
        var confirmBtn = document.createElement('button');
        confirmBtn.className = 'btn btn-ghost btn-sm';
        confirmBtn.textContent = '✓';
        confirmBtn.title = 'Bestätigen';
        (function(s) {
          confirmBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            _openConfirmDialogSingle(s.slotId);
          });
        })(origSlot);
        btnGroup.appendChild(confirmBtn);

        if (!isSlotPast) {
          var cancelBtn = document.createElement('button');
          cancelBtn.className = (isPending && pendingObj.action === 'cancel') ? 'btn btn-ghost btn-sm' : 'btn btn-danger btn-sm';
          cancelBtn.textContent = (isPending && pendingObj.action === 'cancel') ? 'Undo' : 'Cancel';
          (function(s) {
            cancelBtn.addEventListener('click', function(e) {
              e.stopPropagation();
              if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'cancel') {
                delete pendingBookings[s.slotId];
              } else if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'book') {
                delete pendingBookings[s.slotId];
              } else {
                var original = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
                pendingBookings[s.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
              }
              updateBookingSaveBtn();
              renderStudentList();
              renderAllBookingsList();
            });
          })(origSlot);
          btnGroup.appendChild(cancelBtn);
        }
      }

    } else {
      /* Free slot — only show + Add if block is NOT fully confirmed */
      var blockIsConfirmed = !!(block && block.isFullyConfirmed);
      if (!blockIsConfirmed) {
        var addBtn = document.createElement('button');
        addBtn.className = isPending ? 'btn btn-ghost btn-sm' : 'btn btn-primary btn-sm';
        addBtn.textContent = isPending ? 'Undo' : '+ Add';
      (function(s, b) {
        addBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingBookings[s.slotId]) {
            delete pendingBookings[s.slotId];
          } else {
            var original = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
            pendingBookings[s.slotId] = { action: 'book', originalSlot: original, newStudentId: stuId, extraStudents: [] };
          }
          updateBookingSaveBtn();
          renderStudentList();
          renderAllBookingsList();
        });
      })(origSlot, block);
      btnGroup.appendChild(addBtn);
      } /* end if !blockIsConfirmed */
    }

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    row.appendChild(btnGroup);
    detail.appendChild(row);
  }
}

/* ── Simple detail — only the block's own booked slots, no day-lookup ── */
function populateSimpleBlockDetail(detail, block) {
  detail.innerHTML = '';
  var slots = block.bookedSlots;
  if (!slots || !slots.length) return;

  for (var i = 0; i < slots.length; i++) {
    var s    = slots[i];
    var orig = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0] || s;
    var isConfirmed = !!orig.confirmedAt;

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row';

    var timeEl = document.createElement('span');
    timeEl.className = 'all-booking-slot-time';
    timeEl.textContent = orig.time + ' \u2013 ' + Store.slotEndTime(orig.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'all-booking-slot-status';
    statusEl.textContent = isConfirmed ? '\u2713 Bestätigt' : 'Gebucht';

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    detail.appendChild(row);
  }
}

/* ── Bestätigungs-Dialog (Block-Level) ───────────────── */
function _openConfirmDialog(block) {
  var stuName = ProfileStore.getDisplayName(block.student ? block.student.uid : '?');
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">⚠ <strong>Achtung:</strong> Diese Aktion kann nicht rückgängig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Bestätigung der Stunde von <strong>' + stuName + '</strong> (' + block.start + ' – ' + block.end + '):</p>' +
      '<ul style="margin:0;padding-left:var(--sp-5);display:flex;flex-direction:column;gap:var(--sp-1);color:var(--neutral-700);font-size:var(--text-body)">' +
        '<li>kann die Stunde <strong>nicht mehr verschoben</strong> werden</li>' +
        '<li>kann die Stunde <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung für die Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';
  var result = Modal.show({
    title: 'Stunde bestätigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    for (var ci = 0; ci < block.bookedSlots.length; ci++) {
      Store.Slots.confirm(block.bookedSlots[ci].slotId);
    }
    _updateAllBookingsBadges();
    renderAllBookingsList();
    result.close();
  });
}

/* ── Bestätigungs-Dialog (Slot-Level) ────────────────── */
function _openConfirmDialogSingle(slotId) {
  var slot = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
  if (!slot) return;
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">⚠ <strong>Achtung:</strong> Diese Aktion kann nicht rückgängig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Bestätigung des Slots <strong>' + slot.time + ' – ' + Store.slotEndTime(slot.time) + '</strong>:</p>' +
      '<ul style="margin:0;padding-left:var(--sp-5);display:flex;flex-direction:column;gap:var(--sp-1);color:var(--neutral-700);font-size:var(--text-body)">' +
        '<li>kann der Slot <strong>nicht mehr verschoben</strong> werden</li>' +
        '<li>kann der Slot <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung für diesen Slot freigegeben</strong></li>' +
      '</ul>' +
    '</div>';
  var result = Modal.show({
    title: 'Slot bestätigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    Store.Slots.confirm(slotId);
    _updateAllBookingsBadges();
    renderAllBookingsList();
    result.close();
  });
}

/* ── Freigabe-Dialog ─────────────────────────────────── */
function _openReleaseDialog(block) {
  var stuName = ProfileStore.getDisplayName(block.student ? block.student.uid : '?');
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info">Möchtest du die Zeitslots der Stunde von <strong>' + stuName + '</strong> (' + block.start + ' – ' + block.end + ') freigeben?</p>' +
      '<p class="move-dialog-info">Die Stunde wurde bestätigt und bezahlt. Die Slots werden wieder für andere Schüler verfügbar gemacht.</p>' +
      '<p class="move-dialog-info">Ein Hinweis bleibt im Kalender sichtbar.</p>' +
    '</div>';
  var result = Modal.show({
    title: 'Slot freigeben',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Freigeben</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    for (var ri = 0; ri < block.bookedSlots.length; ri++) {
      Store.Slots.release(block.bookedSlots[ri].slotId);
    }
    renderAllBookingsList();
    renderCalendarMonth();
    result.close();
  });
}

/* ── Move Dialog ─────────────────────────────────────── */
function openMoveDialog(slot, block) {
  var stuId      = block.student ? block.student.uid : null;
  var stuName    = ProfileStore.getDisplayName(block.student ? block.student.uid : '?');
  var teacherId  = currentUser.uid;

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info">Move <strong>' + slot.time + ' – ' + Store.slotEndTime(slot.time) + '</strong> for <strong>' + stuName + '</strong></p>' +
      '<div class="move-dialog-row">' +
        '<div class="move-dialog-col">' +
          '<label class="form-label">Datum</label>' +
          '<input type="date" id="move-date-input" class="form-select" value="' + block.dateStr + '" />' +
        '</div>' +
        '<div class="move-dialog-col">' +
          '<label class="form-label">Uhrzeit</label>' +
          '<select id="move-time-select" class="form-select"><option value="">Datum wählen</option></select>' +
        '</div>' +
      '</div>' +
      '<div id="move-check-result" class="move-check-result"></div>' +
      '<div class="move-dialog-btns">' +
        '<button class="btn btn-primary" id="move-check-btn">Verfügbarkeit prüfen</button>' +
        '<button class="btn btn-primary is-hidden" id="move-confirm-btn">Verschieben</button>' +
        '<button class="btn btn-ghost is-hidden" id="move-cal-btn">Im Kalender anzeigen</button>' +
        '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '</div>' +
    '</div>';

  var result = Modal.show({ title: 'Termin verschieben', bodyHTML: bodyHTML, footerHTML: '' });

  var dateInput    = document.getElementById('move-date-input');
  var timeSelect   = document.getElementById('move-time-select');
  var checkResult  = document.getElementById('move-check-result');
  var checkBtn     = document.getElementById('move-check-btn');
  var confirmBtn   = document.getElementById('move-confirm-btn');
  var calBtn       = document.getElementById('move-cal-btn');
  var cancelBtn    = document.getElementById('modal-cancel');

  function resetCheck() {
    checkResult.textContent = '';
    checkResult.className = 'move-check-result';
    confirmBtn.classList.add('is-hidden');
    checkBtn.classList.remove('is-hidden');
    var hasSelection = dateInput.value && timeSelect.value;
    calBtn.classList.toggle('is-hidden', !hasSelection);
  }

  function rebuildTimes() {
    timeSelect.innerHTML = '';
    var dateStr = dateInput.value;
    if (!dateStr) { calBtn.classList.add('is-hidden'); return; }
    var daySlots = Store.Slots.byTeacherDate(teacherId, dateStr)
      .filter(function(s) {
        if (s.slotId === slot.slotId) return false;
        if (s.status === 'available' || s.status === 'recurring') return true;
        if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'cancel') return true;
        return false;
      })
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    if (!daySlots.length) {
      var o = document.createElement('option');
      o.value = '';
      o.textContent = 'Keine freien Slots';
      timeSelect.appendChild(o);
      return;
    }
    for (var i = 0; i < daySlots.length; i++) {
      var o = document.createElement('option');
      o.value = daySlots[i].slotId;
      o.textContent = daySlots[i].time + ' – ' + Store.slotEndTime(daySlots[i].time);
      timeSelect.appendChild(o);
    }
    resetCheck();
  }

  rebuildTimes();
  dateInput.addEventListener('change', function() { rebuildTimes(); resetCheck(); });
  timeSelect.addEventListener('change', function() {
    resetCheck();
    calBtn.classList.toggle('is-hidden', !(dateInput.value && timeSelect.value));
  });

  checkBtn.addEventListener('click', function() {
    var targetSlotId = timeSelect.value;
    if (!targetSlotId) {
      checkResult.textContent = 'Bitte Datum und Uhrzeit wählen.';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var targetSlot = Store.Slots.all().filter(function(s) { return s.slotId === targetSlotId; })[0];
    if (!targetSlot) {
      checkResult.textContent = 'Slot nicht gefunden.';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var alreadyBooked = targetSlot.status === 'booked' && !pendingBookings[targetSlot.slotId];
    if (alreadyBooked) {
      var who = Store.Users.byUid(targetSlot.studentId);
      checkResult.textContent = 'Bereits gebucht von ' + ProfileStore.getDisplayName(targetSlot.studentId) + '.';
      checkResult.className = 'move-check-result move-check-fail';
      confirmBtn.classList.add('is-hidden');
      checkBtn.classList.remove('is-hidden');
    } else {
      checkResult.textContent = '✓ Slot ist frei — Verschiebung möglich.';
      checkResult.className = 'move-check-result move-check-ok';
      confirmBtn.classList.remove('is-hidden');
      calBtn.classList.remove('is-hidden');
      checkBtn.classList.add('is-hidden');
    }
  });

  confirmBtn.addEventListener('click', function() {
    var targetSlotId = timeSelect.value;
    if (!targetSlotId) return;
    var originalSlot = Store.Slots.all().filter(function(s) { return s.slotId === slot.slotId; })[0];
    var targetSlot   = Store.Slots.all().filter(function(s) { return s.slotId === targetSlotId; })[0];
    if (!originalSlot || !targetSlot) return;
    pendingBookings[slot.slotId]      = { action: 'cancel', originalSlot: originalSlot, newStudentId: null };
    pendingBookings[targetSlot.slotId] = { action: 'book',   originalSlot: targetSlot,   newStudentId: stuId, extraStudents: [] };
    updateBookingSaveBtn();
    renderStudentList();
    renderAllBookingsList();
    result.close();
    Toast.info('Verschiebung vorgemerkt — Drück Save zum Bestätigen.');
  });

  cancelBtn.addEventListener('click', result.close);

  calBtn.addEventListener('click', function() {
    var dateStr = dateInput.value;
    if (!dateStr) return;
    var target = new Date(dateStr + 'T00:00:00');
    selectedDate = target;
    viewYear  = target.getFullYear();
    viewMonth = target.getMonth();
    activeDayTab = 'bookings';
    switchTeacherView('schedule');
    renderCalendar();
    renderDayPanel();
    result.close();
    setTimeout(function() {
      var panel = document.getElementById('section-daypanel');
      if (panel) {
        var offset = getStickyOffset();
        var top = panel.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    }, 80);
  });
}

/* ── Move Block Dialog (alle Slots auf einmal) ───────── */
function openMoveBlockDialog(block) {
  openMoveBlockDialogShared({
    block:           block,
    teacherId:       currentUser.uid,
    pendingMap:      pendingBookings,
    stuId:           block.student ? block.student.uid : null,
    onConfirmBlock:  function() {
      _updateAllBookingsBadges();
      renderAllBookingsList();
      renderDayPanel();
    },
    onCancelBlock:   function() {
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderDayPanel();
    },
    onConfirm:  function() {
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderDayPanel();
    },
    onCalJump: function(dateStr, result) {
      if (!dateStr) return;
      var target = new Date(dateStr + 'T00:00:00');
      selectedDate = target;
      viewYear  = target.getFullYear();
      viewMonth = target.getMonth();
      activeDayTab = 'bookings';
      switchTeacherView('schedule');
      renderCalendar();
      renderDayPanel();
      result.close();
      setTimeout(function() {
        var panel = document.getElementById('section-daypanel');
        if (panel) {
          var offset = getStickyOffset();
          var top = panel.getBoundingClientRect().top + window.scrollY - offset;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      }, 80);
    }
  });
}

function getWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(gridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function weekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day:'numeric', month:'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' });
}

function updateStats() {
  var allSlots   = Store.Slots.byTeacher(currentUser.uid);
  var booked     = allSlots.filter(function(s) { return s.status === 'booked'; });
  var today      = fmtDate(new Date());
  var counts     = _calcBlockCounts(booked, today);
  document.getElementById('stat-booked').textContent = counts.all;
  var availEl = document.getElementById('stat-available');
  if (availEl) availEl.textContent = allSlots.filter(function(s) { return s.status === 'available'; }).length;
}

function fmtDate(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}

/* ── Section jump buttons ─────────────────────────────── */
function getSectionJumpTargets() {
  if (activeTeacherView === 'all-bookings') {
    var dividers = document.querySelectorAll('#view-all-bookings .all-bookings-day-divider');
    var pageTop  = document.querySelector('.page-header') || document.getElementById('view-all-bookings');
    if (dividers.length) return [pageTop].concat(Array.prototype.slice.call(dividers)).filter(Boolean);
    return [pageTop].filter(Boolean);
  }
  return [
    document.querySelector('.page-header'),
    document.getElementById('section-calendar'),
    document.getElementById('section-daypanel')
  ].filter(Boolean);
}

function getStickyOffset() {
  var navbar = document.querySelector('.navbar');
  var dayNav = document.getElementById('day-nav-bar');
  var offset = 0;
  if (navbar) offset += navbar.offsetHeight;
  if (dayNav && dayNav.classList.contains('is-sticky')) offset += dayNav.offsetHeight;
  return offset + 8;
}

function getCurrentSectionIndex(targets) {
  var offset = getStickyOffset();
  var scrollY = window.scrollY + offset + 10;
  var best = 0;
  for (var i = 0; i < targets.length; i++) {
    var top = targets[i].getBoundingClientRect().top + window.scrollY;
    if (top <= scrollY) best = i;
  }
  return best;
}

function updateJumpBtns() {
  var jumper  = document.getElementById('section-jumper');
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var upBtn   = document.getElementById('jump-up');
  var downBtn = document.getElementById('jump-down');
  if (!upBtn || !downBtn || !jumper) return;
  /* Show jumper if: scrolled past navbar OR in all-bookings with multiple targets */
  var navbarH = (document.querySelector('.navbar') || {}).offsetHeight || 0;
  var isVisible = window.scrollY > navbarH || (activeTeacherView === 'all-bookings' && targets.length > 1);
  jumper.classList.toggle('is-visible', isVisible);
  upBtn.classList.toggle('is-dimmed', idx <= 0);
  downBtn.classList.toggle('is-dimmed', idx >= targets.length - 1);
}

function jumpSection(delta) {
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var next    = idx + delta;
  if (next < 0 || next >= targets.length) return;
  var target  = targets[next];
  var offset  = getStickyOffset();
  var top     = target.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top: top, behavior: 'smooth' });
  setTimeout(updateJumpBtns, 400);
}

window.addEventListener('scroll', updateJumpBtns);
window.addEventListener('scroll', checkDayNavSticky);

window.addEventListener('resize', function() {
  _dayNavStickyActive = !_dayNavStickyActive;
  checkDayNavSticky();
});

/* ── Cross-tab sync: re-render when another tab changes data ── */
if (Store.onChange) {
  Store.onChange(function(e) {
    if (e.key === 'app_slots' || e.key === 'app_selections' || e.key === 'app_users') {
      updateStats();
      renderStudentList();
      renderCalendar();
      renderDayPanel();
      if (activeTeacherView === 'all-bookings') renderAllBookings();
    }
  });
}
