/**
 * teacher.js — Teacher View Logic
 *
 * Grid modes: 'available' | 'timeout'
 * Recurring slots: materialised on-demand per week from app_recurring
 * No inline styles — all classes from teacher.css
 */

var currentUser  = null;

/* ── Teacher display helper: UTC slot time → teacher local time string ──
   Teacher always sees their own timezone — no offset badge needed.
   Returns "HH:MM" in teacher's local TZ.
   Falls back to raw UTC if TimezoneService not available. */
function _tTeacherTime(utcTimeStr, dateStr) {
  if (!utcTimeStr) return utcTimeStr;
  if (typeof TimezoneService === 'undefined' || !currentUser) return utcTimeStr;
  var tz = TimezoneService.getUserTimezone(currentUser.uid);
  return TimezoneService.utcToLocal(utcTimeStr, dateStr || '', tz).localTime;
}

/* ── Teacher display helper: UTC end time → teacher local end time ── */
function _tTeacherEndTime(utcTimeStr, dateStr) {
  if (!utcTimeStr) return utcTimeStr;
  var localStart = _tTeacherTime(utcTimeStr, dateStr);
  return AppService.slotEndTime(localStart);
}
var viewYear     = 0;
var viewMonth    = 0;
var selectedDate = new Date(); /* Heute vorausgewählt */

var gridWeekStart = null;
var gridMode      = 'available'; // 'available' | 'timeout'
var gridPending   = {};          // { "date|time": 'available'|'timeout'|'disabled'|'remove-recurring' }

/* Preserve free-slots accordion open state across renderDayPanel calls */
var _freeSlotsBlockOpen = false;

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START = '06:00';
var GRID_END   = '22:00';

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('teacher');
  if (!currentUser) return;

  function _initApp() {
    Navbar.init('teacher');

    var now   = new Date();
    viewYear  = now.getFullYear();
    viewMonth = now.getMonth();

    document.getElementById('prev-btn').addEventListener('click', prevMonth);
    document.getElementById('next-btn').addEventListener('click', nextMonth);
    document.getElementById('grid-close-btn').addEventListener('click', closeSlotGrid);
    document.getElementById('grid-save-btn').addEventListener('click', saveSlotGrid);
    document.getElementById('grid-prev-month').addEventListener('click', gridPrevMonth);
    document.getElementById('grid-prev-week').addEventListener('click', gridPrevWeek);
    document.getElementById('grid-next-week').addEventListener('click', gridNextWeek);
    document.getElementById('grid-next-month').addEventListener('click', gridNextMonth);
    document.getElementById('mode-btn-available').addEventListener('click', function() { setGridMode('available'); });
    document.getElementById('mode-btn-timeout').addEventListener('click', function() { setGridMode('timeout'); });

    renderStudentList();
    renderCalendar();
    renderDayPanel();

    // Main view tabs
    document.getElementById('nav-schedule').addEventListener('click', function() { switchTeacherView('schedule'); });
    document.getElementById('nav-all-bookings').addEventListener('click', function() { switchTeacherView('all-bookings'); });
    document.getElementById('nav-students').addEventListener('click', function() { switchTeacherView('students'); });
    document.getElementById('nav-wallet').addEventListener('click', function() { switchTeacherView('wallet'); });
    var dashLink = document.getElementById('nav-dashboard-link');
    if (dashLink && currentUser) { dashLink.href = './dashboard.html?uid=' + encodeURIComponent(currentUser.uid); }

    // Day panel sub-tabs
    document.getElementById('day-tab-availability').addEventListener('click', function() { switchDayTab('availability'); });
    document.getElementById('day-tab-availability2').addEventListener('click', function() { switchDayTab('availability2'); });
    document.getElementById('day-tab-availability3').addEventListener('click', function() { switchDayTab('availability3'); });
    document.getElementById('day-tab-bookings').addEventListener('click', function() { switchDayTab('bookings'); });

    // Teacher Day View overlay
    _tdvInitListeners();
  }

  if (typeof CurrencyService !== 'undefined' && typeof CurrencyService.onReady === 'function') {
    CurrencyService.onReady(_initApp);
  } else {
    _initApp();
  }
});

var activeDayTab = 'availability';

function switchDayTab(tab) {
  activeDayTab = tab;
  document.getElementById('day-tab-availability').classList.toggle('active',  tab === 'availability');
  document.getElementById('day-tab-availability2').classList.toggle('active', tab === 'availability2');
  document.getElementById('day-tab-availability3').classList.toggle('active', tab === 'availability3');
  document.getElementById('day-tab-bookings').classList.toggle('active',      tab === 'bookings');
  renderDayPanel();
}

var activeTeacherView = 'schedule';
/* ── Single shared filter state — used by ALL three views:
      All Bookings tab, Day Panel (Buchungen tab), My Students list ── */
var bookingsFilter = {
  student:   'all',
  time:      'upcoming',
  confirmed: 'all',
  dateFrom:  '',   /* 'YYYY-MM-DD' | '' */
  dateTo:    ''    /* 'YYYY-MM-DD' | '' */
};
var allBookingsSortAsc = true; /* true = oldest→newest, false = newest→oldest */

/* Read/write helpers — always go through bookingsFilter */
/* Legacy aliases — read-only snapshots, updated via _setFilter */
var _closeBookingDropdown = null;
var _closeDdDropdown      = null; /* outside-click handler for custom dropdown */
var expandedAllBlocks  = {};


function _applyConfirmFilter(slots, confirmFilter) {
  if (confirmFilter === 'confirmed')   return slots.filter(function(s) { return !!s.confirmedAt; });
  if (confirmFilter === 'unconfirmed') return slots.filter(function(s) { return !s.confirmedAt;  });
  return slots;
}

/* Pending booking changes — staged, not yet written to Store
   { slotId: { action:'book'|'cancel', originalSlot:{...}, newStudentId:uid|null } } */
var pendingBookings  = {};
var pendingMoveOpts  = {};   /* studentId → { reason, reasonLabel, note } from move dialog */

/* Return effective slot — pending overrides Store */
function getEffectiveTeacherSlot(storeSlot) {
  var p = pendingBookings[storeSlot.slotId];
  if (!p) return storeSlot;
  var s = {}; for (var k in storeSlot) s[k] = storeSlot[k];
  if (p.action === 'book') {
    s.status    = 'booked';
    s.studentId = p.newStudentId;
    s.students  = p.students || [p.newStudentId];
    s._pending  = 'book';
  } else {
    s.status    = storeSlot.baseStatus || 'available';
    s.studentId = null;
    s.students  = [];
    s._pending  = 'cancel';
  }
  return s;
}

function switchTeacherView(view) {
  activeTeacherView = view;
  document.getElementById('nav-schedule').classList.toggle('active',      view === 'schedule');
  document.getElementById('nav-all-bookings').classList.toggle('active',  view === 'all-bookings');
  document.getElementById('nav-students').classList.toggle('active',      view === 'students');
  document.getElementById('nav-wallet').classList.toggle('active',        view === 'wallet');
  document.getElementById('view-schedule').classList.toggle('view-hidden',      view !== 'schedule');
  document.getElementById('view-all-bookings').classList.toggle('view-hidden',  view !== 'all-bookings');
  document.getElementById('view-students').classList.toggle('view-hidden',      view !== 'students');
  document.getElementById('view-wallet').classList.toggle('view-hidden',        view !== 'wallet');
  if (view === 'all-bookings') {
    var bar    = document.getElementById('day-nav-bar');
    var header = document.getElementById('day-sticky-header');
    if (bar)    { bar.classList.remove('is-sticky'); }
    if (header) { header.classList.remove('is-sticky'); header.style.left = ''; header.style.width = ''; }
    window._dayNavStickyActive = false;
    renderAllBookings();
    setTimeout(updateJumpBtns, 200);
  }
  if (view === 'students') {
    renderStudentList();
  }
  if (view === 'schedule') {
    updateDayNavBar();
    setTimeout(updateJumpBtns, 100);
  }
  if (view === 'wallet') {
    if (typeof WalletPanel !== 'undefined') {
      WalletPanel.mount('teacher-wallet-panel', currentUser.uid);
    }
  }
}

/* ══════════════════════════════════════════════════════════
   STUDENT LIST
══════════════════════════════════════════════════════════ */

// Track which student rows are expanded
var expandedStudents = {};

/* ── Student filter: which student UIDs are checked (empty = all) ── */
var _stuFilterSelected = {}; /* { uid: true } — empty object = show all */

/* ── My Students filter state ── */
/* studentListFilter removed — replaced by shared bookingsFilter object */

function renderStudentList() {
  var selections = AppService.getSelectionsByTeacherSync(currentUser.uid);
  var container  = document.getElementById('student-list');
  var statStudentsEl = document.getElementById('stat-students');
  if (statStudentsEl) statStudentsEl.textContent = selections.length;

  if (!selections.length) {
    container.innerHTML = '<p class="text-muted" style="padding:var(--sp-3) var(--sp-4)">Noch keine Schüler.</p>';
    return;
  }

  container.innerHTML = '';
  var today = fmtDate(new Date());

  /* ── Student filter combobox — mockup-renderStudentList-studentFilter-2026-03-24_11-21 ── */
  (function() {
    var allStudents = [];
    for (var ci = 0; ci < selections.length; ci++) {
      var su = AppService.getUserSync(selections[ci].studentId);
      if (su) allStudents.push(su);
    }
    if (allStudents.length < 2) return; /* no point showing filter for 0-1 students */

    /* Init state: if empty, all are selected */
    var isAllSelected = (Object.keys(_stuFilterSelected).length === 0);

    var combo = document.createElement('div');
    combo.className = 'stu-filter-combo';

    /* Trigger */
    var trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'stu-filter-combo-trigger';

    var labelEl = document.createElement('span');
    labelEl.className = 'stu-filter-combo-label';

    var countEl = document.createElement('span');
    countEl.className = 'stu-filter-combo-count';

    var chevron = document.createElement('span');
    chevron.className = 'stu-filter-combo-chevron';
    chevron.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    trigger.appendChild(labelEl);
    trigger.appendChild(countEl);
    trigger.appendChild(chevron);

    /* Dropdown list */
    var list = document.createElement('div');
    list.className = 'stu-filter-combo-list';

    /* Header */
    var header = document.createElement('div');
    header.className = 'stu-filter-combo-header';
    var headerLbl = document.createElement('span');
    headerLbl.className = 'stu-filter-combo-header-label';
    headerLbl.textContent = 'Schüler';
    var allBtn = document.createElement('button');
    allBtn.type = 'button';
    allBtn.className = 'stu-filter-combo-all-btn';
    header.appendChild(headerLbl);
    header.appendChild(allBtn);
    list.appendChild(header);

    /* Update trigger label + count */
    function _updateTrigger() {
      var selKeys = Object.keys(_stuFilterSelected);
      var isAll   = selKeys.length === 0;
      if (isAll) {
        labelEl.textContent = 'Alle Schüler';
        countEl.textContent = allStudents.length;
        countEl.className   = 'stu-filter-combo-count is-all';
        allBtn.textContent  = 'Alle abwählen';
      } else {
        var names = selKeys.map(function(uid) { return AppService.getDisplayNameSync(uid) || uid; });
        labelEl.textContent = names.join(', ');
        countEl.textContent = selKeys.length;
        countEl.className   = 'stu-filter-combo-count';
        allBtn.textContent  = 'Alle auswählen';
      }
    }

    /* Build checkbox rows */
    function _buildRows() {
      /* Remove old rows */
      var old = list.querySelectorAll('.stu-filter-check-row');
      for (var ri = 0; ri < old.length; ri++) old[ri].parentNode.removeChild(old[ri]);

      for (var si = 0; si < allStudents.length; si++) {
        (function(stu) {
          var isAllSel = Object.keys(_stuFilterSelected).length === 0;
          var checked  = isAllSel || !!_stuFilterSelected[stu.uid];

          var row = document.createElement('label');
          row.className = 'stu-filter-check-row';

          var cb = document.createElement('input');
          cb.type    = 'checkbox';
          cb.checked = checked;

          var photo = ProfileStore.getPhoto(stu.uid);
          var avatarEl = document.createElement('div');
          avatarEl.className = 'stu-filter-check-avatar';
          if (photo) {
            avatarEl.innerHTML = '<img src="' + _esc(photo) + '" alt="">';
          } else {
            var n = AppService.getDisplayNameSync(stu.uid) || stu.uid;
            avatarEl.textContent = n.charAt(0).toUpperCase();
          }

          var nameEl = document.createElement('span');
          nameEl.className = 'stu-filter-check-name';
          nameEl.textContent = AppService.getDisplayNameSync(stu.uid) || stu.uid;

          /* Count bookings for this student */
          var bCount = AppService.getSlotsByStudentSync(stu.uid)
            .filter(function(s) { return s.teacherId === currentUser.uid && s.status === 'booked'; }).length;
          var metaEl = document.createElement('span');
          metaEl.className = 'stu-filter-check-meta';
          metaEl.textContent = bCount + ' Buchung' + (bCount !== 1 ? 'en' : '');

          row.appendChild(cb);
          row.appendChild(avatarEl);
          row.appendChild(nameEl);
          row.appendChild(metaEl);

          cb.addEventListener('change', function(e) {
            e.stopPropagation();
            if (cb.checked) {
              _stuFilterSelected[stu.uid] = true;
            } else {
              delete _stuFilterSelected[stu.uid];
            }
            /* If all checked, reset to "show all" */
            if (Object.keys(_stuFilterSelected).length === allStudents.length) {
              _stuFilterSelected = {};
            }
            _updateTrigger();
            renderStudentList();
          });

          list.appendChild(row);
        })(allStudents[si]);
      }
    }

    /* Select all / deselect all */
    allBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      if (Object.keys(_stuFilterSelected).length === 0) {
        /* Deselect all — none selected means show all, so pick first student only */
        /* Actually: "Alle abwählen" → select none = no filter, keep all visible.
           Semantics: empty = all. So button alternates between all/none */
        /* Show only first student when user clicks "Alle abwählen" — set just first */
        _stuFilterSelected = {};
        for (var ai = 0; ai < allStudents.length; ai++) {
          /* Leave empty = all, so this btn instead becomes "no filter" toggle */
        }
        /* Toggle: if all → deselect → keep first only. Actually just clear works. */
      } else {
        _stuFilterSelected = {}; /* all */
      }
      _updateTrigger();
      _buildRows();
      renderStudentList();
    });

    /* Open / close */
    function _open()  { list.classList.add('is-open'); trigger.classList.add('is-open'); }
    function _close() { list.classList.remove('is-open'); trigger.classList.remove('is-open'); }

    trigger.addEventListener('click', function(e) {
      e.stopPropagation();
      if (list.classList.contains('is-open')) { _close(); } else { _open(); }
    });
    list.addEventListener('click', function(e) { e.stopPropagation(); });
    document.addEventListener('click', function() { _close(); });

    _updateTrigger();
    _buildRows();

    combo.appendChild(trigger);
    combo.appendChild(list);
    container.appendChild(combo);
  })();

  /* ── Search input — mockup-renderStudentList-2026-03-23_20-39 ── */
  var searchWrap = document.createElement('div');
  searchWrap.innerHTML = buildSearchInput('stu-list-search', 'Schüler suchen…');
  container.appendChild(searchWrap.firstChild);

  /* ── Filter toolbar — reuses shared helpers from ui.js ── */
  var toolbar = document.createElement('div');
  toolbar.className = 'student-filter-toolbar';

  var onRerender = function() {
    renderStudentList();
    renderDayPanel();
    if (activeTeacherView === 'all-bookings') renderAllBookings();
  };

  toolbar.appendChild(_buildTimeFilterRow(function() { onRerender(); }));

  toolbar.appendChild(_buildSortDateRangeRow(function() { onRerender(); }));

  /* Confirm filter with counts + prices */
  var todayStr  = fmtDate(new Date());
  var allBooked = AppService.getSlotsByTeacherSync(currentUser.uid)
    .filter(function(s) { return s.status === 'booked' && s.studentId; });
  if (bookingsFilter.student !== 'all') {
    allBooked = allBooked.filter(function(s) { return s.studentId === bookingsFilter.student; });
  }
  allBooked = _applyTimeFilter(allBooked, bookingsFilter.time, todayStr);
  allBooked = _applyDateRangeFilter(allBooked);
  var counts = _calcBookingBlockCounts(allBooked, todayStr, {
    mergeFn: mergeAllBookingBlocks,
    priceFn: function(s) { return parseFloat(s.price) || 0; }
  });
  toolbar.appendChild(_buildConfirmFilterRow({
    counts:   counts,
    onFilter: function() { onRerender(); }
  }));

  container.appendChild(toolbar);

  /* ── Per-student rows ── */
  var frag = document.createDocumentFragment();
  var anyVisible = false;

  /* Apply student combobox filter */
  var _stuSelKeys = Object.keys(_stuFilterSelected);
  var _stuFilterActive = _stuSelKeys.length > 0;

  for (var i = 0; i < selections.length; i++) {
    var student = AppService.getUserSync(selections[i].studentId);
    if (!student) continue;

    /* Skip if combobox filter active and student not checked */
    if (_stuFilterActive && !_stuFilterSelected[student.uid]) continue;

    var allSlots = AppService.getSlotsByStudentSync(student.uid)
      .filter(function(s) { return s.teacherId === currentUser.uid && s.status === 'booked'; })
      .sort(function(a, b) { return a.date.localeCompare(b.date) || a.time.localeCompare(b.time); });

    var filtered = _applyTimeFilter(allSlots, bookingsFilter.time, today);
    filtered = _applyDateRangeFilter(filtered);
    filtered = _applyConfirmFilter(filtered, bookingsFilter.confirmed);

    if (!filtered.length) continue;
    anyVisible = true;
    frag.appendChild(buildStudentRow(student, filtered));
  }

  if (!anyVisible) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.classList.add('empty-state-padded');
    empty.textContent = 'Keine Buchungen für diesen Filter.';
    container.appendChild(empty);
    return;
  }

  container.appendChild(frag);

  /* ── Wire search to filter student cards by name ── */
  wireSearchInput('stu-list-search', function(query) {
    var q     = (query || '').trim().toLowerCase();
    var cards = container.querySelectorAll('.student-card');
    var found = 0;
    for (var ci = 0; ci < cards.length; ci++) {
      var nameEl = cards[ci].querySelector('.student-card-name');
      var label  = nameEl ? nameEl.textContent.toLowerCase() : '';
      var show   = !q || label.indexOf(q) !== -1;
      cards[ci].classList.toggle('is-hidden', !show);
      if (show) found++;
    }
    /* Empty state */
    var existingEmpty = container.querySelector('.stu-search-empty');
    if (existingEmpty) existingEmpty.parentNode.removeChild(existingEmpty);
    if (found === 0 && q) {
      var emptyEl = document.createElement('p');
      emptyEl.className = 'text-muted stu-search-empty';
      emptyEl.style.padding = 'var(--sp-3) var(--sp-4)';
      emptyEl.textContent = 'Kein Schüler gefunden.';
      container.appendChild(emptyEl);
    }
  });
}

function buildStudentRow(student, bookedSlots) {
  var isOpen  = !!expandedStudents[student.uid];
  var today   = fmtDate(new Date());
  var profile = (typeof ProfileStore !== 'undefined') ? AppService.getProfileOrDefaultSync(student.uid) : {};

  var counts = _calcBookingBlockCounts(bookedSlots, today, {
    mergeFn: mergeAllBookingBlocks,
    priceFn: function(s) { return parseFloat(s.price) || 0; }
  });

  /* ── Wrapper: .card like teacher card ── */
  var wrapper = document.createElement('div');
  wrapper.className = 'card student-card';

  /* ── Card top: avatar + name/subtitle + chevron ── */
  var cardTop = document.createElement('div');
  cardTop.className = 'student-card-top';
  cardTop.setAttribute('tabindex', '0');
  cardTop.setAttribute('role', 'button');

  /* Avatar — clickable → profile sheet */
  var avatarWrap = document.createElement('div');
  avatarWrap.className = 'student-card-avatar';
  avatarWrap.innerHTML = buildAvatarHTML(student.uid, { size: 'md', role: 'student' });
  (function(uid) {
    avatarWrap.addEventListener('click', function(e) {
      e.stopPropagation();
      showProfileSheet(uid);
    });
  })(student.uid);

  /* Name + subtitle */
  var nameCol = document.createElement('div');
  nameCol.className = 'student-card-name-col';

  var nameEl = document.createElement('div');
  nameEl.className  = 'student-card-name';
  nameEl.textContent = AppService.getDisplayNameSync(student.uid);
  nameCol.appendChild(nameEl);

  /* Subtitle: location or bio snippet */
  var subtitle = (profile.location || '').trim() ||
    (profile.bio ? profile.bio.trim().slice(0, 40) + (profile.bio.length > 40 ? '…' : '') : '');
  if (subtitle) {
    var subEl = document.createElement('div');
    subEl.className  = 'student-card-subtitle';
    subEl.textContent = subtitle;
    nameCol.appendChild(subEl);
  }

  /* Chevron */
  var chevron = document.createElement('span');
  chevron.className = 'student-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  /* ── Edit-Button → my-students.html?uid=... ── */
  var editBtn = document.createElement('a');
  editBtn.className = 'student-card-edit-btn';
  editBtn.title     = 'Preis bearbeiten';
  editBtn.href      = './my-students.html?uid=' + encodeURIComponent(currentUser.uid);
  editBtn.innerHTML = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="M11 2l3 3-9 9H2v-3L11 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  editBtn.addEventListener('click', function(e) { e.stopPropagation(); });

  cardTop.appendChild(avatarWrap);
  cardTop.appendChild(nameCol);
  cardTop.appendChild(editBtn);
  cardTop.appendChild(chevron);

  /* ── Booking summary line ── */
  var summaryEl = document.createElement('div');
  summaryEl.className = 'student-card-summary';
  summaryEl.textContent = counts.all + ' Buchung' + (counts.all !== 1 ? 'en' : '') +
    (counts.totalAll > 0 ? ' · ' + _fmtForUser(counts.totalAll, currentUser ? currentUser.uid : null) : '');

  /* ── Badge row ── */
  var badgeRow = document.createElement('div');
  badgeRow.className = 'student-card-badges';

  var badgeDefs = [
    { label: 'Alle',         val: counts.all,         total: counts.totalAll,         cls: '' },
    { label: 'Unbest.',      val: counts.unconfirmed,  total: counts.totalUnconfirmed,  cls: 'student-card-badge--pending' },
    { label: 'Best. ✓', val: counts.confirmed,    total: counts.totalConfirmed,    cls: 'student-card-badge--confirmed' }
  ];
  badgeDefs.forEach(function(b) {
    if (b.val === 0) return;
    var chip = document.createElement('span');
    chip.className = 'student-card-badge ' + b.cls;
    var countSpan = document.createElement('span');
    countSpan.className = 'student-card-badge-count';
    countSpan.textContent = b.val;
    chip.appendChild(document.createTextNode(b.label + ' '));
    chip.appendChild(countSpan);
    if (b.total > 0) {
      var priceSpan = document.createElement('span');
      priceSpan.className = 'student-card-badge-price';
      priceSpan.textContent = ' ' + _fmtForUser(b.total, currentUser ? currentUser.uid : null);
      chip.appendChild(priceSpan);
    }
    badgeRow.appendChild(chip);
  });

  /* ── Detail panel (expandable) ── */
  var detail = document.createElement('div');
  detail.className = 'student-booking-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) populateStudentBookings(detail, student, bookedSlots);

  /* ── Assemble ── */
  wrapper.appendChild(cardTop);
  wrapper.appendChild(summaryEl);
  wrapper.appendChild(badgeRow);
  wrapper.appendChild(detail);

  /* ── Toggle expand ── */
  function toggle() {
    if (expandedStudents[student.uid]) {
      delete expandedStudents[student.uid];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedStudents[student.uid] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateStudentBookings(detail, student, bookedSlots);
    }
  }
  cardTop.addEventListener('click', toggle);
  cardTop.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  return wrapper;
}
/**
 * Merge consecutive booked slots (same date, consecutive times) into blocks.
 * Returns [{ date, start, end, slotIds[] }]
 */

function populateStudentBookings(detail, student, bookedSlots) {
  detail.innerHTML = '';

  if (!bookedSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted student-bookings-empty';
    empty.textContent = 'Noch keine Buchungen.';
    detail.appendChild(empty);
    return;
  }

  var today = fmtDate(new Date());

  /* Group by date */
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < bookedSlots.length; i++) {
    var d = bookedSlots[i].date;
    if (!byDate[d]) { byDate[d] = []; dateOrder.push(d); }
    byDate[d].push(bookedSlots[i]);
  }
  dateOrder.sort();
  if (!allBookingsSortAsc) { dateOrder.reverse(); }

  for (var di = 0; di < dateOrder.length; di++) {
    var dateStr = dateOrder[di];
    var isPast  = dateStr < today;

    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider student-date-divider'
      + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    detail.appendChild(divider);

    /* mergeAllBookingBlocks — selbe Logik wie All Bookings und Day Panel */
    var blocks = mergeAllBookingBlocks(dateStr, byDate[dateStr], today);
    for (var bi = 0; bi < blocks.length; bi++) {
      detail.appendChild(buildAllBookingBlock(blocks[bi], {
        showDate: false, isPast: isPast, simpleDetail: true
      }));
    }
  }
}

/* buildBookingBlockRow removed — now uses buildBookingBlock */

/* ══════════════════════════════════════════════════════════
   CALENDAR
══════════════════════════════════════════════════════════ */
function materialiseVisibleMonth(year, month) {
  // Find all Mondays in the visible calendar grid (can span prev/next month)
  var first    = new Date(year, month, 1);
  var startDow = first.getDay(); startDow = (startDow === 0) ? 6 : startDow - 1;
  // First Monday shown = first day of month minus startDow days
  var gridStart = new Date(year, month, 1 - startDow);
  // Calendar shows up to 6 weeks = 42 days
  var seen = {};
  for (var d = 0; d < 42; d++) {
    var day = new Date(gridStart);
    day.setDate(gridStart.getDate() + d);
    // Get Monday of this day's week
    var dow = day.getDay(); dow = (dow === 0) ? 6 : dow - 1;
    var mon = new Date(day); mon.setDate(day.getDate() - dow);
    var monKey = mon.getFullYear() + '-' + mon.getMonth() + '-' + mon.getDate();
    if (seen[monKey]) continue;
    seen[monKey] = true;
    var weekDates = [];
    for (var w = 0; w < 7; w++) {
      var wd = new Date(mon); wd.setDate(mon.getDate() + w);
      weekDates.push(wd);
    }
    AppService.materialiseWeek(currentUser.uid, weekDates, function(e){if(e)Toast.error(e.message||e);});
  }
}

function renderCalendar() {
  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;

  // Week view button — add once
  var calHeader = document.getElementById('cal-header-actions');
  if (calHeader && !document.getElementById('week-view-btn')) {
    var wvBtn = document.createElement('button');
    wvBtn.id = 'week-view-btn';
    wvBtn.className = 'btn btn-secondary btn-sm';
    wvBtn.textContent = 'Week view';
    wvBtn.addEventListener('click', openSlotGrid);
    calHeader.appendChild(wvBtn);
  }

  // Materialise recurring slots for every week visible this month
  materialiseVisibleMonth(viewYear, viewMonth);

  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeCell(prevDays - i, true));
  }

  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isToday = date.getTime() === TODAY.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots      = AppService.getSlotsByTeacherDateSync(currentUser.uid, dateStr);
      var hasAny     = slots.length > 0;
      var hasBook    = slots.some(function(s) { return s.status === 'booked'; });
      var hasTimeout = slots.some(function(s) { return s.status === 'timeout'; });

      var cell = makeCell(day, false, isToday, isSel, hasAny, hasBook, hasTimeout);
      cell.addEventListener('click', function() { openTeacherDayView(date); selectDate(date); });
      cell.setAttribute('tabindex', '0');
      cell.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') { openTeacherDayView(date); selectDate(date); }
      });
      grid.appendChild(cell);
    })(d);
  }

  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeCell(t, true));
  }

  updateStats();
}

function makeCell(num, otherMonth, isToday, isSelected, hasSlots, hasBooked, hasTimeout) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth)  el.classList.add('other-month');
  if (isToday)     el.classList.add('today');
  if (isSelected)  el.classList.add('selected');
  if (hasSlots)    el.classList.add('has-slots');
  if (hasBooked)   el.classList.add('has-booked');
  if (hasTimeout)  el.classList.add('has-timeout');
  el.textContent = num;
  return el;
}

function selectDate(date) {
  selectedDate = date;
  renderCalendar();
  renderDayPanel();
}

/* ══════════════════════════════════════════════════════════
   DAY PANEL
══════════════════════════════════════════════════════════ */

function renderDayPanel() {
  updateDayNavBar();
  var panel = document.getElementById('day-panel');
  panel.innerHTML = '';

  if (!selectedDate) {
    var hint = document.createElement('p');
    hint.className = 'text-muted day-panel-empty';
    hint.textContent = 'Select a day.';
    panel.appendChild(hint);
    return;
  }

  var dateStr = fmtDate(selectedDate);

  // Materialise recurring for the week of selected date
  var selMonday = new Date(selectedDate);
  var selDow = selMonday.getDay(); selDow = (selDow === 0) ? 6 : selDow - 1;
  selMonday.setDate(selMonday.getDate() - selDow);
  var selWeekDates = [];
  for (var wi = 0; wi < 7; wi++) { var wd = new Date(selMonday); wd.setDate(wd.getDate() + wi); selWeekDates.push(wd); }
  AppService.materialiseWeek(currentUser.uid, selWeekDates, function(e){if(e)Toast.error(e.message||e);});

  var slots   = AppService.getSlotsByTeacherDateSync(currentUser.uid, dateStr);

  /* Date label removed — already shown in the sticky day-nav-bar above */
  if (activeDayTab === 'availability' || activeDayTab === 'availability2' || activeDayTab === 'availability3') {
    /* Render all 24h slots inline using same _tdvBuildRow logic as Day View */
    var isPastDay = dateStr < fmtDate(new Date());

    /* ── Fix 1: Build allTimes starting from local midnight (UTC-ordered by local) ──
       Without TZ: always 00:00–23:30 UTC (unchanged behaviour)
       With TZ: grid starts at UTC time = local 00:00, wraps 24h */
    var allTimes = [];
    var _gridOffsetMin = 0; /* how many minutes local midnight is ahead of UTC midnight */
    if (typeof TimezoneService !== 'undefined' && currentUser) {
      var _teacherTZ = TimezoneService.getUserTimezone(currentUser.uid);
      _gridOffsetMin = TimezoneService.getOffsetMinutes(_teacherTZ, dateStr);
    }
    /* UTC minutes of local 00:00 = (0 - offset + 1440) % 1440 */
    var _localMidnightUtc = ((-_gridOffsetMin) % 1440 + 1440) % 1440;
    for (var gi = 0; gi < 48; gi++) {
      var _utcMin = (_localMidnightUtc + gi * 30) % 1440;
      var _gh = Math.floor(_utcMin / 60);
      var _gm = _utcMin % 60;
      allTimes.push((_gh < 10 ? '0' : '') + _gh + ':' + (_gm < 10 ? '0' : '') + _gm);
    }

    var slotMap = {};
    for (var si2 = 0; si2 < slots.length; si2++) { slotMap[slots[si2].time] = slots[si2]; }

    /* ── Fix 2: Section labels compare against LOCAL time ── */
    var sections = [
      { label: 'Nacht',      from: '00:00', to: '05:30' },
      { label: 'Morgen',     from: '06:00', to: '09:30' },
      { label: 'Vormittag',  from: '10:00', to: '11:30' },
      { label: 'Mittag',     from: '12:00', to: '13:30' },
      { label: 'Nachmittag', from: '14:00', to: '17:30' },
      { label: 'Abend',      from: '18:00', to: '21:30' },
      { label: 'Nacht',      from: '22:00', to: '23:30' }
    ];
    var sectionRendered = {};
    var sIdx = 0;
    var frag2 = document.createDocumentFragment();

    for (var ti2 = 0; ti2 < allTimes.length; ti2++) {
      var t2 = allTimes[ti2];
      /* Compare section boundaries against LOCAL display time, not UTC */
      var _t2local = _tTeacherTime(t2, dateStr);
      for (var sc2 = sIdx; sc2 < sections.length; sc2++) {
        if (_t2local >= sections[sc2].from && _t2local <= sections[sc2].to && !sectionRendered[sc2]) {
          var lbl2 = document.createElement('div');
          lbl2.className = 'dv-section-label';
          lbl2.textContent = sections[sc2].label;
          frag2.appendChild(lbl2);
          sectionRendered[sc2] = true;
          sIdx = sc2;
          break;
        }
      }
      var _rowBuilder = (activeDayTab === 'availability')  ? _tdvBuildRowV1
                       : (activeDayTab === 'availability2') ? _tdvBuildRowV2
                       : _tdvBuildRow; /* availability3 = exact original */
      var _builtRow = _rowBuilder(slotMap[t2] || null, t2, dateStr, isPastDay);
      if (_builtRow) frag2.appendChild(_builtRow);
    }
    panel.appendChild(frag2);

  } else {
    if (!slots.length) {
      var emptyMsg = document.createElement('p');
      emptyMsg.className = 'text-muted day-panel-empty';
      emptyMsg.textContent = 'Keine Slots für diesen Tag.';
      panel.appendChild(emptyMsg);
      return;
    }
    renderBookingsPanel(panel, slots, dateStr);
  }
}

/* ── Tab 1: Verfügbarkeit ───────────────────────────────── */
/* ── Availability panel with Add-Slots toggle (replaces old header logic) ── */

function renderAvailabilityPanel(panel, slots) {
  for (var i = 0; i < slots.length; i++) {
    panel.appendChild(buildAvailabilityCard(slots[i]));
  }
}

function buildAvailabilityCard(slot) {
  /* Delegate to _tdvBuildRow — same logic, same CSS, same sync */
  var dateStr   = fmtDate(selectedDate);
  var isPastDay = dateStr < fmtDate(new Date());
  return _tdvBuildRow(slot, slot.time, dateStr, isPastDay);
}

/* ── Tab 2: Buchungen ───────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   BOOKINGS PANEL (Tab 2)
══════════════════════════════════════════════════════════ */

// Currently open booking form slot id
var openBookFormSlotId = null;

function renderBookingsPanel(panel, slots, dateStr) {
  var today  = fmtDate(new Date());
  var isPast = dateStr < today;

  panel.innerHTML = '';

  /* ── Filter bar (student picker, time, sort, confirm) ── */
  var filterWrap = document.createElement('div');
  filterWrap.className = 'day-bookings-filters';

  var myStudents = AppService.getSelectionsByTeacherSync(currentUser.uid)
    .map(function(sel) { return AppService.getUserSync(sel.studentId); }).filter(Boolean);
  if (myStudents.length > 1) {
    filterWrap.appendChild(_buildStudentFilterRow(function() { renderDayPanel(); }));
  }

  /* ── Search field below student dropdown — mockup-renderStudentList-studentFilter-2026-03-24_11-21 ── */
  var dayBkSearchWrap = document.createElement('div');
  dayBkSearchWrap.innerHTML = buildSearchInput('day-bk-search', 'Schüler suchen…');
  filterWrap.appendChild(dayBkSearchWrap.firstChild);

  var onDayRerender = function() {
    renderDayPanel();
    if (activeTeacherView === 'students') renderStudentList();
    if (activeTeacherView === 'all-bookings') renderAllBookings();
  };

  filterWrap.appendChild(_buildTimeFilterRow(function() { onDayRerender(); }));
  filterWrap.appendChild(_buildSortDateRangeRow(function() { onDayRerender(); }));

  /* Confirm filter with per-day counts */
  var allSlotsFull = AppService.getSlotsByTeacherDateSync(currentUser.uid, dateStr)
    .filter(function(s) { return s.status === 'booked' && s.studentId; });
  if (bookingsFilter.student !== 'all') {
    allSlotsFull = allSlotsFull.filter(function(s) { return s.studentId === bookingsFilter.student; });
  }
  allSlotsFull = _applyTimeFilter(allSlotsFull, bookingsFilter.time, today);
  var allBlocks    = mergeAllBookingBlocks(dateStr, allSlotsFull, today);
  var unconfBlocks = mergeAllBookingBlocks(dateStr, _applyConfirmFilter(allSlotsFull, 'unconfirmed'), today);
  var confBlocks   = mergeAllBookingBlocks(dateStr, _applyConfirmFilter(allSlotsFull, 'confirmed'),   today);
  filterWrap.appendChild(_buildConfirmFilterRow({
    counts: { all: allBlocks.length, unconfirmed: unconfBlocks.length, confirmed: confBlocks.length,
              totalAll: 0, totalUnconfirmed: 0, totalConfirmed: 0 },
    onFilter: function() { onDayRerender(); }
  }));
  panel.appendChild(filterWrap);

  /* Wire search to filter booking blocks by student name */
  wireSearchInput('day-bk-search', function(query) {
    var q = (query || '').trim().toLowerCase();
    var blocks = panel.querySelectorAll('.all-booking-block-wrapper');
    for (var _bi = 0; _bi < blocks.length; _bi++) {
      if (blocks[_bi].classList.contains('all-booking-free-wrap')) continue;
      var nameEl = blocks[_bi].querySelector('.all-booking-student-name, .all-booking-block-student');
      var name = nameEl ? nameEl.textContent.toLowerCase() : '';
      blocks[_bi].classList.toggle('is-hidden', !!q && name.indexOf(q) === -1);
    }
  });

  /* ── Free slots section (only on future days, teacher-specific) ── */
  if (!isPast) {
    var freeWrapper = document.createElement('div');
    freeWrapper.className = 'all-booking-block-wrapper';
    var freeHeader = document.createElement('div');
    freeHeader.className = 'all-booking-block-header';
    var freeLabel = document.createElement('span');
    freeLabel.className = 'all-booking-block-time';
    var freeCount = slots.filter(function(s) { return !s.studentId; }).length;
    freeLabel.textContent = freeCount + ' freie Slot' + (freeCount !== 1 ? 's' : '');
    var freeChevron = document.createElement('span');
    freeChevron.className = 'all-booking-chevron';
    freeChevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    freeHeader.appendChild(freeLabel);
    freeHeader.appendChild(freeChevron);
    var freeDetail = document.createElement('div');
    freeDetail.className = 'all-booking-block-detail';
    freeDetail.classList.add('free-detail-padded');
    if (_freeSlotsBlockOpen) {
      freeDetail.classList.add('is-open');
      freeChevron.classList.add('is-open');
    }
    populateAllBookingDetail(freeDetail, {
      student: null, dateStr: dateStr, today: today, isFullyConfirmed: false
    }, renderDayPanel, { onDismissAll: discardBookingChanges });
    freeDetail.querySelectorAll('.btn-primary').forEach(function(btn) {
      var rowEl = btn.closest('.all-booking-slot-row');
      if (!rowEl) return;
      var timeEl = rowEl.querySelector('.all-booking-slot-time');
      if (!timeEl) return;
      var time = timeEl.textContent.split('–')[0].trim();
      var rawSlot = slots.filter(function(s) { return s.time === time && !s.studentId; })[0];
      if (!rawSlot) return;
      btn.onclick = function(e) { e.stopPropagation(); buildBookingForm(rawSlot, dateStr, slots); };
    });
    freeHeader.setAttribute('tabindex', '0');
    (function(hdr, det, chv) {
      function toggle() {
        var open = det.classList.contains('is-open');
        det.classList.toggle('is-open', !open);
        chv.classList.toggle('is-open', !open);
        _freeSlotsBlockOpen = !open;
      }
      hdr.addEventListener('click', toggle);
      hdr.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });
    })(freeHeader, freeDetail, freeChevron);
    freeWrapper.appendChild(freeHeader);
    freeWrapper.appendChild(freeDetail);
    panel.appendChild(freeWrapper);
  }

  /* ── Booked blocks — delegate to renderAllBookingsList with date scope ── */
  var bookingsContainer = document.createElement('div');
  panel.appendChild(bookingsContainer);
  renderAllBookingsList({ container: bookingsContainer, dateFilter: dateStr });
}


function buildBookingForm(startSlot, dateStr, allSlots) {
  /* Opens as a proper Modal instead of inline expansion */
  var selections = AppService.getSelectionsByTeacherSync(currentUser.uid);
  var students   = selections.map(function(s) { return AppService.getUserSync(s.studentId); }).filter(Boolean);

  if (!students.length) {
    Modal.show({
      title: 'Buchung erstellen',
      bodyHTML: '<p class="move-dialog-info">Keine Schüler zugewiesen.</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Schließen</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', function() {
      openBookFormSlotId = null; renderDayPanel();
    });
    return null;
  }

  /* Build student checkboxes — already-booked greyed with badge (mockup-buildBookingForm-2026-03-23_20-03) */
  var alreadyBooked = {};
  if (startSlot && startSlot.students && startSlot.students.length) {
    for (var ab = 0; ab < startSlot.students.length; ab++) {
      alreadyBooked[startSlot.students[ab]] = true;
    }
  } else if (startSlot && startSlot.studentId) {
    alreadyBooked[startSlot.studentId] = true;
  }

  var bookedHTML    = '';
  var availableHTML = '';
  var hasBooked     = false;

  for (var i = 0; i < students.length; i++) {
    var uid2 = students[i].uid;
    var name = AppService.getDisplayNameSync(uid2);
    if (alreadyBooked[uid2]) {
      hasBooked = true;
      bookedHTML +=
        '<label class="booking-form-check-row booking-form-check-row--booked">' +
        '<input type="checkbox" class="booking-form-checkbox" disabled checked>' +
        '<span>' + _esc(name) + '</span>' +
        '<span class="booking-form-already-badge">✓ Bereits gebucht</span>' +
        '</label>';
    } else {
      availableHTML +=
        '<label class="booking-form-check-row">' +
        '<input type="checkbox" class="booking-form-checkbox bk-modal-stu-cb" value="' + _esc(uid2) + '" checked>' +
        '<span>' + _esc(name) + '</span>' +
        '</label>';
    }
  }

  var dividerHTML = (hasBooked && availableHTML)
    ? '<div class="booking-form-divider">' +
      '<div class="booking-form-divider-line"></div>' +
      '<span class="booking-form-divider-label">Hinzufügen</span>' +
      '<div class="booking-form-divider-line"></div>' +
      '</div>'
    : '';

  var stuHTML = bookedHTML + dividerHTML + availableHTML;

  var bodyHTML =
    '<div class="move-dialog">' +
      '<div class="booking-form-label">Schüler</div>' +
      buildSearchInput('bk-stu-search', 'Schüler suchen…') +
      '<div class="booking-form-students" id="bk-stu-list">' + stuHTML + '</div>' +
      '<div class="search-empty is-hidden" id="bk-stu-empty">Kein Schüler gefunden.</div>' +
      '<div class="booking-form-time-row">' +
        '<div class="booking-form-time-col">' +
          '<div class="booking-form-label">Von</div>' +
          '<div class="custom-dropdown" id="bk-from-dd" style="min-width:0;width:100%">' +
            '<button type="button" class="custom-dropdown-trigger" id="bk-from-trigger">' +
              '<span class="custom-dropdown-label" id="bk-from-label"></span>' +
              '<svg class="custom-dropdown-chevron" width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '</button>' +
            '<ul class="custom-dropdown-list" id="bk-from-list" role="listbox"></ul>' +
          '</div>' +
        '</div>' +
        '<div class="booking-form-time-col">' +
          '<div class="booking-form-label">Bis</div>' +
          '<div class="custom-dropdown" id="bk-until-dd" style="min-width:0;width:100%">' +
            '<button type="button" class="custom-dropdown-trigger" id="bk-until-trigger">' +
              '<span class="custom-dropdown-label" id="bk-until-label"></span>' +
              '<svg class="custom-dropdown-chevron" width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '</button>' +
            '<ul class="custom-dropdown-list" id="bk-until-list" role="listbox"></ul>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>' +
    '<div id="bk-check-result" class="bk-check-result is-hidden"></div>';

  var result = Modal.show({
    title: 'Buchung erstellen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>'
              + '<button class="btn btn-secondary" id="modal-check">Prüfen</button>'
              + '<button class="btn btn-primary is-hidden" id="modal-confirm">Buchen</button>'
  });

  /* ── Search wiring — filters student checkboxes live ── */
  wireSearchInput('bk-stu-search', function(query) {
    var stuList  = document.getElementById('bk-stu-list');
    var emptyMsg = document.getElementById('bk-stu-empty');
    if (!stuList) return;
    var rows = stuList.querySelectorAll('.booking-form-check-row');
    var q    = (query || '').trim().toLowerCase();
    var visible = 0;
    for (var ri = 0; ri < rows.length; ri++) {
      var rowEl   = rows[ri];
      /* Skip dividers — they have no checkbox */
      if (rowEl.className.indexOf('booking-form-divider') !== -1) continue;
      var nameEl  = rowEl.querySelector('span');
      var label   = nameEl ? nameEl.textContent.toLowerCase() : '';
      var matches = !q || label.indexOf(q) !== -1;
      rowEl.classList.toggle('is-hidden', !matches);
      if (matches) visible++;
    }
    /* Also hide/show divider when searching */
    var divider = stuList.querySelector('.booking-form-divider');
    if (divider) divider.classList.toggle('is-hidden', !!q);
    /* Empty state */
    if (emptyMsg) emptyMsg.classList.toggle('is-hidden', visible > 0);
  });

  /* ── Custom dropdown wiring ── */
  /* Include slots that are available/recurring OR already pending-book in this session.
     Pending-book slots should not break the chain — teacher is still choosing the range. */
  var allUnbooked = allSlots.filter(function(s) {
    var eff = getEffectiveTeacherSlot(s);
    if (eff.status === 'available' || eff.status === 'recurring') return true;
    /* Also include slots pending 'book' — they're staged but chain shouldn't break */
    if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'book') return true;
    return false;
  });

  var fromValue  = startSlot.time;
  var untilValue = '';

  var fromTrigger = document.getElementById('bk-from-trigger');
  var fromLabel   = document.getElementById('bk-from-label');
  var fromList    = document.getElementById('bk-from-list');
  var untilTrigger = document.getElementById('bk-until-trigger');
  var untilLabel   = document.getElementById('bk-until-label');
  var untilList    = document.getElementById('bk-until-list');

  /* Build a time→slot lookup for quick availability check */
  function _buildTimeMap() {
    var m = {};
    for (var xi = 0; xi < allUnbooked.length; xi++) m[allUnbooked[xi].time] = allUnbooked[xi];
    return m;
  }

  function buildUntilOptions() {
    untilList.innerHTML = '';
    untilValue = '';
    var timeMap = _buildTimeMap();
    if (!timeMap[fromValue]) { untilLabel.textContent = '—'; return; }
    /* Walk forward in 30-min steps — stop when next slot is not available */
    var cur = fromValue;
    var opts = [];
    while (timeMap[cur]) {
      var endTime = AppService.slotEndTime(cur);
      opts.push({ val: cur, label: endTime });
      cur = endTime; /* next 30-min slot */
    }
    untilValue = opts[0].val;
    untilLabel.textContent = _tTeacherTime(opts[0].label, dateStr);
    for (var oi = 0; oi < opts.length; oi++) {
      (function(o, first) {
        var li = document.createElement('li');
        li.className = 'custom-dropdown-item' + (first ? ' is-active' : '');
        li.setAttribute('role', 'option');
        li.textContent = _tTeacherTime(o.label, dateStr);
        li.addEventListener('click', function(e) {
          e.stopPropagation();
          untilValue = o.val; /* keep UTC value for slot range */
          untilLabel.textContent = _tTeacherTime(o.label, dateStr);
          untilList.querySelectorAll('.custom-dropdown-item').forEach(function(el) { el.classList.remove('is-active'); });
          li.classList.add('is-active');
          untilList.classList.remove('is-open');
          untilTrigger.classList.remove('is-open');
        });
        untilList.appendChild(li);
      })(opts[oi], oi === 0);
    }
  }

  /* Ensure fromValue is in allUnbooked — timeout/disabled slots can be clicked
     but shouldn't be the start of a booking range. Fall back to first available. */
  var _timeMapCheck = _buildTimeMap();
  if (!_timeMapCheck[fromValue] && allUnbooked.length > 0) {
    fromValue = allUnbooked[0].time;
  }

  /* Build From options */
  fromLabel.textContent = _tTeacherTime(fromValue, dateStr);
  for (var f = 0; f < allUnbooked.length; f++) {
    (function(slot) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (slot.time === fromValue ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.textContent = _tTeacherTime(slot.time, dateStr);
      li.addEventListener('click', function(e) {
        e.stopPropagation();
        fromValue = slot.time; /* keep UTC value for slot lookup */
        fromLabel.textContent = _tTeacherTime(slot.time, dateStr);
        fromList.querySelectorAll('.custom-dropdown-item').forEach(function(el) { el.classList.remove('is-active'); });
        li.classList.add('is-active');
        fromList.classList.remove('is-open');
        fromTrigger.classList.remove('is-open');
        buildUntilOptions();
      });
      fromList.appendChild(li);
    })(allUnbooked[f]);
  }

  buildUntilOptions();

  /* Toggle handlers */
  fromTrigger.addEventListener('click', function(e) {
    e.stopPropagation();
    var open = fromList.classList.contains('is-open');
    fromList.classList.toggle('is-open', !open);
    fromTrigger.classList.toggle('is-open', !open);
  });
  untilTrigger.addEventListener('click', function(e) {
    e.stopPropagation();
    var open = untilList.classList.contains('is-open');
    untilList.classList.toggle('is-open', !open);
    untilTrigger.classList.toggle('is-open', !open);
  });

  document.getElementById('modal-cancel').addEventListener('click', function() {
    /* Remove staging for the slot that was being edited */
    if (startSlot && startSlot.slotId && pendingBookings[startSlot.slotId]) {
      delete pendingBookings[startSlot.slotId];
    }
    openBookFormSlotId = null;
    updateBookingSaveBtn();
    renderDayPanel();
    renderCalendar();
    renderStudentList();
    if (activeTeacherView === 'all-bookings') renderAllBookings();
    result.close();
  });

  /* ── Prüfen button — affordability check ── */
  document.getElementById('modal-check').addEventListener('click', function() {
    var checkedBoxes = document.querySelectorAll('.bk-modal-stu-cb:checked');
    var selectedUids = [];
    for (var k = 0; k < checkedBoxes.length; k++) { selectedUids.push(checkedBoxes[k].value); }
    if (!selectedUids.length) { Toast.error('Bitte mindestens einen Schüler auswählen.'); return; }
    if (!untilValue) { Toast.error('Bitte eine Endzeit wählen.'); return; }

    var checkBtn   = document.getElementById('modal-check');
    var confirmBtn = document.getElementById('modal-confirm');
    var resultDiv  = document.getElementById('bk-check-result');

    /* Count slots in range */
    var rangeSlots = allSlots.filter(function(s) {
      return s.time >= fromValue && s.time <= untilValue && !s.studentId;
    });
    var slotCount  = rangeSlots.length;
    var teacherUid = rangeSlots.length ? rangeSlots[0].teacherId : currentUser.uid;

    /* Disable check button while loading */
    checkBtn.disabled = true;
    checkBtn.textContent = '...';

    /* Bug #1 fix: check affordability for ALL selected students.
       Each student may have an individual price — compute deposit per student. */
    var fmtAmt = (typeof _fmtForUser === 'function') ? _fmtForUser : function(a) { return '\u20ac' + parseFloat(a).toFixed(2).replace('.', ','); };
    var allCanProceed = true;
    var lines = '';
    var remaining = selectedUids.length;

    function _onAllChecked() {
      if (allCanProceed) {
        resultDiv.className = 'bk-check-result bk-check-result-ok';
        confirmBtn.classList.remove('is-hidden');
        checkBtn.classList.add('is-hidden');
      } else {
        resultDiv.className = 'bk-check-result bk-check-result-warn';
        confirmBtn.classList.add('is-hidden');
      }
      resultDiv.innerHTML = lines;
      checkBtn.disabled = false;
      checkBtn.textContent = 'Prüfen';
    }

    if (!selectedUids.length) {
      checkBtn.disabled = false;
      checkBtn.textContent = 'Prüfen';
      return;
    }

    for (var si = 0; si < selectedUids.length; si++) {
      (function(uid2, idx) {
        var stuPrice  = AppService.getStudentPriceForTeacherSync(uid2, teacherUid);
        var stuTotal  = Math.round(stuPrice * slotCount * 100) / 100;
        AppService.calcDepositInfo(teacherUid, stuTotal, function(err, dep) {
          if (err) {
            resultDiv.className = 'bk-check-result bk-check-error';
            resultDiv.innerHTML = 'Fehler: ' + (err.message || err);
            checkBtn.disabled = false;
            checkBtn.textContent = 'Prüfen';
            return;
          }
          var wallet2  = AppService.getWalletSync(uid2);
          var bal2     = wallet2 ? (parseFloat(wallet2.balance) || 0) : 0;
          var name2    = AppService.getDisplayNameSync(uid2);
          var payMode  = dep.paymentMode || 'instant';
          var reqDep   = dep.requiresDeposit !== false;
          var depAmt   = dep.depositAmount || 0;
          var rowLines = '<div class=\"bk-check-row\" style=\"margin-top:' + (idx > 0 ? '6px' : '0') + ';border-top:' + (idx > 0 ? '1px solid var(--neutral-100)' : 'none') + '\">' +
            '<span>' + _esc(name2) + '</span><strong>' + fmtAmt(bal2) + '</strong></div>';
          rowLines += '<div class=\"bk-check-row\"><span>Slots</span><strong>' + slotCount + ' \u00d7 ' + fmtAmt(stuPrice) + ' = ' + fmtAmt(stuTotal) + '</strong></div>';
          if (payMode === 'cash_on_site') {
            rowLines += '<div class=\"bk-check-ok\">\u2713 Zahlung bar vor Ort \u2014 kein Guthaben ben\u00f6tigt.</div>';
          } else if (!reqDep) {
            rowLines += '<div class=\"bk-check-ok\">\u2713 Kein Deposit erforderlich.</div>';
          } else {
            var depLabel2 = dep.depositType === 'percent'
              ? fmtAmt(depAmt) + ' (' + dep.depositPercent + '%)'
              : fmtAmt(depAmt);
            if (bal2 >= depAmt) {
              rowLines += '<div class=\"bk-check-ok\">\u2713 Deposit ' + depLabel2 + ' gedeckt.</div>';
            } else {
              var miss2 = Math.round((depAmt - bal2) * 100) / 100;
              rowLines += '<div class=\"bk-check-warn\">\u2717 ' + _esc(name2) + ': fehlt ' + fmtAmt(miss2) + ' f\u00fcr Deposit.</div>';
              allCanProceed = false;
            }
          }
          lines += rowLines;
          remaining--;
          if (remaining === 0) _onAllChecked();
        });
      })(selectedUids[si], si);
    }
  });

  document.getElementById('modal-confirm').addEventListener('click', function() {
    var checkedBoxes = document.querySelectorAll('.bk-modal-stu-cb:checked');
    var selectedUids = [];
    for (var k = 0; k < checkedBoxes.length; k++) { selectedUids.push(checkedBoxes[k].value); }
    if (!selectedUids.length) { Toast.error('Bitte mindestens einen Schüler auswählen.'); return; }
    var fromSlot = allSlots.filter(function(s) { return s.time === fromValue; })[0] || startSlot;
    openBookFormSlotId = null;
    result.close();
    executeBooking(fromSlot, untilValue, selectedUids, dateStr, allSlots);
  });

  return null;
}

function executeBooking(startSlot, untilTime, studentUids, dateStr, allSlots) {
  // Get all slots from start up to and including untilTime
  // Use effective state (pending overrides) for conflict detection
  var range = allSlots.filter(function(s) {
    return s.time >= startSlot.time && s.time <= untilTime;
  }).map(function(s) { return getEffectiveTeacherSlot(s); });

  // Check for conflicts (already booked by someone else)
  var conflicts = range.filter(function(s) {
    return s.studentId && studentUids.indexOf(s.studentId) === -1;
  });

  if (conflicts.length) {
    var conflictNames = conflicts.map(function(s) {
      var stu = AppService.getUserSync(s.studentId);
      return s.time + ' (booked by ' + AppService.getDisplayNameSync(s.studentId) + ')';
    }).join(', ');

    var result = Modal.show({
      title: 'Booking conflict',
      bodyHTML: '<p>The following slots are already booked:</p><p><strong>' + conflictNames + '</strong></p><p>Overwrite these bookings?</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Cancel</button><button class="btn btn-danger" id="modal-confirm">Overwrite</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      commitBooking(range, studentUids);
      result.close();
    });
  } else {
    commitBooking(range, studentUids);
  }
}

function commitBooking(slots, studentUids) {
  /* Stage then immediately save — no manual Save step needed for direct bookings */
  for (var i = 0; i < slots.length; i++) {
    var slot = slots[i];
    var original = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === slot.slotId; })[0];
    pendingBookings[slot.slotId] = {
      action:        'book',
      originalSlot:  original,
      newStudentId:  studentUids[0],
      students:      studentUids,
      extraStudents: studentUids.slice(1)
    };
  }
  openBookFormSlotId = null;
  /* Immediately save — Buchen button is the final confirmation */
  saveBookingChanges();
}

function updateBookingSaveBtn() {
  var group = document.getElementById('booking-fab-group');
  if (!group) return;
  var keys = Object.keys(pendingBookings);
  var count = keys.length;
  var totalBookings = 0;
  for (var bi = 0; bi < keys.length; bi++) {
    var pb = pendingBookings[keys[bi]];
    if (pb && pb.action === 'book') {
      totalBookings += (pb.students ? pb.students.length : 1);
    } else {
      totalBookings += 1;
    }
  }
  group.classList.toggle('is-visible', count > 0);
  var badge = group.querySelector('.save-badge');
  if (badge) badge.textContent = totalBookings > count ? totalBookings : count;
}

function discardBookingChanges() {
  pendingBookings = {};
  openBookFormSlotId = null;
  updateBookingSaveBtn();
  renderDayPanel();
  renderCalendar();
  renderStudentList();
  if (activeTeacherView === 'all-bookings') renderAllBookings();
  Toast.info('Changes dismissed.');
}

function saveBookingChanges() {
  /* Guard: disable FAB immediately to prevent double-save on rapid clicks */
  var _saveBtn = document.getElementById('booking-save-btn');
  if (_saveBtn) _saveBtn.disabled = true;

  var ids          = Object.keys(pendingBookings);
  var savedChanges = {};

  /* ── Callback barrier ───────────────────────────────────────────
     pending counts every async op (book + extra-student creates + cancels).
     onAllDone() fires exactly once, does a single authoritative re-render.
  ──────────────────────────────────────────────────────────────── */
  var pending = 0;
  var errors  = [];

  function onAllDone() {
    /* Detect move pairs: a cancel + book for the same student = reschedule */
    var cancelMap = {};
    var bookMap   = {};
    var cids = Object.keys(savedChanges);
    for (var mi = 0; mi < cids.length; mi++) {
      var mp = savedChanges[cids[mi]];
      var mstu = mp.originalSlot ? (mp.action === 'book' ? mp.newStudentId : mp.originalSlot.studentId) : null;
      if (!mstu) continue;
      if (mp.action === 'cancel') cancelMap[mstu] = mp.originalSlot;
      else if (mp.action === 'book') bookMap[mstu] = mp.originalSlot;
    }
    Object.keys(cancelMap).forEach(function(stuId) {
      if (bookMap[stuId]) {
        var moveOpts = (pendingMoveOpts && pendingMoveOpts[stuId]) ? pendingMoveOpts[stuId] : {};
        var oldSlot  = cancelMap[stuId];
        var newSlot  = bookMap[stuId];
        AppService.writeMoveRecord(oldSlot, newSlot, currentUser.uid, 'teacher', function(err, result) {
          if (err) return;
          /* Notifications now fired by AppService.writeMoveRecord */
        }, moveOpts);
      }
    });

    /* Write ONE block booking TX per (student, teacher, date) group */
    var blockGroups = {};
    var cids2 = Object.keys(savedChanges);
    for (var bi = 0; bi < cids2.length; bi++) {
      var bp = savedChanges[cids2[bi]];
      if (bp.action !== 'book') continue;
      var bSlot = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === cids2[bi]; })[0];
      if (!bSlot) continue;
      var bKey = (bp.newStudentId || '') + '_' + (bSlot.teacherId || '') + '_' + (bSlot.date || '');
      if (!blockGroups[bKey]) blockGroups[bKey] = { slots: [], escrows: [], stuId: bp.newStudentId, tid: bSlot.teacherId };
      blockGroups[bKey].slots.push(bSlot);
    }
    Object.keys(blockGroups).forEach(function(gKey) {
      var g = blockGroups[gKey];
      if (!g.slots.length) return;
      /* Sort slots by time so block description is correct */
      g.slots.sort(function(a, b) { return (a.time || '').localeCompare(b.time || ''); });
      /* Gather escrows for these slots */
      AppService.getEscrowsByStudent(g.stuId, function(err, allEsc) {
        if (!err && allEsc) {
          g.slots.forEach(function(sl) {
            for (var ei = 0; ei < allEsc.length; ei++) {
              if (allEsc[ei].slotId === sl.slotId) { g.escrows.push(allEsc[ei]); break; }
            }
          });
        }
        AppService.writeBlockBookingRecord(g.slots, g.escrows, 'teacher', function() {});
        AppService.writeBlockEscrowHold(g.slots, g.escrows, function() {});
      });
    });

    pendingBookings = {};
    updateBookingSaveBtn();
    if (_saveBtn) _saveBtn.disabled = false;
    renderDayPanel();
    renderCalendar();
    renderStudentList();
    renderAllBookingsList();
    if (typeof WalletPanel !== 'undefined') WalletPanel.refresh(currentUser.uid);
    if (errors.length) {
      Toast.error(errors[0]);
    } else {
      Toast.success('Bookings saved.');
    }
  }

  /* Count total async ops first so barrier is correct */
  for (var ci = 0; ci < ids.length; ci++) {
    var cp = pendingBookings[ids[ci]];
    pending++;  /* one per slot (primary student + extras handled within) */
  }

  if (!pending) { onAllDone(); return; }

  for (var i = 0; i < ids.length; i++) {
    var p = pendingBookings[ids[i]];
    savedChanges[ids[i]] = p;
    if (p.action === 'book') {
      (function(sid, stuId, tid, extras, allStudents) {
        /* Book primary student on original slot */
        AppService.bookSlotWithEscrowSilent(sid, stuId, tid, function(e) {
          if (e) errors.push(e.message || e);
          /* Update slot.students[] to include all students — single slot record */
          if (allStudents && allStudents.length > 1) {
            AppService.updateSlot(sid, { students: allStudents }, function() {});
          }
          /* Book escrow for each extra student on the SAME slot */
          if (extras && extras.length) {
            for (var j2 = 0; j2 < extras.length; j2++) {
              (function(extraStu2) {
                AppService.createEscrowForStudent(sid, extraStu2, tid, function(escErr) {
                  if (escErr) errors.push(escErr.message || escErr);
                  if (--pending === 0) onAllDone();
                });
              })(extras[j2]);
            }
          } else {
            if (--pending === 0) onAllDone();
          }
        }, 'teacher');
      })(ids[i], p.newStudentId, p.originalSlot.teacherId, p.extraStudents || [], p.students || [p.newStudentId]);
    } else {
      (function(sid) {
        AppService.cancelSlotWithPolicy(sid, 'teacher', function(e) {
          if (e) errors.push(e.message || e);
          if (--pending === 0) onAllDone();
        });
      })(ids[i]);
    }
  }

  /* Email + Chat notifications — group booked slots by (student, date) for ONE block message */
  var emailIds  = Object.keys(savedChanges || {});
  var bookGroups = {}; /* key: stuId_date → { stu, dateLabel, slots[] } */
  for (var ei = 0; ei < emailIds.length; ei++) {
    var ep    = savedChanges[emailIds[ei]];
    var es    = ep.originalSlot;
    var stu   = AppService.getUserSync(ep.action === 'book' ? ep.newStudentId : es.studentId);
    if (!stu) continue;
    var dateObj   = new Date(es.date + 'T00:00:00');
    var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    var endTime   = AppService.slotEndTime(es.time);
    if (ep.action === 'book') {
      /* EmailService.onBookingCreated now fired by AppService.bookSlotWithEscrowSilent */
      /* Collect for block chat message */
      var gKey = stu.uid + '_' + es.date;
      if (!bookGroups[gKey]) bookGroups[gKey] = { stu: stu, dateLabel: dateLabel, slots: [] };
      bookGroups[gKey].slots.push({ slotId: es.slotId, time: es.time, endTime: endTime, date: es.date });
    } else {
      /* EmailService.onBookingCancelled now fired by AppService.cancelSlotWithPolicy */
    }
  }

  /* Send ONE structured booking_notification per student (all dates batched) */
  if (typeof ChatStore !== 'undefined') {
    /* Re-group by student only (drop the date from the key) */
    var notifByStu = {}; /* stuId → { stu, slotsByDate{} } */
    Object.keys(bookGroups).forEach(function(gKey) {
      var g    = bookGroups[gKey];
      var sUid = g.stu.uid;
      if (!notifByStu[sUid]) notifByStu[sUid] = { stu: g.stu, slotsByDate: {} };
      g.slots.forEach(function(sl) {
        var dKey = sl.date;
        if (!notifByStu[sUid].slotsByDate[dKey]) {
          notifByStu[sUid].slotsByDate[dKey] = { date: dKey, slots: [] };
        }
        notifByStu[sUid].slotsByDate[dKey].slots.push(sl);
      });
    });
    Object.keys(notifByStu).forEach(function(sUid) {
      var ng           = notifByStu[sUid];
      var pricePerSlot = AppService.getStudentPriceForTeacherSync(sUid, currentUser.uid);
      var blocks       = [];
      var allSlotIds   = [];
      var totalSlots   = 0;
      Object.keys(ng.slotsByDate).sort().forEach(function(dKey) {
        var dg = ng.slotsByDate[dKey];
        dg.slots.sort(function(a, b) { return a.time.localeCompare(b.time); });
        var bStart    = dg.slots[0].time;
        var bEnd      = dg.slots[dg.slots.length - 1].endTime;
        var cnt       = dg.slots.length;
        var dDateObj  = new Date(dKey + 'T00:00:00');
        var dLabel    = dDateObj.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
        var bSlotIds  = dg.slots.map(function(s) { return s.slotId; });
        var slotTimes = dg.slots.map(function(s) { return { time: s.time }; });
        blocks.push({
          date:      dKey,
          dateLabel: dLabel,
          timeStart: bStart,
          timeEnd:   bEnd,
          slotCount: cnt,
          slotIds:   bSlotIds,
          slotTimes: slotTimes,
          amount:    pricePerSlot * cnt
        });
        allSlotIds = allSlotIds.concat(bSlotIds);
        totalSlots += cnt;
      });
      if (!blocks.length) return;
      var snapshot = {
        actorId:      currentUser.uid,
        actorRole:    'teacher',
        teacherId:    currentUser.uid,
        teacherName:  AppService.getDisplayNameSync(currentUser.uid),
        studentId:    sUid,
        studentName:  AppService.getDisplayNameSync(sUid),
        currency:     'EUR',
        pricePerSlot: pricePerSlot,
        totalSlots:   totalSlots,
        totalAmount:  pricePerSlot * totalSlots,
        blocks:       blocks,
        allSlotIds:   allSlotIds
      };
      ChatStore.sendBookingNotification(currentUser.uid, sUid, snapshot);
    });
  }
}

function deleteSlot(slotId) {
  AppService.deleteSlot(slotId, function(e){if(e)Toast.error(e.message||e);});
  Toast.success('Slot removed.');
  renderDayPanel();
  renderCalendar();
}

/* ══════════════════════════════════════════════════════════
   SLOT GRID OVERLAY
══════════════════════════════════════════════════════════ */
function openSlotGrid() {
  if (!selectedDate) return;

  var monday = new Date(selectedDate);
  var dow = monday.getDay();
  dow = (dow === 0) ? 6 : dow - 1;
  monday.setDate(monday.getDate() - dow);
  gridWeekStart = monday;
  gridPending   = {};

  // Materialise recurring for this week
  AppService.materialiseWeek(currentUser.uid, getWeekDates());

  document.getElementById('slot-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  setGridMode('available');
  renderGridTable();
}

function closeSlotGrid() {
  document.getElementById('slot-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  gridPending = {};
  renderCalendar();
  renderDayPanel();
}

function saveSlotGrid() {
  flushGridPending();
  Toast.success('Slots saved.');
  renderCalendar();
  renderDayPanel();
  // Re-render grid to reflect saved state
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridPrevWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() - 7);
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridNextWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() + 7);
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridPrevMonth() {
  flushGridPending();
  gridWeekStart.setMonth(gridWeekStart.getMonth() - 1);
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridNextMonth() {
  flushGridPending();
  gridWeekStart.setMonth(gridWeekStart.getMonth() + 1);
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function setGridMode(mode) {
  gridMode = mode;
  var btnAvail   = document.getElementById('mode-btn-available');
  var btnTimeout = document.getElementById('mode-btn-timeout');
  btnAvail.className   = 'grid-mode-btn' + (mode === 'available' ? ' active-available' : '');
  btnTimeout.className = 'grid-mode-btn' + (mode === 'timeout'   ? ' active-timeout'   : '');
}

/* ── Grid table render ────────────────────────────────────── */
function renderGridTable() {
  var weekDates = getWeekDates();
  var times     = AppService.slotTimesInRange(GRID_START, GRID_END);

  // Update week label
  document.getElementById('grid-week-label').textContent = weekRangeLabel(weekDates);

  var container = document.getElementById('slot-grid-content');
  container.innerHTML = '';

  var table = document.createElement('table');
  table.className = 'slot-grid-table';

  // ── thead ──
  var thead = document.createElement('thead');
  var hrow  = document.createElement('tr');

  var thTime = document.createElement('th');
  thTime.className = 'grid-th-time';
  thTime.textContent = 'Time';
  hrow.appendChild(thTime);

  for (var d = 0; d < weekDates.length; d++) {
    var wd      = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var isSel   = selectedDate && wd.getTime() === selectedDate.getTime();

    var th = document.createElement('th');
    th.className = 'grid-th-day';
    if (isToday) th.classList.add('grid-th-today');
    if (isSel)   th.classList.add('grid-th-selected');

    var nameSpan = document.createElement('span');
    nameSpan.className = 'grid-day-name';
    nameSpan.textContent = DAY_NAMES[d];

    var numSpan = document.createElement('span');
    numSpan.className = 'grid-day-num';
    if (isToday) numSpan.classList.add('grid-day-today');
    numSpan.textContent = wd.getDate();

    th.appendChild(nameSpan);
    th.appendChild(numSpan);
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // ── tbody ──
  var tbody = document.createElement('tbody');

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    var tr   = document.createElement('tr');

    var tdTime = document.createElement('td');
    tdTime.className = 'grid-td-time';
    tdTime.textContent = time;
    tr.appendChild(tdTime);

    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var dayOfWeek   = dd; // 0=Mon
      var slot        = AppService.slotExistsSync(currentUser.uid, cellDateStr, time);
      var recurring   = AppService.recurringExistsSync(currentUser.uid, dayOfWeek, time);

      // Determine display status
      var status = slot ? slot.status : (recurring ? 'recurring' : 'none');
      var pendingKey = cellDateStr + '|' + time;
      if (gridPending[pendingKey] !== undefined) {
        status = gridPending[pendingKey];
      }

      var td   = document.createElement('td');
      td.className = 'grid-td-cell';

      var cell = document.createElement('div');
      cell.className = 'grid-cell';
      cell.dataset.date      = cellDateStr;
      cell.dataset.time      = time;
      cell.dataset.dayofweek = String(dayOfWeek);
      cell.dataset.booked    = (status === 'booked') ? '1' : '0';

      if (status === 'available' || status === 'recurring') {
        if (slot && slot.releasedAt) {
          cell.classList.add('gc-released');
        } else {
          cell.classList.add('gc-available');
        }
      }
      else if (status === 'booked')    cell.classList.add('gc-booked');
      else if (status === 'timeout')   cell.classList.add('gc-timeout');
      else                             cell.classList.add('gc-empty');

      if (status !== 'booked') {
        cell.addEventListener('click', onGridCellClick);
      }

      td.appendChild(cell);
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  container.appendChild(table);
}

function onGridCellClick(e) {
  var cell       = e.currentTarget;
  var date       = cell.dataset.date;
  var time       = cell.dataset.time;
  var dayOfWeek  = parseInt(cell.dataset.dayofweek, 10);
  var key        = date + '|' + time;

  var isAvailable = cell.classList.contains('gc-available') || cell.classList.contains('gc-recurring');
  var isTimeout   = cell.classList.contains('gc-timeout');
  var isEmpty     = cell.classList.contains('gc-empty');

  if (gridMode === 'available') {
    if (isAvailable) {
      // Toggle off — available (=recurring) → disabled, remove recurring rule
      gridPending[key] = 'disabled';
      cell.className = 'grid-cell gc-empty';
    } else if (isTimeout || isEmpty) {
      // Toggle on — always creates recurring rule
      gridPending[key] = 'available';
      cell.className = 'grid-cell gc-available';
    }
  } else if (gridMode === 'timeout') {
    if (isAvailable || cell.classList.contains('gc-recurring')) {
      // Check if booked
      var existingSlot = AppService.slotExistsSync(currentUser.uid, date, time);
      if (existingSlot && existingSlot.studentId) {
        // Warning: slot is booked
        var student = AppService.getUserSync(existingSlot.studentId);
        var sName   = AppService.getDisplayNameSync(existingSlot.studentId);
        var result  = Modal.show({
          title: 'Slot is booked',
          bodyHTML: '<p>This slot is booked by <strong>' + sName + '</strong>. Setting timeout will cancel their lesson.</p>',
          footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Keep booking</button><button class="btn btn-danger" id="modal-confirm">Cancel lesson & set timeout</button>'
        });
        document.getElementById('modal-cancel').addEventListener('click', result.close);
        (function(k, c, sid) {
          document.getElementById('modal-confirm').addEventListener('click', function() {
            AppService.cancelSlotWithPolicy(sid, 'teacher', function(e){if(e)Toast.error(e.message||e);});
            AppService.setSlotAvailability(sid, 'timeout', function(e){if(e)Toast.error(e.message||e);});
            gridPending[k] = 'timeout';
            c.className = 'grid-cell gc-timeout';
            renderCalendar();
            renderStudentList();
            result.close();
          });
        })(key, cell, existingSlot.slotId);
      } else {
        gridPending[key] = 'timeout';
        cell.className = 'grid-cell gc-timeout';
      }
    } else if (isTimeout) {
      // Remove timeout — restore to available/recurring
      var rec2 = AppService.recurringExistsSync(currentUser.uid, dayOfWeek, time);
      gridPending[key] = rec2 ? 'available' : 'available-no-recurring';
      cell.className = 'grid-cell gc-' + (rec2 ? 'recurring' : 'available');
    }
  }
}

function flushGridPending() {
  var keys = Object.keys(gridPending);
  for (var i = 0; i < keys.length; i++) {
    var key    = keys[i];
    var parts  = key.split('|');
    var date   = parts[0];
    var time   = parts[1];
    var action = gridPending[key];

    // Get dayOfWeek from date string
    var d = new Date(date + 'T00:00:00');
    var dow = d.getDay();
    dow = (dow === 0) ? 6 : dow - 1;

    var existing = AppService.slotExistsSync(currentUser.uid, date, time);

    if (action === 'available-new-recurring' || action === 'available' || action === 'available-no-recurring') {
      // available always means recurring
      AppService.createRecurring(currentUser.uid, dow, time, function(e){if(e)Toast.error(e.message||e);});
      if (existing) AppService.setSlotAvailability(existing.slotId, 'available', function(e){if(e)Toast.error(e.message||e);});
      else AppService.createSlot({ teacherId: currentUser.uid, date: date, time: time, status: 'available', baseStatus: 'available' }, function(e){if(e)Toast.error(e.message||e);});

    } else if (action === 'timeout') {
      // timeout = one-time unavailable, recurring rule stays
      if (existing) AppService.setSlotAvailability(existing.slotId, 'timeout', function(e){if(e)Toast.error(e.message||e);});
      else AppService.createSlot({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout', baseStatus: 'timeout' }, function(e){if(e)Toast.error(e.message||e);});

    } else if (action === 'disabled') {
      // disabled = permanently off, remove recurring rule
      AppService.deleteRecurringByDayTime(currentUser.uid, dow, time, function(e){if(e)Toast.error(e.message||e);});
      if (existing && !existing.studentId) AppService.deleteSlot(existing.slotId, function(e){if(e)Toast.error(e.message||e);});

    } else if (action === 'timeout-disabled') {
      // Keep recurring rule, but mark this specific week's slot as timeout
      if (existing) AppService.setSlotAvailability(existing.slotId, 'timeout', function(e){if(e)Toast.error(e.message||e);});
      else AppService.createSlot({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout' }, function(e){if(e)Toast.error(e.message||e);});
    }
  }
  gridPending = {};
}

/* ── Helpers ──────────────────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   ALL BOOKINGS VIEW
══════════════════════════════════════════════════════════ */

function updateBookingSortBtn() {
  var sortBtn = document.getElementById('bookings-sort-btn');
  if (!sortBtn) return;
  sortBtn.setAttribute('aria-label', allBookingsSortAsc ? 'Älteste zuerst — umkehren' : 'Neueste zuerst — umkehren');
  sortBtn.querySelector('.sort-icon-asc').classList.toggle('is-hidden', !allBookingsSortAsc);
  sortBtn.querySelector('.sort-icon-desc').classList.toggle('is-hidden', allBookingsSortAsc);
}

function renderAllBookings() {
  var selections = AppService.getSelectionsByTeacherSync(currentUser.uid);
  var students   = selections.map(function(s) { return AppService.getUserSync(s.studentId); }).filter(Boolean);

  /* ── Build custom dropdown options ── */
  var list    = document.getElementById('bookings-student-list');
  var label   = document.getElementById('bookings-student-label');
  var trigger = document.getElementById('bookings-student-trigger');
  if (!list || !label || !trigger) return;

  var options = [{ value: 'all', text: 'Alle Schüler' }];
  for (var i = 0; i < students.length; i++) {
    options.push({ value: students[i].uid, text: AppService.getDisplayNameSync(students[i].uid) });
  }

  function setFilter(val) {
    _setFilter('student', val);
    var selected = options.filter(function(o) { return o.value === val; })[0] || options[0];
    label.textContent = selected.text;
    /* Update active state */
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var j = 0; j < items.length; j++) {
      items[j].classList.toggle('is-active', items[j].getAttribute('data-value') === val);
      items[j].setAttribute('aria-selected', items[j].getAttribute('data-value') === val ? 'true' : 'false');
    }
    closeDropdown();
    renderAllBookingsList();
  }

  function openDropdown() {
    list.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    trigger.classList.add('is-open');
  }

  function closeDropdown() {
    list.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.classList.remove('is-open');
  }

  /* Rebuild list items — mockup-bookingsStudentDropdown-2026-03-23_20-55 */
  list.innerHTML = '';

  /* Sticky search row */
  var searchLi = document.createElement('li');
  searchLi.className = 'custom-dropdown-search';
  searchLi.innerHTML = buildSearchInput('bk-stu-dropdown-search', 'Suchen…');
  list.appendChild(searchLi);

  for (var k = 0; k < options.length; k++) {
    (function(opt) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (opt.value === bookingsFilter.student ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', opt.value);
      li.setAttribute('aria-selected', opt.value === bookingsFilter.student ? 'true' : 'false');
      li.textContent = opt.text;
      li.addEventListener('click', function() { setFilter(opt.value); });
      list.appendChild(li);
    })(options[k]);
  }

  /* Wire search to filter dropdown items */
  wireSearchInput('bk-stu-dropdown-search', function(query) {
    var q     = (query || '').trim().toLowerCase();
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var fi = 0; fi < items.length; fi++) {
      var show = !q || items[fi].textContent.toLowerCase().indexOf(q) !== -1;
      items[fi].classList.toggle('is-hidden', !show);
    }
  });

  /* Inject standalone search field below the dropdown */
  var searchWrap = document.getElementById('bookings-search-wrap');
  if (searchWrap) {
    searchWrap.innerHTML = buildSearchInput('all-bookings-search', 'Schüler suchen…');
    wireSearchInput('all-bookings-search', function(query) {
      var q     = (query || '').trim().toLowerCase();
      var cards = document.querySelectorAll('#all-bookings-list .student-card');
      for (var fi = 0; fi < cards.length; fi++) {
        var name = (cards[fi].querySelector('.student-card-name') || {}).textContent || '';
        cards[fi].classList.toggle('is-hidden', !!q && name.toLowerCase().indexOf(q) === -1);
      }
    });
  }

  /* Sync label to current filter */
  var cur = options.filter(function(o) { return o.value === bookingsFilter.student; })[0] || options[0];
  label.textContent = cur.text;

  /* Toggle open/close */
  trigger.onclick = function(e) {
    e.stopPropagation();
    if (list.classList.contains('is-open')) { closeDropdown(); } else { openDropdown(); }
  };

  /* Close on outside click — rebind each time to avoid stale refs */
  document.removeEventListener('click', _closeBookingDropdown);
  _closeBookingDropdown = function() { closeDropdown(); };
  document.addEventListener('click', _closeBookingDropdown);

  // Time filter buttons — scoped to all-bookings view
  var timeBtns = document.querySelectorAll('#view-all-bookings .booking-time-btn');
  for (var t = 0; t < timeBtns.length; t++) {
    timeBtns[t].classList.toggle('active', timeBtns[t].id === 'filter-' + bookingsFilter.time);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('time', btn.id.replace('filter-', ''));
        // Smart default: past → newest-first (desc), upcoming/all → oldest-first (asc)
        allBookingsSortAsc = (bookingsFilter.time !== 'past');
        for (var j = 0; j < timeBtns.length; j++) timeBtns[j].classList.remove('active');
        btn.classList.add('active');
        updateBookingSortBtn();
        _updateAllBookingsBadges();
        renderAllBookingsList();
        if (activeTeacherView === 'students') renderStudentList();
        renderDayPanel();
      };
    })(timeBtns[t]);
  }

  // Sort + date-range row — rebuilt each render so state stays fresh
  var sortDateContainer = document.getElementById('all-bookings-sort-date-row');
  if (sortDateContainer) {
    sortDateContainer.innerHTML = '';
    sortDateContainer.appendChild(_buildSortDateRangeRow(function() {
      renderAllBookingsList();
      if (activeTeacherView === 'students') renderStudentList();
      renderDayPanel();
    }));
  }

  // Confirm filter tabs — scoped to all-bookings view
  var confirmBtns = document.querySelectorAll('#view-all-bookings .booking-confirm-btn');
  for (var ci = 0; ci < confirmBtns.length; ci++) {
    confirmBtns[ci].classList.toggle('active', confirmBtns[ci].dataset.confirm === bookingsFilter.confirmed);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('confirmed', btn.dataset.confirm);
        for (var cj = 0; cj < confirmBtns.length; cj++) confirmBtns[cj].classList.remove('active');
        btn.classList.add('active');
        _updateAllBookingsBadges();
        renderAllBookingsList();
        if (activeTeacherView === 'students') renderStudentList();
        renderDayPanel();
      };
    })(confirmBtns[ci]);
  }
  _updateAllBookingsBadges();

  renderAllBookingsList();
}

/* Berechnet Blockzahlen (merged) für alle drei Confirm-Filter.
 * Wird von All Bookings und Day Panel gleichermaßen verwendet. */
/* Teacher wrapper — uses mergeAllBookingBlocks (groups by studentId) */
function _calcBlockCounts(slots, today) {
  return _calcBookingBlockCounts(slots, today, { mergeFn: mergeAllBookingBlocks });
}

/* Teacher wrapper for shared badge updater */
function _updateAllBookingsBadges() {
  _updateBookingBadges({
    getSlots:    function() {
      return AppService.getSlotsByTeacherSync(currentUser.uid)
        .filter(function(s) { return s.status === 'booked' && s.studentId; });
    },
    partyField:  'studentId',
    mergeFn:     mergeAllBookingBlocks,
    priceFn:     function(s) { return parseFloat(s.price) || 0; },
    badgePrefix: '',
    containerId: 'view-all-bookings'
  });
}

function renderAllBookingsList(opts) {
  opts = opts || {};
  /* opts.container  — DOM element to render into (default: #all-bookings-list)
     opts.dateFilter — string 'YYYY-MM-DD', render only this date (default: all dates) */
  var container = opts.container || document.getElementById('all-bookings-list');
  if (!container) return;
  container.innerHTML = '';

  var today = fmtDate(new Date()); /* FIX: defined here, passed to sub-functions via block.today */

  var allSlots = AppService.getSlotsByTeacherSync(currentUser.uid)
    .filter(function(s) {
      return s.status === 'booked' && s.studentId;
    })
    .map(function(s) {
      var p = pendingBookings[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  // Filter by student
  if (bookingsFilter.student !== 'all') {
    allSlots = allSlots.filter(function(s) { return s.studentId === bookingsFilter.student; })
  }

  // Date scope — when called from renderBookingsPanel, restrict to one day
  if (opts.dateFilter) {
    allSlots = allSlots.filter(function(s) { return s.date === opts.dateFilter; });
  }

  allSlots = _applyTimeFilter(allSlots, bookingsFilter.time, today);
  if (!opts.dateFilter) { allSlots = _applyDateRangeFilter(allSlots); }
  allSlots = _applyConfirmFilter(allSlots, bookingsFilter.confirmed);

  var emptyReasons = {
    past: 'Keine vergangenen Buchungen.',
    upcoming: 'Keine kommenden Buchungen.',
    all: 'Keine Buchungen gefunden.'
  };
  if (!allSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = emptyReasons[bookingsFilter.time] || 'Keine Buchungen gefunden.';
    container.appendChild(empty);
    return;
  }

  // Always sort ascending for correct merging — direction only affects display order
  allSlots.sort(function(a, b) {
    return a.date.localeCompare(b.date) || a.time.localeCompare(b.time);
  });

  // Group by date
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < allSlots.length; i++) {
    var s = allSlots[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  if (!allBookingsSortAsc) { dateOrder.reverse(); }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr   = dateOrder[d];
    var dateSlots = byDate[dateStr];
    var isPast    = dateStr < today;

    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider' + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
    container.appendChild(divider);

    var blocks = mergeAllBookingBlocks(dateStr, dateSlots, today);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(buildAllBookingBlock(blocks[b], { showDate: false, isPast: isPast }));
    }
  }
  /* Only update global badges/jumps when rendering the full all-bookings view */
  if (!opts.dateFilter) {
    _updateAllBookingsBadges();
    setTimeout(updateJumpBtns, 50);
  }
}

/**
 * Teacher wrapper — merges by studentId, resolves student user object.
 */
function mergeAllBookingBlocks(dateStr, bookedSlots, today) {
  /* Deduplicate: if a slot has students[], it already represents all students.
     Filter out any legacy duplicate slots at the same time (extra-student slots
     from old model) by keeping only unique slotIds. */
  var seen = {};
  var deduped = bookedSlots.filter(function(s) {
    if (seen[s.slotId]) return false;
    seen[s.slotId] = true;
    return true;
  });
  /* Add a synthetic groupKey to each slot: sorted student UIDs joined.
     This makes mergeBookingBlocks treat consecutive slots with the same
     student set as one block, regardless of individual slotIds. */
  var keyed = deduped.map(function(s) {
    var sids = (s.students && s.students.length) ? s.students.slice() : (s.studentId ? [s.studentId] : []);
    sids.sort();
    var clone = {};
    for (var k in s) clone[k] = s[k];
    clone._groupKey = sids.join('|') || s.slotId;
    return clone;
  });
  return mergeBookingBlocks(dateStr, keyed, today, {
    groupField:   '_groupKey',
    resolveParty: function(s) {
      var studentIds = (s.students && s.students.length) ? s.students : (s.studentId ? [s.studentId] : []);
      var students   = studentIds.map(function(uid) { return AppService.getUserSync(uid); }).filter(Boolean);
      return {
        student:    students[0] || null,
        students:   students,
        studentIds: studentIds
      };
    }
  });
}

/* Teacher wrapper for shared buildBookingBlock */
function buildAllBookingBlock(block, options) {
  var isPast       = !!(options && options.isPast);
  var simpleDetail = !!(options && options.simpleDetail);
  return buildBookingBlock(block, {
    showDate:       !options || options.showDate !== false,
    isPast:         isPast,
    expandedBlocks: expandedAllBlocks,
    blockKeyFn:     function(b) {
      var slotKey = b.bookedSlots && b.bookedSlots[0] ? b.bookedSlots[0].slotId : 'x';
      return b.dateStr + '-' + b.start + '-' + slotKey;
    },
    nameFn:         function(b) {
      if (b.students && b.students.length > 1) {
        return b.students.map(function(s) {
          return AppService.getDisplayNameSync(s.uid);
        }).join(', ');
      }
      return AppService.getDisplayNameSync(b.student ? b.student.uid : '?');
    },
    priceFn:        function(b) {
      /* Use locked price from first booked slot if available */
      var lockedPrice = b.bookedSlots && b.bookedSlots[0] && b.bookedSlots[0].price;
      var price = parseFloat(lockedPrice) || 0;
      if (!price || isNaN(price)) return '';
      return _fmtForUser(price * b.bookedSlots.length, currentUser ? currentUser.uid : null);
    },
    onConfirmBlock: null, /* hidden — confirmation is student-only */
    onEditBlock:    function(b) { openMoveBlockDialog(b); },
    onReleaseBlock: function(b) { _openReleaseDialog(b); },
    populateDetail: function(det, b) {
      if (simpleDetail) populateSimpleBlockDetail(det, b);
      else populateAllBookingDetail(det, b, null, { onDismissAll: discardBookingChanges });
    }
  });
}

/* Teacher wrapper for shared populateBookingDetail */
function populateAllBookingDetail(detail, block, onAction, extraOpts) {
  var stuId = block.student ? block.student.uid : null;
  populateBookingDetail(detail, block, {
    pendingMap:     pendingBookings,
    hideRecurring:  true,
    onDismissAll:   extraOpts && extraOpts.onDismissAll ? extraOpts.onDismissAll : null,
    getSlots:       function(b) { return AppService.getSlotsByTeacherDateSync(currentUser.uid, b.dateStr); },
    showFreeSlots:  true,
    stuId:          stuId,
    onConfirmSlot:  null, /* hidden — confirmation is student-only */
    slotPriceFn:    function(slot) { return _fmtForUser(slot.price, currentUser ? currentUser.uid : null); },
    onAddSlot:      function(s, map) {
      var original = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0];
      map[s.slotId] = { action: 'book', originalSlot: original, newStudentId: stuId, extraStudents: [] };
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderDayPanel();
    },
    onRequestSlot:  function(s, map) {
      /* on_request: send booking_request service message, don't book yet */
      if (!stuId) return;
      var original  = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0] || s;
      var dateObj   = new Date((original.date || s.date || '') + 'T00:00:00');
      var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
      var endTime   = AppService.slotEndTime(original.time || s.time || '');
      ChatStore.sendBookingRequest(currentUser.uid, stuId, {
        slotId:    original.slotId || s.slotId,
        date:      original.date   || s.date   || '',
        dateLabel: dateLabel,
        time:      original.time   || s.time   || '',
        endTime:   endTime
      });
      /* EmailService.onBookingCreated fired by AppService.bookSlotWithEscrowSilent on confirmation */
      Toast.success('Buchungsanfrage an ' + AppService.getDisplayNameSync(stuId) + ' gesendet.');
    },
    onAction: function() {
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderDayPanel();
      if (onAction) onAction();
    }
  });
}

/* ── Simple detail — only the block's own booked slots, no day-lookup ── */
function populateSimpleBlockDetail(detail, block) {
  detail.innerHTML = '';
  var slots = block.bookedSlots;
  if (!slots || !slots.length) return;

  for (var i = 0; i < slots.length; i++) {
    var s    = slots[i];
    var orig = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0] || s;
    var isConfirmed = !!orig.confirmedAt;

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row';

    var timeEl = document.createElement('span');
    timeEl.className = 'all-booking-slot-time';
    timeEl.textContent = orig.time + ' \u2013 ' + AppService.slotEndTime(orig.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'all-booking-slot-status';
    statusEl.textContent = isConfirmed ? '\u2713 Bestätigt' : 'Gebucht';

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    detail.appendChild(row);
  }
}

/* ── Bestätigungs-Dialog (Block-Level) ───────────────── */
/* ── Verfügbarkeit 2 — single-student cancel dialog ───────── */
function _openV2CancelDialog(studentId, slot) {
  var studentName = AppService.getDisplayNameSync(studentId);
  var dateObj     = new Date((slot.date || '') + 'T00:00:00');
  var dateLabel   = dateObj.toLocaleDateString('de-DE', { weekday:'short', day:'2-digit', month:'2-digit', year:'numeric' });
  var endTime     = AppService.slotEndTime(slot.time || '');
  var price       = parseFloat(slot.price) || 0;
  var fmt         = function(a) { return _fmtForUser(a, currentUser ? currentUser.uid : null); };

  AppService.calcCancellationPolicy(slot.slotId, 'teacher', function(err, policy) {
    var refund  = (!err && policy) ? (parseFloat(policy.refundAmount)  || 0) : price;
    var forfeit = (!err && policy) ? (parseFloat(policy.forfeitAmount) || 0) : 0;

    var policyHTML =
      '<div class="policy-card">' +
        '<div class="policy-row"><span class="policy-label">Preis</span><span class="policy-value">' + fmt(price) + '</span></div>' +
        (refund  > 0 ? '<div class="policy-row"><span class="policy-label">Rückerstattung</span><span class="policy-refund">' + fmt(refund)  + '</span></div>' : '') +
        (forfeit > 0 ? '<div class="policy-row"><span class="policy-label">Einbehalten</span><span class="policy-value">'  + fmt(forfeit) + '</span></div>' : '') +
      '</div>';

    var warnHTML = forfeit > 0
      ? '<div class="policy-warn">⚠️ Kurzfristige Stornierung — Teileinbehalt gemäß Bedingungen.</div>'
      : '<div class="policy-ok">✓ Rechtzeitige Stornierung — volle Rückerstattung.</div>';

    var bodyHTML =
      '<div class="dlg-student-row">' +
        buildAvatarHTML(studentId, { size: 'md', role: 'student' }) +
        '<div style="margin-left:10px"><div class="dlg-name">' + _esc(studentName) + '</div>' +
        '<div class="dlg-slot">' + _esc(dateLabel) + ' · ' + _esc(_tTeacherTime(slot.time || '', slot.date || '')) + '–' + _esc(_tTeacherEndTime(slot.time || '', slot.date || '')) + '</div></div>' +      '</div>' +
      policyHTML +
      warnHTML;

    var result = Modal.show({
      title: 'Buchung stornieren',
      bodyHTML: bodyHTML,
      footerHTML:
        '<button class="btn btn-ghost" id="v2-cancel-abort">Abbrechen</button>' +
        '<button class="btn btn-danger" id="v2-cancel-confirm">Stornieren &amp; Rückerstatten</button>'
    });

    document.getElementById('v2-cancel-abort').addEventListener('click', result.close);
    document.getElementById('v2-cancel-confirm').addEventListener('click', function() {
      result.close();
      AppService.removeStudentFromSlot(slot.slotId, studentId, 'teacher', function(e) {
        if (e) { Toast.error(e.message || e); return; }
        Toast.success(studentName + ' — Buchung storniert.');
        _tdvRenderSlots();
        renderDayPanel();
        renderCalendar();
        renderStudentList();
        renderAllBookingsList();
        if (typeof WalletPanel !== 'undefined') WalletPanel.refresh(currentUser.uid);
      });
    });
  });
}


function _openConfirmDialog(block) {
  var stuUid      = block.student ? block.student.uid : null;
  var stuName     = AppService.getDisplayNameSync(stuUid || '?');
  var teachName   = AppService.getDisplayNameSync(currentUser.uid);
  var bookedSlots = block.bookedSlots || [];
  var slotCount   = bookedSlots.length;
  var firstSlot   = slotCount ? AppService.getAllSlotsSync().filter(function(s){ return s.slotId === bookedSlots[0].slotId; })[0] : null;
  var dateLabel   = firstSlot ? (function() {
    var d = new Date(firstSlot.date + 'T00:00:00');
    return d.toLocaleDateString('de-DE', { weekday:'short', day:'numeric', month:'short', year:'numeric' });
  })() : '';

  function _loadAllEscrows(slots, cb) {
    if (!slots.length) { cb([]); return; }
    var results = []; var pending = slots.length;
    slots.forEach(function(s) {
      AppService.getEscrowBySlot(s.slotId, function(err, esc) {
        if (esc) results.push(esc);
        if (--pending === 0) cb(results);
      });
    });
  }

  function _show(escrows) {
    var totalFull = 0; var totalDeposit = 0;
    var depositStatus = null; var paymentMode = 'instant';
    var requiresDep = false; var depositType = 'fixed'; var depositPct = null;
    escrows.forEach(function(e) {
      totalFull    += parseFloat(e.fullAmount)    || 0;
      totalDeposit += parseFloat(e.depositAmount) || 0;
      depositStatus = e.depositStatus || depositStatus;
      paymentMode   = e.paymentMode   || paymentMode;
      requiresDep   = requiresDep || (e.requiresDeposit !== false);
      depositType   = e.depositType   || depositType;
      if (e.depositPercent != null) depositPct = e.depositPercent;
    });
    totalFull    = Math.round(totalFull    * 100) / 100;
    totalDeposit = Math.round(totalDeposit * 100) / 100;
    var syntheticEscrow = escrows.length ? {
      fullAmount: totalFull, depositAmount: totalDeposit,
      depositStatus: depositStatus, paymentMode: paymentMode,
      requiresDeposit: requiresDep, depositType: depositType, depositPercent: depositPct
    } : null;
    var slotNote = slotCount > 1 ? slotCount + ' Slots' : '1 Slot';
    var bodyHTML = _buildConfirmDetailBody({
      teacherName: teachName, studentName: stuName,
      dateLabel: dateLabel + ' &bull; ' + slotNote,
      timeStart: block.start, timeEnd: block.end,
      escrow: syntheticEscrow, walletBalance: null, actorRole: 'teacher', actorUid: currentUser ? currentUser.uid : null
    });
    var result = Modal.show({
      title: 'Stunde bestätigen', bodyHTML: bodyHTML,
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      result.close();
      AppService.confirmBlock(block.bookedSlots, function(e) {
        if (e) { Toast.error(e.message || e); return; }
        _updateAllBookingsBadges(); renderAllBookingsList(); renderDayPanel();
        if (typeof WalletPanel !== 'undefined') WalletPanel.refresh(currentUser.uid);
      });
    });
  }

  _loadAllEscrows(bookedSlots, _show);
}

/* ── Bestätigungs-Dialog (Slot-Level) ────────────────── */
function _openConfirmDialogSingle(slotId) {
  var slot = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === slotId; })[0];
  if (!slot) return;
  var stuName   = AppService.getDisplayNameSync(slot.studentId || '?');
  var teachName = AppService.getDisplayNameSync(currentUser.uid);
  var endTime   = AppService.slotEndTime(slot.time);
  var dateObj   = new Date(slot.date + 'T00:00:00');
  var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday:'short', day:'numeric', month:'short', year:'numeric' });

  AppService.getEscrowBySlot(slotId, function(err, escrow) {
    var bodyHTML = _buildConfirmDetailBody({
      teacherName: teachName, studentName: stuName,
      dateLabel: dateLabel, timeStart: slot.time, timeEnd: endTime,
      escrow: escrow || null, walletBalance: null, actorRole: 'teacher', actorUid: currentUser ? currentUser.uid : null
    });
    var result = Modal.show({
      title: 'Slot bestätigen', bodyHTML: bodyHTML,
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      AppService.confirmSlot(slotId, function(e){if(e)Toast.error(e.message||e);});
      _updateAllBookingsBadges(); renderAllBookingsList(); renderDayPanel();
      result.close();
    });
  });
}

/* ── Freigabe-Dialog ─────────────────────────────────── */
function _openReleaseDialog(block) {
  var stuName = AppService.getDisplayNameSync(block.student ? block.student.uid : '?');
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info">Möchtest du die Zeitslots der Stunde von <strong>' + stuName + '</strong> (' + block.start + ' \u2013 ' + block.end + ') freigeben?</p>' +
      '<p class="move-dialog-info">Die Slots werden wieder für andere Schüler verfügbar gemacht. Ein Hinweis bleibt im Kalender sichtbar.</p>' +
    '</div>';
  var result = Modal.show({
    title: 'Slot freigeben',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Freigeben</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    for (var ri = 0; ri < block.bookedSlots.length; ri++) {
      AppService.releaseSlot(block.bookedSlots[ri].slotId, function(e){if(e)Toast.error(e.message||e);});
    }
    renderAllBookingsList();
    renderCalendarMonth();
    result.close();
  });
}

/* ── Move Dialog ─────────────────────────────────────── */
/* ── Move Block Dialog (alle Slots auf einmal) ───────── */
function openMoveBlockDialog(block) {
  openMoveBlockDialogShared({
    block:           block,
    teacherId:       currentUser.uid,
    actorRole:       'teacher',
    pendingMap:      pendingBookings,
    stuId:           block.student ? block.student.uid : null,
    onConfirmBlock:  function() {
      _updateAllBookingsBadges();
      renderAllBookingsList();
      renderDayPanel();
    },
    onCancelBlock:   function() {
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderCalendar();
      renderDayPanel();
      /* WalletPanel.refresh and navbar update handled by _showCancelBlockPolicyDialog */
    },
    onConfirm:  function(movedPending, dialogOpts) {
      /* Capture move opts by studentId for writeMoveRecord */
      var stuIdForMove = block.student ? block.student.uid : null;
      if (stuIdForMove && dialogOpts && dialogOpts._lastMoveOpts) {
        pendingMoveOpts[stuIdForMove] = dialogOpts._lastMoveOpts;
      }
      /* Immediately save — no manual Save step needed */
      saveBookingChanges();
    },
    onCalJump: function(dateStr, result) {
      if (!dateStr) return;
      var target = new Date(dateStr + 'T00:00:00');
      selectedDate = target;
      viewYear  = target.getFullYear();
      viewMonth = target.getMonth();
      activeDayTab = 'bookings';
      switchTeacherView('schedule');
      renderCalendar();
      renderDayPanel();
      result.close();
      setTimeout(function() {
        var panel = document.getElementById('section-daypanel');
        if (panel) {
          var offset = getStickyOffset();
          var top = panel.getBoundingClientRect().top + window.scrollY - offset;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      }, 80);
    }
  });
}

function getWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(gridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function weekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day:'numeric', month:'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' });
}

function updateStats() {
  var allSlots = AppService.getSlotsByTeacherSync(currentUser.uid);
  var today    = fmtDate(new Date());

  /* stat-booked: all-time total — same guard as badges (requires studentId) */
  var booked = allSlots.filter(function(s) { return s.status === 'booked' && s.studentId; });
  var counts = _calcBlockCounts(booked, today);
  var statBookedEl = document.getElementById('stat-booked');
  if (statBookedEl) statBookedEl.textContent = counts.all;

  var availEl = document.getElementById('stat-available');
  if (availEl) availEl.textContent = allSlots.filter(function(s) { return s.status === 'available'; }).length;

  /* keep confirm-filter badges in sync from the same trigger */
  _updateAllBookingsBadges();
}

/* ── Section jump buttons ─────────────────────────────── */
function getSectionJumpTargets() {
  if (activeTeacherView === 'all-bookings') {
    var dividers = document.querySelectorAll('#view-all-bookings .all-bookings-day-divider');
    var pageTop  = document.querySelector('.page-header') || document.getElementById('view-all-bookings');
    if (dividers.length) return [pageTop].concat(Array.prototype.slice.call(dividers)).filter(Boolean);
    return [pageTop].filter(Boolean);
  }
  return [
    document.querySelector('.page-header'),
    document.getElementById('section-calendar'),
    document.getElementById('section-daypanel')
  ].filter(Boolean);
}

window.addEventListener('scroll', updateJumpBtns);
window.addEventListener('scroll', checkDayNavSticky);

window.addEventListener('resize', function() {
  window._dayNavStickyActive = !window._dayNavStickyActive;
  checkDayNavSticky();
});


function navDay(delta) { _navDayShared(delta, renderDayPanel); }
function navMonth(delta) { _navMonthShared(delta, renderDayPanel); }

function checkDayNavSticky() { checkDayNavStickyShared('section-daypanel'); }

/* ── Cross-tab sync via AppService.onChange ── */
AppService.onChange(function(e) {
  if (e.key === 'app_slots' || e.key === 'app_selections' || e.key === 'app_users') {
    updateStats();
    renderStudentList();
    renderCalendar();
    renderDayPanel();
    if (activeTeacherView === 'all-bookings') renderAllBookings();
  }
});

function updateJumpBtns() { _updateJumpBtnsShared(activeTeacherView === 'all-bookings' && getSectionJumpTargets().length > 1); }

function prevMonth() { _prevMonthShared(); }
function nextMonth() { _nextMonthShared(); }

/* ══════════════════════════════════════════════════════════
   TEACHER DAY VIEW
   Variables, render, open/close, slot actions
══════════════════════════════════════════════════════════ */

var _tdvDate    = null;   /* currently displayed Date object */
var _tdvOpen    = false;

var _TDV_WEEKDAYS = ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'];
var _TDV_MONTHS   = ['Januar','Februar','März','April','Mai','Juni',
                     'Juli','August','September','Oktober','November','Dezember'];

/* ── Open / Close ───────────────────────────────────────── */
function openTeacherDayView(date) {
  _tdvDate = (date instanceof Date) ? date : new Date(date + 'T00:00:00');
  _tdvOpen = true;
  var overlay = document.getElementById('teacher-day-view-overlay');
  overlay.classList.add('is-open');
  _tdvRenderTopbar();
  _tdvRenderSlots();
}

function closeTeacherDayView() {
  _tdvOpen = false;
  document.getElementById('teacher-day-view-overlay').classList.remove('is-open');
}

/* ── Topbar label ───────────────────────────────────────── */
function _tdvRenderTopbar() {
  if (!_tdvDate) return;
  document.getElementById('tdv-weekday').textContent = _TDV_WEEKDAYS[_tdvDate.getDay()];
  document.getElementById('tdv-date').textContent    =
    _tdvDate.getDate() + '. ' + _TDV_MONTHS[_tdvDate.getMonth()] + ' ' + _tdvDate.getFullYear();
}

/* ── Slot list ──────────────────────────────────────────── */
function _tdvRenderSlots() {
  var container = document.getElementById('tdv-slot-list');
  container.innerHTML = '';

  if (!_tdvDate || !currentUser) return;

  /* Materialise recurring for this week first */
  var dow = _tdvDate.getDay();
  var monday = new Date(_tdvDate);
  monday.setDate(_tdvDate.getDate() - ((dow === 0) ? 6 : dow - 1));
  var weekDates = [];
  for (var wi = 0; wi < 7; wi++) {
    var wd = new Date(monday);
    wd.setDate(monday.getDate() + wi);
    weekDates.push(wd);
  }
  AppService.materialiseWeek(currentUser.uid, weekDates, function(e) { if (e) Toast.error(e.message || e); });

  var dateStr = fmtDate(_tdvDate);
  var slots   = AppService.getSlotsByTeacherDateSync(currentUser.uid, dateStr);

  /* Build a lookup: time → slot */
  var slotMap = {};
  for (var si = 0; si < slots.length; si++) {
    slotMap[slots[si].time] = slots[si];
  }

  var times = _tdvBuildAllDayTimes(); /* 00:00 – 23:30, all 48 slots */
  var todayStr = fmtDate(new Date());
  var isPastDay = dateStr < todayStr;

  /* Section boundaries — full 24h */
  var sections = [
    { label: 'Nacht',      from: '00:00', to: '05:30' },
    { label: 'Morgen',     from: '06:00', to: '09:30' },
    { label: 'Vormittag',  from: '10:00', to: '11:30' },
    { label: 'Mittag',     from: '12:00', to: '13:30' },
    { label: 'Nachmittag', from: '14:00', to: '17:30' },
    { label: 'Abend',      from: '18:00', to: '21:30' },
    { label: 'Nacht',      from: '22:00', to: '23:30' }
  ];
  var sectionIdx = 0;
  var sectionRendered = {};

  var frag = document.createDocumentFragment();

  for (var ti = 0; ti < times.length; ti++) {
    var time = times[ti];

    /* Section label */
    for (var sci = sectionIdx; sci < sections.length; sci++) {
      if (time >= sections[sci].from && time <= sections[sci].to && !sectionRendered[sci]) {
        var lbl = document.createElement('div');
        lbl.className = 'dv-section-label';
        lbl.textContent = sections[sci].label;
        lbl.setAttribute('aria-hidden', 'true');
        frag.appendChild(lbl);
        sectionRendered[sci] = true;
        sectionIdx = sci;
        break;
      }
    }

    var slot = slotMap[time] || null;
    frag.appendChild(_tdvBuildRow(slot, time, dateStr, isPastDay));
  }

  /* If no slots exist at all, show empty state */
  if (!slots.length && !isPastDay) {
    var emptyState = document.createElement('div');
    emptyState.className = 'dv-empty-state';
    var emptyText = document.createElement('p');
    emptyText.className = 'dv-empty-state-text';
    emptyText.textContent = 'Keine Slots für diesen Tag. Öffne die Wochenansicht um Slots hinzuzufügen.';
    emptyState.appendChild(emptyText);
    var wvBtn = document.createElement('button');
    wvBtn.className = 'btn btn-primary btn-sm';
    wvBtn.textContent = 'Wochenansicht öffnen';
    wvBtn.addEventListener('click', function() { closeTeacherDayView(); openSlotGrid(); });
    emptyState.appendChild(wvBtn);
    container.appendChild(emptyState);
    return;
  }

  container.appendChild(frag);
}

/* ── Build a single slot row ────────────────────────────── */
function _tdvBuildRow(slot, time, dateStr, isPastDay) {
  var _localTime = _tTeacherTime(time, dateStr);
  var endTime    = AppService.slotEndTime(_localTime);
  var status  = slot ? (slot.status || slot.baseStatus) : 'empty';

  /* Row classes */
  var rowClass = 'dv-slot-row ';
  if (isPastDay)              rowClass += 'dv-s-past';
  else if (status === 'booked')    rowClass += 'dv-s-booked';
  else if (status === 'available' || status === 'recurring') rowClass += 'dv-s-' + status;
  else if (status === 'timeout') {
    var _base2 = slot ? (slot.baseStatus || 'timeout') : 'timeout';
    var _wasAvail2 = (_base2 === 'available' || _base2 === 'recurring');
    rowClass += _wasAvail2 ? 'dv-s-timeout-avail' : 'dv-s-timeout';
  }
  else if (status === 'disabled')  rowClass += 'dv-s-empty'; /* disabled = visually empty */
  else                             rowClass += 'dv-s-empty';

  var row = document.createElement('div');
  row.className = rowClass.trim();
  row.setAttribute('role', 'listitem');

  /* Time column */
  var timeCol = document.createElement('div');
  timeCol.className = 'dv-slot-time';
  timeCol.setAttribute('aria-label', time + ' bis ' + endTime);
  var tStart = document.createElement('span');
  tStart.className = 'dv-time-start';
  tStart.textContent = _localTime;
  var tEnd = document.createElement('span');
  tEnd.className = 'dv-time-end';
  tEnd.textContent = '\u2013' + endTime;
  timeCol.appendChild(tStart);
  timeCol.appendChild(tEnd);

  /* Separator */
  var sep = document.createElement('div');
  sep.className = 'dv-slot-sep';
  sep.setAttribute('aria-hidden', 'true');

  /* Info column */
  var info = document.createElement('div');
  info.className = 'dv-slot-info';

  /* Action column */
  var action = document.createElement('div');
  action.className = 'dv-slot-action';

  /* ── Fill info + action by status ── */
  if (status === 'booked' && slot) {
    var sName = slot.studentId ? AppService.getDisplayNameSync(slot.studentId) : 'Unbekannt';
    var nameEl = document.createElement('span');
    nameEl.className = 'dv-student-name';
    nameEl.textContent = sName;
    info.appendChild(nameEl);

    if (slot.studentId) {
      var student = AppService.getUserSync(slot.studentId);
      if (student && student.email) {
        var metaEl = document.createElement('span');
        metaEl.className = 'dv-student-meta';
        metaEl.textContent = student.email;
        info.appendChild(metaEl);
      }
    }
    if (slot.confirmedAt) {
      var confBadge = document.createElement('span');
      confBadge.className = 'dv-confirmed-badge';
      confBadge.textContent = '\u2713 Bestätigt';
      info.appendChild(confBadge);
    }

    if (!isPastDay) {
      var detBtn = _tdvMakeActionBtn('dv-btn-detail', 'Details', _svgArrow());
      (function(s) {
        detBtn.addEventListener('click', function() { _tdvOpenBookingDetail(s); });
      })(slot);
      action.appendChild(detBtn);
    }

  } else if (status === 'available' || status === 'recurring') {
    var pill = _tdvMakePill(status === 'recurring' ? 'dv-pill-recurring' : 'dv-pill-available',
                             status === 'recurring' ? 'Wiederkehrend' : 'Verfügbar');
    info.appendChild(pill);
    if (!isPastDay && slot) {
      var deakBtn = _tdvMakeInlineBtn('Deaktivieren');
      (function(s) {
        deakBtn.addEventListener('click', function() {
          var d = new Date(s.date + 'T00:00:00');
          var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
          /* Delete slot entirely — back to "Kein Slot angelegt" */
          AppService.deleteSlot(s.slotId, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
          AppService.deleteRecurringByDayTime(currentUser.uid, dow, s.time, function(e) { if (e) Toast.error(e.message || e); });
        });
      })(slot);
      var toBtn2 = _tdvMakeInlineBtn('Timeout');
      (function(s) {
        toBtn2.addEventListener('click', function() {
          AppService.setSlotAvailability(s.slotId, 'timeout', function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(slot);
      action.appendChild(deakBtn);
      action.appendChild(toBtn2);
    }

  } else if (status === 'timeout') {
    var base = slot ? (slot.baseStatus || 'timeout') : 'timeout';
    var wasAvail = (base === 'available' || base === 'recurring');

    if (wasAvail) {
      /* State 3: Verfügbar + Timeout — blue pill + stopwatch */
      info.appendChild(_tdvMakePill('dv-pill-available', 'Verfügbar'));
    } else {
      /* State 4: Timeout only (no availability) — just stopwatch, no pill */
      var toOnlyLabel = document.createElement('span');
      toOnlyLabel.className = 'dv-empty-hint';
      toOnlyLabel.textContent = 'Nicht verfügbar';
      info.appendChild(toOnlyLabel);
    }
    var swIcon = document.createElement('span');
    swIcon.className = 'dv-timeout-icon';
    swIcon.setAttribute('title', 'Timeout aktiv');
    swIcon.setAttribute('aria-hidden', 'true');
    swIcon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><polyline points="12 9 12 13 14.5 15.5"/><path d="M9 3h6M12 3v2"/></svg>';
    info.appendChild(swIcon);

    if (!isPastDay && slot) {
      var unblockBtn = _tdvMakeInlineBtn('Aufheben');
      (function(s, wasA) {
        unblockBtn.addEventListener('click', function() {
          if (wasA) {
            AppService.setSlotAvailability(s.slotId, 'available', function(e) {
              if (e) { Toast.error(e.message || e); }
              _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
            });
          } else {
            AppService.deleteSlot(s.slotId, function(e) {
              if (e) { Toast.error(e.message || e); }
              _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
            });
          }
        });
      })(slot, wasAvail);
      action.appendChild(unblockBtn);
    }

  } else if (status === 'disabled') {
    /* disabled slots treated as empty — delete to clean up legacy data */
    if (!isPastDay && slot) {
      var hint2 = document.createElement('span');
      hint2.className = 'dv-empty-hint';
      hint2.textContent = 'Kein Slot angelegt';
      info.appendChild(hint2);
      var cleanBtn = _tdvMakeInlineBtn('Hinzufügen');
      (function(s) {
        cleanBtn.addEventListener('click', function() {
          AppService.setSlotAvailability(s.slotId, 'available', function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(slot);
      action.appendChild(cleanBtn);
    }

  } else {
    /* empty — two inline buttons: Verfügbar + Timeout */
    var hint = document.createElement('span');
    hint.className = 'dv-empty-hint';
    hint.textContent = 'Kein Slot angelegt';
    info.appendChild(hint);
    if (!isPastDay) {
      var verfBtn = _tdvMakeInlineBtn('Hinzufügen');
      (function(t, ds) {
        verfBtn.addEventListener('click', function() {
          AppService.createSlot({
            teacherId: currentUser.uid, date: ds, time: t,
            status: 'available', baseStatus: 'available'
          }, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(time, dateStr);
      var toBtn = _tdvMakeInlineBtn('Timeout');
      (function(t, ds) {
        toBtn.addEventListener('click', function() {
          AppService.createSlot({
            teacherId: currentUser.uid, date: ds, time: t,
            status: 'timeout', baseStatus: 'timeout'
          }, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(time, dateStr);
      action.appendChild(verfBtn);
      action.appendChild(toBtn);
    }
  }

  if (isPastDay && status !== 'booked') {
    info.appendChild(_tdvMakePill('dv-pill-past', 'Vergangen'));
  }

  row.appendChild(timeCol);
  row.appendChild(sep);
  row.appendChild(info);
  row.appendChild(action);
  return row;
}

/* ── Booking detail modal ───────────────────────────────── */

/* ── Verfügbarkeit 2 row builder — same as V1 but booked = colored bg + expandable ── */

/* ── Verfügbarkeit 1 — pure slot management, no booking details ── */
function _tdvBuildRowV1(slot, time, dateStr, isPastDay) {
  var _localTime = _tTeacherTime(time, dateStr);
  var endTime    = AppService.slotEndTime(_localTime);
  var status  = slot ? (slot.status || slot.baseStatus) : 'empty';

  /* Row classes */
  var rowClass = 'dv-slot-row ';
  if (isPastDay)              rowClass += 'dv-s-past';
  else if (status === 'booked')    rowClass += 'dv-s-booked';
  else if (status === 'available' || status === 'recurring') rowClass += 'dv-s-' + status;
  else if (status === 'timeout') {
    var _base2 = slot ? (slot.baseStatus || 'timeout') : 'timeout';
    var _wasAvail2 = (_base2 === 'available' || _base2 === 'recurring');
    rowClass += _wasAvail2 ? 'dv-s-timeout-avail' : 'dv-s-timeout';
  }
  else if (status === 'disabled')  rowClass += 'dv-s-empty'; /* disabled = visually empty */
  else                             rowClass += 'dv-s-empty';

  var row = document.createElement('div');
  row.className = rowClass.trim();
  row.setAttribute('role', 'listitem');

  /* Time column */
  var timeCol = document.createElement('div');
  timeCol.className = 'dv-slot-time';
  timeCol.setAttribute('aria-label', time + ' bis ' + endTime);
  var tStart = document.createElement('span');
  tStart.className = 'dv-time-start';
  tStart.textContent = _localTime;
  var tEnd = document.createElement('span');
  tEnd.className = 'dv-time-end';
  tEnd.textContent = '\u2013' + endTime;
  timeCol.appendChild(tStart);
  timeCol.appendChild(tEnd);

  /* Separator */
  var sep = document.createElement('div');
  sep.className = 'dv-slot-sep';
  sep.setAttribute('aria-hidden', 'true');

  /* Info column */
  var info = document.createElement('div');
  info.className = 'dv-slot-info';

  /* Action column */
  var action = document.createElement('div');
  action.className = 'dv-slot-action';

  /* ── Fill info + action by status ── */
  /* V1: booked slots shown as available — no booking info, pure slot management */
  if (status === 'booked' && slot) {
    row.classList.remove('dv-s-booked');
    row.classList.add('dv-s-available');
    var pillV1 = _tdvMakePill('dv-pill-available', 'Verf\u00fcgbar');
    info.appendChild(pillV1);
    if (!isPastDay) {
      var deakBtnV1 = _tdvMakeInlineBtn('Deaktivieren');
      (function(s) {
        deakBtnV1.addEventListener('click', function() {
          AppService.setSlotAvailability(s.slotId, 'disabled', function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel();
          });
        });
      })(slot);
      var toBtnV1 = _tdvMakeInlineBtn('Timeout');
      (function(s) {
        toBtnV1.addEventListener('click', function() {
          AppService.setSlotAvailability(s.slotId, 'timeout', function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel();
          });
        });
      })(slot);
      action.appendChild(deakBtnV1);
      action.appendChild(toBtnV1);
    }

  } else if (status === 'available' || status === 'recurring') {
    var pill = _tdvMakePill(status === 'recurring' ? 'dv-pill-recurring' : 'dv-pill-available',
                             status === 'recurring' ? 'Wiederkehrend' : 'Verfügbar');
    info.appendChild(pill);
    if (!isPastDay && slot) {
      var deakBtn = _tdvMakeInlineBtn('Deaktivieren');
      (function(s) {
        deakBtn.addEventListener('click', function() {
          var d = new Date(s.date + 'T00:00:00');
          var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
          /* Delete slot entirely — back to "Kein Slot angelegt" */
          AppService.deleteSlot(s.slotId, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
          AppService.deleteRecurringByDayTime(currentUser.uid, dow, s.time, function(e) { if (e) Toast.error(e.message || e); });
        });
      })(slot);
      var toBtn2 = _tdvMakeInlineBtn('Timeout');
      (function(s) {
        toBtn2.addEventListener('click', function() {
          AppService.setSlotAvailability(s.slotId, 'timeout', function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(slot);
      action.appendChild(deakBtn);
      action.appendChild(toBtn2);
    }

  } else if (status === 'timeout') {
    var base = slot ? (slot.baseStatus || 'timeout') : 'timeout';
    var wasAvail = (base === 'available' || base === 'recurring');

    if (wasAvail) {
      /* State 3: Verfügbar + Timeout — blue pill + stopwatch */
      info.appendChild(_tdvMakePill('dv-pill-available', 'Verfügbar'));
    } else {
      /* State 4: Timeout only (no availability) — just stopwatch, no pill */
      var toOnlyLabel = document.createElement('span');
      toOnlyLabel.className = 'dv-empty-hint';
      toOnlyLabel.textContent = 'Nicht verfügbar';
      info.appendChild(toOnlyLabel);
    }
    var swIcon = document.createElement('span');
    swIcon.className = 'dv-timeout-icon';
    swIcon.setAttribute('title', 'Timeout aktiv');
    swIcon.setAttribute('aria-hidden', 'true');
    swIcon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><polyline points="12 9 12 13 14.5 15.5"/><path d="M9 3h6M12 3v2"/></svg>';
    info.appendChild(swIcon);

    if (!isPastDay && slot) {
      var unblockBtn = _tdvMakeInlineBtn('Aufheben');
      (function(s, wasA) {
        unblockBtn.addEventListener('click', function() {
          if (wasA) {
            AppService.setSlotAvailability(s.slotId, 'available', function(e) {
              if (e) { Toast.error(e.message || e); }
              _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
            });
          } else {
            AppService.deleteSlot(s.slotId, function(e) {
              if (e) { Toast.error(e.message || e); }
              _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
            });
          }
        });
      })(slot, wasAvail);
      action.appendChild(unblockBtn);
    }

  } else if (status === 'disabled') {
    /* disabled slots treated as empty — delete to clean up legacy data */
    if (!isPastDay && slot) {
      var hint2 = document.createElement('span');
      hint2.className = 'dv-empty-hint';
      hint2.textContent = 'Kein Slot angelegt';
      info.appendChild(hint2);
      var cleanBtn = _tdvMakeInlineBtn('Hinzufügen');
      (function(s) {
        cleanBtn.addEventListener('click', function() {
          AppService.setSlotAvailability(s.slotId, 'available', function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(slot);
      action.appendChild(cleanBtn);
    }

  } else {
    /* empty — two inline buttons: Verfügbar + Timeout */
    var hint = document.createElement('span');
    hint.className = 'dv-empty-hint';
    hint.textContent = 'Kein Slot angelegt';
    info.appendChild(hint);
    if (!isPastDay) {
      var verfBtn = _tdvMakeInlineBtn('Hinzufügen');
      (function(t, ds) {
        verfBtn.addEventListener('click', function() {
          AppService.createSlot({
            teacherId: currentUser.uid, date: ds, time: t,
            status: 'available', baseStatus: 'available'
          }, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(time, dateStr);
      var toBtn = _tdvMakeInlineBtn('Timeout');
      (function(t, ds) {
        toBtn.addEventListener('click', function() {
          AppService.createSlot({
            teacherId: currentUser.uid, date: ds, time: t,
            status: 'timeout', baseStatus: 'timeout'
          }, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(time, dateStr);
      action.appendChild(verfBtn);
      action.appendChild(toBtn);
    }
  }

  if (isPastDay && status !== 'booked') {
    info.appendChild(_tdvMakePill('dv-pill-past', 'Vergangen'));
  }

  row.appendChild(timeCol);
  row.appendChild(sep);
  row.appendChild(info);
  row.appendChild(action);
  return row;
}

/* ── Booking detail modal ───────────────────────────────── */

/* ── Verfügbarkeit 2 row builder — same as V1 but booked = colored bg + expandable ── */
function _tdvBuildRowV2(slot, time, dateStr, isPastDay) {
  var _localTime = _tTeacherTime(time, dateStr);
  var endTime    = AppService.slotEndTime(_localTime);
  var status  = slot ? (slot.status || slot.baseStatus) : 'empty';

  /* Row classes */
  var rowClass = 'dv-slot-row ';
  if (isPastDay)              rowClass += 'dv-s-past';
  else if (status === 'booked')    rowClass += 'dv-s-booked dv-s-booked-v2';
  else if (status === 'available' || status === 'recurring') rowClass += 'dv-s-' + status;
  else if (status === 'timeout') {
    var _base2 = slot ? (slot.baseStatus || 'timeout') : 'timeout';
    var _wasAvail2 = (_base2 === 'available' || _base2 === 'recurring');
    rowClass += _wasAvail2 ? 'dv-s-timeout-avail' : 'dv-s-timeout';
  }
  else if (status === 'disabled')  rowClass += 'dv-s-empty'; /* disabled = visually empty */
  else                             rowClass += 'dv-s-empty';

  var row = document.createElement('div');
  row.className = rowClass.trim();
  row.setAttribute('role', 'listitem');

  /* Time column */
  var timeCol = document.createElement('div');
  timeCol.className = 'dv-slot-time';
  timeCol.setAttribute('aria-label', time + ' bis ' + endTime);
  var tStart = document.createElement('span');
  tStart.className = 'dv-time-start';
  tStart.textContent = _localTime;
  var tEnd = document.createElement('span');
  tEnd.className = 'dv-time-end';
  tEnd.textContent = '\u2013' + endTime;
  timeCol.appendChild(tStart);
  timeCol.appendChild(tEnd);

  /* Separator */
  var sep = document.createElement('div');
  sep.className = 'dv-slot-sep';
  sep.setAttribute('aria-hidden', 'true');

  /* Info column */
  var info = document.createElement('div');
  info.className = 'dv-slot-info';

  /* Action column */
  var action = document.createElement('div');
  action.className = 'dv-slot-action';

  /* ── Fill info + action by status (V2: booked = same as available + expandable) ── */
  if (status === 'booked' && slot) {
    /* ── Stacked avatars — mockup-_tdvBuildRowV2-stackedAvatars-2026-03-23_22-29 ── */
    var studentIds = (slot.students && slot.students.length) ? slot.students : (slot.studentId ? [slot.studentId] : []);
    var MAX_SHOWN  = 3;
    var stack      = document.createElement('div');
    stack.className = 'dv-v2-avatar-stack';

    for (var _ai = 0; _ai < Math.min(studentIds.length, MAX_SHOWN); _ai++) {
      (function(uid) {
        var avatarEl = document.createElement('div');
        avatarEl.className = 'dv-v2-avatar-stack-item';
        var photo = (typeof ProfileStore !== 'undefined') ? ProfileStore.getPhoto(uid) : null;
        if (photo) {
          avatarEl.innerHTML = '<img src="' + _esc(photo) + '" alt="">';
        } else {
          var n = AppService.getDisplayNameSync(uid);
          avatarEl.textContent = n ? n.charAt(0).toUpperCase() : '?';
        }
        stack.appendChild(avatarEl);
      })(studentIds[_ai]);
    }

    if (studentIds.length > MAX_SHOWN) {
      var more = document.createElement('div');
      more.className = 'dv-v2-avatar-stack-more';
      more.textContent = '+' + (studentIds.length - MAX_SHOWN);
      stack.appendChild(more);
    }

    info.appendChild(stack);

    /* Chevron to expand student list */
    var chevron = document.createElement('div');
    chevron.className = 'dv-chevron-v2';
    chevron.innerHTML = '<svg width="10" height="10" viewBox="0 0 16 16" fill="none"><path d="M6 4l4 4-4 4" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    action.appendChild(chevron);

    /* Expandable student list */
    var studentList = document.createElement('div');
    studentList.className = 'dv-v2-student-list is-hidden';
    var studentIds = (slot.students && slot.students.length) ? slot.students : (slot.studentId ? [slot.studentId] : []);
    for (var _vi = 0; _vi < studentIds.length; _vi++) {
      (function(uid) {
        var item = document.createElement('div');
        item.className = 'dv-v2-student-item';
        var avatar = document.createElement('div');
        avatar.className = 'dv-v2-avatar';
        var photo = (typeof ProfileStore !== 'undefined') ? ProfileStore.getPhoto(uid) : null;
        if (photo) {
          avatar.innerHTML = '<img src="' + _esc(photo) + '" alt="">';
        } else {
          var name2 = AppService.getDisplayNameSync(uid);
          avatar.textContent = name2 ? name2.charAt(0).toUpperCase() : '?';
        }
        var nameSpan = document.createElement('span');
        nameSpan.className = 'dv-v2-student-name';
        nameSpan.textContent = AppService.getDisplayNameSync(uid);
        /* Trash button */
        var trashBtn = document.createElement('button');
        trashBtn.className = 'dv-v2-trash';
        trashBtn.setAttribute('aria-label', 'Buchung stornieren');
        trashBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 20 20" fill="none"><path d="M3 6h14M8 6V4h4v2M5 6l1 11a1 1 0 001 1h6a1 1 0 001-1l1-11" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
        (function(stuId, s) {
          trashBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            _openV2CancelDialog(stuId, s);
          });
        })(uid, slot);
        item.appendChild(avatar);
        item.appendChild(nameSpan);
        item.appendChild(trashBtn);
        studentList.appendChild(item);
      })(studentIds[_vi]);
    }
    row.appendChild(studentList);

    /* Toggle on row click */
    row.style.flexDirection = 'column';
    row.style.alignItems = 'stretch';
    var rowTop = document.createElement('div');
    rowTop.className = 'dv-v2-row-top';
    rowTop.appendChild(timeCol);
    rowTop.appendChild(sep);
    rowTop.appendChild(info);
    rowTop.appendChild(action);
    row.appendChild(rowTop);
    row.appendChild(studentList);
    row.style.cursor = 'pointer';
    row.addEventListener('click', function(e) {
      /* Don't toggle if + button was clicked */
      if (e.target.closest('.dv-v2-add-btn')) return;
      var isOpen = !studentList.classList.contains('is-hidden');
      studentList.classList.toggle('is-hidden', isOpen);
      chevron.classList.toggle('dv-chevron-v2--open', !isOpen);
    });

    /* + button on booked rows too */
    if (!isPastDay) {
      var addBtnBooked = document.createElement('button');
      addBtnBooked.className = 'dv-v2-add-btn';
      addBtnBooked.setAttribute('aria-label', 'Schüler hinzufügen');
      addBtnBooked.innerHTML = '<svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      (function(s, ds) {
        addBtnBooked.addEventListener('click', function(e) {
          e.stopPropagation();
          var allSlots = AppService.getSlotsByTeacherDateSync(currentUser.uid, ds);
          buildBookingForm(s, ds, allSlots);
        });
      })(slot, dateStr);
      action.appendChild(addBtnBooked);
    }
    action.appendChild(chevron);

    return row;

  } else if (status === 'available' || status === 'recurring') {
    /* V2: color only — no pill, no buttons */

  } else if (status === 'timeout') {
    var base = slot ? (slot.baseStatus || 'timeout') : 'timeout';
    var wasAvail = (base === 'available' || base === 'recurring');

    if (wasAvail) {
      /* State 3: Verfügbar + Timeout — blue pill + stopwatch */
      info.appendChild(_tdvMakePill('dv-pill-available', 'Verfügbar'));
    } else {
      /* State 4: Timeout only (no availability) — just stopwatch, no pill */
      var toOnlyLabel = document.createElement('span');
      toOnlyLabel.className = 'dv-empty-hint';
      toOnlyLabel.textContent = 'Nicht verfügbar';
      info.appendChild(toOnlyLabel);
    }
    var swIcon = document.createElement('span');
    swIcon.className = 'dv-timeout-icon';
    swIcon.setAttribute('title', 'Timeout aktiv');
    swIcon.setAttribute('aria-hidden', 'true');
    swIcon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="13" r="8"/><polyline points="12 9 12 13 14.5 15.5"/><path d="M9 3h6M12 3v2"/></svg>';
    info.appendChild(swIcon);

    /* V2: color only — no buttons */

  } else if (status === 'disabled') {
    /* disabled slots treated as empty — delete to clean up legacy data */
    if (!isPastDay && slot) {
      var hint2 = document.createElement('span');
      hint2.className = 'dv-empty-hint';
      hint2.textContent = 'Kein Slot angelegt';
      info.appendChild(hint2);
      var cleanBtn = _tdvMakeInlineBtn('Hinzufügen');
      (function(s) {
        cleanBtn.addEventListener('click', function() {
          AppService.setSlotAvailability(s.slotId, 'available', function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(slot);
      action.appendChild(cleanBtn);
    }

  } else {
    /* empty — two inline buttons: Verfügbar + Timeout */
    var hint = document.createElement('span');
    hint.className = 'dv-empty-hint';
    hint.textContent = 'Kein Slot angelegt';
    info.appendChild(hint);
    if (!isPastDay) {
      var verfBtn = _tdvMakeInlineBtn('Hinzufügen');
      (function(t, ds) {
        verfBtn.addEventListener('click', function() {
          AppService.createSlot({
            teacherId: currentUser.uid, date: ds, time: t,
            status: 'available', baseStatus: 'available'
          }, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(time, dateStr);
      var toBtn = _tdvMakeInlineBtn('Timeout');
      (function(t, ds) {
        toBtn.addEventListener('click', function() {
          AppService.createSlot({
            teacherId: currentUser.uid, date: ds, time: t,
            status: 'timeout', baseStatus: 'timeout'
          }, function(e) {
            if (e) { Toast.error(e.message || e); }
            _tdvRenderSlots(); renderCalendar(); renderDayPanel(); if (activeTeacherView === 'all-bookings') renderAllBookings(); renderStudentList();
          });
        });
      })(time, dateStr);
      action.appendChild(verfBtn);
      action.appendChild(toBtn);
    }
  }

  if (isPastDay && status !== 'booked') {
    info.appendChild(_tdvMakePill('dv-pill-past', 'Vergangen'));
  }

  /* + button on all non-booked rows (booked rows have own return above) */
  if (!isPastDay) {
    var addBtnV2 = document.createElement('button');
    addBtnV2.className = 'dv-v2-add-btn';
    addBtnV2.setAttribute('aria-label', 'Schüler hinzufügen');
    addBtnV2.innerHTML = '<svg width="12" height="12" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
    (function(t, ds) {
      addBtnV2.addEventListener('click', function(e) {
        e.stopPropagation();
        var allSlots = AppService.getSlotsByTeacherDateSync(currentUser.uid, ds);
        var slotForTime = allSlots.filter(function(s) { return s.time === t; })[0];
        if (!slotForTime) {
          /* No slot yet — create then open form */
          AppService.createSlot({ teacherId: currentUser.uid, date: ds, time: t, status: 'available', baseStatus: 'available' }, function(err, newId) {
            if (err) { Toast.error(err.message || err); return; }
            var updated = AppService.getSlotsByTeacherDateSync(currentUser.uid, ds);
            var newSlot = updated.filter(function(s) { return s.slotId === newId; })[0];
            if (newSlot) buildBookingForm(newSlot, ds, updated);
          });
        } else {
          var allSlots2 = AppService.getSlotsByTeacherDateSync(currentUser.uid, ds);
          buildBookingForm(slotForTime, ds, allSlots2);
        }
      });
    })(time, dateStr);
    action.appendChild(addBtnV2);
  }

  row.appendChild(timeCol);
  row.appendChild(sep);
  row.appendChild(info);
  row.appendChild(action);
  return row;
}

/* ── Booking detail modal ───────────────────────────────── */
function _tdvOpenBookingDetail(slot) {
  var sName   = slot.studentId ? AppService.getDisplayNameSync(slot.studentId) : 'Unbekannt';
  var student = slot.studentId ? AppService.getUserSync(slot.studentId) : null;
  var endTime = AppService.slotEndTime(slot.time);

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info"><strong>' + _esc(sName) + '</strong></p>' +
      (student && student.email ? '<p>' + _esc(student.email) + '</p>' : '') +
      '<p>' + _esc(_tTeacherTime(slot.time, slot.date)) + ' – ' + _esc(_tTeacherEndTime(slot.time, slot.date)) + ' &nbsp;&bull;&nbsp; ' + _esc(slot.date) + '</p>' +
      (slot.confirmedAt ? '<p style="margin-top:8px;color:var(--status-confirmed-tx)">\u2713 Best\u00e4tigt</p>' : '') +
    '</div>';

  var footerHTML =
    '<button class="btn btn-ghost" id="modal-cancel">Schlie\u00dfen</button>' +
    (!slot.confirmedAt
      ? '<button class="btn btn-danger" id="modal-storno">Buchung stornieren</button>'
      : '');

  var result = Modal.show({ title: 'Buchungsdetail', bodyHTML: bodyHTML, footerHTML: footerHTML });
  document.getElementById('modal-cancel').addEventListener('click', result.close);

  var stornoEl = document.getElementById('modal-storno');
  if (stornoEl) {
    (function(s) {
      stornoEl.addEventListener('click', function() {
        AppService.cancelSlotWithPolicy(s.slotId, 'teacher', function(e) {
          if (e) { Toast.error(e.message || e); return; }
          result.close();
          _tdvRenderSlots();
          renderCalendar();
          renderDayPanel();
        });
      });
    })(slot);
  }
}

/* ── Helpers ─────────────────────────────────────────────── */
/* Generate all 48 half-hour slots 00:00 – 23:30 */
function _tdvBuildAllDayTimes() {
  var times = [];
  for (var h = 0; h < 24; h++) {
    times.push((h < 10 ? '0' : '') + h + ':00');
    times.push((h < 10 ? '0' : '') + h + ':30');
  }
  return times;
}

/* Small inline ghost button — reuses avail-row style */
function _tdvMakeInlineBtn(label) {
  var btn = document.createElement('button');
  btn.className = 'dv-inline-btn';
  btn.textContent = label;
  return btn;
}

function _tdvMakePill(cls, label) {
  var pill = document.createElement('span');
  pill.className = 'dv-pill ' + cls;
  pill.setAttribute('role', 'status');
  var dot = document.createElement('span');
  dot.className = 'dv-pill-dot';
  dot.setAttribute('aria-hidden', 'true');
  pill.appendChild(dot);
  pill.appendChild(document.createTextNode(label));
  return pill;
}

function _tdvMakeActionBtn(cls, label, svgHTML) {
  var btn = document.createElement('button');
  btn.className = 'dv-action-btn ' + cls;
  btn.setAttribute('aria-label', label);
  btn.innerHTML = svgHTML;
  return btn;
}

function _svgArrow() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>';
}
function _svgPlus() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>';
}
function _svgLock() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>';
}
function _svgRefresh() {
  return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>';
}
function _esc(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

/* Wire up overlay buttons — called from init after DOM ready */
function _tdvInitListeners() {
  document.getElementById('tdv-back-btn').addEventListener('click', closeTeacherDayView);
  document.getElementById('tdv-prev-day').addEventListener('click', function() {
    if (!_tdvDate) return;
    var d = new Date(_tdvDate);
    d.setDate(d.getDate() - 1);
    openTeacherDayView(d);
  });
  document.getElementById('tdv-next-day').addEventListener('click', function() {
    if (!_tdvDate) return;
    var d = new Date(_tdvDate);
    d.setDate(d.getDate() + 1);
    openTeacherDayView(d);
  });
}
