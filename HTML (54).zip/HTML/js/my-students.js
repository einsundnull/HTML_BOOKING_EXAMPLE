/**
 * my-students.js — Meine Schüler (Standalone-Page)
 *
 * Zeigt alle Schüler des eingeloggten Lehrers in Karten.
 * Pro Schüler: individuelle Preisanpassung (priceOverride auf der Selection).
 *
 * Wiederverwendete globals aus ui.js (geladen via app-config.js _PAGE_ASSETS):
 *   fmtDate, buildAvatarHTML, showProfileSheet, _fmtForUser, _esc,
 *   buildSearchInput, _calcBookingBlockCounts, Toast
 *
 * Keine Imports — IIFE-Pattern, globale Variable MyStudentsPage.
 * Regeln: var only, function(){}, no arrow functions, no template literals.
 */

var MyStudentsPage = (function() {
  'use strict';

  var _currentUser = null;
  var _searchQuery = '';

  /* ── Simple block-merge: consecutive half-hours same date = 1 block ── */
  function _mergeBlocks(dateStr, slots) {
    var sorted = slots.slice().sort(function(a, b) { return a.time < b.time ? -1 : 1; });
    var blocks = [];
    for (var i = 0; i < sorted.length; i++) {
      var s = sorted[i];
      var last = blocks.length ? blocks[blocks.length - 1] : null;
      if (last && last.date === s.date && last._endTime === s.time) {
        last._endTime = _halfHourAfter(s.time);
        last.bookedSlots.push(s);
        if (s.confirmedAt) last.isFullyConfirmed = true;
      } else {
        blocks.push({
          date:           s.date,
          bookedSlots:    [s],
          _endTime:       _halfHourAfter(s.time),
          isFullyConfirmed: !!s.confirmedAt
        });
      }
    }
    return blocks;
  }

  function _halfHourAfter(timeStr) {
    if (!timeStr) return timeStr;
    var parts = timeStr.split(':');
    var h = parseInt(parts[0], 10);
    var m = parseInt(parts[1], 10);
    m += 30;
    if (m >= 60) { m -= 60; h += 1; }
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  }

  /* ── Build a single student card ── */
  function _buildCard(student) {
    var today = fmtDate(new Date());
    var profile = AppService.getProfileOrDefaultSync(student.uid);
    var slots   = AppService.getSlotsByStudentSync(student.uid).filter(function(s) {
      return s.teacherId === _currentUser.uid && s.status === 'booked';
    });

    var counts = _calcBookingBlockCounts(slots, today, {
      mergeFn: _mergeBlocks,
      priceFn: function(s) { return parseFloat(s.price) || 0; }
    });

    /* Selection for this student — needed for priceOverride */
    var sel = AppService.getSelectionsByTeacherSync(_currentUser.uid).filter(function(s) {
      return s.studentId === student.uid;
    })[0] || null;

    var effectivePrice = AppService.getStudentPriceForTeacherSync(student.uid, _currentUser.uid);
    var defaultPrice   = AppService.getTeacherPriceSync(_currentUser.uid);
    var hasOverride    = sel && sel.priceOverride !== undefined && sel.priceOverride !== null && sel.priceOverride !== '';

    /* ── Card wrapper ── */
    var card = document.createElement('div');
    card.className = 'card student-card';
    card.setAttribute('data-uid', student.uid);

    /* ── Card top: avatar + name/subtitle + chevron ── */
    var cardTop = document.createElement('div');
    cardTop.className = 'student-card-top';
    cardTop.setAttribute('tabindex', '0');
    cardTop.setAttribute('role', 'button');

    var avatarWrap = document.createElement('div');
    avatarWrap.className = 'student-card-avatar';
    avatarWrap.innerHTML = buildAvatarHTML(student.uid, { size: 'md', role: 'student' });
    (function(uid) {
      avatarWrap.addEventListener('click', function(e) {
        e.stopPropagation();
        showProfileSheet(uid);
      });
    })(student.uid);

    var nameCol = document.createElement('div');
    nameCol.className = 'student-card-name-col';

    var nameEl = document.createElement('div');
    nameEl.className  = 'student-card-name';
    nameEl.textContent = AppService.getDisplayNameSync(student.uid);
    nameCol.appendChild(nameEl);

    var subtitle = (profile.location || '').trim() ||
      (profile.bio ? profile.bio.trim().slice(0, 40) + (profile.bio.length > 40 ? '\u2026' : '') : '');
    if (subtitle) {
      var subEl = document.createElement('div');
      subEl.className   = 'student-card-subtitle';
      subEl.textContent = subtitle;
      nameCol.appendChild(subEl);
    }

    var chevron = document.createElement('span');
    chevron.className = 'student-chevron';
    chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    cardTop.appendChild(avatarWrap);
    cardTop.appendChild(nameCol);
    cardTop.appendChild(chevron);

    /* ── Booking summary ── */
    var summaryEl = document.createElement('div');
    summaryEl.className = 'student-card-summary';
    summaryEl.textContent = counts.all + ' Buchung' + (counts.all !== 1 ? 'en' : '') +
      (counts.totalAll > 0 ? ' \u00b7 ' + _fmtForUser(counts.totalAll, _currentUser.uid) : '');

    /* ── Badge row ── */
    var badgeRow = document.createElement('div');
    badgeRow.className = 'student-card-badges';
    var badgeDefs = [
      { label: 'Alle',     val: counts.all,         total: counts.totalAll,         cls: '' },
      { label: 'Unbest.',  val: counts.unconfirmed,  total: counts.totalUnconfirmed,  cls: 'student-card-badge--pending' },
      { label: 'Best. \u2713', val: counts.confirmed, total: counts.totalConfirmed, cls: 'student-card-badge--confirmed' }
    ];
    badgeDefs.forEach(function(b) {
      if (b.val === 0) return;
      var chip = document.createElement('span');
      chip.className = 'student-card-badge ' + b.cls;
      var cntSpan = document.createElement('span');
      cntSpan.className = 'student-card-badge-count';
      cntSpan.textContent = b.val;
      chip.appendChild(document.createTextNode(b.label + ' '));
      chip.appendChild(cntSpan);
      if (b.total > 0) {
        var priceSpan = document.createElement('span');
        priceSpan.className = 'student-card-badge-price';
        priceSpan.textContent = ' ' + _fmtForUser(b.total, _currentUser.uid);
        chip.appendChild(priceSpan);
      }
      badgeRow.appendChild(chip);
    });

    /* ── Detail panel (expandable) ── */
    var detail = document.createElement('div');
    detail.className = 'student-booking-detail';

    /* ── Assemble card ── */
    card.appendChild(cardTop);
    card.appendChild(summaryEl);
    card.appendChild(badgeRow);
    card.appendChild(detail);

    /* ── Toggle expand ── */
    function _toggle() {
      var isOpen = detail.classList.contains('is-open');
      if (isOpen) {
        chevron.classList.remove('is-open');
        detail.classList.remove('is-open');
        detail.innerHTML = '';
      } else {
        chevron.classList.add('is-open');
        detail.classList.add('is-open');
        _populateDetail(detail, student, slots, sel, effectivePrice, defaultPrice, hasOverride);
      }
    }
    cardTop.addEventListener('click', _toggle);
    cardTop.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') _toggle();
    });

    return card;
  }

  /* ── Detail panel: price editor + booking list ── */
  function _populateDetail(detail, student, slots, sel, effectivePrice, defaultPrice, hasOverride) {
    detail.innerHTML = '';

    /* ── Price section ── */
    var priceSection = document.createElement('div');
    priceSection.className = 'ms-price-section';

    var priceHeader = document.createElement('div');
    priceHeader.className = 'ms-price-header';

    var priceLabel = document.createElement('span');
    priceLabel.className = 'ms-price-label';
    priceLabel.textContent = 'Preis pro 30 Min.';
    priceHeader.appendChild(priceLabel);

    var defaultBadge = document.createElement('span');
    defaultBadge.className = 'ms-price-default-badge' + (hasOverride ? ' is-hidden' : '');
    defaultBadge.id = 'ms-def-badge-' + student.uid;
    defaultBadge.textContent = 'Standardpreis';
    priceHeader.appendChild(defaultBadge);

    var overrideBadge = document.createElement('span');
    overrideBadge.className = 'ms-price-override-badge' + (hasOverride ? '' : ' is-hidden');
    overrideBadge.id = 'ms-ovr-badge-' + student.uid;
    overrideBadge.textContent = 'Individuell';
    priceHeader.appendChild(overrideBadge);

    priceSection.appendChild(priceHeader);

    /* Price input row */
    var priceRow = document.createElement('div');
    priceRow.className = 'ms-price-row';

    var priceInput = document.createElement('input');
    priceInput.type        = 'number';
    priceInput.className   = 'ms-price-input';
    priceInput.id          = 'ms-price-input-' + student.uid;
    priceInput.min         = '0';
    priceInput.step        = '0.50';
    priceInput.placeholder = String(defaultPrice || '0');
    priceInput.value       = hasOverride ? String(effectivePrice) : '';

    var priceHint = document.createElement('span');
    priceHint.className   = 'ms-price-hint';
    priceHint.id          = 'ms-price-hint-' + student.uid;
    priceHint.textContent = 'Standardpreis: ' + (defaultPrice || '0');

    var priceActions = document.createElement('div');
    priceActions.className = 'ms-price-actions';

    var saveBtn = document.createElement('button');
    saveBtn.type      = 'button';
    saveBtn.className = 'btn btn-sm btn-primary ms-price-save';
    saveBtn.textContent = 'Speichern';

    var resetBtn = document.createElement('button');
    resetBtn.type      = 'button';
    resetBtn.className = 'btn btn-sm btn-ghost ms-price-reset' + (hasOverride ? '' : ' is-hidden');
    resetBtn.id        = 'ms-reset-btn-' + student.uid;
    resetBtn.textContent = 'Zurücksetzen';

    priceActions.appendChild(saveBtn);
    priceActions.appendChild(resetBtn);

    priceRow.appendChild(priceInput);
    priceRow.appendChild(priceHint);
    priceRow.appendChild(priceActions);
    priceSection.appendChild(priceRow);

    /* ── Save handler ── */
    saveBtn.addEventListener('click', function() {
      var raw = priceInput.value.trim();
      var val = raw === '' ? null : parseFloat(raw);
      if (raw !== '' && (isNaN(val) || val < 0)) {
        Toast.error('Bitte einen gültigen Preis eingeben.');
        return;
      }
      var patch = { priceOverride: val };
      AppService.updateSelection(student.uid, _currentUser.uid, patch, function(err) {
        if (err) { Toast.error('Fehler beim Speichern.'); return; }
        Toast.success('Preis gespeichert.');
        /* Update badge visibility */
        var isNowOverride = val !== null;
        var defBadge = document.getElementById('ms-def-badge-' + student.uid);
        var ovrBadge = document.getElementById('ms-ovr-badge-' + student.uid);
        var rstBtn   = document.getElementById('ms-reset-btn-' + student.uid);
        if (defBadge) defBadge.className = 'ms-price-default-badge' + (isNowOverride ? ' is-hidden' : '');
        if (ovrBadge) ovrBadge.className = 'ms-price-override-badge' + (isNowOverride ? '' : ' is-hidden');
        if (rstBtn)   rstBtn.className   = 'btn btn-sm btn-ghost ms-price-reset' + (isNowOverride ? '' : ' is-hidden');
      });
    });

    /* ── Reset handler ── */
    resetBtn.addEventListener('click', function() {
      AppService.updateSelection(student.uid, _currentUser.uid, { priceOverride: null }, function(err) {
        if (err) { Toast.error('Fehler beim Zurücksetzen.'); return; }
        priceInput.value = '';
        Toast.success('Auf Standardpreis zurückgesetzt.');
        var defBadge = document.getElementById('ms-def-badge-' + student.uid);
        var ovrBadge = document.getElementById('ms-ovr-badge-' + student.uid);
        var rstBtn   = document.getElementById('ms-reset-btn-' + student.uid);
        if (defBadge) defBadge.className = 'ms-price-default-badge';
        if (ovrBadge) ovrBadge.className = 'ms-price-override-badge is-hidden';
        if (rstBtn)   rstBtn.className   = 'btn btn-sm btn-ghost ms-price-reset is-hidden';
      });
    });

    detail.appendChild(priceSection);

    /* ── Booking list ── */
    if (!slots.length) {
      var empty = document.createElement('p');
      empty.className   = 'text-muted student-bookings-empty';
      empty.textContent = 'Noch keine Buchungen.';
      detail.appendChild(empty);
      return;
    }

    var today = fmtDate(new Date());
    var byDate = {};
    var dateOrder = [];
    for (var i = 0; i < slots.length; i++) {
      var d = slots[i].date;
      if (!byDate[d]) { byDate[d] = []; dateOrder.push(d); }
      byDate[d].push(slots[i]);
    }
    dateOrder.sort();

    for (var di = 0; di < dateOrder.length; di++) {
      var dateStr  = dateOrder[di];
      var daySlots = byDate[dateStr].slice().sort(function(a, b) { return a.time < b.time ? -1 : 1; });

      var divider = document.createElement('div');
      divider.className = 'all-bookings-day-divider' + (dateStr < today ? ' all-bookings-day-divider-past' : '');
      divider.textContent = _formatDateLabel(dateStr);
      detail.appendChild(divider);

      for (var si = 0; si < daySlots.length; si++) {
        var s    = daySlots[si];
        var row  = document.createElement('div');
        var isPast = dateStr < today;
        row.className = 'student-booking-row' + (isPast ? ' is-past' : '') + (s.confirmedAt ? ' is-confirmed' : '');

        var timeEl = document.createElement('span');
        timeEl.className   = 'student-booking-time';
        timeEl.textContent = s.time + '\u2013' + _halfHourAfter(s.time);

        var priceEl = document.createElement('span');
        priceEl.className   = 'student-booking-price';
        priceEl.textContent = s.price ? _fmtForUser(parseFloat(s.price), _currentUser.uid) : '\u2014';

        var statusEl = document.createElement('span');
        statusEl.className   = 'student-booking-status';
        statusEl.textContent = s.confirmedAt ? 'Best. \u2713' : 'Unbest.';

        row.appendChild(timeEl);
        row.appendChild(priceEl);
        row.appendChild(statusEl);
        detail.appendChild(row);
      }
    }
  }

  function _halfHourAfter(timeStr) {
    if (!timeStr) return timeStr;
    var parts = timeStr.split(':');
    var h = parseInt(parts[0], 10);
    var m = parseInt(parts[1], 10);
    m += 30;
    if (m >= 60) { m -= 60; h += 1; }
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  }

  function _formatDateLabel(dateStr) {
    if (!dateStr) return dateStr;
    var parts = dateStr.split('-');
    var d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    var days   = ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'];
    var months = ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'];
    return days[d.getDay()] + ', ' + d.getDate() + '. ' + months[d.getMonth()] + ' ' + d.getFullYear();
  }

  /* ── Render the full student list ── */
  function _render() {
    var container = document.getElementById('my-students-list');
    if (!container) return;
    container.innerHTML = '';

    var selections = AppService.getSelectionsByTeacherSync(_currentUser.uid);
    var students   = [];
    for (var i = 0; i < selections.length; i++) {
      var u = AppService.getUserSync(selections[i].studentId);
      if (u) students.push(u);
    }

    /* Search filter */
    var q = _searchQuery.toLowerCase().trim();
    if (q) {
      students = students.filter(function(u) {
        return (AppService.getDisplayNameSync(u.uid) || '').toLowerCase().indexOf(q) !== -1;
      });
    }

    /* Search input */
    var searchWrap = document.createElement('div');
    searchWrap.innerHTML = buildSearchInput('ms-search', 'Schüler suchen\u2026');
    var searchEl = searchWrap.firstChild;
    container.appendChild(searchEl);

    var searchInput = document.getElementById('ms-search');
    if (searchInput) {
      searchInput.value = _searchQuery;
      searchInput.addEventListener('input', function() {
        _searchQuery = searchInput.value;
        _render();
      });
    }

    if (!students.length) {
      var empty = document.createElement('p');
      empty.className   = 'text-muted';
      empty.style.marginTop = '24px';
      empty.textContent = q ? 'Kein Schüler gefunden.' : 'Noch keine Schüler verknüpft.';
      container.appendChild(empty);
      return;
    }

    var frag = document.createDocumentFragment();
    for (var si = 0; si < students.length; si++) {
      frag.appendChild(_buildCard(students[si]));
    }
    container.appendChild(frag);
  }

  /* ── Init ── */
  function init() {
    _currentUser = Auth.require('teacher');
    if (!_currentUser) return;

    Navbar.init('teacher');

    /* Wait for AppService to be ready (adapter resolved on 'load') */
    _render();
  }

  return { init: init };
}());

window.addEventListener('load', function() {
  MyStudentsPage.init();
});
