/**
 * navbar.js — Universal Navbar
 *
 * Injiziert die Navbar in jede Seite.
 * Aufruf: Navbar.init() am Anfang jeder Seite — NACH store.js und auth.js.
 *
 * Erkennt automatisch:
 *  - Aktuellen User aus URL (?uid=)
 *  - Aktive Seite (highlight)
 *  - Rolle → passende Nav-Links
 */

var Navbar = {

  /* Nav-Links pro Rolle */
  _links: {
    admin: [
      { label: 'Users',     href: './admin.html',   page: 'admin'   }
    ],
    teacher: [
      { label: 'Calendar',  href: './teacher.html',  page: 'teacher' }
    ],
    student: [
      { label: 'Catalog',   href: './student.html',  page: 'catalog' },
      { label: 'Book',      href: './student.html',  page: 'book'    }
    ]
  },

  /**
   * Initialisiert die Navbar.
   * @param {string} activePage  - z.B. 'admin', 'teacher', 'catalog', 'book'
   */
  init: function(activePage) {
    var user = Auth.current();
    var self = this;

    // Inject CSS link if not already present
    if (!document.getElementById('navbar-css')) {
      var link = document.createElement('link');
      link.id   = 'navbar-css';
      link.rel  = 'stylesheet';
      link.href = './css/navbar.css';
      document.head.appendChild(link);
    }

    // Build navbar HTML
    var nav = document.createElement('nav');
    nav.className = 'navbar';
    nav.id        = 'main-navbar';

    var uid = user ? encodeURIComponent(user.uid) : '';

    // Links
    var linksHTML = '';
    if (user) {
      var roleLinks = self._links[user.role] || [];
      for (var i = 0; i < roleLinks.length; i++) {
        var l       = roleLinks[i];
        var href    = l.href + (uid ? '?uid=' + uid : '');
        var isActive = (activePage === l.page) ? ' active' : '';
        linksHTML += '<a class="navbar-link' + isActive + '" href="' + href + '">' + l.label + '</a>';
      }
    }

    // Badge class
    var badgeClass = user ? ('navbar-badge role-' + user.role) : 'navbar-badge';
    var badgeLabel = user ? user.role : '';
    var username   = user ? user.name : '';

    nav.innerHTML =
      '<div class="navbar-inner">'
        + '<a class="navbar-brand" href="./index.html">'
            + '<svg width="18" height="18" viewBox="0 0 20 20" fill="none">'
              + '<rect x="1" y="1" width="18" height="18" rx="4" stroke="currentColor" stroke-width="1.5"/>'
              + '<path d="M6 10h8M10 6v8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>'
            + '</svg>'
            + 'BookingSystem'
        + '</a>'
        + '<div class="navbar-links">' + linksHTML + '</div>'
        + '<div class="navbar-right">'
            + '<span class="navbar-username">' + username + '</span>'
            + '<span class="' + badgeClass + '">' + badgeLabel + '</span>'
            + '<button class="navbar-logout" id="navbar-logout">'
                + '<svg width="15" height="15" viewBox="0 0 16 16" fill="none">'
                  + '<path d="M10 2h3a1 1 0 011 1v10a1 1 0 01-1 1h-3M7 11l4-4-4-4M11 8H3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
                + '</svg>'
                + 'Sign out'
            + '</button>'
        + '</div>'
      + '</div>';

    // Insert as first child of body
    document.body.insertBefore(nav, document.body.firstChild);

    // Logout handler
    document.getElementById('navbar-logout').addEventListener('click', function() {
      Auth.logout();
    });
  }
};

window.Navbar = Navbar;
