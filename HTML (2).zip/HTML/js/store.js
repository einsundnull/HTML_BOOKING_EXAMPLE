/**
 * store.js — Central localStorage Service
 *
 * Schema:
 *   app_users      : [{ uid, name, role }]
 *   app_slots      : [{ slotId, teacherId, studentId, date, time, status }]
 *                    status: 'available' | 'booked' | 'disabled' | 'timeout'
 *   app_recurring  : [{ recurringId, teacherId, dayOfWeek (0=Mon…6=Sun), time }]
 *   app_selections : [{ studentId, teacherId }]
 *
 * SLOT_DURATION: 30 minutes (fixed, end = time + 30min)
 */

var SLOT_DURATION = 30;

var KEYS = {
  USERS:      'app_users',
  SLOTS:      'app_slots',
  RECURRING:  'app_recurring',
  SELECTIONS: 'app_selections'
};

function _load(key) {
  try {
    var raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) || []) : [];
  } catch(e) { return []; }
}

function _save(key, data) {
  try { localStorage.setItem(key, JSON.stringify(data)); } catch(e) {}
}

function _uuid() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

// Migrate old 'app_bookings' to 'app_slots'
(function migrateBookings() {
  try {
    var old = localStorage.getItem('app_bookings');
    if (!old) return;
    var bookings = JSON.parse(old) || [];
    if (!bookings.length) return;
    var existing = _load(KEYS.SLOTS);
    var seen = {};
    for (var i = 0; i < existing.length; i++) seen[existing[i].slotId] = true;
    for (var j = 0; j < bookings.length; j++) {
      var b = bookings[j];
      if (seen[b.bookingId]) continue;
      var status = b.status;
      if (status === 'blocked') status = 'disabled';
      existing.push({ slotId: b.bookingId, teacherId: b.teacherId, studentId: b.studentId || null, date: b.date, time: b.start, status: status });
    }
    _save(KEYS.SLOTS, existing);
    localStorage.removeItem('app_bookings');
  } catch(e) {}
})();

// Remove legacy session key
try { localStorage.removeItem('app_session'); } catch(e) {}

// Seed admin
(function seedAdmin() {
  var users = _load(KEYS.USERS);
  for (var i = 0; i < users.length; i++) {
    if (users[i].role === 'admin') return;
  }
  users.push({ uid: 'admin', name: 'Administrator', role: 'admin' });
  _save(KEYS.USERS, users);
})();

/* ── Time helpers ─────────────────────────────────────────── */
function slotEndTime(timeStr) {
  var parts = timeStr.split(':');
  var h = parseInt(parts[0], 10);
  var m = parseInt(parts[1], 10) + SLOT_DURATION;
  if (m >= 60) { h += 1; m -= 60; }
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}

function slotTimesInRange(startTime, endTime) {
  var times = [];
  var parts = startTime.split(':');
  var h = parseInt(parts[0], 10);
  var m = parseInt(parts[1], 10);
  while (true) {
    var t = String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
    if (t >= endTime) break;
    times.push(t);
    m += SLOT_DURATION;
    if (m >= 60) { h += 1; m -= 60; }
    if (h >= 24) break;
  }
  return times;
}

/* ── Users ────────────────────────────────────────────────── */
var Users = {
  all: function() { return _load(KEYS.USERS); },
  byUid: function(uid) {
    var users = this.all();
    for (var i = 0; i < users.length; i++) {
      if (users[i].uid.trim() === uid.trim()) return users[i];
    }
    return null;
  },
  byRole: function(role) { return this.all().filter(function(u) { return u.role === role; }); },
  create: function(opts) {
    var users = this.all();
    for (var i = 0; i < users.length; i++) {
      if (users[i].uid === opts.uid) throw new Error('UID "' + opts.uid + '" already exists.');
    }
    if (!opts.uid || !opts.name || !opts.role) throw new Error('UID, name and role are required.');
    var user = { uid: opts.uid.trim(), name: opts.name.trim(), role: opts.role };
    users.push(user);
    _save(KEYS.USERS, users);
    return user;
  },
  delete: function(uid) {
    if (uid === 'admin') throw new Error('Cannot delete the admin account.');
    var users = this.all();
    var found = false;
    for (var i = 0; i < users.length; i++) { if (users[i].uid === uid) { found = true; break; } }
    if (!found) throw new Error('User not found.');
    _save(KEYS.USERS, users.filter(function(u) { return u.uid !== uid; }));
    Selections.deleteByUser(uid);
    Slots.deleteByUser(uid);
    Recurring.deleteByTeacher(uid);
  }
};

/* ── Slots ────────────────────────────────────────────────── */
var Slots = {
  all: function() { return _load(KEYS.SLOTS); },
  byTeacher: function(tid) { return this.all().filter(function(s) { return s.teacherId === tid; }); },
  byStudent: function(sid) { return this.all().filter(function(s) { return s.studentId === sid; }); },
  byTeacherDate: function(tid, date) {
    return this.byTeacher(tid).filter(function(s) { return s.date === date; })
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
  },
  exists: function(tid, date, time) {
    var list = this.all();
    for (var i = 0; i < list.length; i++) {
      if (list[i].teacherId === tid && list[i].date === date && list[i].time === time) return list[i];
    }
    return null;
  },
  create: function(opts) {
    var slots = this.all();
    var st   = opts.status || 'available';
    var base = opts.baseStatus || (st === 'booked' ? 'available' : st);
    var slot = { slotId: _uuid(), teacherId: opts.teacherId, studentId: opts.studentId || null, date: opts.date, time: opts.time, status: st, baseStatus: base };
    slots.push(slot);
    _save(KEYS.SLOTS, slots);
    return slot;
  },
  createRange: function(tid, date, startTime, endTime, status) {
    var times = slotTimesInRange(startTime, endTime);
    var count = 0;
    for (var i = 0; i < times.length; i++) {
      if (!this.exists(tid, date, times[i])) { this.create({ teacherId: tid, date: date, time: times[i], status: status || 'available' }); count++; }
    }
    return count;
  },
  update: function(slotId, patch) {
    var slots = this.all().map(function(s) {
      if (s.slotId !== slotId) return s;
      var u = {}; for (var k in s) u[k] = s[k]; for (var p in patch) u[p] = patch[p]; return u;
    });
    _save(KEYS.SLOTS, slots);
  },
  /* Set availability — updates both status and baseStatus.
     Recurring rule management is handled by the caller
     since store.js does not have access to dayOfWeek here.
     Use setAvailabilityWithRecurring() from teacher.js instead. */
  setAvailability: function(slotId, newBase) {
    var slots = this.all().map(function(s) {
      if (s.slotId !== slotId) return s;
      var u = {}; for (var k in s) u[k] = s[k];
      u.baseStatus = newBase;
      if (!u.studentId) u.status = newBase;
      return u;
    });
    _save(KEYS.SLOTS, slots);
  },
  /* Cancel a booking — restore status to baseStatus */
  cancelBooking: function(slotId) {
    var slots = this.all().map(function(s) {
      if (s.slotId !== slotId) return s;
      var u = {}; for (var k in s) u[k] = s[k];
      u.studentId = null;
      u.status    = u.baseStatus || 'available';
      return u;
    });
    _save(KEYS.SLOTS, slots);
  },
  /* Book a slot — sets status booked, preserves baseStatus */
  bookSlot: function(slotId, studentId) {
    var slots = this.all().map(function(s) {
      if (s.slotId !== slotId) return s;
      var u = {}; for (var k in s) u[k] = s[k];
      u.studentId  = studentId;
      u.status     = 'booked';
      if (!u.baseStatus) u.baseStatus = 'available';
      return u;
    });
    _save(KEYS.SLOTS, slots);
  },
  delete: function(slotId) { _save(KEYS.SLOTS, this.all().filter(function(s) { return s.slotId !== slotId; })); },
  deleteByUser: function(uid) { _save(KEYS.SLOTS, this.all().filter(function(s) { return s.teacherId !== uid && s.studentId !== uid; })); }
};

/* ── Migration: add baseStatus to legacy slots ─────────────── */
(function() {
  var slots = _load(KEYS.SLOTS);
  var changed = false;
  for (var i = 0; i < slots.length; i++) {
    if (!slots[i].baseStatus) {
      changed = true;
      if (slots[i].status === 'booked') {
        slots[i].baseStatus = 'available';
      } else {
        slots[i].baseStatus = slots[i].status;
      }
    }
  }
  if (changed) _save(KEYS.SLOTS, slots);
})();

/* ── Recurring ────────────────────────────────────────────── */
var Recurring = {
  all: function() { return _load(KEYS.RECURRING); },
  byTeacher: function(tid) { return this.all().filter(function(r) { return r.teacherId === tid; }); },
  exists: function(tid, dayOfWeek, time) {
    var list = this.all();
    for (var i = 0; i < list.length; i++) {
      if (list[i].teacherId === tid && list[i].dayOfWeek === dayOfWeek && list[i].time === time) return list[i];
    }
    return null;
  },
  create: function(tid, dayOfWeek, time) {
    if (this.exists(tid, dayOfWeek, time)) return;
    var list = this.all();
    list.push({ recurringId: _uuid(), teacherId: tid, dayOfWeek: dayOfWeek, time: time });
    _save(KEYS.RECURRING, list);
  },
  delete: function(recurringId) { _save(KEYS.RECURRING, this.all().filter(function(r) { return r.recurringId !== recurringId; })); },
  deleteByTeacherDayTime: function(tid, dayOfWeek, time) {
    _save(KEYS.RECURRING, this.all().filter(function(r) {
      return !(r.teacherId === tid && r.dayOfWeek === dayOfWeek && r.time === time);
    }));
  },
  deleteByTeacher: function(tid) { _save(KEYS.RECURRING, this.all().filter(function(r) { return r.teacherId !== tid; })); },

  /**
   * Materialise recurring rules for a given week into app_slots.
   * weekDates: array of 7 Date objects (Mon–Sun)
   * For each recurring rule, if no slot exists for that date+time, create one as 'available'.
   * Existing slots (including timeouts) are NOT overwritten.
   */
  materialiseWeek: function(tid, weekDates) {
    var rules = this.byTeacher(tid);
    for (var i = 0; i < rules.length; i++) {
      var rule = rules[i];
      var date = weekDates[rule.dayOfWeek];
      if (!date) continue;
      var dateStr = _fmtDate(date);
      if (!Slots.exists(tid, dateStr, rule.time)) {
        Slots.create({ teacherId: tid, date: dateStr, time: rule.time, status: 'available', baseStatus: 'available' });
      }
    }
  }
};

function _fmtDate(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}

/* ── Selections ───────────────────────────────────────────── */
var Selections = {
  all: function() { return _load(KEYS.SELECTIONS); },
  byStudent: function(sid) { return this.all().filter(function(s) { return s.studentId === sid; }); },
  byTeacher: function(tid) { return this.all().filter(function(s) { return s.teacherId === tid; }); },
  exists: function(sid, tid) {
    var list = this.all();
    for (var i = 0; i < list.length; i++) { if (list[i].studentId === sid && list[i].teacherId === tid) return true; }
    return false;
  },
  create: function(sid, tid) {
    if (this.exists(sid, tid)) return;
    var list = this.all(); list.push({ studentId: sid, teacherId: tid }); _save(KEYS.SELECTIONS, list);
  },
  delete: function(sid, tid) { _save(KEYS.SELECTIONS, this.all().filter(function(s) { return !(s.studentId === sid && s.teacherId === tid); })); },
  deleteByUser: function(uid) { _save(KEYS.SELECTIONS, this.all().filter(function(s) { return s.studentId !== uid && s.teacherId !== uid; })); }
};

window.Store = {
  Users: Users, Slots: Slots, Recurring: Recurring, Selections: Selections,
  slotEndTime: slotEndTime, slotTimesInRange: slotTimesInRange, SLOT_DURATION: SLOT_DURATION,
  Bookings: Slots // backwards compat
};
