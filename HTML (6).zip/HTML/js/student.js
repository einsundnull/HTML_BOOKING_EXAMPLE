/**
 * student.js — Student View
 *
 * Booking via week grid (same layout as teacher).
 * Cell states (student perspective):
 *   gc-available  — green,  clickable → book instantly
 *   gc-mine       — navy,   clickable → cancel
 *   gc-empty      — grey,   not clickable
 */

var currentUser     = null;
var activeView      = 'catalog';
var activeTeacherId = null;

var sgridWeekStart  = null;

var viewYear        = 0;
var viewMonth       = 0;
var selectedDate    = null;

var _dayNavStickyActive = false;

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START  = '06:00';
var GRID_END    = '22:00';

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('student');
  if (!currentUser) return;
  Navbar.init('catalog');

  document.getElementById('nav-catalog').addEventListener('click', function() { switchView('catalog'); });
  document.getElementById('nav-calendar').addEventListener('click', function() { switchView('calendar'); });
  document.getElementById('nav-my-bookings').addEventListener('click', function() { switchView('my-bookings'); });
  document.getElementById('sgrid-close-btn').addEventListener('click', closeStudentGrid);
  document.getElementById('sgrid-prev-week').addEventListener('click', sgridPrevWeek);
  document.getElementById('sgrid-next-week').addEventListener('click', sgridNextWeek);
  document.getElementById('sgrid-save-btn').addEventListener('click', commitSgridChanges);
  document.getElementById('sgrid-dismiss-btn').addEventListener('click', discardSgridChanges);

  var now   = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();

  renderStats();
  switchView('catalog');
});

/* ── View switcher ──────────────────────────────────────── */
function switchView(view) {
  activeView = view;
  document.getElementById('nav-catalog').classList.toggle('active', view === 'catalog');
  document.getElementById('nav-calendar').classList.toggle('active', view === 'calendar');
  document.getElementById('nav-my-bookings').classList.toggle('active', view === 'my-bookings');
  document.getElementById('view-catalog').classList.toggle('view-hidden', view !== 'catalog');
  document.getElementById('view-calendar').classList.toggle('view-hidden', view !== 'calendar');
  document.getElementById('view-my-bookings').classList.toggle('view-hidden', view !== 'my-bookings');
  if (view === 'catalog')    renderCatalog();
  if (view === 'calendar')   renderTeacherPicker();
  if (view === 'my-bookings') renderMyBookings();
}

/* ── Stats ──────────────────────────────────────────────── */
function renderStats() {
  var selections = Store.Selections.byStudent(currentUser.uid);
  var bookings   = Store.Slots.byStudent(currentUser.uid).filter(function(s) { return s.status === 'booked'; });
  document.getElementById('stat-teachers').textContent = selections.length;
  document.getElementById('stat-bookings').textContent = bookings.length;
}

/* ══════════════════════════════════════════════════════════
   CATALOG
══════════════════════════════════════════════════════════ */
function renderCatalog() {
  var allTeachers  = Store.Users.byRole('teacher');
  var mySelections = Store.Selections.byStudent(currentUser.uid).map(function(s) { return s.teacherId; });
  var container    = document.getElementById('catalog-grid');
  container.innerHTML = '';

  if (!allTeachers.length) {
    var empty = document.createElement('div');
    empty.className = 'catalog-empty text-muted';
    empty.textContent = 'No teachers available yet.';
    container.appendChild(empty);
    return;
  }

  for (var i = 0; i < allTeachers.length; i++) {
    container.appendChild(buildTeacherCard(allTeachers[i], mySelections));
  }
}

function buildTeacherCard(teacher, mySelections) {
  var isSelected = mySelections.indexOf(teacher.uid) !== -1;
  var availCount = Store.Slots.byTeacher(teacher.uid).filter(function(s) { return s.status === 'available'; }).length;

  var card = document.createElement('div');
  card.className = 'card teacher-card' + (isSelected ? ' teacher-card-selected' : '');

  var top = document.createElement('div');
  top.className = 'teacher-card-top';

  var nameWrap = document.createElement('div');
  var name = document.createElement('div');
  name.className = 'teacher-card-name';
  name.textContent = teacher.name;
  var uid = document.createElement('code');
  uid.className = 'uid-badge';
  uid.textContent = teacher.uid;
  nameWrap.appendChild(name);
  nameWrap.appendChild(uid);
  top.appendChild(nameWrap);

  if (isSelected) {
    var badge = document.createElement('span');
    badge.className = 'teacher-selected-badge';
    badge.textContent = 'Selected';
    top.appendChild(badge);
  }

  var avail = document.createElement('div');
  avail.className = 'teacher-card-avail text-muted';
  avail.textContent = availCount + ' available slot' + (availCount !== 1 ? 's' : '');

  var actions = document.createElement('div');
  actions.className = 'teacher-card-actions';

  if (isSelected) {
    var viewBtn = document.createElement('button');
    viewBtn.className = 'btn btn-secondary btn-sm';
    viewBtn.textContent = 'Book lessons';
    (function(tid) { viewBtn.addEventListener('click', function() { openTeacherGrid(tid); }); })(teacher.uid);

    var removeBtn = document.createElement('button');
    removeBtn.className = 'btn btn-ghost btn-sm';
    removeBtn.textContent = 'Remove';
    (function(tid) { removeBtn.addEventListener('click', function() { deselectTeacher(tid); }); })(teacher.uid);

    actions.appendChild(viewBtn);
    actions.appendChild(removeBtn);
  } else {
    var selectBtn = document.createElement('button');
    selectBtn.className = 'btn btn-primary btn-sm';
    selectBtn.textContent = 'Select';
    (function(tid) { selectBtn.addEventListener('click', function() { selectTeacher(tid); }); })(teacher.uid);
    actions.appendChild(selectBtn);
  }

  card.appendChild(top);
  card.appendChild(avail);
  card.appendChild(actions);
  return card;
}

function selectTeacher(teacherId) {
  Store.Selections.create(currentUser.uid, teacherId);
  Toast.success(Store.Users.byUid(teacherId).name + ' added to your teachers.');
  renderStats();
  renderCatalog();
}

function deselectTeacher(teacherId) {
  Store.Selections.delete(currentUser.uid, teacherId);
  Toast.success(Store.Users.byUid(teacherId).name + ' removed.');
  renderStats();
  renderCatalog();
}

function openTeacherGrid(teacherId, jumpDate) {
  activeTeacherId = teacherId;
  if (jumpDate) {
    selectedDate = jumpDate;
    viewYear     = jumpDate.getFullYear();
    viewMonth    = jumpDate.getMonth();
  } else {
    selectedDate = null;
  }
  switchView('calendar');
}

/* ══════════════════════════════════════════════════════════
   TEACHER PICKER (calendar view top)
══════════════════════════════════════════════════════════ */
function renderTeacherPicker() {
  var myTeachers = Store.Selections.byStudent(currentUser.uid)
    .map(function(s) { return Store.Users.byUid(s.teacherId); })
    .filter(function(t) { return t !== null; });

  var picker = document.getElementById('teacher-picker');
  picker.innerHTML = '';

  if (!myTeachers.length) {
    var p = document.createElement('p');
    p.className = 'text-muted';
    p.textContent = 'No teachers selected yet. Go to the catalog first.';
    picker.appendChild(p);
    document.getElementById('cal-section').classList.add('view-hidden');
    return;
  }

  if (!activeTeacherId) activeTeacherId = myTeachers[0].uid;

  var wrap = document.createElement('div');
  wrap.className = 'teacher-picker-wrap';

  var label = document.createElement('label');
  label.className = 'form-label';
  label.setAttribute('for', 'teacher-select');
  label.textContent = 'Teacher';

  var select = document.createElement('select');
  select.className = 'form-select';
  select.id = 'teacher-select';

  for (var i = 0; i < myTeachers.length; i++) {
    var opt = document.createElement('option');
    opt.value = myTeachers[i].uid;
    opt.textContent = myTeachers[i].name;
    if (myTeachers[i].uid === activeTeacherId) opt.selected = true;
    select.appendChild(opt);
  }

  select.addEventListener('change', function(e) {
    activeTeacherId = e.target.value;
  });

  var weekBtn = document.createElement('button');
  weekBtn.className = 'btn btn-secondary btn-sm';
  weekBtn.textContent = 'Week view';
  weekBtn.addEventListener('click', openStudentGrid);

  wrap.appendChild(label);
  wrap.appendChild(select);
  wrap.appendChild(weekBtn);
  picker.appendChild(wrap);

  document.getElementById('cal-section').classList.remove('view-hidden');

  // Re-bind prev/next each time picker renders
  var prevBtn = document.getElementById('prev-btn');
  var nextBtn = document.getElementById('next-btn');
  var newPrev = prevBtn.cloneNode(true);
  var newNext = nextBtn.cloneNode(true);
  prevBtn.parentNode.replaceChild(newPrev, prevBtn);
  nextBtn.parentNode.replaceChild(newNext, nextBtn);
  newPrev.addEventListener('click', prevMonth);
  newNext.addEventListener('click', nextMonth);

  renderCalendar();
  renderDaySlots();
}

/* ══════════════════════════════════════════════════════════
   STUDENT WEEK GRID OVERLAY
══════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════
   MONTH CALENDAR
══════════════════════════════════════════════════════════ */
function renderCalendar() {
  var calSection = document.getElementById('cal-section');
  if (!calSection) return;

  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;
  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow     = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeDayCell(prevDays - i, true));
  }
  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isPast  = date < TODAY;
      var isToday = date.getTime() === TODAY.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots   = activeTeacherId ? Store.Slots.byTeacherDate(activeTeacherId, dateStr) : [];
      var hasAvail  = !isPast && slots.some(function(s) { return s.status === 'available' || s.status === 'recurring'; });
      var hasMyBook = slots.some(function(s) { return s.status === 'booked' && s.studentId === currentUser.uid; });

      var cell = makeDayCell(day, false, isToday, isSel, hasAvail, hasMyBook);
      if (!isPast) {
        cell.setAttribute('tabindex', '0');
        cell.addEventListener('click', function() { selectedDate = date; renderCalendar(); renderDaySlots(); });
        cell.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') { selectedDate = date; renderCalendar(); renderDaySlots(); } });
      }
      grid.appendChild(cell);
    })(d);
  }
  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeDayCell(t, true));
  }
}

function makeDayCell(num, otherMonth, isToday, isSelected, hasAvail, hasMyBook) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth) el.classList.add('other-month');
  if (isToday)    el.classList.add('today');
  if (isSelected) el.classList.add('selected');
  if (hasAvail)   el.classList.add('has-avail');
  if (hasMyBook)  el.classList.add('has-mybook');
  el.textContent = num;
  return el;
}

function prevMonth() {
  viewMonth--;
  if (viewMonth < 0) { viewMonth = 11; viewYear--; }
  renderCalendar();
  renderDaySlots();
}
function nextMonth() {
  viewMonth++;
  if (viewMonth > 11) { viewMonth = 0; viewYear++; }
  renderCalendar();
  renderDaySlots();
}

/* ══════════════════════════════════════════════════════════
   DAY SLOT LIST
══════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════
   DAY SLOTS — collapsed blocks with expand
══════════════════════════════════════════════════════════ */

// Track which day-slot blocks are open { blockKey: bool }
var expandedDayBlocks = {};

// Pending booking changes — staged, not yet written to Store
// { slotId: { action:'book'|'cancel', originalSlot:{...}, newStudentId:uid|null } }
var pendingDayChanges = {};

/* Return effective slot state — pending overrides Store */
function getEffectiveSlot(storeSlot) {
  var p = pendingDayChanges[storeSlot.slotId];
  if (!p) return storeSlot;
  var s = {}; for (var k in storeSlot) s[k] = storeSlot[k];
  if (p.action === 'book') {
    s.status    = 'booked';
    s.studentId = p.newStudentId;
    s._pending  = 'book';
  } else {
    // Keep original status/studentId so it stays visible as a booked block
    // Only mark as pending — amber shows, Cancel button stays
    s._pending  = 'cancel';
  }
  return s;
}

/* Return effective slots for a teacher+date — merges Store + pending */
function getEffectiveSlots(teacherId, dateStr) {
  var slots = Store.Slots.byTeacherDate(teacherId, dateStr);
  return slots.map(function(s) { return getEffectiveSlot(s); });
}

function checkDayNavSticky() {
  var bar      = document.getElementById('day-nav-bar');
  var sentinel = document.getElementById('day-nav-sentinel');
  if (!bar || !sentinel || !bar.classList.contains('is-visible')) return;
  var navbarH = 52;
  var rect = sentinel.getBoundingClientRect();
  var shouldBeSticky = rect.top < navbarH;
  if (shouldBeSticky === _dayNavStickyActive) return;
  _dayNavStickyActive = shouldBeSticky;
  bar.classList.toggle('is-sticky', shouldBeSticky);
  if (shouldBeSticky) {
    var parent = document.getElementById('day-slots-wrapper');
    if (parent) {
      var pr = parent.getBoundingClientRect();
      bar.style.left  = pr.left + 'px';
      bar.style.width = pr.width + 'px';
      bar.style.right = 'auto';
    }
    sentinel.style.height = bar.offsetHeight + 'px';
  } else {
    bar.style.left  = '';
    bar.style.width = '';
    bar.style.right = '';
    sentinel.style.height = '0';
  }
}

function updateDayNavBar() {
  var bar      = document.getElementById('day-nav-bar');
  var label    = document.getElementById('day-nav-label');
  if (!bar || !label) return;

  if (!selectedDate) {
    bar.classList.remove('is-visible');
    bar.classList.remove('is-sticky');
    _dayNavStickyActive = false;
    return;
  }

  bar.classList.add('is-visible');
  label.textContent = selectedDate.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

  checkDayNavSticky();
}

function navDay(delta) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setDate(d.getDate() + delta);
  selectedDate = d;
  if (d.getFullYear() !== viewYear || d.getMonth() !== viewMonth) {
    viewYear  = d.getFullYear();
    viewMonth = d.getMonth();
  }
  updateDayNavBar();
  renderCalendar();
  renderDaySlots();
}

function navMonth(delta) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setMonth(d.getMonth() + delta);
  selectedDate = d;
  viewYear  = d.getFullYear();
  viewMonth = d.getMonth();
  updateDayNavBar();
  renderCalendar();
  renderDaySlots();
}

function renderDaySlots() {
  updateDayNavBar();
  var container = document.getElementById('day-slots');
  if (!container) return;
  container.innerHTML = '';
  if (!selectedDate || !activeTeacherId) return;

  var dateStr = fmtDate(selectedDate);
  var slots   = getEffectiveSlots(activeTeacherId, dateStr);
  var label   = selectedDate.toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' });

  var card = document.createElement('div');
  card.className = 'card day-slots-card';

  var heading = document.createElement('div');
  heading.className = 'day-slots-heading';
  heading.textContent = label;
  card.appendChild(heading);

  // Show available + own booked (including pending changes)
  var visible = slots.filter(function(s) {
    if (s.status === 'available' || s.status === 'recurring') return true;
    if (s.status === 'booked' && s.studentId === currentUser.uid) return true;
    return false;
  });

  if (!visible.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted day-slots-empty';
    empty.textContent = 'No available slots on this day.';
    card.appendChild(empty);
    container.appendChild(card);
    return;
  }

  var list = document.createElement('div');
  list.className = 'day-slot-list';

  // Split into groups: render available slots individually,
  // merge consecutive booked (mine) slots into collapsible blocks
  var i = 0;
  while (i < visible.length) {
    var slot   = visible[i];
    var isMine = slot.status === 'booked' && slot.studentId === currentUser.uid;

    if (isMine) {
      // Merge consecutive mine slots into one block
      var end  = Store.slotEndTime(slot.time);
      var grp  = [slot];
      var j    = i + 1;
      while (j < visible.length) {
        var next = visible[j];
        var nextMine = next.status === 'booked' && next.studentId === currentUser.uid;
        if (nextMine && next.time === end) {
          end = Store.slotEndTime(next.time);
          grp.push(next);
          j++;
        } else { break; }
      }
      list.appendChild(buildMineDayBlock({ start: slot.time, end: end, slots: grp }));
      i = j;
    } else {
      // Available — single row with Book button
      list.appendChild(buildAvailableDayRow(slot));
      i++;
    }
  }

  card.appendChild(list);
  container.appendChild(card);
}

/* Available slot — simple row: time + Book button */
function buildAvailableDayRow(slot) {
  var row = document.createElement('div');
  row.className = 'day-slot-row' + (slot._pending ? ' slot-pending' : '');

  var timeEl = document.createElement('span');
  timeEl.className = 'day-slot-time';
  timeEl.textContent = slot.time + ' – ' + Store.slotEndTime(slot.time);

  var btn = document.createElement('button');
  btn.className = 'btn btn-primary btn-sm';
  btn.textContent = 'Book';
  (function(s) {
    btn.addEventListener('click', function() { bookDaySlot(s.slotId); });
  })(slot);

  row.appendChild(timeEl);
  row.appendChild(btn);
  return row;
}

/* Booked block — collapsible, navy header, Cancel per slot inside */
function buildMineDayBlock(block) {
  var blockKey = 'mine-' + block.start;
  var isOpen   = !!expandedDayBlocks[blockKey];

  var wrapper = document.createElement('div');
  wrapper.className = 'day-block-wrapper';

  var header = document.createElement('div');
  header.className = 'day-block-header day-block-mine' + (block.slots.some(function(s){ return s._pending; }) ? ' block-pending' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'day-block-time';
  timeEl.textContent = block.start + ' – ' + block.end;

  var metaEl = document.createElement('span');
  metaEl.className = 'day-block-meta';
  metaEl.textContent = block.slots.length + ' slot' + (block.slots.length !== 1 ? 's' : '');

  var chevron = document.createElement('span');
  chevron.className = 'day-block-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  header.appendChild(timeEl);
  header.appendChild(metaEl);
  header.appendChild(chevron);

  var detail = document.createElement('div');
  detail.className = 'day-block-detail day-block-detail-mine' + (isOpen ? ' is-open' : '');
  if (isOpen) populateMineDetail(detail, block.slots);

  function toggle() {
    if (expandedDayBlocks[blockKey]) {
      delete expandedDayBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedDayBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateMineDetail(detail, block.slots);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

function populateMineDetail(detail, slots) {
  detail.innerHTML = '';
  for (var i = 0; i < slots.length; i++) {
    var slot = slots[i];
    var row  = document.createElement('div');
    row.className = 'day-block-slot-row' + (slot._pending ? ' slot-pending' : '');

    var timeEl = document.createElement('span');
    timeEl.className = 'day-block-slot-time';
    timeEl.textContent = slot.time + ' – ' + Store.slotEndTime(slot.time);

    var teacherEl = document.createElement('span');
    teacherEl.className = 'my-booking-slot-teacher';
    var tObj = Store.Users.byUid(slot.teacherId);
    teacherEl.textContent = tObj ? tObj.name : slot.teacherId;

    var btn = document.createElement('button');
    btn.className = 'btn btn-danger btn-sm';
    btn.textContent = slot._pending === 'cancel' ? 'Undo' : 'Cancel';
    (function(s) {
      btn.addEventListener('click', function(e) { e.stopPropagation(); cancelDaySlot(s.slotId, s.time); });
    })(slot);

    row.appendChild(timeEl);
    row.appendChild(teacherEl);
    row.appendChild(btn);
    detail.appendChild(row);
  }
}

function bookDaySlot(slotId) {
  var original = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
  var existing = pendingDayChanges[slotId];
  if (existing && existing.action === 'cancel') {
    delete pendingDayChanges[slotId];
  } else {
    pendingDayChanges[slotId] = { action: 'book', originalSlot: original, newStudentId: currentUser.uid };
    if (original && original.time) {
      // Find the group start: walk back through consecutive mine/pending-book slots
      var dateStr  = fmtDate(selectedDate);
      var allSlots = getEffectiveSlots(original.teacherId, dateStr);
      var groupStart = original.time;
      for (var gi = 0; gi < allSlots.length; gi++) {
        if (allSlots[gi].time === original.time) {
          // Walk back to find group start
          var idx = gi;
          while (idx > 0) {
            var prev = allSlots[idx - 1];
            var prevMine = (prev.status === 'booked' && prev.studentId === currentUser.uid) || (prev._pending === 'book');
            if (prevMine && Store.slotEndTime(prev.time) === allSlots[idx].time) {
              groupStart = prev.time;
              idx--;
            } else { break; }
          }
          break;
        }
      }
      expandedDayBlocks['mine-' + groupStart] = true;
    }
  }
  updateDaySaveBtn();
  renderStats();
  renderCalendar();
  renderDaySlots();
}

function cancelDaySlot(slotId, time) {
  var existing = pendingDayChanges[slotId];
  if (existing) {
    delete pendingDayChanges[slotId];
  } else {
    var original = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
    pendingDayChanges[slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
  }
  updateDaySaveBtn();
  renderStats();
  renderCalendar();
  renderDaySlots();
}

/* ══════════════════════════════════════════════════════════
   MY BOOKINGS VIEW
══════════════════════════════════════════════════════════ */
function renderMyBookings() {
  var container = document.getElementById('my-bookings-list');
  container.innerHTML = '';

  var allBooked = Store.Slots.byStudent(currentUser.uid)
    .filter(function(s) { return s.status === 'booked'; })
    .sort(function(a, b) { return a.date.localeCompare(b.date) || a.time.localeCompare(b.time); });

  if (!allBooked.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = 'You have no bookings yet.';
    container.appendChild(empty);
    return;
  }

  // Group by date
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < allBooked.length; i++) {
    var s = allBooked[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr  = dateOrder[d];
    var daySlots = byDate[dateStr];

    // Day divider
    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider';
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
    container.appendChild(divider);

    // Merge consecutive slots into blocks
    var blocks = mergeMyBookingBlocks(daySlots);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(buildMyBookingBlock(blocks[b]));
    }
  }
}

function mergeMyBookingBlocks(slots) {
  var blocks = [];
  var i = 0;
  while (i < slots.length) {
    var s   = slots[i];
    var end = Store.slotEndTime(s.time);
    var grp = [s];
    var j   = i + 1;
    while (j < slots.length && slots[j].time === end && slots[j].date === s.date) {
      end = Store.slotEndTime(slots[j].time);
      grp.push(slots[j]);
      j++;
    }
    blocks.push({ date: s.date, start: s.time, end: end, slots: grp });
    i = j;
  }
  return blocks;
}

var expandedMyBlocks = {};

function buildMyBookingBlock(block) {
  var teacherId = block.slots[0].teacherId;
  var teacher   = Store.Users.byUid(teacherId);
  var blockKey  = block.date + '-' + block.start + '-' + teacherId;
  var isOpen    = !!expandedMyBlocks[blockKey];

  var wrapper = document.createElement('div');
  wrapper.className = 'all-booking-block-wrapper';

  // Header
  var header = document.createElement('div');
  header.className = 'all-booking-block-header my-booking-block-header';
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'all-booking-block-time';
  timeEl.textContent = block.start + ' – ' + block.end;

  var teacherEl = document.createElement('span');
  teacherEl.className = 'all-booking-block-student';
  teacherEl.textContent = teacher ? teacher.name : teacherId;

  var metaEl = document.createElement('span');
  metaEl.className = 'all-booking-block-meta';
  metaEl.textContent = block.slots.length + ' slot' + (block.slots.length !== 1 ? 's' : '');

  var chevron = document.createElement('span');
  chevron.className = 'all-booking-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  var moveBtn = document.createElement('button');
  moveBtn.className = 'btn btn-ghost btn-sm bk-block-move-btn';
  moveBtn.textContent = '⇄ Move';
  (function(b, tid) {
    moveBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      var normalizedBlock = {
        dateStr:     b.date,
        start:       b.start,
        end:         b.end,
        student:     { uid: currentUser.uid, name: currentUser.name || currentUser.uid },
        bookedSlots: b.slots
      };
      openMoveBlockDialogShared({
        block:      normalizedBlock,
        teacherId:  tid,
        pendingMap: pendingDayChanges,
        stuId:      currentUser.uid,
        onConfirm:  function() {
          updateDaySaveBtn();
          renderMyBookings();
        },
        onCalJump: function(dateStr, result) {
          if (!dateStr) return;
          activeTeacherId = tid;
          selectedDate    = new Date(dateStr + 'T00:00:00');
          viewYear        = selectedDate.getFullYear();
          viewMonth       = selectedDate.getMonth();
          switchView('calendar');
          renderTeacherPicker();
          renderCalendar();
          renderDaySlots();
          result.close();
        }
      });
    });
  })(block, teacherId);

  header.appendChild(timeEl);
  header.appendChild(teacherEl);
  header.appendChild(metaEl);
  header.appendChild(moveBtn);
  header.appendChild(chevron);

  // Detail panel
  var detail = document.createElement('div');
  detail.className = 'all-booking-block-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) {
    detail.innerHTML = '';
    populateMyBookingDetail(detail, block, teacherId);
  }

  function toggle() {
    if (expandedMyBlocks[blockKey]) {
      delete expandedMyBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedMyBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateMyBookingDetail(detail, block, teacherId);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

function populateMyBookingDetail(detail, block, teacherId) {
  detail.innerHTML = '';

  for (var i = 0; i < block.slots.length; i++) {
    var s = block.slots[i];
    var isPending  = !!pendingDayChanges[s.slotId];
    var pendingObj = pendingDayChanges[s.slotId];

    var row = document.createElement('div');
    row.className = 'my-booking-slot-row' + (isPending ? ' slot-pending' : '');

    var timeEl = document.createElement('span');
    timeEl.className = 'my-booking-slot-time';
    timeEl.textContent = s.time + ' – ' + Store.slotEndTime(s.time);

    var teacherLabel = document.createElement('span');
    teacherLabel.className = 'my-booking-slot-teacher';
    var tObj = Store.Users.byUid(teacherId);
    teacherLabel.textContent = tObj ? tObj.name : teacherId;

    var cancelBtn = document.createElement('button');
    cancelBtn.className = (isPending && pendingObj && pendingObj.action === 'cancel')
      ? 'btn btn-ghost btn-sm' : 'btn btn-danger btn-sm';
    cancelBtn.textContent = (isPending && pendingObj && pendingObj.action === 'cancel')
      ? 'Undo' : 'Cancel';
    (function(slot) {
      cancelBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        if (pendingDayChanges[slot.slotId] && pendingDayChanges[slot.slotId].action === 'cancel') {
          delete pendingDayChanges[slot.slotId];
        } else {
          var original = Store.Slots.all().filter(function(x) { return x.slotId === slot.slotId; })[0];
          pendingDayChanges[slot.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
        }
        updateDaySaveBtn();
        renderMyBookings();
      });
    })(s);

    row.appendChild(timeEl);
    row.appendChild(teacherLabel);
    row.appendChild(cancelBtn);
    detail.appendChild(row);
  }

  var calBtn = document.createElement('button');
  calBtn.className = 'btn btn-ghost btn-sm my-booking-cal-btn';
  calBtn.textContent = 'Im Kalender anzeigen';
  (function(b, tid) {
    calBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      activeTeacherId = tid;
      selectedDate    = new Date(b.date + 'T00:00:00');
      viewYear        = selectedDate.getFullYear();
      viewMonth       = selectedDate.getMonth();
      switchView('calendar');
      renderTeacherPicker();
      renderCalendar();
      renderDaySlots();
    });
  })(block, teacherId);
  detail.appendChild(calBtn);
}

/* ── Floating Save button ───────────────────────────────── */
function updateDaySaveBtn() {
  var group = document.getElementById('day-save-group');
  if (!group) return;
  var count = Object.keys(pendingDayChanges).length;
  group.classList.toggle('is-visible', count > 0);
  var badge = group.querySelector('.save-badge');
  if (badge) badge.textContent = count;
  updateSgridFab();
}

function updateSgridFab() {
  var fab = document.getElementById('sgrid-fab-group');
  if (!fab) return;
  var count = Object.keys(pendingDayChanges).length;
  fab.style.display = count > 0 ? 'flex' : 'none';
}

function commitSgridChanges() {
  commitDayChanges();
  updateSgridFab();
  renderStudentGrid();
}

function discardSgridChanges() {
  pendingDayChanges = {};
  updateSgridFab();
  updateDaySaveBtn();
  renderStudentGrid();
  Toast.info('Changes dismissed.');
}

function discardDayChanges() {
  pendingDayChanges = {};
  updateDaySaveBtn();
  renderStats();
  renderCalendar();
  renderDaySlots();
  renderMyBookings();
  Toast.info('Changes dismissed.');
}

function commitDayChanges() {
  var ids = Object.keys(pendingDayChanges);
  for (var i = 0; i < ids.length; i++) {
    var p = pendingDayChanges[ids[i]];
    if (p.action === 'book') {
      Store.Slots.bookSlot(ids[i], p.newStudentId);
    } else {
      Store.Slots.cancelBooking(ids[i]);
    }
  }
  pendingDayChanges = {};
  expandedDayBlocks = {};
  updateDaySaveBtn();
  Toast.success('Saved.');
  renderStats();
  renderCalendar();
  renderDaySlots();
  renderMyBookings();
}

function openStudentGrid() {
  if (!activeTeacherId) return;

  // Start on current week (Monday)
  if (!sgridWeekStart) {
    var monday = new Date(TODAY);
    var dow = monday.getDay();
    dow = (dow === 0) ? 6 : dow - 1;
    monday.setDate(monday.getDate() - dow);
    sgridWeekStart = monday;
  }

  var teacher = Store.Users.byUid(activeTeacherId);
  document.getElementById('sgrid-teacher-name').textContent = teacher ? teacher.name : '';

  document.getElementById('student-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  renderStudentGrid();
}

function closeStudentGrid() {
  document.getElementById('student-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  renderStats();
}

function sgridPrevWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() - 7);
  renderStudentGrid();
}

function sgridNextWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() + 7);
  renderStudentGrid();
}

/* ── Week grid render ───────────────────────────────────── */
function renderStudentGrid() {
  var weekDates = getSgridWeekDates();

  // Materialise recurring rules for this week so all days show correct slots
  if (activeTeacherId) {
    Store.Recurring.materialiseWeek(activeTeacherId, weekDates);
  }

  var times = Store.slotTimesInRange(GRID_START, GRID_END);

  // Update week label
  document.getElementById('sgrid-week-label').textContent = sgridWeekRangeLabel(weekDates);

  var container = document.getElementById('sgrid-content');
  container.innerHTML = '';

  // Build table via innerHTML for performance (single DOM insertion)
  var html = '<table class="slot-grid-table"><thead><tr><th class="grid-th-time">Time</th>';
  for (var d = 0; d < weekDates.length; d++) {
    var wd = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var todayCls = isToday ? ' grid-th-today' : '';
    var numCls = isToday ? ' grid-day-today' : '';
    html += '<th class="grid-th-day' + todayCls + '"><span class="grid-day-name">' + DAY_NAMES[d] + '</span><span class="grid-day-num' + numCls + '">' + wd.getDate() + '</span></th>';
  }
  html += '</tr></thead><tbody>';

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    html += '<tr><td class="grid-td-time">' + time + '</td>';
    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var isPastDay   = cellDate < TODAY;
      var rawSlot     = Store.Slots.exists(activeTeacherId, cellDateStr, time);
      var slot        = rawSlot ? getEffectiveSlot(rawSlot) : null;
      var cellClass, isClickable = false;
      if (!slot || slot.status === 'disabled' || slot.status === 'timeout' || isPastDay) {
        cellClass = 'gc-empty';
      } else if (!slot.studentId && (slot.baseStatus === 'available' || slot.status === 'available' || slot.status === 'recurring' || slot.baseStatus === 'recurring')) {
        cellClass = 'gc-available' + (slot._pending ? ' gc-pending' : '');
        isClickable = true;
      } else if (slot.studentId === currentUser.uid) {
        cellClass = 'gc-mine' + (slot._pending ? ' gc-pending' : '');
        isClickable = true;
      } else {
        cellClass = 'gc-empty';
      }
      var slotId = slot ? slot.slotId : '';
      var clickable = isClickable ? ' data-clickable="1"' : '';
      html += '<td class="grid-td-cell"><div class="grid-cell ' + cellClass + '" data-date="' + cellDateStr + '" data-time="' + time + '" data-slotid="' + slotId + '"' + clickable + '></div></td>';
    }
    html += '</tr>';
  }
  html += '</tbody></table>';
  container.innerHTML = html;

  // Attach click listeners to clickable cells only
  var clickables = container.querySelectorAll('[data-clickable="1"]');
  for (var ci = 0; ci < clickables.length; ci++) {
    clickables[ci].addEventListener('click', onStudentCellClick);
  }
}

function onStudentCellClick(e) {
  var cell   = e.currentTarget;
  var date   = cell.dataset.date;
  var time   = cell.dataset.time;
  var slotId = cell.dataset.slotid;
  var isMine = cell.classList.contains('gc-mine');

  if (isMine) {
    // If this booking is only staged (pending book), just undo it — no dialog
    if (pendingDayChanges[slotId] && pendingDayChanges[slotId].action === 'book') {
      delete pendingDayChanges[slotId];
      updateDaySaveBtn();
      Toast.info('Booking removed.');
      renderStats();
      renderStudentGrid();
      return;
    }
    // Real stored booking — show confirmation dialog
    var result = Modal.show({
      title: 'Cancel booking',
      bodyHTML: '<p>Cancel your booking at <strong>' + time + ' – ' + Store.slotEndTime(time) + '</strong> on ' + date + '?</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Keep it</button><button class="btn btn-danger" id="modal-confirm">Cancel booking</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      var original = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
      pendingDayChanges[slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
      updateDaySaveBtn();
      Toast.info('Cancellation staged — press Done to confirm.');
      renderStats();
      renderStudentGrid();
      result.close();
    });
  } else {
    // Book slot
    var slot = Store.Slots.exists(activeTeacherId, date, time);
    if (!slot) return;
    var existingPending = pendingDayChanges[slot.slotId];
    if (existingPending && existingPending.action === 'cancel') {
      delete pendingDayChanges[slot.slotId];
    } else {
      pendingDayChanges[slot.slotId] = { action: 'book', originalSlot: slot, newStudentId: currentUser.uid };
    }
    updateDaySaveBtn();
    Toast.info('Booking staged — press Done to confirm.');
    renderStats();
    renderStudentGrid();
  }
}

/* ── Helpers ────────────────────────────────────────────── */
function getSgridWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(sgridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function sgridWeekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function fmtDate(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}

/* ── Section jump buttons ─────────────────────────────── */
function getSectionJumpTargets() {
  var calSection = document.getElementById('cal-section');
  var daySlots   = document.getElementById('day-slots');
  var myBookings = document.getElementById('view-my-bookings');
  var targets = [];
  if (calSection && !calSection.classList.contains('view-hidden')) {
    targets.push(calSection);
    if (daySlots) targets.push(daySlots);
  }
  if (myBookings && !myBookings.classList.contains('view-hidden')) {
    targets.push(myBookings);
  }
  return targets.filter(Boolean);
}

function getStickyOffset() {
  var navbar = document.querySelector('.navbar');
  var dayNav = document.getElementById('day-nav-bar');
  var offset = 0;
  if (navbar) offset += navbar.offsetHeight;
  if (dayNav && dayNav.classList.contains('is-sticky')) offset += dayNav.offsetHeight;
  return offset + 8;
}

function getCurrentSectionIndex(targets) {
  var offset = getStickyOffset();
  var scrollY = window.scrollY + offset + 10;
  var best = 0;
  for (var i = 0; i < targets.length; i++) {
    var top = targets[i].getBoundingClientRect().top + window.scrollY;
    if (top <= scrollY) best = i;
  }
  return best;
}

function updateJumpBtns() {
  var jumper  = document.getElementById('section-jumper');
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var upBtn   = document.getElementById('jump-up');
  var downBtn = document.getElementById('jump-down');
  if (!upBtn || !downBtn || !jumper) return;
  var isVisible = window.scrollY > 80;
  jumper.classList.toggle('is-visible', isVisible);
  upBtn.classList.toggle('is-dimmed', idx === 0);
  downBtn.classList.toggle('is-dimmed', idx === targets.length - 1);
}

function jumpSection(delta) {
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var next    = idx + delta;
  if (next < 0 || next >= targets.length) return;
  var target  = targets[next];
  var offset  = getStickyOffset();
  var top     = target.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top: top, behavior: 'smooth' });
  setTimeout(updateJumpBtns, 400);
}

window.addEventListener('scroll', updateJumpBtns);
window.addEventListener('scroll', checkDayNavSticky);
window.addEventListener('resize', function() {
  _dayNavStickyActive = !_dayNavStickyActive;
  checkDayNavSticky();
});
