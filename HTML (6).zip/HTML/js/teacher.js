/**
 * teacher.js — Teacher View Logic
 *
 * Grid modes: 'available' | 'timeout'
 * Recurring slots: materialised on-demand per week from app_recurring
 * No inline styles — all classes from teacher.css
 */

var currentUser  = null;
var viewYear     = 0;
var viewMonth    = 0;
var selectedDate = null;

var gridWeekStart = null;
var gridMode      = 'available'; // 'available' | 'timeout'
var gridPending   = {};          // { "date|time": 'available'|'timeout'|'disabled'|'remove-recurring' }

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START = '06:00';
var GRID_END   = '22:00';

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('teacher');
  if (!currentUser) return;
  Navbar.init('teacher');

  var now   = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();

  document.getElementById('prev-btn').addEventListener('click', prevMonth);
  document.getElementById('next-btn').addEventListener('click', nextMonth);
  document.getElementById('grid-close-btn').addEventListener('click', closeSlotGrid);
  document.getElementById('grid-save-btn').addEventListener('click', saveSlotGrid);
  document.getElementById('grid-prev-week').addEventListener('click', gridPrevWeek);
  document.getElementById('grid-next-week').addEventListener('click', gridNextWeek);
  document.getElementById('mode-btn-available').addEventListener('click', function() { setGridMode('available'); });
  document.getElementById('mode-btn-timeout').addEventListener('click', function() { setGridMode('timeout'); });

  renderStudentList();
  renderCalendar();
  renderDayPanel();

  // Main view tabs
  document.getElementById('nav-schedule').addEventListener('click', function() { switchTeacherView('schedule'); });
  document.getElementById('nav-all-bookings').addEventListener('click', function() { switchTeacherView('all-bookings'); });

  // Day panel sub-tabs
  document.getElementById('day-tab-availability').addEventListener('click', function() { switchDayTab('availability'); });
  document.getElementById('day-tab-bookings').addEventListener('click', function() { switchDayTab('bookings'); });
});

var activeDayTab = 'availability';

function switchDayTab(tab) {
  activeDayTab = tab;
  document.getElementById('day-tab-availability').classList.toggle('active', tab === 'availability');
  document.getElementById('day-tab-bookings').classList.toggle('active', tab === 'bookings');
  renderDayPanel();
}

var activeTeacherView = 'schedule';
var allBookingsFilter  = 'all';
var expandedAllBlocks  = {};

/* Pending booking changes — staged, not yet written to Store
   { slotId: { action:'book'|'cancel', originalSlot:{...}, newStudentId:uid|null } } */
var pendingBookings = {};

/* Return effective slot — pending overrides Store */
function getEffectiveTeacherSlot(storeSlot) {
  var p = pendingBookings[storeSlot.slotId];
  if (!p) return storeSlot;
  var s = {}; for (var k in storeSlot) s[k] = storeSlot[k];
  if (p.action === 'book') {
    s.status    = 'booked';
    s.studentId = p.newStudentId;
    s._pending  = 'book';
  } else {
    s.status    = storeSlot.baseStatus || 'available';
    s.studentId = null;
    s._pending  = 'cancel';
  }
  return s;
}

function switchTeacherView(view) {
  activeTeacherView = view;
  document.getElementById('nav-schedule').classList.toggle('active', view === 'schedule');
  document.getElementById('nav-all-bookings').classList.toggle('active', view === 'all-bookings');
  document.getElementById('view-schedule').classList.toggle('view-hidden', view !== 'schedule');
  document.getElementById('view-all-bookings').classList.toggle('view-hidden', view !== 'all-bookings');
  if (view === 'all-bookings') {
    var bar = document.getElementById('day-nav-bar');
    if (bar) { bar.classList.remove('is-sticky'); }
    renderAllBookings();
  }
  if (view === 'schedule') {
    updateDayNavBar();
  }
}

/* ══════════════════════════════════════════════════════════
   STUDENT LIST
══════════════════════════════════════════════════════════ */

// Track which student rows are expanded
var expandedStudents = {};

function renderStudentList() {
  var selections = Store.Selections.byTeacher(currentUser.uid);
  var container  = document.getElementById('student-list');
  document.getElementById('stat-students').textContent = selections.length;

  if (!selections.length) {
    container.innerHTML = '<p class="text-muted">No students yet.</p>';
    return;
  }

  container.innerHTML = '';
  var frag = document.createDocumentFragment();

  for (var i = 0; i < selections.length; i++) {
    var student = Store.Users.byUid(selections[i].studentId);
    if (!student) continue;

    var bookedSlots = Store.Slots.byStudent(student.uid)
      .filter(function(s) { return s.teacherId === currentUser.uid && s.status === 'booked'; })
      .sort(function(a, b) { return a.date.localeCompare(b.date) || a.time.localeCompare(b.time); });

    frag.appendChild(buildStudentRow(student, bookedSlots));
  }

  container.appendChild(frag);
}

function buildStudentRow(student, bookedSlots) {
  var isOpen   = !!expandedStudents[student.uid];
  var blockCount = mergeStudentBlocks(bookedSlots).length;

  var wrapper = document.createElement('div');
  wrapper.className = 'student-row-wrapper';

  // ── Header ──
  var header = document.createElement('div');
  header.className = 'student-row' + (isOpen ? ' student-row-open' : '');
  header.setAttribute('tabindex', '0');

  var info = document.createElement('div');
  info.className = 'student-row-info';

  var name = document.createElement('div');
  name.className = 'student-name';
  name.textContent = student.name;

  var count = document.createElement('div');
  count.className = 'student-count text-muted';
  count.textContent = blockCount + ' booking block' + (blockCount !== 1 ? 's' : '')
    + ' · ' + bookedSlots.length + ' slot' + (bookedSlots.length !== 1 ? 's' : '');

  info.appendChild(name);
  info.appendChild(count);

  var right = document.createElement('div');
  right.className = 'student-row-right';

  var uid = document.createElement('code');
  uid.className = 'uid-badge';
  uid.textContent = student.uid;

  var chevron = document.createElement('span');
  chevron.className = 'student-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  right.appendChild(uid);
  right.appendChild(chevron);

  header.appendChild(info);
  header.appendChild(right);

  // ── Booking detail panel ──
  var detail = document.createElement('div');
  detail.className = 'student-booking-detail' + (isOpen ? ' is-open' : '');

  if (isOpen) {
    populateStudentBookings(detail, student, bookedSlots);
  }

  // Toggle expand
  function toggle() {
    if (expandedStudents[student.uid]) {
      delete expandedStudents[student.uid];
      header.classList.remove('student-row-open');
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedStudents[student.uid] = true;
      header.classList.add('student-row-open');
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateStudentBookings(detail, student, bookedSlots);
    }
  }

  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') toggle();
  });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

/**
 * Merge consecutive booked slots (same date, consecutive times) into blocks.
 * Returns [{ date, start, end, slotIds[] }]
 */
function mergeStudentBlocks(slots) {
  var blocks = [];
  var i = 0;
  while (i < slots.length) {
    var s     = slots[i];
    var start = s.time;
    var end   = Store.slotEndTime(s.time);
    var ids   = [s.slotId];
    var date  = s.date;
    var j     = i + 1;

    while (j < slots.length) {
      var next = slots[j];
      if (next.date === date && next.time === end) {
        end = Store.slotEndTime(next.time);
        ids.push(next.slotId);
        j++;
      } else {
        break;
      }
    }
    blocks.push({ date: date, start: start, end: end, slotIds: ids });
    i = j;
  }
  return blocks;
}

function populateStudentBookings(detail, student, bookedSlots) {
  detail.innerHTML = '';

  if (!bookedSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted student-bookings-empty';
    empty.textContent = 'No bookings yet.';
    detail.appendChild(empty);
    return;
  }

  var blocks = mergeStudentBlocks(bookedSlots);

  for (var i = 0; i < blocks.length; i++) {
    detail.appendChild(buildBookingBlockRow(blocks[i]));
  }
}

function buildBookingBlockRow(block) {
  var row = document.createElement('div');
  row.className = 'student-booking-row';
  row.setAttribute('tabindex', '0');
  row.setAttribute('title', 'Jump to ' + block.date);

  // Date
  var dateEl = document.createElement('div');
  dateEl.className = 'student-booking-date';
  var d = new Date(block.date + 'T00:00:00');
  dateEl.textContent = d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });

  // Time block
  var timeEl = document.createElement('div');
  timeEl.className = 'student-booking-time';
  timeEl.textContent = block.start + ' – ' + block.end;

  // Slot count
  var countEl = document.createElement('div');
  countEl.className = 'student-booking-count';
  countEl.textContent = block.slotIds.length + ' slot' + (block.slotIds.length !== 1 ? 's' : '');

  row.appendChild(dateEl);
  row.appendChild(timeEl);
  row.appendChild(countEl);

  // Click → jump to that date in calendar
  (function(b) {
    row.addEventListener('click', function() {
      var target = new Date(b.date + 'T00:00:00');
      selectedDate = target;
      viewYear     = target.getFullYear();
      viewMonth    = target.getMonth();
      switchTeacherView('schedule');
      renderCalendar();
      renderDayPanel();
    });
    row.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') row.click();
    });
  })(block);

  return row;
}

/* ══════════════════════════════════════════════════════════
   CALENDAR
══════════════════════════════════════════════════════════ */
function materialiseVisibleMonth(year, month) {
  // Find all Mondays in the visible calendar grid (can span prev/next month)
  var first    = new Date(year, month, 1);
  var startDow = first.getDay(); startDow = (startDow === 0) ? 6 : startDow - 1;
  // First Monday shown = first day of month minus startDow days
  var gridStart = new Date(year, month, 1 - startDow);
  // Calendar shows up to 6 weeks = 42 days
  var seen = {};
  for (var d = 0; d < 42; d++) {
    var day = new Date(gridStart);
    day.setDate(gridStart.getDate() + d);
    // Get Monday of this day's week
    var dow = day.getDay(); dow = (dow === 0) ? 6 : dow - 1;
    var mon = new Date(day); mon.setDate(day.getDate() - dow);
    var monKey = mon.getFullYear() + '-' + mon.getMonth() + '-' + mon.getDate();
    if (seen[monKey]) continue;
    seen[monKey] = true;
    var weekDates = [];
    for (var w = 0; w < 7; w++) {
      var wd = new Date(mon); wd.setDate(mon.getDate() + w);
      weekDates.push(wd);
    }
    Store.Recurring.materialiseWeek(currentUser.uid, weekDates);
  }
}

function renderCalendar() {
  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;

  // Week view button — add once
  var calHeader = document.getElementById('cal-header-actions');
  if (calHeader && !document.getElementById('week-view-btn')) {
    var wvBtn = document.createElement('button');
    wvBtn.id = 'week-view-btn';
    wvBtn.className = 'btn btn-secondary btn-sm';
    wvBtn.textContent = 'Week view';
    wvBtn.addEventListener('click', openSlotGrid);
    calHeader.appendChild(wvBtn);
  }

  // Materialise recurring slots for every week visible this month
  materialiseVisibleMonth(viewYear, viewMonth);

  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeCell(prevDays - i, true));
  }

  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isToday = date.getTime() === TODAY.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots      = Store.Slots.byTeacherDate(currentUser.uid, dateStr);
      var hasAny     = slots.length > 0;
      var hasBook    = slots.some(function(s) { return s.status === 'booked'; });
      var hasTimeout = slots.some(function(s) { return s.status === 'timeout'; });

      var cell = makeCell(day, false, isToday, isSel, hasAny, hasBook, hasTimeout);
      cell.addEventListener('click', function() { selectDate(date); });
      cell.setAttribute('tabindex', '0');
      cell.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') selectDate(date);
      });
      grid.appendChild(cell);
    })(d);
  }

  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeCell(t, true));
  }

  updateStats();
}

function makeCell(num, otherMonth, isToday, isSelected, hasSlots, hasBooked, hasTimeout) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth)  el.classList.add('other-month');
  if (isToday)     el.classList.add('today');
  if (isSelected)  el.classList.add('selected');
  if (hasSlots)    el.classList.add('has-slots');
  if (hasBooked)   el.classList.add('has-booked');
  if (hasTimeout)  el.classList.add('has-timeout');
  el.textContent = num;
  return el;
}

function selectDate(date) {
  selectedDate = date;
  renderCalendar();
  renderDayPanel();
}

function prevMonth() {
  viewMonth--;
  if (viewMonth < 0) { viewMonth = 11; viewYear--; }
  renderCalendar();
}
function nextMonth() {
  viewMonth++;
  if (viewMonth > 11) { viewMonth = 0; viewYear++; }
  renderCalendar();
}

/* ══════════════════════════════════════════════════════════
   DAY PANEL
══════════════════════════════════════════════════════════ */
var _dayNavStickyActive = false;

function checkDayNavSticky() {
  var bar      = document.getElementById('day-nav-bar');
  var sentinel = document.getElementById('day-nav-sentinel');
  if (!bar || !sentinel || !bar.classList.contains('is-visible')) return;
  var navbarH = 52;
  var rect = sentinel.getBoundingClientRect();
  var shouldBeSticky = rect.top < navbarH;
  if (shouldBeSticky === _dayNavStickyActive) return;
  _dayNavStickyActive = shouldBeSticky;
  bar.classList.toggle('is-sticky', shouldBeSticky);
  if (shouldBeSticky) {
    var parent = document.getElementById('section-daypanel');
    if (parent) {
      var pr = parent.getBoundingClientRect();
      bar.style.left  = pr.left + 'px';
      bar.style.width = pr.width + 'px';
      bar.style.right = 'auto';
    }
    sentinel.style.height = bar.offsetHeight + 'px';
  } else {
    bar.style.left  = '';
    bar.style.width = '';
    bar.style.right = '';
    sentinel.style.height = '0';
  }
}

function updateDayNavBar() {
  var bar      = document.getElementById('day-nav-bar');
  var label    = document.getElementById('day-nav-label');
  if (!bar || !label) return;

  if (!selectedDate) {
    bar.classList.remove('is-visible');
    bar.classList.remove('is-sticky');
    _dayNavStickyActive = false;
    return;
  }

  bar.classList.add('is-visible');
  label.textContent = selectedDate.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });

  checkDayNavSticky();
}

function navDay(delta) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setDate(d.getDate() + delta);
  selectedDate = d;
  if (d.getFullYear() !== viewYear || d.getMonth() !== viewMonth) {
    viewYear  = d.getFullYear();
    viewMonth = d.getMonth();
  }
  updateDayNavBar();
  renderCalendar();
  renderDayPanel();
}

function navMonth(delta) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setMonth(d.getMonth() + delta);
  selectedDate = d;
  viewYear  = d.getFullYear();
  viewMonth = d.getMonth();
  updateDayNavBar();
  renderCalendar();
  renderDayPanel();
}

function renderDayPanel() {
  updateDayNavBar();
  var panel = document.getElementById('day-panel');
  panel.innerHTML = '';

  if (!selectedDate) {
    var hint = document.createElement('p');
    hint.className = 'text-muted day-panel-empty';
    hint.textContent = 'Select a day.';
    panel.appendChild(hint);
    return;
  }

  var dateStr = fmtDate(selectedDate);

  // Materialise recurring for the week of selected date
  var selMonday = new Date(selectedDate);
  var selDow = selMonday.getDay(); selDow = (selDow === 0) ? 6 : selDow - 1;
  selMonday.setDate(selMonday.getDate() - selDow);
  var selWeekDates = [];
  for (var wi = 0; wi < 7; wi++) { var wd = new Date(selMonday); wd.setDate(wd.getDate() + wi); selWeekDates.push(wd); }
  Store.Recurring.materialiseWeek(currentUser.uid, selWeekDates);

  var slots   = Store.Slots.byTeacherDate(currentUser.uid, dateStr);
  var label   = selectedDate.toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' });

  var header = document.createElement('div');
  header.className = 'day-panel-header';
  var lbl = document.createElement('div');
  lbl.className = 'day-panel-label';
  lbl.textContent = label;
  header.appendChild(lbl);

  // "Add slots" button only in availability tab
  if (activeDayTab === 'availability') {
    var btn = document.createElement('button');
    btn.className = 'btn btn-primary btn-sm';
    btn.id = 'add-slot-btn';
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Add slots';
    btn.addEventListener('click', openSlotGrid);
    header.appendChild(btn);
  }
  panel.appendChild(header);

  if (!slots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted day-panel-empty';
    empty.textContent = '';
    panel.appendChild(empty);
    return;
  }

  if (activeDayTab === 'availability') {
    renderAvailabilityPanel(panel, slots);
  } else {
    renderBookingsPanel(panel, slots, dateStr);
  }
}

/* ── Tab 1: Verfügbarkeit ───────────────────────────────── */
function renderAvailabilityPanel(panel, slots) {
  for (var i = 0; i < slots.length; i++) {
    panel.appendChild(buildAvailabilityCard(slots[i]));
  }
}

function buildAvailabilityCard(slot) {
  // Show baseStatus — hide booking info
  var base = slot.baseStatus || (slot.status === 'booked' ? 'available' : slot.status);
  var card = document.createElement('div');
  card.className = 'slot-card slot-card-' + base;

  var info = document.createElement('div');
  info.className = 'slot-card-info';
  var timeEl = document.createElement('div');
  timeEl.className = 'slot-card-time';
  timeEl.textContent = slot.time + ' – ' + Store.slotEndTime(slot.time);
  var statusEl = document.createElement('div');
  statusEl.className = 'slot-card-status';
  statusEl.textContent = base;
  info.appendChild(timeEl);
  info.appendChild(statusEl);

  var actions = document.createElement('div');
  actions.className = 'slot-card-actions';

  if (base === 'available') {
    // Disable button
    var disableBtn = document.createElement('button');
    disableBtn.className = 'slot-action-btn';
    disableBtn.textContent = 'Disable';
    (function(s) {
      disableBtn.addEventListener('click', function() {
        var d = new Date(s.date + 'T00:00:00');
        var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
        Store.Slots.setAvailability(s.slotId, 'disabled');
        Store.Recurring.deleteByTeacherDayTime(currentUser.uid, dow, s.time);
        renderDayPanel();
        renderCalendar();
      });
    })(slot);
    actions.appendChild(disableBtn);

    // Timeout button
    var timeoutBtn = document.createElement('button');
    timeoutBtn.className = 'slot-action-btn slot-action-btn-timeout';
    timeoutBtn.textContent = 'Timeout';
    (function(s) {
      timeoutBtn.addEventListener('click', function() {
        // Check if booked first
        var current = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
        if (current && current.studentId) {
          var student = Store.Users.byUid(current.studentId);
          var sName   = student ? student.name : current.studentId;
          var result  = Modal.show({
            title: 'Slot is booked',
            bodyHTML: '<p>This slot is booked by <strong>' + sName + '</strong>. Setting timeout will cancel their lesson.</p>',
            footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Keep booking</button><button class="btn btn-danger" id="modal-confirm">Cancel & set timeout</button>'
          });
          document.getElementById('modal-cancel').addEventListener('click', result.close);
          (function(sid) {
            document.getElementById('modal-confirm').addEventListener('click', function() {
              Store.Slots.cancelBooking(sid);
              Store.Slots.setAvailability(sid, 'timeout');
              renderDayPanel();
              renderCalendar();
              renderStudentList();
              result.close();
            });
          })(s.slotId);
        } else {
          Store.Slots.setAvailability(s.slotId, 'timeout');
          renderDayPanel();
          renderCalendar();
        }
      });
    })(slot);
    actions.appendChild(timeoutBtn);

  } else if (base === 'disabled' || base === 'timeout') {
    // Enable button — restores to available + creates recurring rule
    var enableBtn = document.createElement('button');
    enableBtn.className = 'slot-action-btn';
    enableBtn.textContent = 'Enable';
    (function(s) {
      enableBtn.addEventListener('click', function() {
        var d = new Date(s.date + 'T00:00:00');
        var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
        Store.Slots.setAvailability(s.slotId, 'available');
        Store.Recurring.create(currentUser.uid, dow, s.time);
        renderDayPanel();
        renderCalendar();
      });
    })(slot);
    actions.appendChild(enableBtn);
  }

  var delBtn = document.createElement('button');
  delBtn.className = 'slot-action-icon-btn';
  delBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  (function(s) {
    delBtn.addEventListener('click', function() { deleteSlot(s.slotId); });
  })(slot);
  actions.appendChild(delBtn);

  card.appendChild(info);
  card.appendChild(actions);
  return card;
}

/* ── Tab 2: Buchungen ───────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   BOOKINGS PANEL (Tab 2)
══════════════════════════════════════════════════════════ */

// Currently open booking form slot id
var openBookFormSlotId = null;

function renderBookingsPanel(panel, slots, dateStr) {
  var list = document.createElement('div');
  list.className = 'bk-slot-list';
  var effective = slots.map(function(s) { return getEffectiveTeacherSlot(s); });

  var i = 0;
  while (i < effective.length) {
    var s = effective[i];
    // Try to build a consecutive block for booked slots of same student
    if (s.studentId) {
      var j = i + 1;
      while (j < effective.length) {
        var next = effective[j];
        if (!next.studentId || next.studentId !== s.studentId) break;
        // Check consecutive: next slot time == end of previous
        if (Store.slotEndTime(effective[j-1].time) !== next.time) break;
        j++;
      }
      if (j - i >= 2) {
        // Build a collapsible block
        var blockSlots = effective.slice(i, j);
        list.appendChild(buildBookingBlock(blockSlots, dateStr, effective));
        i = j;
        continue;
      }
    }
    list.appendChild(buildBookingCard(effective[i], dateStr, effective));
    i++;
  }
  panel.appendChild(list);
}

var expandedBkBlocks = {};

function buildBookingBlock(blockSlots, dateStr, allSlots) {
  var first    = blockSlots[0];
  var last     = blockSlots[blockSlots.length - 1];
  var student  = first.studentId ? Store.Users.byUid(first.studentId) : null;
  var stuName  = student ? student.name : '?';
  var stuId    = first.studentId;
  var blockKey = dateStr + '-' + first.time + '-' + (stuId || 'x');
  var isOpen   = !!expandedBkBlocks[blockKey];
  var hasPending = blockSlots.some(function(s) { return !!s._pending; });

  var block = {
    dateStr:     dateStr,
    student:     student,
    start:       first.time,
    end:         Store.slotEndTime(last.time),
    bookedSlots: blockSlots.map(function(s) {
      return Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0] || s;
    })
  };

  var wrapper = document.createElement('div');
  wrapper.className = 'bk-block-wrapper';

  // Header
  var header = document.createElement('div');
  header.className = 'bk-block-header' + (hasPending ? ' block-pending' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'bk-block-time';
  timeEl.textContent = first.time + ' – ' + Store.slotEndTime(last.time);

  var stuEl = document.createElement('span');
  stuEl.className = 'bk-block-student';
  stuEl.textContent = stuName;

  var metaEl = document.createElement('span');
  metaEl.className = 'bk-block-meta';
  metaEl.textContent = blockSlots.length + ' slots';

  var moveBtn = document.createElement('button');
  moveBtn.className = 'btn btn-ghost btn-sm bk-block-move-btn';
  moveBtn.textContent = '⇄ Move';
  (function(b) {
    moveBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      openMoveBlockDialog(b);
    });
  })(block);

  var chevron = document.createElement('span');
  chevron.className = 'bk-block-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  header.appendChild(timeEl);
  header.appendChild(stuEl);
  header.appendChild(metaEl);
  header.appendChild(moveBtn);
  header.appendChild(chevron);

  // Detail
  var detail = document.createElement('div');
  detail.className = 'bk-block-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) populateBkBlockDetail(detail, blockSlots, dateStr, allSlots, block);

  function toggle() {
    if (expandedBkBlocks[blockKey]) {
      delete expandedBkBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedBkBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateBkBlockDetail(detail, blockSlots, dateStr, allSlots, block);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

function populateBkBlockDetail(detail, blockSlots, dateStr, allSlots, block) {
  detail.innerHTML = '';
  var stuId = block.student ? block.student.uid : null;

  // Show all slots in block — booked ones + available slots on same day for +Add
  var daySlots = Store.Slots.byTeacherDate(currentUser.uid, dateStr)
    .sort(function(a, b) { return a.time.localeCompare(b.time); });

  var display = daySlots.filter(function(s) {
    if (s.status === 'booked' && s.studentId === stuId) return true;
    if ((s.status === 'available' || s.status === 'recurring') && !s.studentId) return true;
    if (pendingBookings[s.slotId]) return true;
    return false;
  });

  for (var i = 0; i < display.length; i++) {
    var origSlot   = display[i];
    var isPending  = !!pendingBookings[origSlot.slotId];
    var pendingObj = pendingBookings[origSlot.slotId];
    var isBooked   = (origSlot.status === 'booked' && origSlot.studentId === stuId)
                   || (isPending && pendingObj && pendingObj.action === 'book');

    var row = document.createElement('div');
    row.className = 'bk-block-slot-row' + (isBooked ? ' bk-block-slot-booked' : '') + (isPending ? ' slot-pending' : '');

    var timeEl = document.createElement('span');
    timeEl.className = 'bk-block-slot-time';
    timeEl.textContent = origSlot.time + ' – ' + Store.slotEndTime(origSlot.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'bk-block-slot-status';
    statusEl.textContent = isBooked ? 'Gebucht' : 'Frei';

    var btnGroup = document.createElement('div');
    btnGroup.className = 'bk-block-slot-btns';

    if (isBooked) {
      var cancelBtn = document.createElement('button');
      cancelBtn.className = (isPending && pendingObj && pendingObj.action === 'cancel') ? 'btn btn-ghost btn-sm' : 'btn btn-danger btn-sm';
      cancelBtn.textContent = (isPending && pendingObj && pendingObj.action === 'cancel') ? 'Undo' : 'Cancel';
      (function(s) {
        cancelBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'cancel') {
            delete pendingBookings[s.slotId];
          } else if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'book') {
            delete pendingBookings[s.slotId];
          } else {
            var original = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
            pendingBookings[s.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
          }
          updateBookingSaveBtn();
          renderDayPanel();
        });
      })(origSlot);
      btnGroup.appendChild(cancelBtn);
    } else {
      var addBtn = document.createElement('button');
      addBtn.className = isPending ? 'btn btn-ghost btn-sm' : 'btn btn-primary btn-sm';
      addBtn.textContent = isPending ? 'Undo' : '+ Add';
      (function(s) {
        addBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingBookings[s.slotId]) {
            delete pendingBookings[s.slotId];
          } else {
            var original = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
            pendingBookings[s.slotId] = { action: 'book', originalSlot: original, newStudentId: stuId, extraStudents: [] };
          }
          updateBookingSaveBtn();
          renderDayPanel();
        });
      })(origSlot);
      btnGroup.appendChild(addBtn);
    }

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    row.appendChild(btnGroup);
    detail.appendChild(row);
  }
}

function buildBookingCard(slot, dateStr, allSlots) {
  var base       = slot.baseStatus || 'available';
  var isBooked   = !!slot.studentId;
  var isFormOpen = openBookFormSlotId === slot.slotId;
  var isPending  = !!slot._pending;

  var rowClass = 'bk-slot-row';
  if (isBooked)  rowClass += ' bk-slot-booked';
  if (isPending) rowClass += ' slot-pending';

  var row = document.createElement('div');
  row.className = rowClass;

  var left = document.createElement('div');
  left.className = 'bk-slot-left';

  var timeEl = document.createElement('div');
  timeEl.className = 'bk-slot-time';
  timeEl.textContent = slot.time + ' – ' + Store.slotEndTime(slot.time);
  left.appendChild(timeEl);

  if (isBooked) {
    var student = Store.Users.byUid(slot.studentId);
    if (student) {
      var stuEl = document.createElement('div');
      stuEl.className = 'bk-slot-student';
      stuEl.textContent = student.name + ' ';
      var uidSpan = document.createElement('span');
      uidSpan.className = 'bk-slot-student-uid';
      uidSpan.textContent = '(' + student.uid + ')';
      stuEl.appendChild(uidSpan);
      if (base !== 'available') {
        var baseNote = document.createElement('span');
        baseNote.className = 'bk-slot-base-note';
        baseNote.textContent = ' · ' + base + ' after cancel';
        stuEl.appendChild(baseNote);
      }
      left.appendChild(stuEl);
    }
  }

  var actions = document.createElement('div');
  actions.className = 'bk-slot-actions';

  if (isBooked) {
    var cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn btn-danger btn-sm';
    cancelBtn.textContent = isPending ? 'Undo' : 'Cancel';
    (function(s) {
      cancelBtn.addEventListener('click', function() { cancelBookingFromPanel(s); });
    })(slot);
    actions.appendChild(cancelBtn);
  } else {
    var bookBtn = document.createElement('button');
    bookBtn.className = 'btn btn-primary btn-sm';
    bookBtn.textContent = isFormOpen ? '− Hide' : '+ Book';
    (function(s) {
      bookBtn.addEventListener('click', function() {
        openBookFormSlotId = (openBookFormSlotId === s.slotId) ? null : s.slotId;
        renderDayPanel();
      });
    })(slot);
    actions.appendChild(bookBtn);
  }

  row.appendChild(left);
  row.appendChild(actions);

  if (isFormOpen && !isBooked) {
    var formWrap = document.createElement('div');
    formWrap.className = 'bk-slot-form-wrap';
    formWrap.appendChild(buildBookingForm(slot, dateStr, allSlots));
    row.appendChild(formWrap);
  }

  return row;
}

function buildBookingForm(startSlot, dateStr, allSlots) {
  var form = document.createElement('div');
  form.className = 'booking-form';

  // Get all students of this teacher
  var selections = Store.Selections.byTeacher(currentUser.uid);
  var students   = selections.map(function(s) { return Store.Users.byUid(s.studentId); }).filter(Boolean);

  if (!students.length) {
    var noStu = document.createElement('p');
    noStu.className = 'text-muted booking-form-empty';
    noStu.textContent = 'No students assigned yet.';
    form.appendChild(noStu);
    return form;
  }

  // Student checkboxes
  var stuLabel = document.createElement('div');
  stuLabel.className = 'booking-form-label';
  stuLabel.textContent = 'Students';
  form.appendChild(stuLabel);

  var stuList = document.createElement('div');
  stuList.className = 'booking-form-students';
  for (var i = 0; i < students.length; i++) {
    (function(stu) {
      var row = document.createElement('label');
      row.className = 'booking-form-check-row';
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = stu.uid;
      cb.className = 'booking-form-checkbox';
      var span = document.createElement('span');
      span.textContent = stu.name;
      row.appendChild(cb);
      row.appendChild(span);
      stuList.appendChild(row);
    })(students[i]);
  }
  form.appendChild(stuList);

  // "Until" time selector — available slots from startSlot onwards
  // Teacher can extend booking across any unbooked slots
  var availableAfter = allSlots.filter(function(s) {
    return s.time >= startSlot.time && !s.studentId;
  });

  // ── From selector ──
  var fromLabel = document.createElement('div');
  fromLabel.className = 'booking-form-label';
  fromLabel.textContent = 'From';

  var fromSel = document.createElement('select');
  fromSel.className = 'form-select booking-form-until';

  // All unbooked slots on this day, sorted
  var allUnbooked = allSlots.filter(function(s) { return !s.studentId; });
  for (var f = 0; f < allUnbooked.length; f++) {
    var fOpt = document.createElement('option');
    fOpt.value = allUnbooked[f].time;
    fOpt.textContent = allUnbooked[f].time;
    if (allUnbooked[f].time === startSlot.time) fOpt.selected = true;
    fromSel.appendChild(fOpt);
  }

  // ── Until selector ──
  var untilLabel = document.createElement('div');
  untilLabel.className = 'booking-form-label';
  untilLabel.textContent = 'Until';

  var untilSel = document.createElement('select');
  untilSel.className = 'form-select booking-form-until';

  function rebuildUntil() {
    untilSel.innerHTML = '';
    var fromTime = fromSel.value;
    // Find consecutive unbooked from fromTime
    var idx = allUnbooked.findIndex ? allUnbooked.findIndex(function(s) { return s.time === fromTime; })
      : (function() { for (var x=0;x<allUnbooked.length;x++) { if(allUnbooked[x].time===fromTime) return x; } return -1; })();
    if (idx < 0) return;
    var prevEnd2 = Store.slotEndTime(allUnbooked[idx].time);
    // First option = end of from slot itself
    var d0 = document.createElement('option');
    d0.value = allUnbooked[idx].time;
    d0.textContent = prevEnd2;
    untilSel.appendChild(d0);
    for (var jj = idx + 1; jj < allUnbooked.length; jj++) {
      var ss = allUnbooked[jj];
      if (ss.time === prevEnd2) {
        prevEnd2 = Store.slotEndTime(ss.time);
        var oo = document.createElement('option');
        oo.value = ss.time;
        oo.textContent = prevEnd2;
        untilSel.appendChild(oo);
      } else { break; }
    }
  }

  rebuildUntil();
  fromSel.addEventListener('change', rebuildUntil);

  var timeRow = document.createElement('div');
  timeRow.className = 'booking-form-time-row';
  var fl = document.createElement('div'); fl.className = 'booking-form-time-col';
  fl.appendChild(fromLabel); fl.appendChild(fromSel);
  var ul = document.createElement('div'); ul.className = 'booking-form-time-col';
  ul.appendChild(untilLabel); ul.appendChild(untilSel);
  timeRow.appendChild(fl);
  timeRow.appendChild(ul);
  form.appendChild(timeRow);

  // Action buttons
  var btnRow = document.createElement('div');
  btnRow.className = 'booking-form-btns';

  var confirmBtn = document.createElement('button');
  confirmBtn.className = 'btn btn-primary btn-sm';
  confirmBtn.textContent = 'Book';

  var cancelFormBtn = document.createElement('button');
  cancelFormBtn.className = 'btn btn-ghost btn-sm';
  cancelFormBtn.textContent = 'Close';
  cancelFormBtn.addEventListener('click', function() {
    openBookFormSlotId = null;
    renderDayPanel();
  });
  confirmBtn.addEventListener('click', function() {
    var checkedBoxes = stuList.querySelectorAll('input[type=checkbox]:checked');
    var selectedUids = [];
    for (var k = 0; k < checkedBoxes.length; k++) {
      selectedUids.push(checkedBoxes[k].value);
    }
    if (!selectedUids.length) {
      Toast.error('Please select at least one student.');
      return;
    }
    // Find the actual from-slot object
    var fromTime  = fromSel.value;
    var fromSlot  = allSlots.filter(function(s) { return s.time === fromTime; })[0];
    if (!fromSlot) fromSlot = startSlot;
    var untilTime = untilSel.value;
    executeBooking(fromSlot, untilTime, selectedUids, dateStr, allSlots);
  });

  btnRow.appendChild(confirmBtn);
  btnRow.appendChild(cancelFormBtn);
  form.appendChild(btnRow);
  return form;
}

function executeBooking(startSlot, untilTime, studentUids, dateStr, allSlots) {
  // Get all slots from start up to and including untilTime
  // Use effective state (pending overrides) for conflict detection
  var range = allSlots.filter(function(s) {
    return s.time >= startSlot.time && s.time <= untilTime;
  }).map(function(s) { return getEffectiveTeacherSlot(s); });

  // Check for conflicts (already booked by someone else)
  var conflicts = range.filter(function(s) {
    return s.studentId && studentUids.indexOf(s.studentId) === -1;
  });

  if (conflicts.length) {
    var conflictNames = conflicts.map(function(s) {
      var stu = Store.Users.byUid(s.studentId);
      return s.time + ' (booked by ' + (stu ? stu.name : s.studentId) + ')';
    }).join(', ');

    var result = Modal.show({
      title: 'Booking conflict',
      bodyHTML: '<p>The following slots are already booked:</p><p><strong>' + conflictNames + '</strong></p><p>Overwrite these bookings?</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Cancel</button><button class="btn btn-danger" id="modal-confirm">Overwrite</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      commitBooking(range, studentUids);
      result.close();
    });
  } else {
    commitBooking(range, studentUids);
  }
}

function commitBooking(slots, studentUids) {
  for (var i = 0; i < slots.length; i++) {
    var slot = slots[i];
    var original = Store.Slots.all().filter(function(s) { return s.slotId === slot.slotId; })[0];
    pendingBookings[slot.slotId] = {
      action:       'book',
      originalSlot: original,
      newStudentId: studentUids[0],
      extraStudents: studentUids.slice(1)
    };
  }
  openBookFormSlotId = null;
  updateBookingSaveBtn();
  Toast.info('Booking staged — press Save to confirm.');
  renderDayPanel();
  renderCalendar();
  renderStudentList();
}

function cancelBookingFromPanel(slot) {
  var original = Store.Slots.all().filter(function(s) { return s.slotId === slot.slotId; })[0];
  var existing = pendingBookings[slot.slotId];
  if (existing) {
    delete pendingBookings[slot.slotId];
    updateBookingSaveBtn();
    renderDayPanel();
    renderCalendar();
    renderStudentList();
    return;
  }
  pendingBookings[slot.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
  updateBookingSaveBtn();
  renderDayPanel();
  renderCalendar();
  renderStudentList();
}

function updateBookingSaveBtn() {
  var group = document.getElementById('booking-fab-group');
  if (!group) return;
  var count = Object.keys(pendingBookings).length;
  group.classList.toggle('is-visible', count > 0);
  var badge = group.querySelector('.save-badge');
  if (badge) badge.textContent = count;
}

function discardBookingChanges() {
  pendingBookings = {};
  openBookFormSlotId = null;
  updateBookingSaveBtn();
  renderDayPanel();
  Toast.info('Changes dismissed.');
}

function saveBookingChanges() {
  var ids = Object.keys(pendingBookings);
  for (var i = 0; i < ids.length; i++) {
    var p = pendingBookings[ids[i]];
    if (p.action === 'book') {
      Store.Slots.bookSlot(ids[i], p.newStudentId);
      // Extra students — create new slots
      if (p.extraStudents && p.extraStudents.length) {
        var orig = p.originalSlot;
        for (var j = 0; j < p.extraStudents.length; j++) {
          Store.Slots.create({
            teacherId:  orig.teacherId,
            studentId:  p.extraStudents[j],
            date:       orig.date,
            time:       orig.time,
            status:     'booked',
            baseStatus: 'available'
          });
        }
      }
    } else {
      Store.Slots.cancelBooking(ids[i]);
    }
  }
  pendingBookings = {};
  updateBookingSaveBtn();
  renderDayPanel();
  renderCalendar();
  renderStudentList();
  renderAllBookingsList();
  Toast.success('Bookings saved.');
}

function deleteSlot(slotId) {
  Store.Slots.delete(slotId);
  Toast.success('Slot removed.');
  renderDayPanel();
  renderCalendar();
}

/* ══════════════════════════════════════════════════════════
   SLOT GRID OVERLAY
══════════════════════════════════════════════════════════ */
function openSlotGrid() {
  if (!selectedDate) return;

  var monday = new Date(selectedDate);
  var dow = monday.getDay();
  dow = (dow === 0) ? 6 : dow - 1;
  monday.setDate(monday.getDate() - dow);
  gridWeekStart = monday;
  gridPending   = {};

  // Materialise recurring for this week
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());

  document.getElementById('slot-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  setGridMode('available');
  renderGridTable();
}

function closeSlotGrid() {
  document.getElementById('slot-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  gridPending = {};
  renderCalendar();
  renderDayPanel();
}

function saveSlotGrid() {
  flushGridPending();
  Toast.success('Slots saved.');
  renderCalendar();
  renderDayPanel();
  // Re-render grid to reflect saved state
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridPrevWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() - 7);
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridNextWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() + 7);
  Store.Recurring.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function setGridMode(mode) {
  gridMode = mode;
  var btnAvail   = document.getElementById('mode-btn-available');
  var btnTimeout = document.getElementById('mode-btn-timeout');
  btnAvail.className   = 'grid-mode-btn' + (mode === 'available' ? ' active-available' : '');
  btnTimeout.className = 'grid-mode-btn' + (mode === 'timeout'   ? ' active-timeout'   : '');
}

/* ── Grid table render ────────────────────────────────────── */
function renderGridTable() {
  var weekDates = getWeekDates();
  var times     = Store.slotTimesInRange(GRID_START, GRID_END);

  // Update week label
  document.getElementById('grid-week-label').textContent = weekRangeLabel(weekDates);

  var container = document.getElementById('slot-grid-content');
  container.innerHTML = '';

  var table = document.createElement('table');
  table.className = 'slot-grid-table';

  // ── thead ──
  var thead = document.createElement('thead');
  var hrow  = document.createElement('tr');

  var thTime = document.createElement('th');
  thTime.className = 'grid-th-time';
  thTime.textContent = 'Time';
  hrow.appendChild(thTime);

  for (var d = 0; d < weekDates.length; d++) {
    var wd      = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var isSel   = selectedDate && wd.getTime() === selectedDate.getTime();

    var th = document.createElement('th');
    th.className = 'grid-th-day';
    if (isToday) th.classList.add('grid-th-today');
    if (isSel)   th.classList.add('grid-th-selected');

    var nameSpan = document.createElement('span');
    nameSpan.className = 'grid-day-name';
    nameSpan.textContent = DAY_NAMES[d];

    var numSpan = document.createElement('span');
    numSpan.className = 'grid-day-num';
    if (isToday) numSpan.classList.add('grid-day-today');
    numSpan.textContent = wd.getDate();

    th.appendChild(nameSpan);
    th.appendChild(numSpan);
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // ── tbody ──
  var tbody = document.createElement('tbody');

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    var tr   = document.createElement('tr');

    var tdTime = document.createElement('td');
    tdTime.className = 'grid-td-time';
    tdTime.textContent = time;
    tr.appendChild(tdTime);

    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var dayOfWeek   = dd; // 0=Mon
      var slot        = Store.Slots.exists(currentUser.uid, cellDateStr, time);
      var recurring   = Store.Recurring.exists(currentUser.uid, dayOfWeek, time);

      // Determine display status
      var status = slot ? slot.status : (recurring ? 'recurring' : 'none');
      var pendingKey = cellDateStr + '|' + time;
      if (gridPending[pendingKey] !== undefined) {
        status = gridPending[pendingKey];
      }

      var td   = document.createElement('td');
      td.className = 'grid-td-cell';

      var cell = document.createElement('div');
      cell.className = 'grid-cell';
      cell.dataset.date      = cellDateStr;
      cell.dataset.time      = time;
      cell.dataset.dayofweek = String(dayOfWeek);
      cell.dataset.booked    = (status === 'booked') ? '1' : '0';

      if (status === 'available' || status === 'recurring') cell.classList.add('gc-available');
      else if (status === 'booked')    cell.classList.add('gc-booked');
      else if (status === 'timeout')   cell.classList.add('gc-timeout');
      else                             cell.classList.add('gc-empty');

      if (status !== 'booked') {
        cell.addEventListener('click', onGridCellClick);
      }

      td.appendChild(cell);
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  container.appendChild(table);
}

function onGridCellClick(e) {
  var cell       = e.currentTarget;
  var date       = cell.dataset.date;
  var time       = cell.dataset.time;
  var dayOfWeek  = parseInt(cell.dataset.dayofweek, 10);
  var key        = date + '|' + time;

  var isAvailable = cell.classList.contains('gc-available') || cell.classList.contains('gc-recurring');
  var isTimeout   = cell.classList.contains('gc-timeout');
  var isEmpty     = cell.classList.contains('gc-empty');

  if (gridMode === 'available') {
    if (isAvailable) {
      // Toggle off — available (=recurring) → disabled, remove recurring rule
      gridPending[key] = 'disabled';
      cell.className = 'grid-cell gc-empty';
    } else if (isTimeout || isEmpty) {
      // Toggle on — always creates recurring rule
      gridPending[key] = 'available';
      cell.className = 'grid-cell gc-available';
    }
  } else if (gridMode === 'timeout') {
    if (isAvailable || cell.classList.contains('gc-recurring')) {
      // Check if booked
      var existingSlot = Store.Slots.exists(currentUser.uid, date, time);
      if (existingSlot && existingSlot.studentId) {
        // Warning: slot is booked
        var student = Store.Users.byUid(existingSlot.studentId);
        var sName   = student ? student.name : existingSlot.studentId;
        var result  = Modal.show({
          title: 'Slot is booked',
          bodyHTML: '<p>This slot is booked by <strong>' + sName + '</strong>. Setting timeout will cancel their lesson.</p>',
          footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Keep booking</button><button class="btn btn-danger" id="modal-confirm">Cancel lesson & set timeout</button>'
        });
        document.getElementById('modal-cancel').addEventListener('click', result.close);
        (function(k, c, sid) {
          document.getElementById('modal-confirm').addEventListener('click', function() {
            Store.Slots.cancelBooking(sid);
            Store.Slots.setAvailability(sid, 'timeout');
            gridPending[k] = 'timeout';
            c.className = 'grid-cell gc-timeout';
            renderCalendar();
            renderStudentList();
            result.close();
          });
        })(key, cell, existingSlot.slotId);
      } else {
        gridPending[key] = 'timeout';
        cell.className = 'grid-cell gc-timeout';
      }
    } else if (isTimeout) {
      // Remove timeout — restore to available/recurring
      var rec2 = Store.Recurring.exists(currentUser.uid, dayOfWeek, time);
      gridPending[key] = rec2 ? 'available' : 'available-no-recurring';
      cell.className = 'grid-cell gc-' + (rec2 ? 'recurring' : 'available');
    }
  }
}

function flushGridPending() {
  var keys = Object.keys(gridPending);
  for (var i = 0; i < keys.length; i++) {
    var key    = keys[i];
    var parts  = key.split('|');
    var date   = parts[0];
    var time   = parts[1];
    var action = gridPending[key];

    // Get dayOfWeek from date string
    var d = new Date(date + 'T00:00:00');
    var dow = d.getDay();
    dow = (dow === 0) ? 6 : dow - 1;

    var existing = Store.Slots.exists(currentUser.uid, date, time);

    if (action === 'available-new-recurring' || action === 'available' || action === 'available-no-recurring') {
      // available always means recurring
      Store.Recurring.create(currentUser.uid, dow, time);
      if (existing) Store.Slots.setAvailability(existing.slotId, 'available');
      else Store.Slots.create({ teacherId: currentUser.uid, date: date, time: time, status: 'available', baseStatus: 'available' });

    } else if (action === 'timeout') {
      // timeout = one-time unavailable, recurring rule stays
      if (existing) Store.Slots.setAvailability(existing.slotId, 'timeout');
      else Store.Slots.create({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout', baseStatus: 'timeout' });

    } else if (action === 'disabled') {
      // disabled = permanently off, remove recurring rule
      Store.Recurring.deleteByTeacherDayTime(currentUser.uid, dow, time);
      if (existing && !existing.studentId) Store.Slots.delete(existing.slotId);

    } else if (action === 'timeout-disabled') {
      // Keep recurring rule, but mark this specific week's slot as timeout
      if (existing) Store.Slots.update(existing.slotId, { status: 'timeout' });
      else Store.Slots.create({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout' });
    }
  }
  gridPending = {};
}

/* ── Helpers ──────────────────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   ALL BOOKINGS VIEW
══════════════════════════════════════════════════════════ */

function renderAllBookings() {
  // Populate student filter
  var filterEl  = document.getElementById('bookings-student-filter');
  var selections = Store.Selections.byTeacher(currentUser.uid);
  var students   = selections.map(function(s) { return Store.Users.byUid(s.studentId); }).filter(Boolean);

  filterEl.innerHTML = '';
  var optAll = document.createElement('option');
  optAll.value = 'all';
  optAll.textContent = 'All students';
  filterEl.appendChild(optAll);
  for (var i = 0; i < students.length; i++) {
    var opt = document.createElement('option');
    opt.value = students[i].uid;
    opt.textContent = students[i].name;
    filterEl.appendChild(opt);
  }
  filterEl.value = allBookingsFilter;

  // Re-render on filter change
  filterEl.onchange = function() {
    allBookingsFilter = filterEl.value;
    renderAllBookingsList();
  };

  renderAllBookingsList();
}

function renderAllBookingsList() {
  var container = document.getElementById('all-bookings-list');
  container.innerHTML = '';

  // Gather all booked slots — keep original Store data for grouping/display
  // Mark pending-cancel slots with _pending flag for amber styling
  var allSlots = Store.Slots.byTeacher(currentUser.uid)
    .filter(function(s) {
      return s.status === 'booked' && s.studentId;
    })
    .map(function(s) {
      var p = pendingBookings[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  // Filter by student
  if (allBookingsFilter !== 'all') {
    allSlots = allSlots.filter(function(s) { return s.studentId === allBookingsFilter; });
  }

  if (!allSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = 'No bookings found.';
    container.appendChild(empty);
    return;
  }

  // Sort by date + time
  allSlots.sort(function(a, b) {
    return a.date.localeCompare(b.date) || a.time.localeCompare(b.time);
  });

  // Group by date
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < allSlots.length; i++) {
    var s = allSlots[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr  = dateOrder[d];
    var dateSlots = byDate[dateStr];

    // Day divider
    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider';
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('en-GB', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
    container.appendChild(divider);

    // Merge consecutive booked slots (same student) into blocks
    var blocks = mergeAllBookingBlocks(dateStr, dateSlots);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(buildAllBookingBlock(blocks[b]));
    }
  }
}

/**
 * Merge consecutive booked slots of the same student into blocks.
 * Also include available slots between booked ones for display when expanded.
 */
function mergeAllBookingBlocks(dateStr, bookedSlots) {
  var blocks = [];
  var i = 0;
  while (i < bookedSlots.length) {
    var s       = bookedSlots[i];
    var student = Store.Users.byUid(s.studentId);
    var end     = Store.slotEndTime(s.time);
    var grp     = [s];
    var j       = i + 1;

    // Merge consecutive slots of same student
    while (j < bookedSlots.length) {
      var next = bookedSlots[j];
      if (next.studentId === s.studentId && next.time === end) {
        end = Store.slotEndTime(next.time);
        grp.push(next);
        j++;
      } else { break; }
    }

    var blockHasPending = grp.some(function(x) { return !!x._pending; });
    blocks.push({
      dateStr:     dateStr,
      student:     student,
      start:       s.time,
      end:         end,
      bookedSlots: grp,
      hasPending:  blockHasPending
    });
    i = j;
  }
  return blocks;
}

function buildAllBookingBlock(block) {
  var blockKey = block.dateStr + '-' + block.start + '-' + (block.student ? block.student.uid : 'x');
  var isOpen   = !!expandedAllBlocks[blockKey];
  var studentName = block.student ? block.student.name : '?';

  var hasPending = !!block.hasPending;
  var wrapper = document.createElement('div');
  wrapper.className = 'all-booking-block-wrapper';

  // Header
  var header = document.createElement('div');
  header.className = 'all-booking-block-header' + (hasPending ? ' block-pending' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'all-booking-block-time';
  timeEl.textContent = block.start + ' – ' + block.end;

  var studentEl = document.createElement('span');
  studentEl.className = 'all-booking-block-student';
  studentEl.textContent = studentName;

  var metaEl = document.createElement('span');
  metaEl.className = 'all-booking-block-meta';
  metaEl.textContent = block.bookedSlots.length + ' slot' + (block.bookedSlots.length !== 1 ? 's' : '');

  var chevron = document.createElement('span');
  chevron.className = 'all-booking-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  var moveAllBtn = document.createElement('button');
  moveAllBtn.className = 'btn btn-ghost btn-sm all-booking-move-all-btn';
  moveAllBtn.textContent = '⇄ Move';
  (function(b) {
    moveAllBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      openMoveBlockDialog(b);
    });
  })(block);

  header.appendChild(timeEl);
  header.appendChild(studentEl);
  header.appendChild(metaEl);
  header.appendChild(moveAllBtn);
  header.appendChild(chevron);

  // Detail panel
  var detail = document.createElement('div');
  detail.className = 'all-booking-block-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) populateAllBookingDetail(detail, block);

  function toggle() {
    if (expandedAllBlocks[blockKey]) {
      delete expandedAllBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedAllBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateAllBookingDetail(detail, block);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

function populateAllBookingDetail(detail, block) {
  detail.innerHTML = '';
  var stuId = block.student ? block.student.uid : null;

  var allDateSlots = Store.Slots.byTeacherDate(currentUser.uid, block.dateStr)
    .sort(function(a, b) { return a.time.localeCompare(b.time); });

  var display = allDateSlots.filter(function(s) {
    if (s.status === 'booked' && s.studentId === stuId) return true;
    if ((s.status === 'available' || s.status === 'recurring') && !s.studentId) return true;
    if (pendingBookings[s.slotId]) return true;
    return false;
  });

  if (!display.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.style.padding = 'var(--sp-3)';
    empty.textContent = 'No slots available on this day.';
    detail.appendChild(empty);
    return;
  }

  for (var i = 0; i < display.length; i++) {
    var origSlot   = display[i];
    var isPending  = !!pendingBookings[origSlot.slotId];
    var pendingObj = pendingBookings[origSlot.slotId];
    var isBooked   = (origSlot.status === 'booked' && origSlot.studentId === stuId)
                   || (isPending && pendingObj.action === 'book');

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row' + (isBooked ? '' : ' all-booking-slot-available') + (isPending ? ' slot-pending' : '');

    var timeEl = document.createElement('span');
    timeEl.className = 'all-booking-slot-time';
    timeEl.textContent = origSlot.time + ' – ' + Store.slotEndTime(origSlot.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'all-booking-slot-status';
    statusEl.textContent = isBooked ? 'Gebucht' : 'Frei';

    var btnGroup = document.createElement('div');
    btnGroup.className = 'all-booking-slot-btns';

    if (isBooked) {
      var cancelBtn = document.createElement('button');
      cancelBtn.className = (isPending && pendingObj.action === 'cancel') ? 'btn btn-ghost btn-sm' : 'btn btn-danger btn-sm';
      cancelBtn.textContent = (isPending && pendingObj.action === 'cancel') ? 'Undo' : 'Cancel';
      (function(s) {
        cancelBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'cancel') {
            delete pendingBookings[s.slotId];
          } else if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'book') {
            delete pendingBookings[s.slotId];
          } else {
            var original = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
            pendingBookings[s.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
          }
          updateBookingSaveBtn();
          renderStudentList();
          renderAllBookingsList();
        });
      })(origSlot);
      btnGroup.appendChild(cancelBtn);


    } else {
      var addBtn = document.createElement('button');
      addBtn.className = isPending ? 'btn btn-ghost btn-sm' : 'btn btn-primary btn-sm';
      addBtn.textContent = isPending ? 'Undo' : '+ Add';
      (function(s, b) {
        addBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingBookings[s.slotId]) {
            delete pendingBookings[s.slotId];
          } else {
            var original = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
            pendingBookings[s.slotId] = { action: 'book', originalSlot: original, newStudentId: stuId, extraStudents: [] };
          }
          updateBookingSaveBtn();
          renderStudentList();
          renderAllBookingsList();
        });
      })(origSlot, block);
      btnGroup.appendChild(addBtn);
    }

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    row.appendChild(btnGroup);
    detail.appendChild(row);
  }
}

/* ── Move Dialog ─────────────────────────────────────── */
function openMoveDialog(slot, block) {
  var stuId      = block.student ? block.student.uid : null;
  var stuName    = block.student ? block.student.name : '?';
  var teacherId  = currentUser.uid;

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info">Move <strong>' + slot.time + ' – ' + Store.slotEndTime(slot.time) + '</strong> for <strong>' + stuName + '</strong></p>' +
      '<div class="move-dialog-row">' +
        '<div class="move-dialog-col">' +
          '<label class="form-label">Datum</label>' +
          '<input type="date" id="move-date-input" class="form-select" value="' + block.dateStr + '" />' +
        '</div>' +
        '<div class="move-dialog-col">' +
          '<label class="form-label">Uhrzeit</label>' +
          '<select id="move-time-select" class="form-select"><option value="">Datum wählen</option></select>' +
        '</div>' +
      '</div>' +
      '<div id="move-check-result" class="move-check-result"></div>' +
      '<div class="move-dialog-btns">' +
        '<button class="btn btn-primary" id="move-check-btn">Verfügbarkeit prüfen</button>' +
        '<button class="btn btn-primary" id="move-confirm-btn" style="display:none">Verschieben</button>' +
        '<button class="btn btn-ghost" id="move-cal-btn" style="display:none">Im Kalender anzeigen</button>' +
        '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '</div>' +
    '</div>';

  var result = Modal.show({ title: 'Termin verschieben', bodyHTML: bodyHTML, footerHTML: '' });

  var dateInput    = document.getElementById('move-date-input');
  var timeSelect   = document.getElementById('move-time-select');
  var checkResult  = document.getElementById('move-check-result');
  var checkBtn     = document.getElementById('move-check-btn');
  var confirmBtn   = document.getElementById('move-confirm-btn');
  var calBtn       = document.getElementById('move-cal-btn');
  var cancelBtn    = document.getElementById('modal-cancel');

  function resetCheck() {
    checkResult.textContent = '';
    checkResult.className = 'move-check-result';
    confirmBtn.style.display = 'none';
    checkBtn.style.display = '';
    var hasSelection = dateInput.value && timeSelect.value;
    calBtn.style.display = hasSelection ? '' : 'none';
  }

  function rebuildTimes() {
    timeSelect.innerHTML = '';
    var dateStr = dateInput.value;
    if (!dateStr) { calBtn.style.display = 'none'; return; }
    var daySlots = Store.Slots.byTeacherDate(teacherId, dateStr)
      .filter(function(s) {
        if (s.slotId === slot.slotId) return false;
        if (s.status === 'available' || s.status === 'recurring') return true;
        if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'cancel') return true;
        return false;
      })
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    if (!daySlots.length) {
      var o = document.createElement('option');
      o.value = '';
      o.textContent = 'Keine freien Slots';
      timeSelect.appendChild(o);
      return;
    }
    for (var i = 0; i < daySlots.length; i++) {
      var o = document.createElement('option');
      o.value = daySlots[i].slotId;
      o.textContent = daySlots[i].time + ' – ' + Store.slotEndTime(daySlots[i].time);
      timeSelect.appendChild(o);
    }
    resetCheck();
  }

  rebuildTimes();
  dateInput.addEventListener('change', function() { rebuildTimes(); resetCheck(); });
  timeSelect.addEventListener('change', function() {
    resetCheck();
    calBtn.style.display = (dateInput.value && timeSelect.value) ? '' : 'none';
  });

  checkBtn.addEventListener('click', function() {
    var targetSlotId = timeSelect.value;
    if (!targetSlotId) {
      checkResult.textContent = 'Bitte Datum und Uhrzeit wählen.';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var targetSlot = Store.Slots.all().filter(function(s) { return s.slotId === targetSlotId; })[0];
    if (!targetSlot) {
      checkResult.textContent = 'Slot nicht gefunden.';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var alreadyBooked = targetSlot.status === 'booked' && !pendingBookings[targetSlot.slotId];
    if (alreadyBooked) {
      var who = Store.Users.byUid(targetSlot.studentId);
      checkResult.textContent = 'Bereits gebucht von ' + (who ? who.name : targetSlot.studentId) + '.';
      checkResult.className = 'move-check-result move-check-fail';
      confirmBtn.style.display = 'none';
      checkBtn.style.display = '';
    } else {
      checkResult.textContent = '✓ Slot ist frei — Verschiebung möglich.';
      checkResult.className = 'move-check-result move-check-ok';
      confirmBtn.style.display = '';
      calBtn.style.display = '';
      checkBtn.style.display = 'none';
    }
  });

  confirmBtn.addEventListener('click', function() {
    var targetSlotId = timeSelect.value;
    if (!targetSlotId) return;
    var originalSlot = Store.Slots.all().filter(function(s) { return s.slotId === slot.slotId; })[0];
    var targetSlot   = Store.Slots.all().filter(function(s) { return s.slotId === targetSlotId; })[0];
    if (!originalSlot || !targetSlot) return;
    pendingBookings[slot.slotId]      = { action: 'cancel', originalSlot: originalSlot, newStudentId: null };
    pendingBookings[targetSlot.slotId] = { action: 'book',   originalSlot: targetSlot,   newStudentId: stuId, extraStudents: [] };
    updateBookingSaveBtn();
    renderStudentList();
    renderAllBookingsList();
    result.close();
    Toast.info('Verschiebung vorgemerkt — Drück Save zum Bestätigen.');
  });

  cancelBtn.addEventListener('click', result.close);

  calBtn.addEventListener('click', function() {
    var dateStr = dateInput.value;
    if (!dateStr) return;
    var target = new Date(dateStr + 'T00:00:00');
    selectedDate = target;
    viewYear  = target.getFullYear();
    viewMonth = target.getMonth();
    activeDayTab = 'bookings';
    switchTeacherView('schedule');
    renderCalendar();
    renderDayPanel();
    result.close();
    setTimeout(function() {
      var panel = document.getElementById('section-daypanel');
      if (panel) {
        var offset = getStickyOffset();
        var top = panel.getBoundingClientRect().top + window.scrollY - offset;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    }, 80);
  });
}

/* ── Move Block Dialog (alle Slots auf einmal) ───────── */
function openMoveBlockDialog(block) {
  openMoveBlockDialogShared({
    block:      block,
    teacherId:  currentUser.uid,
    pendingMap: pendingBookings,
    stuId:      block.student ? block.student.uid : null,
    onConfirm:  function() {
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderDayPanel();
    },
    onCalJump: function(dateStr, result) {
      if (!dateStr) return;
      var target = new Date(dateStr + 'T00:00:00');
      selectedDate = target;
      viewYear  = target.getFullYear();
      viewMonth = target.getMonth();
      activeDayTab = 'bookings';
      switchTeacherView('schedule');
      renderCalendar();
      renderDayPanel();
      result.close();
      setTimeout(function() {
        var panel = document.getElementById('section-daypanel');
        if (panel) {
          var offset = getStickyOffset();
          var top = panel.getBoundingClientRect().top + window.scrollY - offset;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      }, 80);
    }
  });
}

function getWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(gridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function weekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day:'numeric', month:'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' });
}

function updateStats() {
  var allSlots  = Store.Slots.byTeacher(currentUser.uid);
  var booked    = allSlots.filter(function(s) { return s.status === 'booked'; }).length;
  var available = allSlots.filter(function(s) { return s.status === 'available'; }).length;
  document.getElementById('stat-booked').textContent    = booked;
  document.getElementById('stat-available').textContent = available;
}

function fmtDate(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}

/* ── Section jump buttons ─────────────────────────────── */
function getSectionJumpTargets() {
  if (activeTeacherView === 'all-bookings') {
    var blocks = document.querySelectorAll('#view-all-bookings .all-booking-block-wrapper');
    if (blocks.length) return Array.prototype.slice.call(blocks);
    var dividers = document.querySelectorAll('#view-all-bookings .all-bookings-day-divider');
    return dividers.length ? Array.prototype.slice.call(dividers) : [document.getElementById('view-all-bookings')].filter(Boolean);
  }
  return [
    document.getElementById('section-calendar'),
    document.getElementById('section-daypanel')
  ].filter(Boolean);
}

function getStickyOffset() {
  var navbar = document.querySelector('.navbar');
  var dayNav = document.getElementById('day-nav-bar');
  var offset = 0;
  if (navbar) offset += navbar.offsetHeight;
  if (dayNav && dayNav.classList.contains('is-sticky')) offset += dayNav.offsetHeight;
  return offset + 8;
}

function getCurrentSectionIndex(targets) {
  var offset = getStickyOffset();
  var scrollY = window.scrollY + offset + 10;
  var best = 0;
  for (var i = 0; i < targets.length; i++) {
    var top = targets[i].getBoundingClientRect().top + window.scrollY;
    if (top <= scrollY) best = i;
  }
  return best;
}

function updateJumpBtns() {
  var jumper  = document.getElementById('section-jumper');
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var upBtn   = document.getElementById('jump-up');
  var downBtn = document.getElementById('jump-down');
  if (!upBtn || !downBtn || !jumper) return;
  var isVisible = window.scrollY > 80;
  jumper.classList.toggle('is-visible', isVisible);
  upBtn.classList.toggle('is-dimmed', idx === 0);
  downBtn.classList.toggle('is-dimmed', idx === targets.length - 1);
}

function jumpSection(delta) {
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var next    = idx + delta;
  if (next < 0 || next >= targets.length) return;
  var target  = targets[next];
  var offset  = getStickyOffset();
  var top     = target.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top: top, behavior: 'smooth' });
  setTimeout(updateJumpBtns, 400);
}

window.addEventListener('scroll', updateJumpBtns);
window.addEventListener('scroll', checkDayNavSticky);

window.addEventListener('resize', function() {
  _dayNavStickyActive = !_dayNavStickyActive;
  checkDayNavSticky();
});
