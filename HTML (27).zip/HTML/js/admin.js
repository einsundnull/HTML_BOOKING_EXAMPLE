/**
 * admin.js — Admin View Logic
 *
 * Regeln: var only, function(){}, no arrow, no template literals,
 *         no ?. or ??, kein inline-style — classList only.
 */

var currentUser = null;
var activeTab   = 'teacher';

window.addEventListener('load', function() {
  currentUser = Auth.require('admin');
  if (!currentUser) return;
  Navbar.init('admin');

  /* Tab-Wechsel */
  var tabBtns = document.querySelectorAll('.segmented-btn');
  for (var t = 0; t < tabBtns.length; t++) {
    (function(btn) {
      btn.addEventListener('click', function() {
        activeTab = btn.dataset.tab;
        for (var i = 0; i < tabBtns.length; i++) { tabBtns[i].classList.remove('active'); }
        btn.classList.add('active');
        renderTable();
      });
    })(tabBtns[t]);
  }

  /* Disziplin-Gruppe ein-/ausblenden */
  document.getElementById('f-role').addEventListener('change', function() {
    _toggleDisciplineField('f-discipline-group', this.value);
    if (this.value !== 'teacher') {
      document.getElementById('f-discipline').value = '';
    }
  });

  document.getElementById('create-form').addEventListener('submit', handleCreate);

  renderStats();
  renderTable();
});

/* ── Hilfsfunktion: Disziplin-Feld toggle ─────────────── */
function _toggleDisciplineField(groupId, role) {
  var grp = document.getElementById(groupId);
  if (grp) grp.classList.toggle('is-hidden', role !== 'teacher');
}

/* ── CREATE ───────────────────────────────────────────── */
function handleCreate(e) {
  e.preventDefault();
  var uid        = document.getElementById('f-uid').value.trim();
  var name       = document.getElementById('f-name').value.trim();
  var email      = document.getElementById('f-email').value.trim();
  var role       = document.getElementById('f-role').value;
  var password   = document.getElementById('f-password').value;
  var discipline = role === 'teacher'
    ? document.getElementById('f-discipline').value.trim()
    : '';

  _clearErrors();
  var valid = true;
  if (!uid)  { _showError('e-uid',  'UID ist erforderlich.');  valid = false; }
  if (!name) { _showError('e-name', 'Name ist erforderlich.'); valid = false; }
  if (!role) { _showError('e-role', 'Rolle wählen.');          valid = false; }
  if (!valid) return;

  try {
    Store.Users.create({ uid: uid, name: name, role: role, email: email, discipline: discipline, password: password });
    var roleLabel = role === 'teacher' ? 'Lehrer' : 'Schüler';
    Toast.success(roleLabel + ' <strong>' + name + '</strong> erstellt.');
    e.target.reset();
    _toggleDisciplineField('f-discipline-group', '');
    activeTab = role;
    var tabBtns = document.querySelectorAll('.segmented-btn');
    for (var i = 0; i < tabBtns.length; i++) {
      tabBtns[i].classList.toggle('active', tabBtns[i].dataset.tab === role);
    }
    renderStats();
    renderTable();
  } catch(err) {
    _showError('e-uid', err.message);
  }
}

/* ── EDIT ─────────────────────────────────────────────── */
function handleEdit(uid) {
  var user = Store.Users.byUid(uid);
  if (!user) return;

  var tpl = document.getElementById('tpl-edit-modal');
  var body = document.importNode(tpl.content, true);
  var wrapper = document.createElement('div');
  wrapper.appendChild(body);

  var nameInput  = wrapper.querySelector('#edit-name');
  var emailInput = wrapper.querySelector('#edit-email');
  var discInput  = wrapper.querySelector('#edit-discipline');
  var discGroup  = wrapper.querySelector('#edit-discipline-group');

  nameInput.value  = user.name  || '';
  emailInput.value = user.email || '';
  discInput.value  = user.discipline || '';

  /* Disziplin nur für Lehrer anzeigen */
  if (discGroup) {
    discGroup.classList.toggle('is-hidden', user.role !== 'teacher');
  }

  var result = Modal.show({
    title: 'Benutzer bearbeiten — ' + uid,
    bodyHTML: wrapper.innerHTML,
    footerHTML:
      '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '<button class="btn btn-primary" id="modal-save">Speichern</button>'
  });

  /* Werte nach Modal-Injection lesen */
  document.getElementById('edit-name').value  = user.name  || '';
  document.getElementById('edit-email').value = user.email || '';
  document.getElementById('edit-password').value  = '';
  document.getElementById('edit-discipline').value = user.discipline || '';

  document.getElementById('modal-cancel').addEventListener('click', result.close);

  document.getElementById('modal-save').addEventListener('click', function() {
    var newName  = document.getElementById('edit-name').value.trim();
    var newEmail = document.getElementById('edit-email').value.trim();
    var newPw    = document.getElementById('edit-password').value;
    var newDisc  = user.role === 'teacher'
      ? document.getElementById('edit-discipline').value.trim()
      : '';

    var errEl = document.getElementById('edit-e-name');
    if (!newName) {
      if (errEl) { errEl.textContent = 'Name ist erforderlich.'; errEl.classList.remove('is-hidden'); }
      return;
    }
    if (errEl) { errEl.textContent = ''; errEl.classList.add('is-hidden'); }

    try {
      Store.Users.update(uid, { name: newName, email: newEmail, discipline: newDisc, password: newPw });
      Toast.success('Benutzer <strong>' + newName + '</strong> aktualisiert.');
      renderStats();
      renderTable();
      result.close();
    } catch(err) {
      Toast.error(err.message);
    }
  });
}

/* ── DELETE ───────────────────────────────────────────── */
function handleDelete(uid) {
  var user = Store.Users.byUid(uid);
  if (!user) return;

  var displayName = ProfileStore.getDisplayName(user.uid);
  var result = Modal.show({
    title: 'Benutzer löschen',
    bodyHTML:
      '<p><strong>' + displayName + '</strong> (' + uid + ') wirklich löschen?</p>' +
      '<p class="text-muted">Alle Buchungen und Auswahlen werden ebenfalls entfernt.</p>',
    footerHTML:
      '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '<button class="btn btn-danger" id="modal-confirm">Löschen</button>'
  });

  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      Store.Users.delete(uid);
      Toast.success('Benutzer <strong>' + displayName + '</strong> gelöscht.');
      renderStats();
      renderTable();
    } catch(err) {
      Toast.error(err.message);
    }
    result.close();
  });
}

/* ── STATS ────────────────────────────────────────────── */
function renderStats() {
  var users    = Store.Users.all();
  var teachers = users.filter(function(u) { return u.role === 'teacher'; }).length;
  var students = users.filter(function(u) { return u.role === 'student'; }).length;
  var bookings = Store.Slots.all().filter(function(s) { return s.status === 'booked'; }).length;
  document.getElementById('stat-teachers').textContent = teachers;
  document.getElementById('stat-students').textContent = students;
  document.getElementById('stat-bookings').textContent = bookings;
}

/* ── TABLE ────────────────────────────────────────────── */
function renderTable() {
  var users = Store.Users.byRole(activeTab);
  var tbody = document.getElementById('user-tbody');

  if (!users.length) {
    tbody.innerHTML =
      '<tr><td colspan="4" class="table-empty-cell">Noch keine ' +
      (activeTab === 'teacher' ? 'Lehrer' : 'Schüler') +
      ' vorhanden.</td></tr>';
    return;
  }

  var rows = '';
  for (var i = 0; i < users.length; i++) {
    var u = users[i];
    var bookingCount = activeTab === 'teacher'
      ? Store.Slots.byTeacher(u.uid).length
      : Store.Slots.byStudent(u.uid).length;
    var selCount = activeTab === 'teacher'
      ? Store.Selections.byTeacher(u.uid).length
      : Store.Selections.byStudent(u.uid).length;

    var discBadge = (activeTab === 'teacher' && u.discipline)
      ? '<span class="admin-discipline-badge">' + _esc(_disciplineLabel(u.discipline)) + '</span>'
      : '';

    var emailBadge = u.email
      ? '<span class="admin-email-badge">' + _esc(u.email) + '</span>'
      : '';

    var infoText = activeTab === 'teacher'
      ? selCount + ' Schüler · ' + bookingCount + ' Slots'
      : selCount + ' Lehrer · ' + bookingCount + ' Buchungen';

    rows +=
      '<tr>' +
      '<td><code class="uid-badge">' + _esc(u.uid) + '</code></td>' +
      '<td class="td-name">' +
        '<span class="admin-user-name">' + _esc(ProfileStore.getDisplayName(u.uid)) + '</span>' +
        (discBadge || '') +
        (emailBadge || '') +
      '</td>' +
      '<td class="td-meta">' + infoText + '</td>' +
      '<td class="admin-actions">' +
        '<button class="btn btn-secondary btn-sm" onclick="handleEdit(\'' + _esc(u.uid) + '\')">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<path d="M11.5 2.5a2 2 0 012.8 2.8L5 14.5l-4 1 1-4 9.5-9z"' +
            ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>' +
          ' Bearbeiten' +
        '</button>' +
        '<button class="btn btn-danger btn-sm" onclick="handleDelete(\'' + _esc(u.uid) + '\')">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4"' +
            ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>' +
          ' Löschen' +
        '</button>' +
      '</td>' +
      '</tr>';
  }
  tbody.innerHTML = rows;
}

/* ── Discipline label map ────────────────────────────── */
var DISCIPLINE_LABELS = {
  'ski':         'Ski-Instruktor',
  'paragliding': 'Paragliding-Instruktor',
  'diving':      'Tauch-Instruktor',
  'tourguide':   'Reiseführer'
};

function _disciplineLabel(key) {
  return DISCIPLINE_LABELS[key] || key;
}

/* ── Helpers ──────────────────────────────────────────── */
function _showError(id, msg) {
  var el = document.getElementById(id);
  if (el) { el.textContent = msg; el.classList.remove('is-hidden'); }
}

function _clearErrors() {
  var ids = ['e-uid', 'e-name', 'e-role'];
  for (var i = 0; i < ids.length; i++) {
    var el = document.getElementById(ids[i]);
    if (el) { el.textContent = ''; el.classList.add('is-hidden'); }
  }
}

function _esc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
