/**
 * adapter-localstorage.js — LocalStorage Adapter
 *
 * Implementiert die vollständige AppService-Schnittstelle
 * auf Basis von Store (store.js) und ProfileStore (profile.js).
 *
 * WICHTIG: Diese Datei ist die einzige erlaubte Stelle, an der
 * Store.* und ProfileStore.* direkt aufgerufen werden dürfen.
 * Consumer-Code (teacher.js, student.js etc.) darf das NICHT.
 *
 * Callbacks folgen immer Node.js-Konvention: function(err, result)
 * Callbacks werden synchron aufgerufen — das ist gültig.
 * FirestoreAdapter ruft sie asynchron auf — Consumer-Code
 * unterscheidet das nicht.
 *
 * Regeln: var only, function(){}, no arrow functions,
 *         no template literals, no ?. or ??
 */

var LocalStorageAdapter = (function() {

  /* ── Interner Helfer: sicherer Callback-Aufruf ────────── */
  function _cb(callback, err, result) {
    if (typeof callback === 'function') {
      try {
        callback(err, result !== undefined ? result : null);
      } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
          console.error('[LocalStorageAdapter] Callback-Fehler:', e);
        }
      }
    }
  }

  /* ══════════════════════════════════════════════════════
     USERS
  ══════════════════════════════════════════════════════ */

  function getUser(uid, callback) {
    try {
      var user = Store.Users.byUid(uid);
      _cb(callback, null, user);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getAllUsers(callback) {
    try {
      var users = Store.Users.all();
      _cb(callback, null, users);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getUsersByRole(role, callback) {
    try {
      var users = Store.Users.byRole(role);
      _cb(callback, null, users);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createUser(data, callback) {
    try {
      var user = Store.Users.create(data);
      _cb(callback, null, user);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteUser(uid, callback) {
    try {
      Store.Users.delete(uid);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     PROFILES
  ══════════════════════════════════════════════════════ */

  function getProfile(uid, callback) {
    try {
      var profile = ProfileStore.get(uid);
      _cb(callback, null, profile);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getProfileOrDefault(uid, callback) {
    try {
      var profile = ProfileStore.getOrDefault(uid);
      _cb(callback, null, profile);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function saveProfile(uid, data, callback) {
    try {
      var saved = ProfileStore.save(uid, data);
      _cb(callback, null, saved);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getDisplayName(uid, callback) {
    try {
      var name = ProfileStore.getDisplayName(uid);
      _cb(callback, null, name);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getProfilePhoto(uid, callback) {
    try {
      var photo = ProfileStore.getPhoto(uid);
      _cb(callback, null, photo);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     TEACHERS + PROFILES (kombinierte Abfrage)
     In Firestore: eine denormalisierte Collection
     teacher_profiles/{uid} = { ...user, ...profile }
     Hier: zwei separate Reads, im Adapter gejoined.
  ══════════════════════════════════════════════════════ */

  function getTeachersWithProfiles(callback) {
    try {
      var teachers = Store.Users.byRole('teacher');
      var result   = [];
      for (var i = 0; i < teachers.length; i++) {
        var user    = teachers[i];
        var profile = ProfileStore.getOrDefault(user.uid);
        result.push({ user: user, profile: profile });
      }
      _cb(callback, null, result);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     SLOTS
  ══════════════════════════════════════════════════════ */

  function getSlotById(slotId, callback) {
    try {
      var slots = Store.Slots.all();
      var slot  = null;
      for (var i = 0; i < slots.length; i++) {
        if (slots[i].slotId === slotId) { slot = slots[i]; break; }
      }
      _cb(callback, null, slot);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSlotsByTeacher(teacherId, callback) {
    try {
      var slots = Store.Slots.byTeacher(teacherId);
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSlotsByTeacherDate(teacherId, date, callback) {
    try {
      var slots = Store.Slots.byTeacherDate(teacherId, date);
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSlotsByStudent(studentId, callback) {
    try {
      var slots = Store.Slots.byStudent(studentId);
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getAllSlots(callback) {
    try {
      var slots = Store.Slots.all();
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function slotExists(teacherId, date, time, callback) {
    try {
      var slot = Store.Slots.exists(teacherId, date, time);
      _cb(callback, null, slot);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createSlot(data, callback) {
    try {
      var slot = Store.Slots.create(data);
      _cb(callback, null, slot);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createSlotRange(teacherId, date, startTime, endTime, status, callback) {
    try {
      var count = Store.Slots.createRange(teacherId, date, startTime, endTime, status);
      _cb(callback, null, count);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function updateSlot(slotId, patch, callback) {
    try {
      Store.Slots.update(slotId, patch);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function setSlotAvailability(slotId, newBase, callback) {
    try {
      Store.Slots.setAvailability(slotId, newBase);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function bookSlot(slotId, studentId, callback) {
    try {
      Store.Slots.bookSlot(slotId, studentId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function cancelSlotBooking(slotId, callback) {
    try {
      Store.Slots.cancelBooking(slotId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteSlot(slotId, callback) {
    try {
      Store.Slots.delete(slotId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     RECURRING RULES
  ══════════════════════════════════════════════════════ */

  function getRecurringByTeacher(teacherId, callback) {
    try {
      var rules = Store.Recurring.byTeacher(teacherId);
      _cb(callback, null, rules);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function recurringExists(teacherId, dayOfWeek, time, callback) {
    try {
      var rule = Store.Recurring.exists(teacherId, dayOfWeek, time);
      _cb(callback, null, rule);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createRecurring(teacherId, dayOfWeek, time, callback) {
    try {
      Store.Recurring.create(teacherId, dayOfWeek, time);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteRecurringByDayTime(teacherId, dayOfWeek, time, callback) {
    try {
      Store.Recurring.deleteByTeacherDayTime(teacherId, dayOfWeek, time);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function materialiseWeek(teacherId, weekDates, callback) {
    try {
      Store.Recurring.materialiseWeek(teacherId, weekDates);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     SELECTIONS (Student ↔ Teacher)
  ══════════════════════════════════════════════════════ */

  function getSelectionsByStudent(studentId, callback) {
    try {
      var sels = Store.Selections.byStudent(studentId);
      _cb(callback, null, sels);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSelectionsByTeacher(teacherId, callback) {
    try {
      var sels = Store.Selections.byTeacher(teacherId);
      _cb(callback, null, sels);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createSelection(studentId, teacherId, callback) {
    try {
      Store.Selections.create(studentId, teacherId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteSelection(studentId, teacherId, callback) {
    try {
      Store.Selections.delete(studentId, teacherId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     STATS (Dashboard-Aggregate)
  ══════════════════════════════════════════════════════ */

  function getAdminStats(callback) {
    try {
      var users    = Store.Users.all();
      var slots    = Store.Slots.all();
      var teachers = 0;
      var students = 0;
      var booked   = 0;
      for (var i = 0; i < users.length; i++) {
        if (users[i].role === 'teacher') teachers++;
        if (users[i].role === 'student') students++;
      }
      for (var j = 0; j < slots.length; j++) {
        if (slots[j].status === 'booked') booked++;
      }
      _cb(callback, null, {
        totalUsers: users.length,
        teachers:   teachers,
        students:   students,
        bookings:   booked
      });
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getUserStats(uid, callback) {
    try {
      var slotCount = Store.Slots.byTeacher(uid).length;
      var selCount  = Store.Selections.byTeacher(uid).length;
      _cb(callback, null, { slots: slotCount, selections: selCount });
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     TIME HELPERS (Passthrough — kein Datenzugriff)
  ══════════════════════════════════════════════════════ */

  function slotEndTime(timeStr) {
    return Store.slotEndTime(timeStr);
  }

  function slotTimesInRange(startTime, endTime) {
    return Store.slotTimesInRange(startTime, endTime);
  }

  /* ══════════════════════════════════════════════════════
     WALLET
     localStorage Key: app_wallets  { uid: { uid, balance, currency, updatedAt } }
     localStorage Key: app_transactions  [ ...txObjects ]

     Schema Wallet:
       { uid, balance, currency: 'EUR', updatedAt }

     Schema Transaktion:
       { txId, uid, type, amount, balance, description,
         status, createdAt, relatedUid }
       type:   'deposit'|'withdrawal'|'escrow_hold'|
               'escrow_release'|'refund'|'transfer'
       status: 'completed'|'pending'|'failed'

     MIGRATION ZU STRIPE/FIRESTORE:
       - Wallets   → Firestore Collection wallets/{uid}
       - Transaktionen → Firestore Collection transactions/
         oder Stripe Payment Intents + Webhook-Log
       - escrow_hold/release → Stripe Connect Transfers
         oder separate Escrow-Collection
  ══════════════════════════════════════════════════════ */

  var _WALLET_KEY = 'app_wallets';
  var _TX_KEY     = 'app_transactions';

  function _loadWallets() {
    try {
      var raw = localStorage.getItem(_WALLET_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch(e) { return {}; }
  }

  function _saveWallets(data) {
    try { localStorage.setItem(_WALLET_KEY, JSON.stringify(data)); } catch(e) {}
  }

  function _loadTxs() {
    try {
      var raw = localStorage.getItem(_TX_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  }

  function _saveTxs(data) {
    try { localStorage.setItem(_TX_KEY, JSON.stringify(data)); } catch(e) {}
  }

  function _txId() {
    return 'tx_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7);
  }

  function _isoNow() {
    return new Date().toISOString();
  }

  /* Wallet laden oder initialisieren */
  function getWallet(uid, callback) {
    try {
      var wallets = _loadWallets();
      if (!wallets[uid]) {
        wallets[uid] = { uid: uid, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
        _saveWallets(wallets);
      }
      _cb(callback, null, wallets[uid]);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* Einzahlung */
  function deposit(uid, amount, description, callback) {
    try {
      var amt = parseFloat(amount);
      if (isNaN(amt) || amt <= 0) {
        _cb(callback, new Error('Ungültiger Betrag.'), null);
        return;
      }
      var wallets  = _loadWallets();
      if (!wallets[uid]) {
        wallets[uid] = { uid: uid, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var wallet   = wallets[uid];
      wallet.balance  = Math.round((wallet.balance + amt) * 100) / 100;
      wallet.updatedAt = _isoNow();
      _saveWallets(wallets);

      var tx = {
        txId:        _txId(),
        uid:         uid,
        type:        'deposit',
        amount:      amt,
        balance:     wallet.balance,
        description: description || '',
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  null
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);

      _cb(callback, null, { wallet: wallet, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* Auszahlung */
  function withdraw(uid, amount, description, callback) {
    try {
      var amt = parseFloat(amount);
      if (isNaN(amt) || amt <= 0) {
        _cb(callback, new Error('Ungültiger Betrag.'), null);
        return;
      }
      var wallets = _loadWallets();
      if (!wallets[uid]) {
        wallets[uid] = { uid: uid, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var wallet = wallets[uid];
      if (wallet.balance < amt) {
        _cb(callback, new Error('Nicht genug Guthaben.'), null);
        return;
      }
      wallet.balance   = Math.round((wallet.balance - amt) * 100) / 100;
      wallet.updatedAt = _isoNow();
      _saveWallets(wallets);

      var tx = {
        txId:        _txId(),
        uid:         uid,
        type:        'withdrawal',
        amount:      -amt,
        balance:     wallet.balance,
        description: description || '',
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  null
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);

      _cb(callback, null, { wallet: wallet, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* Transaktionshistorie für einen User */
  function getTransactions(uid, callback) {
    try {
      var all = _loadTxs();
      var result = [];
      for (var i = 0; i < all.length; i++) {
        if (all[i].uid === uid) result.push(all[i]);
      }
      _cb(callback, null, result);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /*
   * PHASE 2 — NOCH NICHT IMPLEMENTIERT
   * Signaturen bereits definiert für spätere Migration:
   *
   * escrowHold(studentUid, teacherUid, amount, bookingId, callback)
   *   → Student-Guthaben reservieren, in Escrow-Wallet halten
   *
   * escrowRelease(bookingId, callback)
   *   → Escrow-Betrag an Teacher freigeben
   *
   * escrowRefund(bookingId, callback)
   *   → Escrow-Betrag an Student zurückerstatten
   *
   * transferPayment(fromUid, toUid, amount, description, callback)
   *   → Direkt-Transfer zwischen zwei Wallets
   *
   * setPaymentMethod(teacherUid, method, callback)
   *   method: 'escrow'|'direct'|'on_site'|'stripe'
   *
   * getPaymentMethod(teacherUid, callback)
   */

  /* ══════════════════════════════════════════════════════
     ÖFFENTLICHE SCHNITTSTELLE
  ══════════════════════════════════════════════════════ */

  return {
    /* Users */
    getUser:                getUser,
    getAllUsers:             getAllUsers,
    getUsersByRole:         getUsersByRole,
    createUser:             createUser,
    deleteUser:             deleteUser,

    /* Profiles */
    getProfile:             getProfile,
    getProfileOrDefault:    getProfileOrDefault,
    saveProfile:            saveProfile,
    getDisplayName:         getDisplayName,
    getProfilePhoto:        getProfilePhoto,

    /* Teachers + Profiles (joined) */
    getTeachersWithProfiles: getTeachersWithProfiles,

    /* Slots */
    getSlotById:            getSlotById,
    getSlotsByTeacher:      getSlotsByTeacher,
    getSlotsByTeacherDate:  getSlotsByTeacherDate,
    getSlotsByStudent:      getSlotsByStudent,
    getAllSlots:             getAllSlots,
    slotExists:             slotExists,
    createSlot:             createSlot,
    createSlotRange:        createSlotRange,
    updateSlot:             updateSlot,
    setSlotAvailability:    setSlotAvailability,
    bookSlot:               bookSlot,
    cancelSlotBooking:      cancelSlotBooking,
    deleteSlot:             deleteSlot,

    /* Recurring */
    getRecurringByTeacher:      getRecurringByTeacher,
    recurringExists:            recurringExists,
    createRecurring:            createRecurring,
    deleteRecurringByDayTime:   deleteRecurringByDayTime,
    materialiseWeek:            materialiseWeek,

    /* Selections */
    getSelectionsByStudent: getSelectionsByStudent,
    getSelectionsByTeacher: getSelectionsByTeacher,
    createSelection:        createSelection,
    deleteSelection:        deleteSelection,

    /* Stats */
    getAdminStats:          getAdminStats,
    getUserStats:           getUserStats,

    /* Time helpers */
    slotEndTime:            slotEndTime,
    slotTimesInRange:       slotTimesInRange,

    /* Wallet */
    getWallet:              getWallet,
    deposit:                deposit,
    withdraw:               withdraw,
    getTransactions:        getTransactions
  };

}());
