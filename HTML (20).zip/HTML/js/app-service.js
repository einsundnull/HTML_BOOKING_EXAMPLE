/**
 * app-service.js — AppService
 *
 * Einzige Datenzugriffs-Schnittstelle für alle Consumer-Dateien.
 * Delegiert jeden Aufruf an den in app-config.js konfigurierten Adapter.
 *
 * Consumer-Code (teacher.js, student.js, admin.js, navbar.js,
 * skiing-catalog.js etc.) ruft NUR AppService.* auf — niemals
 * Store.*, ProfileStore.* oder localStorage direkt.
 *
 * Alle Methoden sind asynchron: function(err, result)
 *   err    — Error-Objekt bei Fehler, sonst null
 *   result — Ergebnis bei Erfolg, sonst null
 *
 * Fehler müssen im Consumer-Code immer behandelt werden.
 *
 * Regeln: var only, function(){}, no arrow functions,
 *         no template literals, no ?. or ??
 *
 * Abhängigkeiten (Ladereihenfolge in HTML):
 *   store.js → profile.js → adapter-localstorage.js (oder firestore)
 *   → app-config.js → app-service.js → [consumer files]
 */

var AppService = (function() {

  /* ── Adapter-Zugriff ────────────────────────────────────
     AppAdapter wird in app-config.js gesetzt.
     Fehler hier bedeutet: falsche Script-Ladereihenfolge. */
  function _adapter() {
    if (typeof AppAdapter === 'undefined') {
      throw new Error('[AppService] AppAdapter nicht gefunden. Ladereihenfolge prüfen: app-config.js muss vor app-service.js geladen werden.');
    }
    return AppAdapter;
  }

  /* ── Interner Helfer: Methode prüfen und delegieren ───── */
  function _call(method, args) {
    var adapter = _adapter();
    if (typeof adapter[method] !== 'function') {
      var cb = args[args.length - 1];
      if (typeof cb === 'function') {
        cb(new Error('[AppService] Adapter-Methode "' + method + '" nicht gefunden.'), null);
      }
      return;
    }
    adapter[method].apply(adapter, args);
  }

  /* ══════════════════════════════════════════════════════
     USERS
  ══════════════════════════════════════════════════════ */

  /** Einzelnen User laden.
   *  @param {string}   uid
   *  @param {function} callback — function(err, user|null) */
  function getUser(uid, callback) {
    _call('getUser', [uid, callback]);
  }

  /** Alle User laden.
   *  @param {function} callback — function(err, users[]) */
  function getAllUsers(callback) {
    _call('getAllUsers', [callback]);
  }

  /** User nach Rolle laden.
   *  @param {string}   role — 'teacher'|'student'|'admin'
   *  @param {function} callback — function(err, users[]) */
  function getUsersByRole(role, callback) {
    _call('getUsersByRole', [role, callback]);
  }

  /** User erstellen.
   *  @param {object}   data — {uid, name, role, email}
   *  @param {function} callback — function(err, user) */
  function createUser(data, callback) {
    _call('createUser', [data, callback]);
  }

  /** User löschen (inkl. zugehörige Slots + Selections).
   *  @param {string}   uid
   *  @param {function} callback — function(err, true) */
  function deleteUser(uid, callback) {
    _call('deleteUser', [uid, callback]);
  }

  /* ══════════════════════════════════════════════════════
     PROFILES
  ══════════════════════════════════════════════════════ */

  /** Profil laden oder null.
   *  @param {string}   uid
   *  @param {function} callback — function(err, profile|null) */
  function getProfile(uid, callback) {
    _call('getProfile', [uid, callback]);
  }

  /** Profil laden oder Default-Objekt (nie null).
   *  @param {string}   uid
   *  @param {function} callback — function(err, profile) */
  function getProfileOrDefault(uid, callback) {
    _call('getProfileOrDefault', [uid, callback]);
  }

  /** Profil speichern.
   *  @param {string}   uid
   *  @param {object}   data
   *  @param {function} callback — function(err, savedProfile) */
  function saveProfile(uid, data, callback) {
    _call('saveProfile', [uid, data, callback]);
  }

  /** Anzeigename: Profil-Name > Store-Name > uid.
   *  @param {string}   uid
   *  @param {function} callback — function(err, name) */
  function getDisplayName(uid, callback) {
    _call('getDisplayName', [uid, callback]);
  }

  /** Profilbild (base64) oder null.
   *  @param {string}   uid
   *  @param {function} callback — function(err, photo|null) */
  function getProfilePhoto(uid, callback) {
    _call('getProfilePhoto', [uid, callback]);
  }

  /* ══════════════════════════════════════════════════════
     TEACHERS + PROFILES (kombinierte Abfrage)
  ══════════════════════════════════════════════════════ */

  /** Alle Teacher mit ihren Profilen laden.
   *  Firestore: ein Read aus teacher_profiles Collection.
   *  LocalStorage: join in Adapter.
   *  @param {function} callback — function(err, [{user, profile}]) */
  function getTeachersWithProfiles(callback) {
    _call('getTeachersWithProfiles', [callback]);
  }

  /* ══════════════════════════════════════════════════════
     SLOTS
  ══════════════════════════════════════════════════════ */

  /** Einzelnen Slot per ID laden.
   *  @param {string}   slotId
   *  @param {function} callback — function(err, slot|null) */
  function getSlotById(slotId, callback) {
    _call('getSlotById', [slotId, callback]);
  }

  /** Alle Slots eines Teachers laden.
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, slots[]) */
  function getSlotsByTeacher(teacherId, callback) {
    _call('getSlotsByTeacher', [teacherId, callback]);
  }

  /** Slots eines Teachers für ein bestimmtes Datum (sortiert nach Zeit).
   *  @param {string}   teacherId
   *  @param {string}   date — 'YYYY-MM-DD'
   *  @param {function} callback — function(err, slots[]) */
  function getSlotsByTeacherDate(teacherId, date, callback) {
    _call('getSlotsByTeacherDate', [teacherId, date, callback]);
  }

  /** Alle Slots eines Students laden.
   *  @param {string}   studentId
   *  @param {function} callback — function(err, slots[]) */
  function getSlotsByStudent(studentId, callback) {
    _call('getSlotsByStudent', [studentId, callback]);
  }

  /** Alle Slots laden (nur Admin-Dashboard).
   *  HINWEIS: In Firestore teuer — sparsam verwenden.
   *  @param {function} callback — function(err, slots[]) */
  function getAllSlots(callback) {
    _call('getAllSlots', [callback]);
  }

  /** Prüfen ob ein Slot existiert.
   *  @param {string}   teacherId
   *  @param {string}   date
   *  @param {string}   time — 'HH:MM'
   *  @param {function} callback — function(err, slot|null) */
  function slotExists(teacherId, date, time, callback) {
    _call('slotExists', [teacherId, date, time, callback]);
  }

  /** Einzelnen Slot erstellen.
   *  @param {object}   data — {teacherId, date, time, status, ...}
   *  @param {function} callback — function(err, slot) */
  function createSlot(data, callback) {
    _call('createSlot', [data, callback]);
  }

  /** Mehrere Slots für einen Zeitbereich erstellen.
   *  @param {string}   teacherId
   *  @param {string}   date
   *  @param {string}   startTime — 'HH:MM'
   *  @param {string}   endTime   — 'HH:MM'
   *  @param {string}   status
   *  @param {function} callback — function(err, count) */
  function createSlotRange(teacherId, date, startTime, endTime, status, callback) {
    _call('createSlotRange', [teacherId, date, startTime, endTime, status, callback]);
  }

  /** Slot-Felder aktualisieren (patch).
   *  @param {string}   slotId
   *  @param {object}   patch
   *  @param {function} callback — function(err, true) */
  function updateSlot(slotId, patch, callback) {
    _call('updateSlot', [slotId, patch, callback]);
  }

  /** Verfügbarkeit eines Slots setzen (baseStatus + status).
   *  @param {string}   slotId
   *  @param {string}   newBase — 'available'|'disabled'|'timeout'
   *  @param {function} callback — function(err, true) */
  function setSlotAvailability(slotId, newBase, callback) {
    _call('setSlotAvailability', [slotId, newBase, callback]);
  }

  /** Slot buchen (status=booked, studentId setzen).
   *  Firestore: Transaction empfohlen.
   *  @param {string}   slotId
   *  @param {string}   studentId
   *  @param {function} callback — function(err, true) */
  function bookSlot(slotId, studentId, callback) {
    _call('bookSlot', [slotId, studentId, callback]);
  }

  /** Buchung stornieren (status=baseStatus, studentId=null).
   *  @param {string}   slotId
   *  @param {function} callback — function(err, true) */
  function cancelSlotBooking(slotId, callback) {
    _call('cancelSlotBooking', [slotId, callback]);
  }

  /** Slot löschen.
   *  @param {string}   slotId
   *  @param {function} callback — function(err, true) */
  function deleteSlot(slotId, callback) {
    _call('deleteSlot', [slotId, callback]);
  }

  /* ══════════════════════════════════════════════════════
     RECURRING RULES
  ══════════════════════════════════════════════════════ */

  /** Alle Recurring-Regeln eines Teachers.
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, rules[]) */
  function getRecurringByTeacher(teacherId, callback) {
    _call('getRecurringByTeacher', [teacherId, callback]);
  }

  /** Prüfen ob Recurring-Regel existiert.
   *  @param {string}   teacherId
   *  @param {number}   dayOfWeek — 0=Mo…6=So
   *  @param {string}   time — 'HH:MM'
   *  @param {function} callback — function(err, rule|null) */
  function recurringExists(teacherId, dayOfWeek, time, callback) {
    _call('recurringExists', [teacherId, dayOfWeek, time, callback]);
  }

  /** Recurring-Regel erstellen.
   *  @param {string}   teacherId
   *  @param {number}   dayOfWeek
   *  @param {string}   time
   *  @param {function} callback — function(err, true) */
  function createRecurring(teacherId, dayOfWeek, time, callback) {
    _call('createRecurring', [teacherId, dayOfWeek, time, callback]);
  }

  /** Recurring-Regel per Tag+Zeit löschen.
   *  @param {string}   teacherId
   *  @param {number}   dayOfWeek
   *  @param {string}   time
   *  @param {function} callback — function(err, true) */
  function deleteRecurringByDayTime(teacherId, dayOfWeek, time, callback) {
    _call('deleteRecurringByDayTime', [teacherId, dayOfWeek, time, callback]);
  }

  /** Recurring-Regeln für eine Woche materialisieren (Slots erstellen).
   *  @param {string}   teacherId
   *  @param {Date[]}   weekDates — Array von 7 Date-Objekten (Mo–So)
   *  @param {function} callback — function(err, true) */
  function materialiseWeek(teacherId, weekDates, callback) {
    _call('materialiseWeek', [teacherId, weekDates, callback]);
  }

  /* ══════════════════════════════════════════════════════
     SELECTIONS (Student ↔ Teacher)
  ══════════════════════════════════════════════════════ */

  /** Alle Selections eines Students.
   *  @param {string}   studentId
   *  @param {function} callback — function(err, selections[]) */
  function getSelectionsByStudent(studentId, callback) {
    _call('getSelectionsByStudent', [studentId, callback]);
  }

  /** Alle Selections eines Teachers.
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, selections[]) */
  function getSelectionsByTeacher(teacherId, callback) {
    _call('getSelectionsByTeacher', [teacherId, callback]);
  }

  /** Selection erstellen (Student wählt Teacher).
   *  @param {string}   studentId
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, true) */
  function createSelection(studentId, teacherId, callback) {
    _call('createSelection', [studentId, teacherId, callback]);
  }

  /** Selection löschen.
   *  @param {string}   studentId
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, true) */
  function deleteSelection(studentId, teacherId, callback) {
    _call('deleteSelection', [studentId, teacherId, callback]);
  }

  /* ══════════════════════════════════════════════════════
     STATS
  ══════════════════════════════════════════════════════ */

  /** Admin-Dashboard-Statistiken.
   *  @param {function} callback — function(err, {totalUsers, teachers, students, bookings}) */
  function getAdminStats(callback) {
    _call('getAdminStats', [callback]);
  }

  /** User-Statistiken (Slots + Selections).
   *  @param {string}   uid
   *  @param {function} callback — function(err, {slots, selections}) */
  function getUserStats(uid, callback) {
    _call('getUserStats', [uid, callback]);
  }

  /* ══════════════════════════════════════════════════════
     TIME HELPERS
     Kein Datenzugriff — werden direkt an Adapter delegiert
     (FirestoreAdapter hat eigene Implementierung ohne Store-Abhängigkeit)
  ══════════════════════════════════════════════════════ */

  /** Endzeit eines Slots berechnen (+30 Minuten).
   *  @param  {string} timeStr — 'HH:MM'
   *  @return {string} — 'HH:MM' */
  function slotEndTime(timeStr) {
    return _adapter().slotEndTime(timeStr);
  }

  /** Alle Slot-Zeiten in einem Bereich (30-min-Schritte).
   *  @param  {string} startTime — 'HH:MM'
   *  @param  {string} endTime   — 'HH:MM'
   *  @return {string[]} */
  function slotTimesInRange(startTime, endTime) {
    return _adapter().slotTimesInRange(startTime, endTime);
  }

  /* ══════════════════════════════════════════════════════
     ÖFFENTLICHE SCHNITTSTELLE
  ══════════════════════════════════════════════════════ */

  return {
    /* Users */
    getUser:                getUser,
    getAllUsers:             getAllUsers,
    getUsersByRole:         getUsersByRole,
    createUser:             createUser,
    deleteUser:             deleteUser,

    /* Profiles */
    getProfile:             getProfile,
    getProfileOrDefault:    getProfileOrDefault,
    saveProfile:            saveProfile,
    getDisplayName:         getDisplayName,
    getProfilePhoto:        getProfilePhoto,

    /* Teachers + Profiles */
    getTeachersWithProfiles: getTeachersWithProfiles,

    /* Slots */
    getSlotById:            getSlotById,
    getSlotsByTeacher:      getSlotsByTeacher,
    getSlotsByTeacherDate:  getSlotsByTeacherDate,
    getSlotsByStudent:      getSlotsByStudent,
    getAllSlots:             getAllSlots,
    slotExists:             slotExists,
    createSlot:             createSlot,
    createSlotRange:        createSlotRange,
    updateSlot:             updateSlot,
    setSlotAvailability:    setSlotAvailability,
    bookSlot:               bookSlot,
    cancelSlotBooking:      cancelSlotBooking,
    deleteSlot:             deleteSlot,

    /* Recurring */
    getRecurringByTeacher:    getRecurringByTeacher,
    recurringExists:          recurringExists,
    createRecurring:          createRecurring,
    deleteRecurringByDayTime: deleteRecurringByDayTime,
    materialiseWeek:          materialiseWeek,

    /* Selections */
    getSelectionsByStudent: getSelectionsByStudent,
    getSelectionsByTeacher: getSelectionsByTeacher,
    createSelection:        createSelection,
    deleteSelection:        deleteSelection,

    /* Stats */
    getAdminStats:          getAdminStats,
    getUserStats:           getUserStats,

  /* ══════════════════════════════════════════════════════
     WALLET
  ══════════════════════════════════════════════════════ */

  /**
   * Wallet eines Users laden (oder initialisieren).
   * @param {string}   uid
   * @param {Function} callback  fn(err, wallet)
   *   wallet: { uid, balance, currency, updatedAt }
   */
  function getWallet(uid, callback) {
    _call('getWallet', [uid, callback]);
  }

  /**
   * Guthaben einzahlen.
   * @param {string}   uid
   * @param {number}   amount       — positiver Betrag in EUR
   * @param {string}   description  — optionaler Verwendungszweck
   * @param {Function} callback     fn(err, { wallet, transaction })
   */
  function deposit(uid, amount, description, callback) {
    _call('deposit', [uid, amount, description, callback]);
  }

  /**
   * Guthaben auszahlen.
   * Schlägt fehl wenn balance < amount.
   * @param {string}   uid
   * @param {number}   amount
   * @param {string}   description
   * @param {Function} callback  fn(err, { wallet, transaction })
   */
  function withdraw(uid, amount, description, callback) {
    _call('withdraw', [uid, amount, description, callback]);
  }

  /**
   * Transaktionshistorie eines Users laden.
   * @param {string}   uid
   * @param {Function} callback  fn(err, transactions[])
   */
  function getTransactions(uid, callback) {
    _call('getTransactions', [uid, callback]);
  }

  /*
   * PHASE 2 — NOCH NICHT IMPLEMENTIERT
   *
   * escrowHold(studentUid, teacherUid, amount, bookingId, cb)
   * escrowRelease(bookingId, cb)
   * escrowRefund(bookingId, cb)
   * transferPayment(fromUid, toUid, amount, description, cb)
   * setPaymentMethod(teacherUid, method, cb)
   * getPaymentMethod(teacherUid, cb)
   */

  /* Time helpers (synchron) */
    slotEndTime:            slotEndTime,
    slotTimesInRange:       slotTimesInRange
  };

}());

window.AppService = AppService;
