/**
 * app-config.js — Adapter-Switch
 *
 * DAS ist die einzige Datei, die bei der Migration von Mockup
 * auf Firestore-Produktion geändert werden muss.
 *
 * Mockup (localStorage):   AppAdapter = LocalStorageAdapter
 * Produktion (Firestore):  AppAdapter = FirestoreAdapter
 *
 * Regeln: var only, function(){}, no arrow functions,
 *         no template literals, no ?. or ??
 */

/* ── Adapter-Switch ─────────────────────────────────────────
   Genau eine Zeile ändern für die Migration:              */

var AppAdapter = LocalStorageAdapter;
/* var AppAdapter = FirestoreAdapter; */

/* ── Firestore-Konfiguration (nur relevant für Produktion) ──
   Beim Wechsel auf FirestoreAdapter hier die Firebase-Config
   eintragen und firebase SDK in den HTML-Dateien einbinden.

var FirebaseConfig = {
  apiKey:            'YOUR_API_KEY',
  authDomain:        'YOUR_PROJECT.firebaseapp.com',
  projectId:         'YOUR_PROJECT_ID',
  storageBucket:     'YOUR_PROJECT.appspot.com',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId:             'YOUR_APP_ID'
};
*/
