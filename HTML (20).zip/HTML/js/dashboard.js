/**
 * dashboard.js — Upcoming Lessons Dashboard
 *
 * Supports teacher and student roles.
 * Reads slots via AppService (sync), groups by date, renders schedule list.
 *
 * Rules: var only, function(){}, no arrow functions,
 *        no template literals, no ?. or ??
 *        All DOM via createElement/appendChild, no innerHTML with IDs.
 */

/* ── i18n ──────────────────────────────────────────────── */
var _dashI18n = {};

function _loadDashI18n(cb) {
  var v   = typeof APP_VERSION !== 'undefined' ? ('?v=' + APP_VERSION) : '';
  var xhr = new XMLHttpRequest();
  xhr.open('GET', './locales/dashboard.json' + v);
  xhr.onload = function() {
    try { _dashI18n = JSON.parse(xhr.responseText); } catch(e) { _dashI18n = {}; }
    cb();
  };
  xhr.onerror = function() { _dashI18n = {}; cb(); };
  xhr.send();
}

function _t(key) {
  return (_dashI18n && _dashI18n[key]) ? _dashI18n[key] : key;
}

/* ── Date helpers ──────────────────────────────────────── */
function _fmtDateKey(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}

function _todayKey() {
  return _fmtDateKey(new Date());
}

function _monthKey(dateStr) {
  /* Returns "2026-03" from "2026-03-20" */
  return dateStr.slice(0, 7);
}

function _monthLabel(monthKey) {
  /* "2026-03" → "März 2026" */
  var parts = monthKey.split('-');
  var year  = parseInt(parts[0], 10);
  var month = parseInt(parts[1], 10) - 1;
  var d = new Date(year, month, 1);
  return d.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });
}

function _weekday(dateStr) {
  /* "2026-03-20" → "Fr." */
  var d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('de-DE', { weekday: 'short' });
}

function _dayNum(dateStr) {
  return parseInt(dateStr.split('-')[2], 10);
}

/* ── Data loading ──────────────────────────────────────── */
function _loadSlots(currentUser) {
  var slots;
  if (currentUser.role === 'teacher') {
    slots = AppService.getSlotsByTeacherSync(currentUser.uid);
  } else {
    slots = AppService.getSlotsByStudentSync(currentUser.uid);
  }
  /* Only booked slots */
  slots = slots.filter(function(s) {
    return s.studentId && s.status === 'booked';
  });
  /* Sort by date + time */
  slots.sort(function(a, b) {
    if (a.date !== b.date) return a.date.localeCompare(b.date);
    return a.time.localeCompare(b.time);
  });
  return slots;
}

/* ── Stats ──────────────────────────────────────────────── */
function _buildStats(slots, currentUser, today) {
  var todaySlots  = slots.filter(function(s) { return s.date === today; });
  var weekEnd     = new Date();
  weekEnd.setDate(weekEnd.getDate() + 7);
  var weekEndKey  = _fmtDateKey(weekEnd);
  var weekSlots   = slots.filter(function(s) { return s.date >= today && s.date <= weekEndKey; });
  var totalFuture = slots.filter(function(s) { return s.date >= today; });

  var statsRow = document.getElementById('dash-stats-row');
  if (!statsRow) return;

  var defs = [
    { label: _t('statToday'),  value: todaySlots.length  },
    { label: _t('statWeek'),   value: weekSlots.length   },
    { label: _t('statTotal'),  value: totalFuture.length }
  ];

  for (var i = 0; i < defs.length; i++) {
    var card  = document.createElement('div');
    card.className = 'stat-card';
    var lbl   = document.createElement('div');
    lbl.className  = 'stat-label';
    lbl.textContent = defs[i].label;
    var val   = document.createElement('div');
    val.className  = 'stat-value';
    val.textContent = defs[i].value;
    card.appendChild(lbl);
    card.appendChild(val);
    statsRow.appendChild(card);
  }
}

/* ── Lesson card ─────────────────────────────────────────── */
function _buildLessonCard(slot, currentUser, today) {
  var card = document.createElement('div');
  card.className = 'dash-lesson';

  var isPast       = slot.date < today;
  var isConfirmed  = !!slot.confirmedAt;

  if (isPast) {
    card.classList.add('dash-lesson--past');
  } else if (isConfirmed) {
    card.classList.add('dash-lesson--confirmed');
  } else {
    card.classList.add('dash-lesson--pending');
  }

  /* Determine the "other party" uid */
  var otherUid  = currentUser.role === 'teacher' ? slot.studentId : slot.teacherId;
  var otherRole = currentUser.role === 'teacher' ? 'student' : 'teacher';

  /* Avatar */
  var avatarWrap = document.createElement('div');
  avatarWrap.className = 'dash-lesson-avatar';
  avatarWrap.innerHTML = buildAvatarHTML(otherUid, { size: 'sm', role: otherRole });

  /* Body */
  var body = document.createElement('div');
  body.className = 'dash-lesson-body';

  var name = document.createElement('div');
  name.className  = 'dash-lesson-name';
  name.textContent = ProfileStore.getDisplayName(otherUid);

  var endTime = AppService.slotEndTime(slot.time);
  var time    = document.createElement('div');
  time.className  = 'dash-lesson-time';
  time.textContent = slot.time + ' \u2013 ' + endTime;

  body.appendChild(name);
  body.appendChild(time);
  card.appendChild(body);
  card.appendChild(avatarWrap);

  return card;
}

/* ── Schedule list ─────────────────────────────────────── */
function _buildSchedule(slots, currentUser) {
  var container = document.getElementById('dash-schedule');
  if (!container) return;

  var loading = container.querySelector('.dash-loading');
  if (loading) container.removeChild(loading);

  var today     = _todayKey();
  /* Show only upcoming (today + future) */
  var upcoming  = slots.filter(function(s) { return s.date >= today; });

  if (!upcoming.length) {
    var empty = document.createElement('div');
    empty.className  = 'dash-empty';
    empty.textContent = _t('emptySchedule');
    container.appendChild(empty);
    return;
  }

  /* Group by date */
  var byDate  = {};
  var dates   = [];
  for (var i = 0; i < upcoming.length; i++) {
    var s = upcoming[i];
    if (!byDate[s.date]) {
      byDate[s.date] = [];
      dates.push(s.date);
    }
    byDate[s.date].push(s);
  }

  /* Group dates by month */
  var byMonth  = {};
  var months   = [];
  for (var di = 0; di < dates.length; di++) {
    var mk = _monthKey(dates[di]);
    if (!byMonth[mk]) {
      byMonth[mk] = [];
      months.push(mk);
    }
    byMonth[mk].push(dates[di]);
  }

  /* Render month by month */
  for (var mi = 0; mi < months.length; mi++) {
    var mk    = months[mi];
    var mDates = byMonth[mk];

    /* Month header */
    var mHeader = document.createElement('div');
    mHeader.className  = 'dash-month-header';
    mHeader.textContent = _monthLabel(mk);
    container.appendChild(mHeader);

    /* Day groups */
    for (var ddi = 0; ddi < mDates.length; ddi++) {
      var dateStr  = mDates[ddi];
      var daySlots = byDate[dateStr];

      var dayRow = document.createElement('div');
      dayRow.className = 'dash-day';

      /* Left label: weekday + day number */
      var dayLabel = document.createElement('div');
      dayLabel.className = 'dash-day-label';

      var wdEl = document.createElement('div');
      wdEl.className  = 'dash-day-weekday';
      wdEl.textContent = _weekday(dateStr);

      var dnEl = document.createElement('div');
      dnEl.className  = 'dash-day-num' + (dateStr === today ? ' dash-day-num--today' : '');
      dnEl.textContent = _dayNum(dateStr);

      dayLabel.appendChild(wdEl);
      dayLabel.appendChild(dnEl);

      /* Right: lesson cards */
      var slotsCol = document.createElement('div');
      slotsCol.className = 'dash-day-slots';

      for (var si = 0; si < daySlots.length; si++) {
        slotsCol.appendChild(_buildLessonCard(daySlots[si], currentUser, today));
      }

      dayRow.appendChild(dayLabel);
      dayRow.appendChild(slotsCol);
      container.appendChild(dayRow);
    }
  }
}

/* ── Init ───────────────────────────────────────────────── */
window.addEventListener('load', function() {
  var currentUser = Auth.current();
  if (!currentUser) {
    window.location.href = './index.html';
    return;
  }

  Navbar.init('dashboard');

  /* Loading placeholder */
  var container = document.getElementById('dash-schedule');
  if (container) {
    var loading = document.createElement('div');
    loading.className  = 'dash-loading';
    loading.textContent = _t('loading');
    container.appendChild(loading);
  }

  /* Role-specific page header */
  var titleEl    = document.getElementById('dash-title');
  var subtitleEl = document.getElementById('dash-subtitle');

  _loadDashI18n(function() {
    if (titleEl)    titleEl.textContent    = _t('pageTitle');
    if (subtitleEl) subtitleEl.textContent = _t('pageSubtitle');

    var slots = _loadSlots(currentUser);

    /* Stats */
    var today = _todayKey();
    _buildStats(slots, currentUser, today);

    /* Schedule */
    _buildSchedule(slots, currentUser);
  });
});
