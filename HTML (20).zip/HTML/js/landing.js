/**
 * landing.js — Landing Page Logic
 *
 * Verantwortlichkeiten:
 *  - Navbar initialisieren (kein Auth-Guard, public page)
 *  - AuthModal öffnen bei Login-Button und Hero-CTA
 *  - Skiing-Karte → skiing.html navigieren
 *  - Coming-soon Karten: keine Navigation
 *
 * i18n Namespace: landing
 * Regeln: var only, function(){}, string concat, no arrow functions,
 *         no ?. or ??, no template literals, no inline styles
 */

/* ── i18n ───────────────────────────────────────────────── */
var LandingI18n = {
  navLoginBtn:        'Anmelden',
  authModalTitle:     'Willkommen',
  authTabSignIn:      'Sign In',
  authTabSignUp:      'Sign Up',
  signInEmailLabel:   'E-Mail',
  signInEmailPlaceholder: 'deine@email.com',
  signInPasswordLabel: 'Passwort',
  signInPasswordPlaceholder: '••••••••',
  signInSubmit:       'Anmelden',
  signUpNameLabel:    'Vollständiger Name',
  signUpNamePlaceholder: 'Max Mustermann',
  signUpEmailLabel:   'E-Mail',
  signUpEmailPlaceholder: 'deine@email.com',
  signUpPasswordLabel: 'Passwort',
  signUpPasswordPlaceholder: 'Mindestens 8 Zeichen',
  signUpSubmit:       'Konto erstellen',
  orDivider:          'oder',
  googleSignIn:       'Mit Google anmelden',
  googleSignUp:       'Mit Google registrieren',
  mockupNotice:       'Mockup — Funktion folgt demnächst.',
  comingSoon:         'Demnächst verfügbar'
};

/* ══════════════════════════════════════════════════════════
   AuthModal — Standalone-Objekt
══════════════════════════════════════════════════════════ */
var AuthModal = {

  _overlay: null,
  _activeTab: 'signin',
  _hint: null,

  open: function(initialTab, hint) {
    var self = this;
    self._activeTab = initialTab || 'signin';
    self._hint      = hint || null;

    if (self._overlay) {
      /* Update hint text if modal already open */
      var hintEl = document.getElementById('auth-modal-hint');
      if (hintEl) {
        hintEl.textContent = self._hint || '';
        hintEl.classList.toggle('is-hidden', !self._hint);
      }
      self._setTab(self._activeTab);
      return;
    }

    self._render();
    self._bind();
    self._setTab(self._activeTab);
  },

  close: function() {
    var self = this;
    if (!self._overlay) return;
    self._overlay.remove();
    self._overlay = null;
  },

  _render: function() {
    var self = this;
    var t    = LandingI18n;

    var overlay = document.createElement('div');
    overlay.className  = 'modal-overlay';
    overlay.id         = 'auth-modal-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', t.authModalTitle);

    overlay.innerHTML =
      '<div class="modal auth-modal">' +
        '<div class="modal-header">' +
          '<span class="modal-title">' + t.authModalTitle + '</span>' +
          '<button class="modal-close" id="auth-modal-close" aria-label="Schließen">' +
            '<svg width="16" height="16" viewBox="0 0 16 16" fill="none">' +
              '<path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
            '</svg>' +
          '</button>' +
        '</div>' +
        '<div class="modal-body">' +

          /* Contextual hint (e.g. "Melde dich an, um mit X zu chatten") */
          '<div class="auth-hint' + (self._hint ? '' : ' is-hidden') + '" id="auth-modal-hint">' +
            '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true">' +
              '<circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>' +
              '<path d="M8 7v4M8 5v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
            '</svg>' +
            '<span id="auth-modal-hint-text">' + (self._hint ? self._hint : '') + '</span>' +
          '</div>' +

          /* Tab switcher */
          '<div class="auth-tabs" role="tablist">' +
            '<button class="auth-tab-btn" id="auth-tab-signin" role="tab" aria-controls="auth-panel-signin" aria-selected="false">' +
              t.authTabSignIn +
            '</button>' +
            '<button class="auth-tab-btn" id="auth-tab-signup" role="tab" aria-controls="auth-panel-signup" aria-selected="false">' +
              t.authTabSignUp +
            '</button>' +
          '</div>' +

          /* ── Sign In Panel ── */
          '<div class="auth-panel" id="auth-panel-signin" role="tabpanel" aria-labelledby="auth-tab-signin">' +

            '<div class="form-group">' +
              '<label class="form-label" for="signin-email">' + t.signInEmailLabel + '</label>' +
              '<input class="form-input" type="email" id="signin-email" placeholder="' + t.signInEmailPlaceholder + '" autocomplete="email" />' +
            '</div>' +

            '<div class="form-group">' +
              '<label class="form-label" for="signin-password">' + t.signInPasswordLabel + '</label>' +
              '<input class="form-input" type="password" id="signin-password" placeholder="' + t.signInPasswordPlaceholder + '" autocomplete="current-password" />' +
            '</div>' +

            '<button class="btn btn-primary auth-submit-btn" id="signin-submit">' + t.signInSubmit + '</button>' +

            '<div class="auth-divider">' +
              '<span class="auth-divider-line"></span>' +
              '<span>' + t.orDivider + '</span>' +
              '<span class="auth-divider-line"></span>' +
            '</div>' +

            '<button class="auth-google-btn" id="signin-google">' +
              AuthModal._googleIcon() +
              t.googleSignIn +
            '</button>' +

            '<p class="auth-mockup-notice">' + t.mockupNotice + '</p>' +
          '</div>' +

          /* ── Sign Up Panel ── */
          '<div class="auth-panel" id="auth-panel-signup" role="tabpanel" aria-labelledby="auth-tab-signup">' +

            '<div class="form-group">' +
              '<label class="form-label" for="signup-name">' + t.signUpNameLabel + '</label>' +
              '<input class="form-input" type="text" id="signup-name" placeholder="' + t.signUpNamePlaceholder + '" autocomplete="name" />' +
            '</div>' +

            '<div class="form-group">' +
              '<label class="form-label" for="signup-email">' + t.signUpEmailLabel + '</label>' +
              '<input class="form-input" type="email" id="signup-email" placeholder="' + t.signUpEmailPlaceholder + '" autocomplete="email" />' +
            '</div>' +

            '<div class="form-group">' +
              '<label class="form-label" for="signup-password">' + t.signUpPasswordLabel + '</label>' +
              '<input class="form-input" type="password" id="signup-password" placeholder="' + t.signUpPasswordPlaceholder + '" autocomplete="new-password" />' +
            '</div>' +

            '<button class="btn btn-primary auth-submit-btn" id="signup-submit">' + t.signUpSubmit + '</button>' +

            '<div class="auth-divider">' +
              '<span class="auth-divider-line"></span>' +
              '<span>' + t.orDivider + '</span>' +
              '<span class="auth-divider-line"></span>' +
            '</div>' +

            '<button class="auth-google-btn" id="signup-google">' +
              AuthModal._googleIcon() +
              t.googleSignUp +
            '</button>' +

            '<p class="auth-mockup-notice">' + t.mockupNotice + '</p>' +
          '</div>' +

        '</div>' +
      '</div>';

    document.body.appendChild(overlay);
    self._overlay = overlay;
  },

  _googleIcon: function() {
    return '<svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">' +
      '<path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.615z" fill="#4285F4"/>' +
      '<path d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.258c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>' +
      '<path d="M3.964 10.707A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.707V4.961H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.039l3.007-2.332z" fill="#FBBC05"/>' +
      '<path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.961L3.964 7.293C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>' +
    '</svg>';
  },

  _bind: function() {
    var self = this;

    /* Close button */
    var closeBtn = document.getElementById('auth-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', function() { self.close(); });

    /* Overlay click outside */
    self._overlay.addEventListener('click', function(e) {
      if (e.target === self._overlay) self.close();
    });

    /* Escape key */
    document.addEventListener('keydown', function authEsc(e) {
      if (e.key === 'Escape') {
        self.close();
        document.removeEventListener('keydown', authEsc);
      }
    });

    /* Tab buttons */
    var tabSignIn = document.getElementById('auth-tab-signin');
    var tabSignUp = document.getElementById('auth-tab-signup');

    if (tabSignIn) tabSignIn.addEventListener('click', function() { self._setTab('signin'); });
    if (tabSignUp) tabSignUp.addEventListener('click', function() { self._setTab('signup'); });

    /* Mockup: submit + google → show mockup toast */
    var mockupBtns = ['signin-submit', 'signin-google', 'signup-submit', 'signup-google'];
    for (var i = 0; i < mockupBtns.length; i++) {
      (function(id) {
        var btn = document.getElementById(id);
        if (btn) btn.addEventListener('click', function() {
          Toast.show(LandingI18n.mockupNotice, 'info');
        });
      })(mockupBtns[i]);
    }
  },

  _setTab: function(tab) {
    var self = this;
    self._activeTab = tab;

    var tabSignIn  = document.getElementById('auth-tab-signin');
    var tabSignUp  = document.getElementById('auth-tab-signup');
    var panelSignIn = document.getElementById('auth-panel-signin');
    var panelSignUp = document.getElementById('auth-panel-signup');

    if (!tabSignIn || !tabSignUp) return;

    if (tab === 'signin') {
      tabSignIn.classList.add('active');
      tabSignIn.setAttribute('aria-selected', 'true');
      tabSignUp.classList.remove('active');
      tabSignUp.setAttribute('aria-selected', 'false');
      if (panelSignIn) panelSignIn.classList.add('is-active');
      if (panelSignUp) panelSignUp.classList.remove('is-active');
    } else {
      tabSignUp.classList.add('active');
      tabSignUp.setAttribute('aria-selected', 'true');
      tabSignIn.classList.remove('active');
      tabSignIn.setAttribute('aria-selected', 'false');
      if (panelSignUp) panelSignUp.classList.add('is-active');
      if (panelSignIn) panelSignIn.classList.remove('is-active');
    }
  }
};

/* ══════════════════════════════════════════════════════════
   Landing Page Init — only called from landing.html
   AuthModal bleibt global verfügbar für andere Seiten.
══════════════════════════════════════════════════════════ */
var LandingPage = {
  init: function() {
    /* Navbar — kein Auth-Guard, public page */
    Navbar.init('landing', {
      loginBtn: {
        label:   LandingI18n.navLoginBtn,
        onClick: function() { AuthModal.open('signin'); }
      }
    });

  /* Hero CTA */
  var heroCta = document.getElementById('hero-cta-signin');
  if (heroCta) {
    heroCta.addEventListener('click', function() {
      AuthModal.open('signin');
    });
  }

  /* Instructor CTA → SignUp */
  var instructorCta = document.getElementById('instructor-cta');
  if (instructorCta) {
    instructorCta.addEventListener('click', function() {
      AuthModal.open('signup', 'Registriere dich als Instruktor und erstelle dein Lehrerprofil.');
    });
  }

  /* Skiing card → skiing.html */
    var skiCard = document.getElementById('sport-skiing');
    if (skiCard) {
      skiCard.addEventListener('click', function() {
        window.location.href = './skiing.html';
      });

      /* Keyboard support */
      skiCard.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          window.location.href = './skiing.html';
        }
      });
    }

    /* Scroll-to-top button */
    var jumper = document.getElementById('section-jumper');
    var topBtn = document.getElementById('jump-top');

    function _updateLandingScrollBtn() {
      var navH = (document.querySelector('.navbar') || {}).offsetHeight || 52;
      var scrolled = window.scrollY > navH;
      if (jumper) jumper.classList.toggle('is-visible', scrolled);
      if (topBtn) topBtn.classList.toggle('is-hidden-top', !scrolled);
    }

    if (topBtn) {
      topBtn.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }

    window.addEventListener('scroll', _updateLandingScrollBtn);
    _updateLandingScrollBtn();
  }
};

window.AuthModal  = AuthModal;
window.LandingPage = LandingPage;
