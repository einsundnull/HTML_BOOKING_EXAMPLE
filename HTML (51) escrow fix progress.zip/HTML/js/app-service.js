/**
 * app-service.js — AppService
 *
 * Einzige Datenzugriffs-Schnittstelle für alle Consumer-Dateien.
 * Delegiert jeden Aufruf an den in app-config.js konfigurierten Adapter.
 *
 * Consumer-Code (teacher.js, student.js, admin.js, navbar.js,
 * skiing-catalog.js etc.) ruft NUR AppService.* auf — niemals
 * Store.*, ProfileStore.* oder localStorage direkt.
 *
 * Alle Methoden sind asynchron: function(err, result)
 *   err    — Error-Objekt bei Fehler, sonst null
 *   result — Ergebnis bei Erfolg, sonst null
 *
 * Fehler müssen im Consumer-Code immer behandelt werden.
 *
 * Regeln: var only, function(){}, no arrow functions,
 *         no template literals, no ?. or ??
 *
 * Abhängigkeiten (Ladereihenfolge in HTML):
 *   store.js → profile.js → adapter-localstorage.js (oder firestore)
 *   → app-config.js → app-service.js → [consumer files]
 */

var AppService = (function() {

  /* ── Adapter-Zugriff ────────────────────────────────────
     AppAdapter wird in app-config.js gesetzt.
     Fehler hier bedeutet: falsche Script-Ladereihenfolge. */
  function _adapter() {
    if (typeof AppAdapter === 'undefined') {
      throw new Error('[AppService] AppAdapter nicht gefunden. Ladereihenfolge prüfen: app-config.js muss vor app-service.js geladen werden.');
    }
    return AppAdapter;
  }

  /* ── Interner Helfer: Methode prüfen und delegieren ───── */
  function _call(method, args) {
    var adapter = _adapter();
    if (typeof adapter[method] !== 'function') {
      var cb = args[args.length - 1];
      if (typeof cb === 'function') {
        cb(new Error('[AppService] Adapter-Methode "' + method + '" nicht gefunden.'), null);
      }
      return;
    }
    adapter[method].apply(adapter, args);
  }

  /* ══════════════════════════════════════════════════════
     USERS
  ══════════════════════════════════════════════════════ */

  /** Einzelnen User laden.
   *  @param {string}   uid
   *  @param {function} callback — function(err, user|null) */
  function getUser(uid, callback) {
    _call('getUser', [uid, callback]);
  }

  /** Alle User laden.
   *  @param {function} callback — function(err, users[]) */
  function getAllUsers(callback) {
    _call('getAllUsers', [callback]);
  }

  /** User nach Rolle laden.
   *  @param {string}   role — 'teacher'|'student'|'admin'
   *  @param {function} callback — function(err, users[]) */
  function getUsersByRole(role, callback) {
    _call('getUsersByRole', [role, callback]);
  }

  /** User erstellen.
   *  @param {object}   data — {uid, name, role, email}
   *  @param {function} callback — function(err, user) */
  function createUser(data, callback) {
    _call('createUser', [data, callback]);
  }

  /** User löschen (inkl. zugehörige Slots + Selections).
   *  @param {string}   uid
   *  @param {function} callback — function(err, true) */
  function deleteUser(uid, callback) {
    _call('deleteUser', [uid, callback]);
  }

  /* ══════════════════════════════════════════════════════
     PROFILES
  ══════════════════════════════════════════════════════ */

  /** Profil laden oder null.
   *  @param {string}   uid
   *  @param {function} callback — function(err, profile|null) */
  function getProfile(uid, callback) {
    _call('getProfile', [uid, callback]);
  }

  /** Profil laden oder Default-Objekt (nie null).
   *  @param {string}   uid
   *  @param {function} callback — function(err, profile) */
  function getProfileOrDefault(uid, callback) {
    _call('getProfileOrDefault', [uid, callback]);
  }

  /** Profil speichern.
   *  @param {string}   uid
   *  @param {object}   data
   *  @param {function} callback — function(err, savedProfile) */
  function saveProfile(uid, data, callback) {
    _call('saveProfile', [uid, data, callback]);
  }

  /** Anzeigename: Profil-Name > Store-Name > uid.
   *  @param {string}   uid
   *  @param {function} callback — function(err, name) */
  function getDisplayName(uid, callback) {
    _call('getDisplayName', [uid, callback]);
  }

  /** Profilbild (base64) oder null.
   *  @param {string}   uid
   *  @param {function} callback — function(err, photo|null) */
  function getProfilePhoto(uid, callback) {
    _call('getProfilePhoto', [uid, callback]);
  }

  /* ══════════════════════════════════════════════════════
     TEACHERS + PROFILES (kombinierte Abfrage)
  ══════════════════════════════════════════════════════ */

  /** Alle Teacher mit ihren Profilen laden.
   *  Firestore: ein Read aus teacher_profiles Collection.
   *  LocalStorage: join in Adapter.
   *  @param {function} callback — function(err, [{user, profile}]) */
  function getTeachersWithProfiles(callback) {
    _call('getTeachersWithProfiles', [callback]);
  }

  /* ══════════════════════════════════════════════════════
     SLOTS
  ══════════════════════════════════════════════════════ */

  /** Einzelnen Slot per ID laden.
   *  @param {string}   slotId
   *  @param {function} callback — function(err, slot|null) */
  function getSlotById(slotId, callback) {
    _call('getSlotById', [slotId, callback]);
  }

  /** Alle Slots eines Teachers laden.
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, slots[]) */
  function getSlotsByTeacher(teacherId, callback) {
    _call('getSlotsByTeacher', [teacherId, callback]);
  }

  /** Slots eines Teachers für ein bestimmtes Datum (sortiert nach Zeit).
   *  @param {string}   teacherId
   *  @param {string}   date — 'YYYY-MM-DD'
   *  @param {function} callback — function(err, slots[]) */
  function getSlotsByTeacherDate(teacherId, date, callback) {
    _call('getSlotsByTeacherDate', [teacherId, date, callback]);
  }

  /** Alle Slots eines Students laden.
   *  @param {string}   studentId
   *  @param {function} callback — function(err, slots[]) */
  function getSlotsByStudent(studentId, callback) {
    _call('getSlotsByStudent', [studentId, callback]);
  }

  /** Alle Slots laden (nur Admin-Dashboard).
   *  HINWEIS: In Firestore teuer — sparsam verwenden.
   *  @param {function} callback — function(err, slots[]) */
  function getAllSlots(callback) {
    _call('getAllSlots', [callback]);
  }

  /** Prüfen ob ein Slot existiert.
   *  @param {string}   teacherId
   *  @param {string}   date
   *  @param {string}   time — 'HH:MM'
   *  @param {function} callback — function(err, slot|null) */
  function slotExists(teacherId, date, time, callback) {
    _call('slotExists', [teacherId, date, time, callback]);
  }

  /** Einzelnen Slot erstellen.
   *  @param {object}   data — {teacherId, date, time, status, ...}
   *  @param {function} callback — function(err, slot) */
  function createSlot(data, callback) {
    _call('createSlot', [data, callback]);
  }

  /** Mehrere Slots für einen Zeitbereich erstellen.
   *  @param {string}   teacherId
   *  @param {string}   date
   *  @param {string}   startTime — 'HH:MM'
   *  @param {string}   endTime   — 'HH:MM'
   *  @param {string}   status
   *  @param {function} callback — function(err, count) */
  function createSlotRange(teacherId, date, startTime, endTime, status, callback) {
    _call('createSlotRange', [teacherId, date, startTime, endTime, status, callback]);
  }

  /** Slot-Felder aktualisieren (patch).
   *  @param {string}   slotId
   *  @param {object}   patch
   *  @param {function} callback — function(err, true) */
  function updateSlot(slotId, patch, callback) {
    _call('updateSlot', [slotId, patch, callback]);
  }

  /** Verfügbarkeit eines Slots setzen (baseStatus + status).
   *  @param {string}   slotId
   *  @param {string}   newBase — 'available'|'disabled'|'timeout'
   *  @param {function} callback — function(err, true) */
  function setSlotAvailability(slotId, newBase, callback) {
    _call('setSlotAvailability', [slotId, newBase, callback]);
  }

  /** Slot buchen (status=booked, studentId setzen).
   *  Firestore: Transaction empfohlen.
   *  @param {string}   slotId
   *  @param {string}   studentId
   *  @param {function} callback — function(err, true) */
  function bookSlot(slotId, studentId, callback) {
    _call('bookSlot', [slotId, studentId, callback]);
  }

  /** Buchung stornieren (status=baseStatus, studentId=null).
   *  @param {string}   slotId
   *  @param {function} callback — function(err, true) */
  function cancelSlotBooking(slotId, callback) {
    _call('cancelSlotBooking', [slotId, callback]);
  }

  /** Slot löschen.
   *  @param {string}   slotId
   *  @param {function} callback — function(err, true) */
  function deleteSlot(slotId, callback) {
    _call('deleteSlot', [slotId, callback]);
  }

  /**
   * Release a confirmed slot — marks as paid+released, frees for others.
   * @param {string}   slotId
   * @param {function} callback  fn(err)
   */
  function releaseSlot(slotId, callback) {
    _call('releaseSlot', [slotId, callback]);
  }

  /* ══════════════════════════════════════════════════════
     RECURRING RULES
  ══════════════════════════════════════════════════════ */

  /** Alle Recurring-Regeln eines Teachers.
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, rules[]) */
  function getRecurringByTeacher(teacherId, callback) {
    _call('getRecurringByTeacher', [teacherId, callback]);
  }

  /** Prüfen ob Recurring-Regel existiert.
   *  @param {string}   teacherId
   *  @param {number}   dayOfWeek — 0=Mo…6=So
   *  @param {string}   time — 'HH:MM'
   *  @param {function} callback — function(err, rule|null) */
  function recurringExists(teacherId, dayOfWeek, time, callback) {
    _call('recurringExists', [teacherId, dayOfWeek, time, callback]);
  }

  /** Recurring-Regel erstellen.
   *  @param {string}   teacherId
   *  @param {number}   dayOfWeek
   *  @param {string}   time
   *  @param {function} callback — function(err, true) */
  function createRecurring(teacherId, dayOfWeek, time, callback) {
    _call('createRecurring', [teacherId, dayOfWeek, time, callback]);
  }

  /** Recurring-Regel per Tag+Zeit löschen.
   *  @param {string}   teacherId
   *  @param {number}   dayOfWeek
   *  @param {string}   time
   *  @param {function} callback — function(err, true) */
  function deleteRecurringByDayTime(teacherId, dayOfWeek, time, callback) {
    _call('deleteRecurringByDayTime', [teacherId, dayOfWeek, time, callback]);
  }

  /** Recurring-Regeln für eine Woche materialisieren (Slots erstellen).
   *  @param {string}   teacherId
   *  @param {Date[]}   weekDates — Array von 7 Date-Objekten (Mo–So)
   *  @param {function} callback — function(err, true) */
  function materialiseWeek(teacherId, weekDates, callback) {
    _call('materialiseWeek', [teacherId, weekDates, callback]);
  }

  /* ══════════════════════════════════════════════════════
     SELECTIONS (Student ↔ Teacher)
  ══════════════════════════════════════════════════════ */

  /** Alle Selections eines Students.
   *  @param {string}   studentId
   *  @param {function} callback — function(err, selections[]) */
  function getSelectionsByStudent(studentId, callback) {
    _call('getSelectionsByStudent', [studentId, callback]);
  }

  /** Alle Selections eines Teachers.
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, selections[]) */
  function getSelectionsByTeacher(teacherId, callback) {
    _call('getSelectionsByTeacher', [teacherId, callback]);
  }

  /** Selection erstellen (Student wählt Teacher).
   *  @param {string}   studentId
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, true) */
  function createSelection(studentId, teacherId, callback) {
    _call('createSelection', [studentId, teacherId, callback]);
  }

  /** Selection löschen.
   *  @param {string}   studentId
   *  @param {string}   teacherId
   *  @param {function} callback — function(err, true) */
  function deleteSelection(studentId, teacherId, callback) {
    _call('deleteSelection', [studentId, teacherId, callback]);
  }

  /* ══════════════════════════════════════════════════════
     STATS
  ══════════════════════════════════════════════════════ */

  /** Admin-Dashboard-Statistiken.
   *  @param {function} callback — function(err, {totalUsers, teachers, students, bookings}) */
  function getAdminStats(callback) {
    _call('getAdminStats', [callback]);
  }

  /** User-Statistiken (Slots + Selections).
   *  @param {string}   uid
   *  @param {function} callback — function(err, {slots, selections}) */
  function getUserStats(uid, callback) {
    _call('getUserStats', [uid, callback]);
  }

  /* ══════════════════════════════════════════════════════
     TIME HELPERS
     Kein Datenzugriff — werden direkt an Adapter delegiert
     (FirestoreAdapter hat eigene Implementierung ohne Store-Abhängigkeit)
  ══════════════════════════════════════════════════════ */

  /** Endzeit eines Slots berechnen (+30 Minuten).
   *  @param  {string} timeStr — 'HH:MM'
   *  @return {string} — 'HH:MM' */
  function slotEndTime(timeStr) {
    return _adapter().slotEndTime(timeStr);
  }

  /** Alle Slot-Zeiten in einem Bereich (30-min-Schritte).
   *  @param  {string} startTime — 'HH:MM'
   *  @param  {string} endTime   — 'HH:MM'
   *  @return {string[]} */
  function slotTimesInRange(startTime, endTime) {
    return _adapter().slotTimesInRange(startTime, endTime);
  }

  /* ══════════════════════════════════════════════════════
     WALLET
  ══════════════════════════════════════════════════════ */

  /**
   * Wallet eines Users laden (oder initialisieren).
   * @param {string}   uid
   * @param {function} callback  fn(err, wallet)
   *   wallet: { uid, balance, currency, updatedAt }
   */
  function getWallet(uid, callback) {
    _call('getWallet', [uid, callback]);
  }

  /**
   * calcDepositInfo — deposit settings for a teacher + given total amount.
   * cb: fn(err, { depositAmount, depositType, depositPercent, requiresDeposit, paymentMode })
   */
  function calcDepositInfo(teacherId, fullAmount, cb) {
    _call('calcDepositInfo', [teacherId, fullAmount, cb]);
  }

  /**
   * checkPendingAffordability — single service call that answers:
   * "Can studentId afford these pending book slots?"
   *
   * pendingSlots: array of { slotId, teacherId, price } (action='book' entries)
   * cb: fn(err, {
   *   totalCost,        — sum of all pending-book slot prices
   *   walletBalance,    — current student wallet balance
   *   canAfford,        — totalCost <= walletBalance
   *   requiresDeposit,  — teacher requires deposit
   *   depositAmount,    — deposit amount required
   *   depositCovered,   — totalCost <= depositAmount (deposit is enough)
   *   paymentMode       — 'instant' | 'cash_on_site'
   * })
   */
  function checkPendingAffordability(pendingSlots, studentId, cb) {
    if (!pendingSlots || !pendingSlots.length) {
      return cb(null, { totalCost: 0, walletBalance: 0, canAfford: true,
        requiresDeposit: false, depositAmount: 0, depositCovered: true, paymentMode: 'instant' });
    }
    /* All pending slots are for one teacher (single day view) */
    var teacherId  = pendingSlots[0].teacherId;
    var totalCost  = 0;
    for (var i = 0; i < pendingSlots.length; i++) {
      totalCost += parseFloat(pendingSlots[i].price) || 0;
    }
    totalCost = Math.round(totalCost * 100) / 100;

    getWallet(studentId, function(err, wallet) {
      if (err) return cb(err, null);
      var balance = wallet ? (wallet.balance || 0) : 0;
      calcDepositInfo(teacherId, totalCost, function(err2, dep) {
        if (err2) return cb(err2, null);
        cb(null, {
          totalCost:       totalCost,
          walletBalance:   balance,
          canAfford:       totalCost <= balance,
          requiresDeposit: dep.requiresDeposit,
          depositAmount:   dep.depositAmount,
          depositCovered:  dep.requiresDeposit ? (balance >= dep.depositAmount) : true,
          paymentMode:     dep.paymentMode
        });
      });
    });
  }

  /**
   * Guthaben einzahlen.
   * @param {string}   uid
   * @param {number}   amount       — positiver Betrag in EUR
   * @param {string}   description  — optionaler Verwendungszweck
   * @param {function} callback     fn(err, { wallet, transaction })
   */
  function deposit(uid, amount, description, callback) {
    _call('deposit', [uid, amount, description, callback]);
  }

  /**
   * Guthaben auszahlen.
   * Schlaegt fehl wenn balance < amount.
   * @param {string}   uid
   * @param {number}   amount
   * @param {string}   description
   * @param {function} callback  fn(err, { wallet, transaction })
   */
  function withdraw(uid, amount, description, callback) {
    _call('withdraw', [uid, amount, description, callback]);
  }

  /**
   * Transaktionshistorie eines Users laden.
   * @param {string}   uid
   * @param {function} callback  fn(err, transactions[])
   */
  function getTransactions(uid, callback) {
    _call('getTransactions', [uid, callback]);
  }

  /*
   * PHASE 2 — IMPLEMENTIERT (localStorage Adapter)
   * Für Firestore-Migration: Adapter-Methoden ersetzen.
   */

  /* ══════════════════════════════════════════════════════
     ESCROW
  ══════════════════════════════════════════════════════ */

  function getAllEscrows(callback) { _call('getAllEscrows', [callback]); }
  function createEscrow(slotId, studentId, teacherId, cb) { _call('createEscrow', [slotId, studentId, teacherId, cb]); }
  function getEscrowBySlot(slotId, cb) { _call('getEscrowBySlot', [slotId, cb]); }
  function getEscrowsByStudent(uid, cb) { _call('getEscrowsByStudent', [uid, cb]); }
  function getEscrowsByTeacher(uid, cb) { _call('getEscrowsByTeacher', [uid, cb]); }
  function adminReleaseEscrow(escrowId, adminUid, cb) { _call('adminReleaseEscrow', [escrowId, adminUid, cb]); }
  function payDeposit(escrowId, cb) { _call('payDeposit', [escrowId, cb]); }
  function requestDepositRefund(escrowId, cb) { _call('requestDepositRefund', [escrowId, cb]); }
  function releaseDeposit(escrowId, cb) { _call('releaseDeposit', [escrowId, cb]); }
  function forfeitDeposit(escrowId, cb) { _call('forfeitDeposit', [escrowId, cb]); }
  function confirmLesson(escrowId, cb) { _call('confirmLesson', [escrowId, cb]); }

  /**
   * bookSlotWithEscrow — atomic: book slot + create escrow + pay deposit (if instant).
   * UI always calls this instead of bookSlot directly.
   * cb: fn(err, { escrow, transaction|null })
   */
  function bookSlotWithEscrow(slotId, studentId, teacherId, cb) {
    bookSlot(slotId, studentId, function(err) {
      if (err) return cb(err, null);
      createEscrow(slotId, studentId, teacherId, function(err2, escrow) {
        if (err2) {
          /* Rollback slot booking if escrow creation fails */
          cancelSlotBooking(slotId, function() { cb(err2, null); });
          return;
        }
        /* Only charge wallet if paymentMode is instant and deposit required */
        if (escrow.paymentMode === 'cash_on_site' || !escrow.requiresDeposit) {
          return cb(null, { escrow: escrow, transaction: null });
        }
        payDeposit(escrow.escrowId, function(err3, result) {
          if (err3) {
            /* Rollback: cancel slot so it doesn't appear as booked without payment */
            cancelSlotBooking(slotId, function() { cb(err3, null); });
            return;
          }
          cb(null, result);
        });
      });
    });
  }

  /** Confirm a slot booking (mark as confirmed, payment released).
   *  @param {string}   slotId
   *  @param {function} callback fn(err)  */
  function confirmSlot(slotId, callback) { _call('confirmSlot', [slotId, callback]); }

  /* ══════════════════════════════════════════════════════
     CANCELLATION POLICY
  ══════════════════════════════════════════════════════ */

  /**
   * calcCancellationPolicy — computes what happens financially if slotId is cancelled.
   * actorRole: 'student' | 'teacher' | 'admin'
   * cb: fn(err, {
   *   tier,           — 'full_refund'|'partial'|'forfeit'|'teacher_cancel'|'no_escrow'
   *   noticeHours,    — hours remaining until lesson (null if past/unknown)
   *   depositStatus,  — current escrow deposit status or null
   *   depositAmount,  — amount held (0 if no escrow)
   *   refundAmount,   — what student gets back
   *   forfeitAmount,  — what teacher keeps
   *   escrowId        — escrow id or null
   *   paymentMode     — 'instant'|'cash_on_site'
   * })
   */
  function calcCancellationPolicy(slotId, actorRole, cb) {
    /* Read slot for date+time */
    var slot = getAllSlotsSync().filter(function(s) { return s.slotId === slotId; })[0];
    if (!slot) return cb(new Error('Slot nicht gefunden: ' + slotId), null);

    getEscrowBySlot(slotId, function(err, escrow) {
      if (err) return cb(err, null);

      var depositAmount  = escrow ? (escrow.depositAmount || 0) : 0;
      var depositStatus  = escrow ? escrow.depositStatus : null;
      var paymentMode    = escrow ? (escrow.paymentMode || 'instant') : 'instant';
      var escrowId       = escrow ? escrow.escrowId : null;
      var isHeld         = depositStatus === 'held';

      /* Calculate notice hours */
      var noticeHours = null;
      try {
        var lessonMs = new Date(slot.date + 'T' + slot.time + ':00').getTime();
        noticeHours  = Math.max(0, (lessonMs - Date.now()) / 3600000);
      } catch(e) {}

      /* Teacher/admin cancels → always full refund to student */
      if (actorRole === 'teacher' || actorRole === 'admin') {
        return cb(null, {
          tier:          'teacher_cancel',
          noticeHours:   noticeHours,
          depositStatus: depositStatus,
          depositAmount: depositAmount,
          refundAmount:  isHeld ? depositAmount : 0,
          forfeitAmount: 0,
          escrowId:      escrowId,
          paymentMode:   paymentMode
        });
      }

      /* No escrow, cash payment, or deposit never paid — just cancel slot */
      if (!escrow || paymentMode === 'cash_on_site' || !isHeld) {
        var noEscrowReason = !escrow ? 'no_escrow'
          : paymentMode === 'cash_on_site' ? 'cash_on_site'
          : 'deposit_unpaid';
        return cb(null, {
          tier:          'no_escrow',
          noEscrowReason: noEscrowReason,
          noticeHours:   noticeHours,
          depositStatus: depositStatus,
          depositAmount: 0,
          refundAmount:  0,
          forfeitAmount: 0,
          escrowId:      escrowId,
          paymentMode:   paymentMode
        });
      }

      /* Read teacher profile for cancellation window settings */
      var profile           = _syncRead('getProfileOrDefault', [slot.teacherId]) || {};
      var windowHours       = parseFloat(profile.cancellationWindow)  || 48;
      var partialPct        = parseFloat(profile.cancellationPartial) || 50;
      var strictMode        = (profile.cancellationStrict === true);

      var tier, refundAmount, forfeitAmount;
      if (strictMode || noticeHours <= 0) {
        tier          = 'forfeit';
        refundAmount  = 0;
        forfeitAmount = depositAmount;
      } else if (noticeHours <= (windowHours / 2)) {
        tier          = 'partial';
        forfeitAmount = Math.round(depositAmount * (partialPct / 100) * 100) / 100;
        refundAmount  = Math.round((depositAmount - forfeitAmount) * 100) / 100;
      } else if (noticeHours <= windowHours) {
        tier          = 'partial';
        forfeitAmount = Math.round(depositAmount * (partialPct / 100) * 100) / 100;
        refundAmount  = Math.round((depositAmount - forfeitAmount) * 100) / 100;
      } else {
        tier          = 'full_refund';
        refundAmount  = depositAmount;
        forfeitAmount = 0;
      }

      cb(null, {
        tier:          tier,
        noticeHours:   noticeHours,
        depositStatus: depositStatus,
        depositAmount: depositAmount,
        refundAmount:  refundAmount,
        forfeitAmount: forfeitAmount,
        escrowId:      escrowId,
        paymentMode:   paymentMode
      });
    });
  }

  /**
   * cancelSlotWithPolicy — atomic cancellation respecting policy tier.
   * Calls cancelSlotBooking + correct escrow action.
   * actorRole: 'student'|'teacher'|'admin'
   * cb: fn(err, { policy, transaction|null })
   */
  function cancelSlotWithPolicy(slotId, actorRole, cb) {
    calcCancellationPolicy(slotId, actorRole, function(err, policy) {
      if (err) return cb(err, null);

      cancelSlotBooking(slotId, function(err2) {
        if (err2) return cb(err2, null);

        /* No escrow to settle, or deposit was never paid — still record the cancellation */
        if (!policy.escrowId || policy.tier === 'no_escrow' || policy.depositStatus === 'unpaid') {
          var slot2 = getAllSlotsSync().filter(function(s) { return s.slotId === slotId; })[0] || {};
          _call('writeCancellationRecord', [
            slotId, slot2.studentId || null, slot2.teacherId || null, policy,
            function() { cb(null, { policy: policy, transaction: null }); }
          ]);
          return;
        }

        /* Tag the escrow with cancellation tier so transactions record it */
        _call('_tagEscrowTier', [policy.escrowId, policy.tier, function() {}]);

        if (policy.tier === 'full_refund' || policy.tier === 'teacher_cancel') {
          /* request + auto release = full refund to student */
          requestDepositRefund(policy.escrowId, function(err3) {
            if (err3) return cb(new Error('Rückerstattungsanfrage fehlgeschlagen: ' + err3.message), null);
            releaseDeposit(policy.escrowId, function(err4, result) {
              if (err4) return cb(new Error('Rückerstattung fehlgeschlagen: ' + err4.message), null);
              cb(null, { policy: policy, transaction: result ? result.transaction : null });
            });
          });
        } else if (policy.tier === 'forfeit') {
          /* request + forfeit = deposit goes to teacher */
          requestDepositRefund(policy.escrowId, function(err3) {
            if (err3) return cb(new Error('Deposit-Anfrage fehlgeschlagen: ' + err3.message), null);
            forfeitDeposit(policy.escrowId, function(err4, result) {
              if (err4) return cb(new Error('Deposit-Einbehalt fehlgeschlagen: ' + err4.message), null);
              cb(null, { policy: policy, transaction: result ? result.transaction : null });
            });
          });
        } else {
          /* partial — MVP: forfeit full deposit */
          requestDepositRefund(policy.escrowId, function(err3) {
            if (err3) return cb(new Error('Deposit-Anfrage fehlgeschlagen: ' + err3.message), null);
            forfeitDeposit(policy.escrowId, function(err4, result) {
              if (err4) return cb(new Error('Deposit-Einbehalt fehlgeschlagen: ' + err4.message), null);
              cb(null, { policy: policy, transaction: result ? result.transaction : null });
            });
          });
        }
      });
    });
  }

  /** Subscribe to data changes (cross-tab sync).
   *  @param {function} callback fn(event) */
  function onChange(callback) {
    if (Store.onChange) Store.onChange(callback);
  }


  /* ══════════════════════════════════════════════════════
     SYNCHRONOUS READ HELPERS
     Valid with LocalStorageAdapter (synchronous _cb).
     Mark for async migration when switching to Firestore.
  ══════════════════════════════════════════════════════ */

  function _syncRead(method, args) {
    var result = null;
    var cbArgs = args.concat([function(err, res) { result = res; }]);
    _call(method, cbArgs);
    return result;
  }

  /* Slot reads */
  function getAllSlotsSync()                    { return _syncRead('getAllSlots', []); }
  function getSlotsByTeacherSync(uid)           { return _syncRead('getSlotsByTeacher', [uid]); }
  function getSlotsByTeacherDateSync(uid, date) { return _syncRead('getSlotsByTeacherDate', [uid, date]); }
  function getSlotsByStudentSync(uid)           { return _syncRead('getSlotsByStudent', [uid]); }
  function slotExistsSync(uid, date, time)      { return _syncRead('slotExists', [uid, date, time]); }

  /* User reads */
  function getUserSync(uid)                     { return _syncRead('getUser', [uid]); }
  function getUsersByRoleSync(role)             { return _syncRead('getUsersByRole', [role]); }

  /* Selection reads */
  function getSelectionsByStudentSync(uid)      { return _syncRead('getSelectionsByStudent', [uid]); }
  function getSelectionsByTeacherSync(uid)      { return _syncRead('getSelectionsByTeacher', [uid]); }

  /* Recurring reads */
  function recurringExistsSync(uid, dow, time)  { return _syncRead('recurringExists', [uid, dow, time]); }

  /* Wallet sync */
  function getWalletSync(uid) { return _syncRead('getWallet', [uid]); }

  /* Teacher price sync — reads locked slot price or falls back to current profile price */
  function getTeacherPriceSync(teacherId) {
    var profile = _syncRead('getProfileOrDefault', [teacherId]);
    return profile ? (parseFloat(profile.pricePerHalfHour) || 0) : 0;
  }

  /* ══════════════════════════════════════════════════════
     ÖFFENTLICHE SCHNITTSTELLE
  ══════════════════════════════════════════════════════ */

  return {
    /* Users */
    getUser:                getUser,
    getAllUsers:             getAllUsers,
    getUsersByRole:         getUsersByRole,
    createUser:             createUser,
    deleteUser:             deleteUser,

    /* Profiles */
    getProfile:             getProfile,
    getProfileOrDefault:    getProfileOrDefault,
    saveProfile:            saveProfile,
    getDisplayName:         getDisplayName,
    getProfilePhoto:        getProfilePhoto,

    /* Teachers + Profiles */
    getTeachersWithProfiles: getTeachersWithProfiles,

    /* Slots */
    getSlotById:            getSlotById,
    getSlotsByTeacher:      getSlotsByTeacher,
    getSlotsByTeacherDate:  getSlotsByTeacherDate,
    getSlotsByStudent:      getSlotsByStudent,
    getAllSlots:             getAllSlots,
    slotExists:             slotExists,
    createSlot:             createSlot,
    createSlotRange:        createSlotRange,
    updateSlot:             updateSlot,
    setSlotAvailability:    setSlotAvailability,
    bookSlot:               bookSlot,
    cancelSlotBooking:      cancelSlotBooking,
    deleteSlot:             deleteSlot,
    releaseSlot:            releaseSlot,

    /* Recurring */
    getRecurringByTeacher:    getRecurringByTeacher,
    recurringExists:          recurringExists,
    createRecurring:          createRecurring,
    deleteRecurringByDayTime: deleteRecurringByDayTime,
    materialiseWeek:          materialiseWeek,

    /* Selections */
    getSelectionsByStudent: getSelectionsByStudent,
    getSelectionsByTeacher: getSelectionsByTeacher,
    createSelection:        createSelection,
    deleteSelection:        deleteSelection,

    /* Stats */
    getAdminStats:          getAdminStats,
    getUserStats:           getUserStats,

    /* Time helpers (synchron) */
    slotEndTime:            slotEndTime,
    slotTimesInRange:       slotTimesInRange,

    /* Wallet */
    getWallet:              getWallet,
    getWalletSync:          getWalletSync,
    getTeacherPriceSync:    getTeacherPriceSync,
    calcDepositInfo:        calcDepositInfo,
    checkPendingAffordability: checkPendingAffordability,
    deposit:                deposit,
    withdraw:               withdraw,
    getTransactions:        getTransactions,

    /* Escrow */
    getAllEscrows:           getAllEscrows,
    createEscrow:            createEscrow,
    getEscrowBySlot:        getEscrowBySlot,
    getEscrowsByStudent:    getEscrowsByStudent,
    getEscrowsByTeacher:    getEscrowsByTeacher,
    adminReleaseEscrow:     adminReleaseEscrow,
    payDeposit:             payDeposit,
    requestDepositRefund:   requestDepositRefund,
    releaseDeposit:         releaseDeposit,
    forfeitDeposit:         forfeitDeposit,
    confirmLesson:          confirmLesson,
    bookSlotWithEscrow:     bookSlotWithEscrow,
    cancelSlotWithPolicy:   cancelSlotWithPolicy,
    calcCancellationPolicy: calcCancellationPolicy,
    confirmSlot:            confirmSlot,
    onChange:               onChange,

    /* Synchronous read helpers (localStorage only) */
    getAllSlotsSync:              getAllSlotsSync,
    getSlotsByTeacherSync:        getSlotsByTeacherSync,
    getSlotsByTeacherDateSync:    getSlotsByTeacherDateSync,
    getSlotsByStudentSync:        getSlotsByStudentSync,
    slotExistsSync:               slotExistsSync,
    getUserSync:                  getUserSync,
    getUsersByRoleSync:           getUsersByRoleSync,
    getSelectionsByStudentSync:   getSelectionsByStudentSync,
    getSelectionsByTeacherSync:   getSelectionsByTeacherSync,
    recurringExistsSync:          recurringExistsSync
  };

}());

window.AppService = AppService;
