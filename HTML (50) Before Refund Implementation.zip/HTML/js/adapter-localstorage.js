/**
 * adapter-localstorage.js — LocalStorage Adapter
 *
 * Implementiert die vollständige AppService-Schnittstelle
 * auf Basis von Store (store.js) und ProfileStore (profile.js).
 *
 * WICHTIG: Diese Datei ist die einzige erlaubte Stelle, an der
 * Store.* und ProfileStore.* direkt aufgerufen werden dürfen.
 * Consumer-Code (teacher.js, student.js etc.) darf das NICHT.
 *
 * Callbacks folgen immer Node.js-Konvention: function(err, result)
 * Callbacks werden synchron aufgerufen — das ist gültig.
 * FirestoreAdapter ruft sie asynchron auf — Consumer-Code
 * unterscheidet das nicht.
 *
 * Regeln: var only, function(){}, no arrow functions,
 *         no template literals, no ?. or ??
 */

var LocalStorageAdapter = (function() {

  /* ── Interner Helfer: sicherer Callback-Aufruf ────────── */
  function _cb(callback, err, result) {
    if (typeof callback === 'function') {
      callback(err, result !== undefined ? result : null);
    }
  }

  /* ══════════════════════════════════════════════════════
     USERS
  ══════════════════════════════════════════════════════ */

  function getUser(uid, callback) {
    try {
      var user = Store.Users.byUid(uid);
      _cb(callback, null, user);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getAllUsers(callback) {
    try {
      var users = Store.Users.all();
      _cb(callback, null, users);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getUsersByRole(role, callback) {
    try {
      var users = Store.Users.byRole(role);
      _cb(callback, null, users);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createUser(data, callback) {
    try {
      var user = Store.Users.create(data);
      _cb(callback, null, user);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteUser(uid, callback) {
    try {
      Store.Users.delete(uid);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     PROFILES
  ══════════════════════════════════════════════════════ */

  function getProfile(uid, callback) {
    try {
      var profile = ProfileStore.get(uid);
      _cb(callback, null, profile);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getProfileOrDefault(uid, callback) {
    try {
      var profile = ProfileStore.getOrDefault(uid);
      _cb(callback, null, profile);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function saveProfile(uid, data, callback) {
    try {
      var saved = ProfileStore.save(uid, data);
      _cb(callback, null, saved);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getDisplayName(uid, callback) {
    try {
      var name = ProfileStore.getDisplayName(uid);
      _cb(callback, null, name);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getProfilePhoto(uid, callback) {
    try {
      var photo = ProfileStore.getPhoto(uid);
      _cb(callback, null, photo);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     TEACHERS + PROFILES (kombinierte Abfrage)
     In Firestore: eine denormalisierte Collection
     teacher_profiles/{uid} = { ...user, ...profile }
     Hier: zwei separate Reads, im Adapter gejoined.
  ══════════════════════════════════════════════════════ */

  function getTeachersWithProfiles(callback) {
    try {
      var teachers = Store.Users.byRole('teacher');
      var result   = [];
      for (var i = 0; i < teachers.length; i++) {
        var user    = teachers[i];
        var profile = ProfileStore.getOrDefault(user.uid);
        result.push({ user: user, profile: profile });
      }
      _cb(callback, null, result);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     SLOTS
  ══════════════════════════════════════════════════════ */

  function getSlotById(slotId, callback) {
    try {
      var slots = Store.Slots.all();
      var slot  = null;
      for (var i = 0; i < slots.length; i++) {
        if (slots[i].slotId === slotId) { slot = slots[i]; break; }
      }
      _cb(callback, null, slot);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSlotsByTeacher(teacherId, callback) {
    try {
      var slots = Store.Slots.byTeacher(teacherId);
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSlotsByTeacherDate(teacherId, date, callback) {
    try {
      var slots = Store.Slots.byTeacherDate(teacherId, date);
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSlotsByStudent(studentId, callback) {
    try {
      var slots = Store.Slots.byStudent(studentId);
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getAllSlots(callback) {
    try {
      var slots = Store.Slots.all();
      _cb(callback, null, slots);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function slotExists(teacherId, date, time, callback) {
    try {
      var slot = Store.Slots.exists(teacherId, date, time);
      _cb(callback, null, slot);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createSlot(data, callback) {
    try {
      var slot = Store.Slots.create(data);
      _cb(callback, null, slot);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createSlotRange(teacherId, date, startTime, endTime, status, callback) {
    try {
      var count = Store.Slots.createRange(teacherId, date, startTime, endTime, status);
      _cb(callback, null, count);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function updateSlot(slotId, patch, callback) {
    try {
      Store.Slots.update(slotId, patch);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function setSlotAvailability(slotId, newBase, callback) {
    try {
      Store.Slots.setAvailability(slotId, newBase);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function bookSlot(slotId, studentId, callback) {
    try {
      /* Lock price at booking time — read from teacher profile */
      var slot    = Store.Slots.all().filter(function(s) { return s.slotId === slotId; })[0];
      var price   = slot ? (parseFloat(ProfileStore.getPrice(slot.teacherId)) || null) : null;
      Store.Slots.bookSlot(slotId, studentId, price);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function cancelSlotBooking(slotId, callback) {
    try {
      Store.Slots.cancelBooking(slotId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteSlot(slotId, callback) {
    try {
      Store.Slots.delete(slotId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function releaseSlot(slotId, callback) {
    try {
      Store.Slots.release(slotId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function confirmSlot(slotId, callback) {
    try {
      Store.Slots.confirm(slotId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     RECURRING RULES
  ══════════════════════════════════════════════════════ */

  function getRecurringByTeacher(teacherId, callback) {
    try {
      var rules = Store.Recurring.byTeacher(teacherId);
      _cb(callback, null, rules);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function recurringExists(teacherId, dayOfWeek, time, callback) {
    try {
      var rule = Store.Recurring.exists(teacherId, dayOfWeek, time);
      _cb(callback, null, rule);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createRecurring(teacherId, dayOfWeek, time, callback) {
    try {
      Store.Recurring.create(teacherId, dayOfWeek, time);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteRecurringByDayTime(teacherId, dayOfWeek, time, callback) {
    try {
      Store.Recurring.deleteByTeacherDayTime(teacherId, dayOfWeek, time);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function materialiseWeek(teacherId, weekDates, callback) {
    try {
      Store.Recurring.materialiseWeek(teacherId, weekDates);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     SELECTIONS (Student ↔ Teacher)
  ══════════════════════════════════════════════════════ */

  function getSelectionsByStudent(studentId, callback) {
    try {
      var sels = Store.Selections.byStudent(studentId);
      _cb(callback, null, sels);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getSelectionsByTeacher(teacherId, callback) {
    try {
      var sels = Store.Selections.byTeacher(teacherId);
      _cb(callback, null, sels);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function createSelection(studentId, teacherId, callback) {
    try {
      Store.Selections.create(studentId, teacherId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function deleteSelection(studentId, teacherId, callback) {
    try {
      Store.Selections.delete(studentId, teacherId);
      _cb(callback, null, true);
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     STATS (Dashboard-Aggregate)
  ══════════════════════════════════════════════════════ */

  function getAdminStats(callback) {
    try {
      var users    = Store.Users.all();
      var slots    = Store.Slots.all();
      var teachers = 0;
      var students = 0;
      var booked   = 0;
      for (var i = 0; i < users.length; i++) {
        if (users[i].role === 'teacher') teachers++;
        if (users[i].role === 'student') students++;
      }
      for (var j = 0; j < slots.length; j++) {
        if (slots[j].status === 'booked') booked++;
      }
      _cb(callback, null, {
        totalUsers: users.length,
        teachers:   teachers,
        students:   students,
        bookings:   booked
      });
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  function getUserStats(uid, callback) {
    try {
      var slotCount = Store.Slots.byTeacher(uid).length;
      var selCount  = Store.Selections.byTeacher(uid).length;
      _cb(callback, null, { slots: slotCount, selections: selCount });
    } catch (e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     TIME HELPERS (Passthrough — kein Datenzugriff)
  ══════════════════════════════════════════════════════ */

  function slotEndTime(timeStr) {
    return Store.slotEndTime(timeStr);
  }

  function slotTimesInRange(startTime, endTime) {
    return Store.slotTimesInRange(startTime, endTime);
  }

  /* ══════════════════════════════════════════════════════
     WALLET
     localStorage Key: app_wallets  { uid: { uid, balance, currency, updatedAt } }
     localStorage Key: app_transactions  [ ...txObjects ]

     Schema Wallet:
       { uid, balance, currency: 'EUR', updatedAt }

     Schema Transaktion:
       { txId, uid, type, amount, balance, description,
         status, createdAt, relatedUid }
       type:   'deposit'|'withdrawal'|'escrow_hold'|
               'escrow_release'|'refund'|'transfer'
       status: 'completed'|'pending'|'failed'

     MIGRATION ZU STRIPE/FIRESTORE:
       - Wallets   → Firestore Collection wallets/{uid}
       - Transaktionen → Firestore Collection transactions/
         oder Stripe Payment Intents + Webhook-Log
       - escrow_hold/release → Stripe Connect Transfers
         oder separate Escrow-Collection
  ══════════════════════════════════════════════════════ */

  var _WALLET_KEY = 'app_wallets';
  var _TX_KEY     = 'app_transactions';

  function _loadWallets() {
    try {
      var raw = localStorage.getItem(_WALLET_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch(e) { return {}; }
  }

  function _saveWallets(data) {
    try { localStorage.setItem(_WALLET_KEY, JSON.stringify(data)); } catch(e) {}
  }

  function _loadTxs() {
    try {
      var raw = localStorage.getItem(_TX_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  }

  function _saveTxs(data) {
    try { localStorage.setItem(_TX_KEY, JSON.stringify(data)); } catch(e) {}
  }

  function _txId() {
    return 'tx_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7);
  }

  function _isoNow() {
    return new Date().toISOString();
  }

  /* Wallet laden oder initialisieren */
  function getWallet(uid, callback) {
    try {
      var wallets = _loadWallets();
      if (!wallets[uid]) {
        wallets[uid] = { uid: uid, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
        _saveWallets(wallets);
      }
      _cb(callback, null, wallets[uid]);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* Einzahlung */
  function deposit(uid, amount, description, callback) {
    try {
      var amt = parseFloat(amount);
      if (isNaN(amt) || amt <= 0) {
        _cb(callback, new Error('Ungültiger Betrag.'), null);
        return;
      }
      var wallets  = _loadWallets();
      if (!wallets[uid]) {
        wallets[uid] = { uid: uid, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var wallet   = wallets[uid];
      wallet.balance  = Math.round((wallet.balance + amt) * 100) / 100;
      wallet.updatedAt = _isoNow();
      _saveWallets(wallets);

      var tx = {
        txId:        _txId(),
        uid:         uid,
        type:        'deposit',
        amount:      amt,
        balance:     wallet.balance,
        description: description || '',
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  null
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);

      _cb(callback, null, { wallet: wallet, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* Auszahlung */
  function withdraw(uid, amount, description, callback) {
    try {
      var amt = parseFloat(amount);
      if (isNaN(amt) || amt <= 0) {
        _cb(callback, new Error('Ungültiger Betrag.'), null);
        return;
      }
      var wallets = _loadWallets();
      if (!wallets[uid]) {
        wallets[uid] = { uid: uid, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var wallet = wallets[uid];
      if (wallet.balance < amt) {
        _cb(callback, new Error('Nicht genug Guthaben.'), null);
        return;
      }
      wallet.balance   = Math.round((wallet.balance - amt) * 100) / 100;
      wallet.updatedAt = _isoNow();
      _saveWallets(wallets);

      var tx = {
        txId:        _txId(),
        uid:         uid,
        type:        'withdrawal',
        amount:      -amt,
        balance:     wallet.balance,
        description: description || '',
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  null
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);

      _cb(callback, null, { wallet: wallet, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* Transaktionshistorie für einen User */
  function getTransactions(uid, callback) {
    try {
      var all = _loadTxs();
      var result = [];
      for (var i = 0; i < all.length; i++) {
        if (all[i].uid === uid) result.push(all[i]);
      }
      _cb(callback, null, result);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /*
   * PHASE 2 — WALLET-TRANSFERS: NOCH NICHT IMPLEMENTIERT
   * Signaturen bereits definiert fuer spaetere Migration:
   *
   * transferPayment(fromUid, toUid, amount, description, cb)
   * setPaymentMethod(teacherUid, method, cb)
   * getPaymentMethod(teacherUid, cb)
   */

  /* ══════════════════════════════════════════════════════
     ESCROW & DEPOSIT
     localStorage Key: app_escrow  [ ...escrowObjects ]

     Schema Escrow:
       { escrowId, slotId, studentId, teacherId,
         depositAmount, depositType, depositPercent,
         fullAmount, negotiatedAmount,
         paymentMode, requiresDeposit,
         depositStatus, fullPaymentStatus,
         depositPaidAt, fullPaidAt,
         studentConfirmedAt, releasedAt, createdAt }

     depositStatus:
       'unpaid' -> 'held' -> 'released'
                          -> 'refund_requested' -> 'refunded'
                                               -> 'forfeited'

     fullPaymentStatus:
       'unpaid' -> 'paid' -> 'verified'

     Profil-Felder (Teacher):
       requiresDeposit   bool    Standard: true
       depositMode       string  'fixed'|'percent'   Standard: 'fixed'
       depositFixed      number  Standard: 50
       depositPercent    number  Standard: 20
       paymentMode       string  'instant'|'cash_on_site'  Standard: 'instant'

     MIGRATION ZU FIRESTORE:
       - Escrow   -> Collection escrow/{escrowId}
       - Profil   -> denormalisiert in teacher_profiles/{uid}
  ══════════════════════════════════════════════════════ */

  var _ESCROW_KEY = 'app_escrow';

  function _loadEscrows() {
    try {
      var raw = localStorage.getItem(_ESCROW_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  }

  function _saveEscrows(data) {
    try { localStorage.setItem(_ESCROW_KEY, JSON.stringify(data)); } catch(e) {}
  }

  function _escrowId() {
    return 'esc_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
  }

  /* Deposit-Betrag aus Teacher-Profil berechnen */
  function _calcDeposit(profile, fullAmount) {
    var mode = profile.depositMode    || 'fixed';
    var fixed = parseFloat(profile.depositFixed)   || 50;
    var pct   = parseFloat(profile.depositPercent) || 20;
    var full  = parseFloat(fullAmount) || 0;
    if (mode === 'percent') {
      return {
        depositAmount:  Math.round((full * pct / 100) * 100) / 100,
        depositType:    'percent',
        depositPercent: pct
      };
    }
    return {
      depositAmount:  fixed,
      depositType:    'fixed',
      depositPercent: null
    };
  }

  /**
   * calcDepositInfo — public wrapper around _calcDeposit.
   * Returns { depositAmount, depositType, depositPercent, requiresDeposit, paymentMode }
   */
  function calcDepositInfo(teacherId, fullAmount, callback) {
    try {
      var profile = ProfileStore.getOrDefault(teacherId);
      var calc    = _calcDeposit(profile, fullAmount);
      _cb(callback, null, {
        depositAmount:   calc.depositAmount,
        depositType:     calc.depositType,
        depositPercent:  calc.depositPercent,
        requiresDeposit: (profile.requiresDeposit !== false),
        paymentMode:     profile.paymentMode || 'instant'
      });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* ── Lesen ───────────────────────────────────────────── */

  function getEscrow(escrowId, callback) {
    try {
      var all = _loadEscrows();
      var found = null;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { found = all[i]; break; }
      }
      _cb(callback, null, found);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  function getEscrowBySlot(slotId, callback) {
    try {
      var all = _loadEscrows();
      var found = null;
      for (var i = 0; i < all.length; i++) {
        if (all[i].slotId === slotId) { found = all[i]; break; }
      }
      _cb(callback, null, found);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  function getEscrowsByStudent(studentId, callback) {
    try {
      var all    = _loadEscrows();
      var result = [];
      for (var i = 0; i < all.length; i++) {
        if (all[i].studentId === studentId) result.push(all[i]);
      }
      _cb(callback, null, result);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  function getEscrowsByTeacher(teacherId, callback) {
    try {
      var all    = _loadEscrows();
      var result = [];
      for (var i = 0; i < all.length; i++) {
        if (all[i].teacherId === teacherId) result.push(all[i]);
      }
      _cb(callback, null, result);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* ── Erstellen ───────────────────────────────────────── */

  /*
   * createEscrow — beim Buchen aufgerufen.
   * Liest Teacher-Profil, berechnet Deposit, legt Escrow-Objekt an.
   * Zieht noch KEIN Geld ab — nur payDeposit() tut das.
   */
  function createEscrow(slotId, studentId, teacherId, callback) {
    try {
      var profile    = ProfileStore.getOrDefault(teacherId);
      var fullAmount = parseFloat(profile.pricePerHalfHour) || 0;
      var calc       = _calcDeposit(profile, fullAmount);
      var escrow = {
        escrowId:           _escrowId(),
        slotId:             slotId,
        studentId:          studentId,
        teacherId:          teacherId,
        depositAmount:      calc.depositAmount,
        depositType:        calc.depositType,
        depositPercent:     calc.depositPercent,
        fullAmount:         fullAmount,
        negotiatedAmount:   null,
        paymentMode:        profile.paymentMode    || 'instant',
        requiresDeposit:    (profile.requiresDeposit !== false),
        depositStatus:      'unpaid',
        fullPaymentStatus:  'unpaid',
        depositPaidAt:      null,
        fullPaidAt:         null,
        studentConfirmedAt: null,
        releasedAt:         null,
        createdAt:          _isoNow()
      };
      var all = _loadEscrows();
      all.unshift(escrow);
      _saveEscrows(all);
      _cb(callback, null, escrow);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* ── Aktionen Student ────────────────────────────────── */

  /* payDeposit: unpaid -> held. Zieht depositAmount aus Student-Wallet. */
  function payDeposit(escrowId, callback) {
    try {
      var all = _loadEscrows();
      var idx = -1;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { idx = i; break; }
      }
      if (idx === -1) { _cb(callback, new Error('Escrow nicht gefunden: ' + escrowId), null); return; }
      var escrow = all[idx];
      if (escrow.depositStatus !== 'unpaid') {
        _cb(callback, new Error('Deposit bereits bezahlt oder ungültiger Status: ' + escrow.depositStatus), null);
        return;
      }
      var wallets = _loadWallets();
      if (!wallets[escrow.studentId]) {
        wallets[escrow.studentId] = { uid: escrow.studentId, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var wallet = wallets[escrow.studentId];
      if (wallet.balance < escrow.depositAmount) {
        _cb(callback, new Error('Nicht genug Guthaben fuer Deposit (' + escrow.depositAmount + ' benoetigt).'), null);
        return;
      }
      wallet.balance   = Math.round((wallet.balance - escrow.depositAmount) * 100) / 100;
      wallet.updatedAt = _isoNow();
      _saveWallets(wallets);
      var tx = {
        txId:        _txId(),
        uid:         escrow.studentId,
        type:        'escrow_hold',
        amount:      -escrow.depositAmount,
        balance:     wallet.balance,
        description: 'Deposit fuer Slot ' + escrow.slotId,
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  escrow.teacherId
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);
      escrow.depositStatus = 'held';
      escrow.depositPaidAt = _isoNow();
      all[idx] = escrow;
      _saveEscrows(all);
      _cb(callback, null, { escrow: escrow, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* requestDepositRefund: held -> refund_requested. Teacher entscheidet. */
  function requestDepositRefund(escrowId, callback) {
    try {
      var all = _loadEscrows();
      var idx = -1;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { idx = i; break; }
      }
      if (idx === -1) { _cb(callback, new Error('Escrow nicht gefunden: ' + escrowId), null); return; }
      var escrow = all[idx];
      if (escrow.depositStatus !== 'held') {
        _cb(callback, new Error('Rueckerstattung nur moeglich wenn Status "held" (aktuell: ' + escrow.depositStatus + ').'), null);
        return;
      }
      escrow.depositStatus = 'refund_requested';
      all[idx] = escrow;
      _saveEscrows(all);
      _cb(callback, null, escrow);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /*
   * confirmLesson: Schüler bestätigt Stunde.
   * held -> released + fullPaymentStatus -> verified.
   * Schreibt Deposit ans Teacher-Wallet.
   */
  function confirmLesson(escrowId, callback) {
    try {
      var all = _loadEscrows();
      var idx = -1;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { idx = i; break; }
      }
      if (idx === -1) { _cb(callback, new Error('Escrow nicht gefunden: ' + escrowId), null); return; }
      var escrow = all[idx];
      if (escrow.depositStatus !== 'held') {
        _cb(callback, new Error('Stunde kann nur bestaetigt werden wenn Deposit "held" (aktuell: ' + escrow.depositStatus + ').'), null);
        return;
      }
      var wallets = _loadWallets();
      if (!wallets[escrow.teacherId]) {
        wallets[escrow.teacherId] = { uid: escrow.teacherId, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var tw = wallets[escrow.teacherId];
      tw.balance   = Math.round((tw.balance + escrow.depositAmount) * 100) / 100;
      tw.updatedAt = _isoNow();
      _saveWallets(wallets);
      var tx = {
        txId:        _txId(),
        uid:         escrow.teacherId,
        type:        'escrow_release',
        amount:      escrow.depositAmount,
        balance:     tw.balance,
        description: 'Deposit freigegeben fuer Slot ' + escrow.slotId,
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  escrow.studentId
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);
      var now = _isoNow();
      escrow.studentConfirmedAt = now;
      escrow.depositStatus      = 'released';
      escrow.fullPaymentStatus  = 'verified';
      escrow.releasedAt         = now;
      all[idx] = escrow;
      _saveEscrows(all);
      _cb(callback, null, { escrow: escrow, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* ── Aktionen Teacher ────────────────────────────────── */

  /* releaseDeposit: refund_requested -> refunded. Deposit zurueck an Student. */
  function releaseDeposit(escrowId, callback) {
    try {
      var all = _loadEscrows();
      var idx = -1;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { idx = i; break; }
      }
      if (idx === -1) { _cb(callback, new Error('Escrow nicht gefunden: ' + escrowId), null); return; }
      var escrow = all[idx];
      if (escrow.depositStatus !== 'refund_requested') {
        _cb(callback, new Error('Freigabe nur moeglich bei Status "refund_requested" (aktuell: ' + escrow.depositStatus + ').'), null);
        return;
      }
      var wallets = _loadWallets();
      if (!wallets[escrow.studentId]) {
        wallets[escrow.studentId] = { uid: escrow.studentId, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var sw = wallets[escrow.studentId];
      sw.balance   = Math.round((sw.balance + escrow.depositAmount) * 100) / 100;
      sw.updatedAt = _isoNow();
      _saveWallets(wallets);
      var tx = {
        txId:        _txId(),
        uid:         escrow.studentId,
        type:        'refund',
        amount:      escrow.depositAmount,
        balance:     sw.balance,
        description: 'Deposit erstattet fuer Slot ' + escrow.slotId,
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  escrow.teacherId
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);
      escrow.depositStatus = 'refunded';
      escrow.releasedAt    = _isoNow();
      all[idx] = escrow;
      _saveEscrows(all);
      _cb(callback, null, { escrow: escrow, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* forfeitDeposit: refund_requested -> forfeited. Deposit geht an Teacher (Trollschutz). */
  function forfeitDeposit(escrowId, callback) {
    try {
      var all = _loadEscrows();
      var idx = -1;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { idx = i; break; }
      }
      if (idx === -1) { _cb(callback, new Error('Escrow nicht gefunden: ' + escrowId), null); return; }
      var escrow = all[idx];
      if (escrow.depositStatus !== 'refund_requested') {
        _cb(callback, new Error('Einbehalten nur moeglich bei Status "refund_requested" (aktuell: ' + escrow.depositStatus + ').'), null);
        return;
      }
      var wallets = _loadWallets();
      if (!wallets[escrow.teacherId]) {
        wallets[escrow.teacherId] = { uid: escrow.teacherId, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var tw = wallets[escrow.teacherId];
      tw.balance   = Math.round((tw.balance + escrow.depositAmount) * 100) / 100;
      tw.updatedAt = _isoNow();
      _saveWallets(wallets);
      var tx = {
        txId:        _txId(),
        uid:         escrow.teacherId,
        type:        'escrow_release',
        amount:      escrow.depositAmount,
        balance:     tw.balance,
        description: 'Deposit einbehalten (Trollschutz) fuer Slot ' + escrow.slotId,
        status:      'completed',
        createdAt:   _isoNow(),
        relatedUid:  escrow.studentId
      };
      var txs = _loadTxs();
      txs.unshift(tx);
      _saveTxs(txs);
      escrow.depositStatus = 'forfeited';
      escrow.releasedAt    = _isoNow();
      all[idx] = escrow;
      _saveEscrows(all);
      _cb(callback, null, { escrow: escrow, transaction: tx });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* getAllEscrows — alle Escrows (nur Admin). */
  function getAllEscrows(callback) {
    try {
      _cb(callback, null, _loadEscrows());
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /*
   * adminReleaseEscrow — Admin gibt hinterlegten Deposit frei an Teacher.
   * held → released. Schreibt Deposit ans Teacher-Wallet.
   * Erstellt je eine Transaktion für Teacher (escrow_release) und
   * eine für den Admin-Log (transfer).
   */
  function adminReleaseEscrow(escrowId, adminUid, callback) {
    try {
      var all = _loadEscrows();
      var idx = -1;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { idx = i; break; }
      }
      if (idx === -1) { _cb(callback, new Error('Escrow nicht gefunden: ' + escrowId), null); return; }
      var escrow = all[idx];
      if (escrow.depositStatus !== 'held') {
        _cb(callback, new Error('Freigabe nur möglich wenn Status "held" (aktuell: ' + escrow.depositStatus + ').'), null);
        return;
      }
      var wallets = _loadWallets();
      if (!wallets[escrow.teacherId]) {
        wallets[escrow.teacherId] = { uid: escrow.teacherId, balance: 0, currency: 'EUR', updatedAt: _isoNow() };
      }
      var tw = wallets[escrow.teacherId];
      tw.balance   = Math.round((tw.balance + escrow.depositAmount) * 100) / 100;
      tw.updatedAt = _isoNow();
      _saveWallets(wallets);

      var txs = _loadTxs();
      var now = _isoNow();

      /* Teacher bekommt Gutschrift */
      txs.unshift({
        txId:        _txId(),
        uid:         escrow.teacherId,
        type:        'escrow_release',
        amount:      escrow.depositAmount,
        balance:     tw.balance,
        description: 'Zahlung freigegeben durch Admin',
        status:      'completed',
        createdAt:   now,
        relatedUid:  escrow.studentId,
        adminUid:    adminUid || null
      });

      /* Admin-Log: Transfer vermerkt */
      if (adminUid) {
        txs.unshift({
          txId:        _txId(),
          uid:         adminUid,
          type:        'transfer',
          amount:      escrow.depositAmount,
          balance:     0,
          description: 'Escrow freigegeben: ' + escrow.teacherId + ' ← ' + escrow.studentId,
          status:      'completed',
          createdAt:   now,
          relatedUid:  escrow.teacherId
        });
      }
      _saveTxs(txs);

      escrow.depositStatus = 'released';
      escrow.releasedAt    = now;
      escrow.adminReleasedBy = adminUid || null;
      all[idx] = escrow;
      _saveEscrows(all);

      _cb(callback, null, { escrow: escrow });
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* updateNegotiatedAmount — abweichender Preis nach Verhandlung. */
  function updateNegotiatedAmount(escrowId, amount, callback) {
    try {
      var amt = parseFloat(amount);
      if (isNaN(amt) || amt < 0) {
        _cb(callback, new Error('Ungültiger Betrag: ' + amount), null);
        return;
      }
      var all = _loadEscrows();
      var idx = -1;
      for (var i = 0; i < all.length; i++) {
        if (all[i].escrowId === escrowId) { idx = i; break; }
      }
      if (idx === -1) { _cb(callback, new Error('Escrow nicht gefunden: ' + escrowId), null); return; }
      all[idx].negotiatedAmount = amt;
      _saveEscrows(all);
      _cb(callback, null, all[idx]);
    } catch(e) {
      _cb(callback, e, null);
    }
  }

  /* ══════════════════════════════════════════════════════
     ÖFFENTLICHE SCHNITTSTELLE
  ══════════════════════════════════════════════════════ */

  return {
    /* Users */
    getUser:                getUser,
    getAllUsers:             getAllUsers,
    getUsersByRole:         getUsersByRole,
    createUser:             createUser,
    deleteUser:             deleteUser,

    /* Profiles */
    getProfile:             getProfile,
    getProfileOrDefault:    getProfileOrDefault,
    saveProfile:            saveProfile,
    getDisplayName:         getDisplayName,
    getProfilePhoto:        getProfilePhoto,

    /* Teachers + Profiles (joined) */
    getTeachersWithProfiles: getTeachersWithProfiles,

    /* Slots */
    getSlotById:            getSlotById,
    getSlotsByTeacher:      getSlotsByTeacher,
    getSlotsByTeacherDate:  getSlotsByTeacherDate,
    getSlotsByStudent:      getSlotsByStudent,
    getAllSlots:             getAllSlots,
    slotExists:             slotExists,
    createSlot:             createSlot,
    createSlotRange:        createSlotRange,
    updateSlot:             updateSlot,
    setSlotAvailability:    setSlotAvailability,
    bookSlot:               bookSlot,
    cancelSlotBooking:      cancelSlotBooking,
    deleteSlot:             deleteSlot,
    releaseSlot:            releaseSlot,
    confirmSlot:            confirmSlot,

    /* Recurring */
    getRecurringByTeacher:      getRecurringByTeacher,
    recurringExists:            recurringExists,
    createRecurring:            createRecurring,
    deleteRecurringByDayTime:   deleteRecurringByDayTime,
    materialiseWeek:            materialiseWeek,

    /* Selections */
    getSelectionsByStudent: getSelectionsByStudent,
    getSelectionsByTeacher: getSelectionsByTeacher,
    createSelection:        createSelection,
    deleteSelection:        deleteSelection,

    /* Stats */
    getAdminStats:          getAdminStats,
    getUserStats:           getUserStats,

    /* Time helpers */
    slotEndTime:            slotEndTime,
    slotTimesInRange:       slotTimesInRange,

    /* Wallet */
    getWallet:              getWallet,
    calcDepositInfo:        calcDepositInfo,
    deposit:                deposit,
    withdraw:               withdraw,
    getTransactions:        getTransactions,

    /* Escrow */
    getEscrow:                  getEscrow,
    getEscrowBySlot:            getEscrowBySlot,
    getEscrowsByStudent:        getEscrowsByStudent,
    getEscrowsByTeacher:        getEscrowsByTeacher,
    getAllEscrows:               getAllEscrows,
    createEscrow:               createEscrow,
    payDeposit:                 payDeposit,
    requestDepositRefund:       requestDepositRefund,
    confirmLesson:              confirmLesson,
    releaseDeposit:             releaseDeposit,
    forfeitDeposit:             forfeitDeposit,
    adminReleaseEscrow:         adminReleaseEscrow,
    updateNegotiatedAmount:     updateNegotiatedAmount
  };

}());
