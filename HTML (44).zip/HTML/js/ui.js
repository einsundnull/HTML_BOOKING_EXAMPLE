/**
 * ui.js — Shared UI Utilities
 * Toast, Modal, Icons — ohne const/let/arrow für maximale Kompatibilität.
 */

/* ── Toast ────────────────────────────────────────────── */
var Toast = (function() {
  var container = null;

  function getContainer() {
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    return container;
  }

  function show(message, type, duration) {
    type     = type     || 'success';
    duration = duration || 4000;

    var el = document.createElement('div');
    el.className = 'toast' + (type === 'error' ? ' toast-error' : type === 'info' ? ' toast-info' : '');

    var iconColor = type === 'success' ? '#4d7aa0' : '#e74c3c';
    var iconPath  = type === 'success'
      ? '<circle cx="8" cy="8" r="7" stroke="' + iconColor + '" stroke-width="1.5"/><path d="M5 8l2 2 4-4" stroke="' + iconColor + '" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
      : '<circle cx="8" cy="8" r="7" stroke="' + iconColor + '" stroke-width="1.5"/><path d="M8 5v3M8 11v.5" stroke="' + iconColor + '" stroke-width="1.5" stroke-linecap="round"/>';

    el.innerHTML = '<svg class="toast-icon" width="16" height="16" viewBox="0 0 16 16" fill="none">' + iconPath + '</svg>'
      + '<div><span>' + message + '</span></div>';

    getContainer().appendChild(el);
    setTimeout(function() {
      el.classList.add('toast-exit');
      el.addEventListener('animationend', function() { el.remove(); });
    }, duration);
  }

  return {
    success: function(msg) { show(msg, 'success'); },
    error:   function(msg) { show(msg, 'error'); },
    info:    function(msg) { show(msg, 'info'); }
  };
})();

/* ── Modal ────────────────────────────────────────────── */
var Modal = {
  show: function(opts) {
    var title      = opts.title      || '';
    var bodyHTML   = opts.bodyHTML   || '';
    var footerHTML = opts.footerHTML || '';

    var overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML =
      '<div class="modal" role="dialog" aria-modal="true">'
        + '<div class="modal-header">'
          + '<span class="modal-title">' + title + '</span>'
          + '<button class="modal-close" aria-label="Close">'
            + '<svg width="16" height="16" viewBox="0 0 16 16" fill="none">'
            + '<path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>'
            + '</svg>'
          + '</button>'
        + '</div>'
        + '<div class="modal-body">' + bodyHTML + '</div>'
        + (footerHTML ? '<div class="modal-footer">' + footerHTML + '</div>' : '')
      + '</div>';

    document.body.appendChild(overlay);

    function esc(e) {
      if (e.key === 'Escape') close();
    }
    function close() {
      overlay.remove();
      document.removeEventListener('keydown', esc);
    }

    overlay.querySelector('.modal-close').addEventListener('click', close);
    overlay.addEventListener('click', function(e) { if (e.target === overlay) close(); });
    document.addEventListener('keydown', esc);

    return { overlay: overlay, close: close };
  }
};

/* ── Icons ────────────────────────────────────────────── */
var Icons = {
  trash: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  plus:  '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>'
};


/* ── Shared Move Block Dialog ────────────────────────────
   opts = {
     block:        { dateStr, start, end, bookedSlots:[{slotId}], student:{uid,name} }
     teacherId:    string
     pendingMap:   object  (pendingBookings or pendingDayChanges)
     stuId:        string|null
     onConfirm:    function(pendingMap) — called after staging, before close
     onCalJump:    function(dateStr, result) — navigate to calendar
   }
──────────────────────────────────────────────────────── */
function openMoveBlockDialogShared(opts) {
  var block     = opts.block;
  var teacherId = opts.teacherId;
  var pending   = opts.pendingMap;
  var stuId     = opts.stuId;
  /* displayName override allows callers to pass a pre-resolved name (e.g. student showing teacher name) */
  var stuName = opts.displayName
    ? opts.displayName
    : ProfileStore.getDisplayName(block.student ? block.student.uid : (opts && opts.stuId ? opts.stuId : '?'));
  var slotCount = block.bookedSlots.length;

  /* Check if block is fully confirmed */
  var isFullyConfirmed = block.bookedSlots.every(function(s) {
    var orig = Store.Slots.all().filter(function(x) { return x.slotId === s.slotId; })[0];
    return orig && !!orig.confirmedAt;
  });

  /* ── Aktionsbereich oben: Bestätigen + Stornieren ── */
  var actionSectionHTML = '';
  if (!isFullyConfirmed) {
    actionSectionHTML =
      '<div class="move-dialog-actions">' +
        '<button class="btn btn-primary btn-sm" id="bk-block-confirm-btn">\u2713 Bestätigen</button>' +
        '<button class="btn btn-danger btn-sm" id="bk-block-cancel-btn">Stornieren</button>' +
      '</div>' +
      '<hr class="move-dialog-divider">';
  } else {
    actionSectionHTML =
      '<div class="move-dialog-actions">' +
        '<span class="badge badge-confirmed">\u2713 Bestätigt</span>' +
      '</div>' +
      '<hr class="move-dialog-divider">';
  }

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info"><strong>' + slotCount + ' Slot' + (slotCount !== 1 ? 's' : '') + '</strong>' +
        ' (' + block.start + ' \u2013 ' + block.end + ') \u2014 <strong>' + stuName + '</strong></p>' +

      actionSectionHTML +

      (isFullyConfirmed ? '' :
        '<div class="move-dialog-row">' +
          '<div class="move-dialog-col">' +
            '<label class="form-label">Datum</label>' +
            '<input type="date" id="move-date-input" class="form-select" value="' + block.dateStr + '" />' +
          '</div>' +
          '<div class="move-dialog-col">' +
            '<label class="form-label">Startzeit</label>' +
            '<select id="move-time-select" class="form-select"><option value="">Datum w\u00e4hlen</option></select>' +
          '</div>' +
        '</div>' +
        '<div id="move-check-result" class="move-check-result"></div>' +
        '<div class="move-dialog-btns">' +
          '<button class="btn btn-primary" id="move-check-btn">Verf\u00fcgbarkeit pr\u00fcfen</button>' +
          '<button class="btn btn-primary is-hidden" id="move-confirm-btn">Verschieben</button>' +
          '<button class="btn btn-ghost is-hidden" id="move-cal-btn">Im Kalender anzeigen</button>' +
        '</div>' +

        '<div class="recur-section">' +
          '<button class="btn btn-ghost recur-toggle-btn" id="recur-toggle">' +
            '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 8a6 6 0 0111.46-2.46M14 8a6 6 0 01-11.46 2.46" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M14 2v4h-4M2 14v-4h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            ' Regelm\u00e4\u00dfig buchen' +
          '</button>' +
          '<div id="recur-panel" class="recur-panel is-hidden">' +
            '<p class="recur-info">Gleicher Wochentag + gleiche Uhrzeit f\u00fcr die n\u00e4chsten Wochen wiederholen.</p>' +
            '<div class="move-dialog-row">' +
              '<div class="move-dialog-col">' +
                '<label class="form-label">Anzahl Wochen</label>' +
                '<input type="number" id="recur-weeks" class="form-select" min="1" max="52" value="4" />' +
              '</div>' +
            '</div>' +
            '<div id="recur-result" class="recur-result"></div>' +
            '<div class="move-dialog-btns">' +
              '<button class="btn btn-primary" id="recur-check-btn">Verf\u00fcgbarkeit pr\u00fcfen</button>' +
              '<button class="btn btn-primary is-hidden" id="recur-confirm-btn">Verf\u00fcgbare Tage buchen</button>' +
            '</div>' +
          '</div>' +
        '</div>'
      ) +

      '<div class="move-dialog-btns">' +
        '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '</div>' +
    '</div>';

  var result = Modal.show({ title: 'Block bearbeiten', bodyHTML: bodyHTML, footerHTML: '' });

  var cancelBtn = document.getElementById('modal-cancel');
  cancelBtn.addEventListener('click', result.close);

  /* ── Bestätigen ── */
  var confirmBlockBtn = document.getElementById('bk-block-confirm-btn');
  if (confirmBlockBtn) {
    confirmBlockBtn.addEventListener('click', function() {
      result.close();
      /* Warn-Dialog vor Bestätigung */
      var warnHTML =
        '<div class="move-dialog">' +
          '<p class="confirm-dialog-warning">\u26a0 <strong>Achtung:</strong> Diese Aktion kann nicht r\u00fckcg\u00e4ngig gemacht werden.</p>' +
          '<p class="move-dialog-info">Mit der Best\u00e4tigung der Stunde von <strong>' + stuName + '</strong> (' + block.start + ' \u2013 ' + block.end + '):</p>' +
          '<ul class="confirm-dialog-list">' +
            '<li>kann die Stunde <strong>nicht mehr verschoben</strong> werden</li>' +
            '<li>kann die Stunde <strong>nicht mehr storniert</strong> werden</li>' +
            '<li>wird die <strong>Zahlung f\u00fcr die Stunde freigegeben</strong></li>' +
          '</ul>' +
        '</div>';
      var warn = Modal.show({
        title: 'Stunde best\u00e4tigen',
        bodyHTML: warnHTML,
        footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt best\u00e4tigen</button>'
      });
      document.getElementById('modal-cancel').addEventListener('click', warn.close);
      document.getElementById('modal-confirm').addEventListener('click', function() {
        for (var ci = 0; ci < block.bookedSlots.length; ci++) {
          Store.Slots.confirm(block.bookedSlots[ci].slotId);
        }
        if (opts.onConfirmBlock) opts.onConfirmBlock();
        warn.close();
      });
    });
  }

  /* ── Stornieren ── */
  var cancelBlockBtn = document.getElementById('bk-block-cancel-btn');
  if (cancelBlockBtn) {
    cancelBlockBtn.addEventListener('click', function() {
      result.close();
      var warnResult = Modal.show({
        title: 'Buchung stornieren',
        bodyHTML: '<p>Buchung von <strong>' + stuName + '</strong> (' + block.start + ' \u2013 ' + block.end + ') wirklich stornieren?</p>',
        footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button><button class="btn btn-danger" id="modal-confirm">Stornieren</button>'
      });
      document.getElementById('modal-cancel').addEventListener('click', warnResult.close);
      document.getElementById('modal-confirm').addEventListener('click', function() {
        for (var ri = 0; ri < block.bookedSlots.length; ri++) {
          Store.Slots.cancelBooking(block.bookedSlots[ri].slotId);
        }
        if (opts.onCancelBlock) opts.onCancelBlock();
        warnResult.close();
      });
    });
  }

  if (isFullyConfirmed) return; /* Confirmed blocks: no move/recurring logic needed */

  var dateInput   = document.getElementById('move-date-input');
  var timeSelect  = document.getElementById('move-time-select');
  var checkResult = document.getElementById('move-check-result');
  var checkBtn    = document.getElementById('move-check-btn');
  var confirmBtn  = document.getElementById('move-confirm-btn');
  var calBtn      = document.getElementById('move-cal-btn');

  function resetCheck() {
    checkResult.textContent = '';
    checkResult.className = 'move-check-result';
    confirmBtn.classList.add('is-hidden');
    checkBtn.classList.remove('is-hidden');
    var hasInputs = dateInput.value && timeSelect.value;
    calBtn.classList.toggle('is-hidden', !hasInputs);
  }

  function isFreeSlot(s) {
    if (s.status === 'available' || s.status === 'recurring') return true;
    if (pending[s.slotId] && pending[s.slotId].action === 'cancel') return true;
    return false;
  }

  function rebuildTimes() {
    timeSelect.innerHTML = '';
    var dateStr = dateInput.value;
    if (!dateStr) { calBtn.classList.add('is-hidden'); return; }
    var allDay = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var free = allDay.filter(isFreeSlot);
    if (!free.length) {
      var o = document.createElement('option');
      o.value = ''; o.textContent = 'Keine freien Slots';
      timeSelect.appendChild(o);
      return;
    }
    for (var i = 0; i < free.length; i++) {
      var o = document.createElement('option');
      o.value = free[i].slotId;
      o.textContent = free[i].time + ' – ' + Store.slotEndTime(free[i].time);
      timeSelect.appendChild(o);
    }
    resetCheck();
  }

  rebuildTimes();
  dateInput.addEventListener('change', function() { rebuildTimes(); resetCheck(); });
  timeSelect.addEventListener('change', function() {
    resetCheck();
    var hasInputs = dateInput.value && timeSelect.value;
    calBtn.classList.toggle('is-hidden', !hasInputs);
  });

  checkBtn.addEventListener('click', function() {
    var startSlotId = timeSelect.value;
    if (!startSlotId) {
      checkResult.textContent = 'Bitte Datum und Startzeit wählen.';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var dateStr = dateInput.value;
    var allDay  = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var startIdx = -1;
    for (var i = 0; i < allDay.length; i++) {
      if (allDay[i].slotId === startSlotId) { startIdx = i; break; }
    }
    if (startIdx === -1 || startIdx + slotCount > allDay.length) {
      checkResult.textContent = 'Nicht genug Slots ab dieser Zeit (' + slotCount + ' benötigt).';
      checkResult.className = 'move-check-result move-check-fail';
      return;
    }
    var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
    var blocked = [];
    for (var j = 0; j < targetSlots.length; j++) {
      if (!isFreeSlot(targetSlots[j])) blocked.push(targetSlots[j].time);
    }
    if (blocked.length) {
      checkResult.textContent = 'Nicht alle Slots frei. Belegt: ' + blocked.join(', ') + '.';
      checkResult.className = 'move-check-result move-check-fail';
      confirmBtn.classList.add('is-hidden');
      checkBtn.classList.remove('is-hidden');
    } else {
      checkResult.textContent = '\u2713 Alle ' + slotCount + ' Slots frei \u2014 Verschiebung möglich.';
      checkResult.className = 'move-check-result move-check-ok';
      confirmBtn.classList.remove('is-hidden');
      calBtn.classList.remove('is-hidden');
      checkBtn.classList.add('is-hidden');
    }
  });

  confirmBtn.addEventListener('click', function() {
    var startSlotId = timeSelect.value;
    if (!startSlotId) return;
    var dateStr = dateInput.value;
    var allDay  = Store.Slots.byTeacherDate(teacherId, dateStr)
      .sort(function(a, b) { return a.time.localeCompare(b.time); });
    var startIdx = -1;
    for (var i = 0; i < allDay.length; i++) {
      if (allDay[i].slotId === startSlotId) { startIdx = i; break; }
    }
    if (startIdx === -1) return;
    var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
    for (var k = 0; k < block.bookedSlots.length; k++) {
      var orig = Store.Slots.all().filter(function(x) { return x.slotId === block.bookedSlots[k].slotId; })[0];
      if (orig) pending[orig.slotId] = { action: 'cancel', originalSlot: orig, newStudentId: null };
    }
    for (var m = 0; m < targetSlots.length; m++) {
      var tgt = Store.Slots.all().filter(function(x) { return x.slotId === targetSlots[m].slotId; })[0];
      if (tgt) pending[tgt.slotId] = { action: 'book', originalSlot: tgt, newStudentId: stuId, extraStudents: [] };
    }
    opts.onConfirm(pending);
    result.close();
    Toast.info('Block-Verschiebung vorgemerkt \u2014 Dr\u00fcck Save zum Best\u00e4tigen.');
  });

  calBtn.addEventListener('click', function() {
    opts.onCalJump(dateInput.value, result);
  });

  cancelBtn.addEventListener('click', result.close);

  /* ── Recurring booking logic ──────────────────────────── */
  var recurToggle  = document.getElementById('recur-toggle');
  var recurPanel   = document.getElementById('recur-panel');
  var recurWeeks   = document.getElementById('recur-weeks');
  var recurResult  = document.getElementById('recur-result');
  var recurCheckBtn   = document.getElementById('recur-check-btn');
  var recurConfirmBtn = document.getElementById('recur-confirm-btn');
  var recurData = null; // stores the check results

  recurToggle.addEventListener('click', function() {
    var isOpen = !recurPanel.classList.contains('is-hidden');
    recurPanel.classList.toggle('is-hidden', isOpen);
    recurToggle.classList.toggle('active', !isOpen);
  });

  function fmtDateLocal(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var dd = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + dd;
  }

  function getWeekDates(dateObj) {
    var d = new Date(dateObj);
    var dow = d.getDay(); // 0=Sun
    var monday = new Date(d);
    monday.setDate(d.getDate() - ((dow + 6) % 7)); // back to Monday
    var dates = [];
    for (var i = 0; i < 7; i++) {
      var day = new Date(monday);
      day.setDate(monday.getDate() + i);
      dates.push(day);
    }
    return dates; // [Mon, Tue, Wed, Thu, Fri, Sat, Sun]
  }

  function formatWeekday(dateObj) {
    return dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric' });
  }

  recurCheckBtn.addEventListener('click', function() {
    var weeks = parseInt(recurWeeks.value, 10);
    if (!weeks || weeks < 1) {
      recurResult.innerHTML = '<p class="move-check-fail">Bitte Anzahl Wochen angeben.</p>';
      return;
    }

    // Source: current block date + time range
    var sourceDate = new Date(block.dateStr + 'T00:00:00');
    var startTime  = block.start;

    recurData = [];
    recurResult.innerHTML = '';

    for (var w = 1; w <= weeks; w++) {
      var targetDate = new Date(sourceDate);
      targetDate.setDate(sourceDate.getDate() + (w * 7));
      var targetDateStr = fmtDateLocal(targetDate);

      // Materialise recurring slots for that week
      var weekDates = getWeekDates(targetDate);
      Store.Recurring.materialiseWeek(teacherId, weekDates);

      // Check slot availability
      var allDay = Store.Slots.byTeacherDate(teacherId, targetDateStr)
        .sort(function(a, b) { return a.time.localeCompare(b.time); });

      // Find consecutive free slots starting at startTime
      var startIdx = -1;
      for (var i = 0; i < allDay.length; i++) {
        if (allDay[i].time === startTime) { startIdx = i; break; }
      }

      var entry = { date: targetDate, dateStr: targetDateStr, week: w, available: false, reason: '', slots: [] };

      if (startIdx === -1) {
        entry.reason = 'Keine Slots an diesem Tag';
      } else if (startIdx + slotCount > allDay.length) {
        entry.reason = 'Nicht genug Slots (' + slotCount + ' benötigt)';
      } else {
        var targetSlots = allDay.slice(startIdx, startIdx + slotCount);
        var blocked = [];
        for (var j = 0; j < targetSlots.length; j++) {
          var ts = targetSlots[j];
          if (!isFreeSlot(ts)) {
            var reason = ts.status === 'timeout' ? 'Timeout'
              : (ts.status === 'booked' ? 'Gebucht (' + (ts.studentId || '?') + ')' : ts.status);
            blocked.push(ts.time + ' \u2013 ' + reason);
          }
        }
        if (blocked.length) {
          entry.reason = blocked.join(', ');
        } else {
          entry.available = true;
          entry.slots = targetSlots;
        }
      }
      recurData.push(entry);
    }

    // Render results
    var availCount = recurData.filter(function(e) { return e.available; }).length;
    var html = '<div class="recur-summary">' + availCount + ' von ' + weeks + ' Wochen verfügbar</div>';
    html += '<div class="recur-list">';
    for (var r = 0; r < recurData.length; r++) {
      var e = recurData[r];
      var icon = e.available ? '\u2713' : '\u2717';
      var cls  = e.available ? 'recur-row-ok' : 'recur-row-fail';
      html += '<div class="recur-row ' + cls + '">'
        + '<span class="recur-row-icon">' + icon + '</span>'
        + '<span class="recur-row-date">Woche ' + e.week + ': ' + formatWeekday(e.date) + '</span>'
        + (e.reason ? '<span class="recur-row-reason">' + e.reason + '</span>' : '')
        + '</div>';
    }
    html += '</div>';
    recurResult.innerHTML = html;

    if (availCount > 0) {
      recurConfirmBtn.classList.remove('is-hidden');
      recurConfirmBtn.textContent = availCount + ' verfügbare Tage buchen';
      recurCheckBtn.classList.add('is-hidden');
    } else {
      recurConfirmBtn.classList.add('is-hidden');
      recurCheckBtn.classList.remove('is-hidden');
    }
  });

  recurConfirmBtn.addEventListener('click', function() {
    if (!recurData) return;
    var booked = 0;
    for (var r = 0; r < recurData.length; r++) {
      var e = recurData[r];
      if (!e.available || !e.slots.length) continue;
      for (var s = 0; s < e.slots.length; s++) {
        var tgt = Store.Slots.all().filter(function(x) { return x.slotId === e.slots[s].slotId; })[0];
        if (tgt) {
          pending[tgt.slotId] = { action: 'book', originalSlot: tgt, newStudentId: stuId, extraStudents: [] };
        }
      }
      booked++;
    }
    opts.onConfirm(pending);
    result.close();
    Toast.info(booked + ' Wochen vorgemerkt \u2014 Dr\u00fcck Save zum Best\u00e4tigen.');
  });
}

window.openMoveBlockDialogShared = openMoveBlockDialogShared;

window.Toast = Toast;
window.Modal = Modal;
window.Icons = Icons;

/* ═══════════════════════════════════════════════════════════════
   SHARED UTILITIES — used by both teacher.js and student.js
   Exported as window globals so both can access
═══════════════════════════════════════════════════════════════ */

function fmtDate(date) {
  var y = date.getFullYear();
  var m = String(date.getMonth() + 1).padStart(2, '0');
  var d = String(date.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + d;
}
window.fmtDate = fmtDate;

/* ── Shared filter helpers — eine Logik für alle drei Tabs ── */
function _applyTimeFilter(slots, timeFilter, today) {
  if (timeFilter === 'past')     return slots.filter(function(s) { return s.date <  today; });
  if (timeFilter === 'upcoming') return slots.filter(function(s) { return s.date >= today; });
  return slots;
}
window._applyTimeFilter = _applyTimeFilter;

/* Apply optional date range filter after time filter */
function _applyDateRangeFilter(slots) {
  var from = bookingsFilter.dateFrom;
  var to   = bookingsFilter.dateTo;
  if (!from && !to) return slots;
  return slots.filter(function(s) {
    if (from && s.date < from) return false;
    if (to   && s.date > to)   return false;
    return true;
  });
}
window._applyDateRangeFilter = _applyDateRangeFilter;

function getStickyOffset() {
  var navbar = document.querySelector('.navbar');
  var dayNav = document.getElementById('day-nav-bar');
  var offset = 0;
  if (navbar) offset += navbar.offsetHeight;
  if (dayNav && dayNav.classList.contains('is-sticky')) offset += dayNav.offsetHeight;
  return offset + 8;
}
window.getStickyOffset = getStickyOffset;

function getCurrentSectionIndex(targets) {
  var offset = getStickyOffset();
  var scrollY = window.scrollY + offset + 10;
  var best = 0;
  for (var i = 0; i < targets.length; i++) {
    var top = targets[i].getBoundingClientRect().top + window.scrollY;
    if (top <= scrollY) best = i;
  }
  return best;
}
window.getCurrentSectionIndex = getCurrentSectionIndex;

/* ── Shared sort + date-range row ─────────────────────────
   Renders: [↑↓ Sort]  [Von ____ Bis ____]  [✕ Reset]
   onRerender: function to call after any change            */
function _buildSortDateRangeRow(onRerender) {
  var row = document.createElement('div');
  row.className = 'bookings-sort-date-row';

  /* Sort button */
  var sortBtn = document.createElement('button');
  sortBtn.className = 'btn btn-secondary btn-sm sort-btn-shared';
  sortBtn.setAttribute('aria-label', allBookingsSortAsc ? 'Älteste zuerst' : 'Neueste zuerst');
  sortBtn.innerHTML =
    '<span class="sort-icon-asc"' + (allBookingsSortAsc ? '' : ' style="display:none"') + '>' +
      '<svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M7 2v10M3 8l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '</span>' +
    '<span class="sort-icon-desc"' + (!allBookingsSortAsc ? '' : ' style="display:none"') + '>' +
      '<svg width="13" height="13" viewBox="0 0 14 14" fill="none" aria-hidden="true"><path d="M7 12V2M3 6l4-4 4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
    '</span>';
  sortBtn.addEventListener('click', function() {
    allBookingsSortAsc = !allBookingsSortAsc;
    onRerender();
  });
  row.appendChild(sortBtn);

  /* Date-range: Von */
  var fromLbl = document.createElement('label');
  fromLbl.className = 'date-range-label';
  fromLbl.textContent = 'Von';
  var fromInput = document.createElement('input');
  fromInput.type = 'date';
  fromInput.className = 'date-range-input';
  fromInput.value = bookingsFilter.dateFrom;
  fromInput.addEventListener('change', function() {
    _setFilter('dateFrom', fromInput.value);
    onRerender();
  });

  /* Date-range: Bis */
  var toLbl = document.createElement('label');
  toLbl.className = 'date-range-label';
  toLbl.textContent = 'Bis';
  var toInput = document.createElement('input');
  toInput.type = 'date';
  toInput.className = 'date-range-input';
  toInput.value = bookingsFilter.dateTo;
  toInput.addEventListener('change', function() {
    _setFilter('dateTo', toInput.value);
    onRerender();
  });

  /* Reset button — only visible when a date is set */
  var resetBtn = document.createElement('button');
  resetBtn.className = 'btn btn-ghost btn-sm date-range-reset' + (bookingsFilter.dateFrom || bookingsFilter.dateTo ? '' : ' is-hidden');
  resetBtn.textContent = '✕';
  resetBtn.setAttribute('aria-label', 'Datumsfilter zurücksetzen');
  resetBtn.addEventListener('click', function() {
    _setFilter('dateFrom', '');
    _setFilter('dateTo', '');
    onRerender();
  });

  row.appendChild(fromLbl);
  row.appendChild(fromInput);
  row.appendChild(toLbl);
  row.appendChild(toInput);
  row.appendChild(resetBtn);
  return row;
}
window._buildSortDateRangeRow = _buildSortDateRangeRow;

/* navDay / navMonth — shared core, render callback injected by caller */
function _navDayShared(delta, renderFn) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setDate(d.getDate() + delta);
  selectedDate = d;
  if (d.getFullYear() !== viewYear || d.getMonth() !== viewMonth) {
    viewYear  = d.getFullYear();
    viewMonth = d.getMonth();
  }
  updateDayNavBar();
  renderCalendar();
  renderFn();
}
window._navDayShared = _navDayShared;

function _navMonthShared(delta, renderFn) {
  if (!selectedDate) return;
  var d = new Date(selectedDate);
  d.setMonth(d.getMonth() + delta);
  selectedDate = d;
  viewYear  = d.getFullYear();
  viewMonth = d.getMonth();
  updateDayNavBar();
  renderCalendar();
  renderFn();
}
window._navMonthShared = _navMonthShared;

/* checkDayNavSticky — shared, containerId injected per-file */
function checkDayNavStickyShared(containerId) {
  var bar      = document.getElementById('day-nav-bar');
  var sentinel = document.getElementById('day-nav-sentinel');
  if (!bar || !sentinel || !bar.classList.contains('is-visible')) return;
  var navbarH = 52;
  var rect = sentinel.getBoundingClientRect();
  var shouldBeSticky = rect.top < navbarH;
  if (shouldBeSticky === window._dayNavStickyActive) return;
  window._dayNavStickyActive = shouldBeSticky;
  bar.classList.toggle('is-sticky', shouldBeSticky);
  if (shouldBeSticky) {
    var parent = document.getElementById(containerId);
    if (parent) {
      var pr = parent.getBoundingClientRect();
      bar.style.left  = pr.left + 'px';
      bar.style.width = pr.width + 'px';
      bar.style.right = 'auto';
    }
    sentinel.style.height = bar.offsetHeight + 'px';
  } else {
    bar.style.left  = '';
    bar.style.width = '';
    bar.style.right = '';
    sentinel.style.height = '0';
  }
}
window.checkDayNavStickyShared = checkDayNavStickyShared;

/* updateDayNavBar — identical in both files */
function updateDayNavBar() {
  var bar   = document.getElementById('day-nav-bar');
  var label = document.getElementById('day-nav-label');
  if (!bar || !label) return;
  if (!selectedDate) {
    bar.classList.remove('is-visible');
    bar.classList.remove('is-sticky');
    window._dayNavStickyActive = false;
    return;
  }
  bar.classList.add('is-visible');
  label.textContent = selectedDate.toLocaleDateString('de-DE', {
    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
  });
}
window.updateDayNavBar = updateDayNavBar;

/* _setFilter — shared by teacher.js and student.js */
function _setFilter(key, val) { bookingsFilter[key] = val; }
window._setFilter = _setFilter;

/* jumpSection — shared, calls local getSectionJumpTargets via window */
function jumpSection(delta) {
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var next    = idx + delta;
  if (next < 0 || next >= targets.length) return;
  var target  = targets[next];
  var offset  = getStickyOffset();
  var top     = target.getBoundingClientRect().top + window.scrollY - offset;
  window.scrollTo({ top: top, behavior: 'smooth' });
  setTimeout(updateJumpBtns, 400);
}
window.jumpSection = jumpSection;

/* updateJumpBtns — shared core, visibilityExtra passed by each file's local wrapper */
function _updateJumpBtnsShared(visibilityExtra) {
  var jumper  = document.getElementById('section-jumper');
  var targets = getSectionJumpTargets();
  var idx     = getCurrentSectionIndex(targets);
  var upBtn   = document.getElementById('jump-up');
  var downBtn = document.getElementById('jump-down');
  if (!upBtn || !downBtn || !jumper) return;
  var navbarH = (document.querySelector('.navbar') || {}).offsetHeight || 0;
  var isVisible = window.scrollY > navbarH || visibilityExtra;
  jumper.classList.toggle('is-visible', isVisible);
  upBtn.classList.toggle('is-dimmed', idx <= 0);
  downBtn.classList.toggle('is-dimmed', idx >= targets.length - 1);
}
window._updateJumpBtnsShared = _updateJumpBtnsShared;

/* prevMonth/nextMonth shared cores */
function _prevMonthShared(extraRenderFn) {
  viewMonth--;
  if (viewMonth < 0) { viewMonth = 11; viewYear--; }
  renderCalendar();
  if (extraRenderFn) extraRenderFn();
}
function _nextMonthShared(extraRenderFn) {
  viewMonth++;
  if (viewMonth > 11) { viewMonth = 0; viewYear++; }
  renderCalendar();
  if (extraRenderFn) extraRenderFn();
}
window._prevMonthShared = _prevMonthShared;
window._nextMonthShared = _nextMonthShared;
