/**
 * student.js — Student View
 *
 * Booking via week grid (same layout as teacher).
 * Cell states (student perspective):
 *   gc-available  — green,  clickable → book instantly
 *   gc-mine       — navy,   clickable → cancel
 *   gc-empty      — grey,   not clickable
 */

var currentUser     = null;
var activeView      = 'catalog';
var activeTeacherId = null;

var sgridWeekStart  = null;

var viewYear        = 0;
var viewMonth       = 0;
var selectedDate    = null;

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START  = '06:00';
var GRID_END    = '22:00';

/* Stored document-level listeners — ermöglicht sauberes removeEventListener */
var _closeTeacherPickerDropdown = null;
var _closeMbTeacherDropdown     = null;
var _pickerMonthBtnsInit        = false;

/* My Bookings — uses shared bookingsFilter + allBookingsSortAsc from teacher.js-compatible globals */
/* bookingsFilter and allBookingsSortAsc are defined here so student.js works standalone */
var bookingsFilter = {
  student:   'all',
  time:      'upcoming',
  confirmed: 'all',
  dateFrom:  '',
  dateTo:    ''
};
var allBookingsSortAsc = true;

/* ── Pending move system (mirrors teacher pendingBookings) ── */
var pendingDayChanges = {};
var expandedStudentBlocks = {};  /* blockKey → true, persists open state across re-renders */

function updateDaySaveBtn() {
  var group = document.getElementById('day-save-group');
  if (!group) return;
  var count = Object.keys(pendingDayChanges).length;
  group.classList.toggle('is-visible', count > 0);
  var badge = group.querySelector('.save-badge');
  if (badge) badge.textContent = count;
}

function commitDayChanges() {
  var ids = Object.keys(pendingDayChanges);
  var saved = {};
  for (var i = 0; i < ids.length; i++) {
    var p = pendingDayChanges[ids[i]];
    saved[ids[i]] = p;
    if (p.action === 'book') {
      AppService.bookSlot(ids[i], p.newStudentId || currentUser.uid, function(e){if(e)Toast.error(e.message||e);});
    } else {
      AppService.cancelSlotBooking(ids[i], function(e){if(e)Toast.error(e.message||e);});
    }
  }
  /* Email notifications — mirrors teacher saveBookingChanges */
  var emailIds = Object.keys(saved);
  for (var ei = 0; ei < emailIds.length; ei++) {
    var ep  = saved[emailIds[ei]];
    var es  = ep.originalSlot;
    if (!es) continue;
    var teacher = AppService.getUserSync(es.teacherId);
    if (!teacher) continue;
    var dateObj   = new Date(es.date + 'T00:00:00');
    var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    var endTime   = AppService.slotEndTime(es.time);
    if (ep.action === 'book') {
      EmailService.onBookingCreated(teacher.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(teacher.uid),
        studentName: ProfileStore.getDisplayName(currentUser.uid)
      });
    } else {
      EmailService.onBookingCancelled(teacher.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(teacher.uid),
        studentName: ProfileStore.getDisplayName(currentUser.uid)
      });
    }
  }
  pendingDayChanges = {};
  updateDaySaveBtn();
  renderStats();
  _updateMyBookingsBadges();
  renderMyBookingsList();
  renderCalendar();
  renderDaySlots();
  Toast.success('Gespeichert.');
}

function discardDayChanges() {
  pendingDayChanges = {};
  updateDaySaveBtn();
  renderMyBookingsList();
  renderDaySlots();
  Toast.info('Änderungen verworfen.');
}



/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('student');
  if (!currentUser) return;
  Navbar.init('catalog');

  document.getElementById('nav-catalog').addEventListener('click', function() { switchView('catalog'); });
  document.getElementById('nav-calendar').addEventListener('click', function() { switchView('calendar'); });
  document.getElementById('nav-my-bookings').addEventListener('click', function() { switchView('my-bookings'); });
  document.getElementById('nav-wallet').addEventListener('click', function() { switchView('wallet'); });
  document.getElementById('sgrid-close-btn').addEventListener('click', closeStudentGrid);
  document.getElementById('sgrid-prev-week').addEventListener('click', sgridPrevWeek);
  document.getElementById('sgrid-next-week').addEventListener('click', sgridNextWeek);

  /* Day-nav-bar buttons — same as teacher.js */
  document.getElementById('day-nav-prev').addEventListener('click', function() { navDay(-1); });
  document.getElementById('day-nav-next').addEventListener('click', function() { navDay(1); });
  document.getElementById('day-nav-prev-month').addEventListener('click', function() { navMonth(-1); });
  document.getElementById('day-nav-next-month').addEventListener('click', function() { navMonth(1); });

  var now   = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();

  renderStats();
  switchView('catalog');
});

/* ── View switcher ──────────────────────────────────────── */
function switchView(view) {
  activeView = view;
  document.getElementById('nav-catalog').classList.toggle('active', view === 'catalog');
  document.getElementById('nav-calendar').classList.toggle('active', view === 'calendar');
  document.getElementById('nav-my-bookings').classList.toggle('active', view === 'my-bookings');
  document.getElementById('nav-wallet').classList.toggle('active', view === 'wallet');
  document.getElementById('view-catalog').classList.toggle('view-hidden', view !== 'catalog');
  document.getElementById('view-calendar').classList.toggle('view-hidden', view !== 'calendar');
  document.getElementById('view-my-bookings').classList.toggle('view-hidden', view !== 'my-bookings');
  document.getElementById('view-wallet').classList.toggle('view-hidden', view !== 'wallet');
  if (view === 'catalog')     renderCatalog();
  if (view === 'calendar')    { renderTeacherPicker(); setTimeout(updateJumpBtns, 100); }
  if (view === 'my-bookings') { renderMyBookings(); setTimeout(updateJumpBtns, 200); }
  if (view === 'wallet' && typeof WalletPanel !== 'undefined') {
    WalletPanel.mount('student-wallet-panel', currentUser.uid);
  }
}

/* ── Stats ──────────────────────────────────────────────── */
function renderStats() {
  var selections = AppService.getSelectionsByStudentSync(currentUser.uid);
  var bookings   = AppService.getSlotsByStudentSync(currentUser.uid).filter(function(s) { return s.status === 'booked'; });
  document.getElementById('stat-teachers').textContent = selections.length;
  document.getElementById('stat-bookings').textContent = bookings.length;
}

/* ══════════════════════════════════════════════════════════
   CATALOG
══════════════════════════════════════════════════════════ */
function renderCatalog() {
  var allTeachers  = AppService.getUsersByRoleSync('teacher');
  var mySelections = AppService.getSelectionsByStudentSync(currentUser.uid).map(function(s) { return s.teacherId; });
  var container    = document.getElementById('catalog-grid');
  container.innerHTML = '';

  if (!allTeachers.length) {
    var empty = document.createElement('div');
    empty.className = 'catalog-empty text-muted';
    empty.textContent = 'No teachers available yet.';
    container.appendChild(empty);
    return;
  }

  for (var i = 0; i < allTeachers.length; i++) {
    container.appendChild(buildTeacherCard(allTeachers[i], mySelections));
  }
}

function buildTeacherCard(teacher, mySelections) {
  var isSelected = mySelections.indexOf(teacher.uid) !== -1;
  var availCount = AppService.getSlotsByTeacherSync(teacher.uid).filter(function(s) { return s.status === 'available'; }).length;

  var card = document.createElement('div');
  card.className = 'card teacher-card' + (isSelected ? ' teacher-card-selected' : '');

  var top = document.createElement('div');
  top.className = 'teacher-card-top';

  var nameWrap = document.createElement('div');
  var name = document.createElement('div');
  name.className = 'teacher-card-name';
  name.textContent = ProfileStore.getDisplayName(teacher.uid);
  var uid = document.createElement('code');
  uid.className = 'uid-badge';
  uid.textContent = teacher.uid;
  nameWrap.appendChild(name);
  nameWrap.appendChild(uid);
  top.appendChild(nameWrap);

  if (isSelected) {
    var badge = document.createElement('span');
    badge.className = 'teacher-selected-badge';
    badge.textContent = 'Selected';
    top.appendChild(badge);
  }

  var avail = document.createElement('div');
  avail.className = 'teacher-card-avail text-muted';
  avail.textContent = availCount + ' available slot' + (availCount !== 1 ? 's' : '');

  var actions = document.createElement('div');
  actions.className = 'teacher-card-actions';

  if (isSelected) {
    var viewBtn = document.createElement('button');
    viewBtn.className = 'btn btn-secondary btn-sm';
    viewBtn.textContent = 'Book lessons';
    (function(tid) { viewBtn.addEventListener('click', function() { openTeacherGrid(tid); }); })(teacher.uid);

    var removeBtn = document.createElement('button');
    removeBtn.className = 'btn btn-ghost btn-sm';
    removeBtn.textContent = 'Remove';
    (function(tid) { removeBtn.addEventListener('click', function() { deselectTeacher(tid); }); })(teacher.uid);

    actions.appendChild(viewBtn);
    actions.appendChild(removeBtn);
  } else {
    var selectBtn = document.createElement('button');
    selectBtn.className = 'btn btn-primary btn-sm';
    selectBtn.textContent = 'Select';
    (function(tid) { selectBtn.addEventListener('click', function() { selectTeacher(tid); }); })(teacher.uid);
    actions.appendChild(selectBtn);
  }

  card.appendChild(top);
  card.appendChild(avail);
  card.appendChild(actions);
  return card;
}

function selectTeacher(teacherId) {
  AppService.createSelection(currentUser.uid, teacherId, function(e){if(e)Toast.error(e.message||e);});
  Toast.success(ProfileStore.getDisplayName(teacherId) + ' added to your teachers.');
  renderStats();
  renderCatalog();
}

function deselectTeacher(teacherId) {
  AppService.deleteSelection(currentUser.uid, teacherId, function(e){if(e)Toast.error(e.message||e);});
  Toast.success(ProfileStore.getDisplayName(teacherId) + ' removed.');
  renderStats();
  renderCatalog();
}

function openTeacherGrid(teacherId) {
  activeTeacherId = teacherId;
  /* Pre-select today so day panel loads immediately on calendar open */
  var now = new Date();
  now.setHours(0, 0, 0, 0);
  selectedDate = now;
  switchView('calendar');
}

/* ══════════════════════════════════════════════════════════
   TEACHER PICKER (calendar view top)
══════════════════════════════════════════════════════════ */
function renderTeacherPicker() {
  var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(s) { return AppService.getUserSync(s.teacherId); })
    .filter(function(t) { return t !== null; });

  var calSection = document.getElementById('cal-section');
  var list    = document.getElementById('teacher-picker-list');
  var label   = document.getElementById('teacher-picker-label');
  var trigger = document.getElementById('teacher-picker-trigger');
  var weekBtn = document.getElementById('teacher-picker-week-btn');

  if (!myTeachers.length) {
    if (list)    list.innerHTML = '';
    if (label)   label.textContent = 'Kein Lehrer ausgewählt';
    if (weekBtn) weekBtn.disabled = true;
    calSection.classList.add('view-hidden');
    return;
  }

  if (!activeTeacherId) activeTeacherId = myTeachers[0].uid;

  /* ── Build options list ── */
  var options = [];
  for (var i = 0; i < myTeachers.length; i++) {
    options.push({ value: myTeachers[i].uid, text: ProfileStore.getDisplayName(myTeachers[i].uid) });
  }

  function setTeacher(val) {
    activeTeacherId = val;
    var selected = null;
    for (var j = 0; j < options.length; j++) {
      if (options[j].value === val) { selected = options[j]; break; }
    }
    label.textContent = selected ? selected.text : options[0].text;
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var k = 0; k < items.length; k++) {
      var isActive = items[k].getAttribute('data-value') === val;
      items[k].classList.toggle('is-active', isActive);
      items[k].setAttribute('aria-selected', isActive ? 'true' : 'false');
    }
    closeDropdown();
    renderCalendar();
    renderDaySlots();
  }

  function openDropdown() {
    list.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    trigger.classList.add('is-open');
  }

  function closeDropdown() {
    list.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.classList.remove('is-open');
  }

  /* ── Rebuild list items ── */
  list.innerHTML = '';
  for (var m = 0; m < options.length; m++) {
    (function(opt) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (opt.value === activeTeacherId ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', opt.value);
      li.setAttribute('aria-selected', opt.value === activeTeacherId ? 'true' : 'false');
      li.textContent = opt.text;
      li.addEventListener('click', function() { setTeacher(opt.value); });
      list.appendChild(li);
    })(options[m]);
  }

  /* ── Sync label to current selection ── */
  var curOpt = null;
  for (var n = 0; n < options.length; n++) {
    if (options[n].value === activeTeacherId) { curOpt = options[n]; break; }
  }
  label.textContent = curOpt ? curOpt.text : options[0].text;

  /* ── Toggle open/close — onclick überschreibt statt zu stapeln ── */
  trigger.onclick = function(e) {
    e.stopPropagation();
    if (list.classList.contains('is-open')) { closeDropdown(); } else { openDropdown(); }
  };

  /* ── Close on outside click — alten Listener zuerst entfernen ── */
  if (_closeTeacherPickerDropdown) {
    document.removeEventListener('click', _closeTeacherPickerDropdown);
  }
  _closeTeacherPickerDropdown = function() { closeDropdown(); };
  document.addEventListener('click', _closeTeacherPickerDropdown);

  /* ── Wochenansicht-Button — onclick überschreibt ── */
  weekBtn.disabled = false;
  weekBtn.onclick  = openStudentGrid;

  /* ── Prev/Next-Monat — einmalig binden ── */
  if (!_pickerMonthBtnsInit) {
    _pickerMonthBtnsInit = true;
    document.getElementById('prev-btn').addEventListener('click', prevMonth);
    document.getElementById('next-btn').addEventListener('click', nextMonth);
  }

  /* Pre-select today if no date selected yet */
  if (!selectedDate) {
    var now = new Date();
    now.setHours(0, 0, 0, 0);
    selectedDate = now;
  }

  calSection.classList.remove('view-hidden');
  renderCalendar();
  renderDaySlots();
}

/* Materialise recurring slots for all weeks visible in the current month view.
   Mirrors teacher's materialiseVisibleMonth — uses activeTeacherId instead of currentUser.uid */
function materialiseVisibleMonth(year, month) {
  if (!activeTeacherId) return;
  var first    = new Date(year, month, 1);
  var startDow = first.getDay(); startDow = (startDow === 0) ? 6 : startDow - 1;
  var gridStart = new Date(year, month, 1 - startDow);
  var seen = {};
  for (var d = 0; d < 42; d++) {
    var day = new Date(gridStart);
    day.setDate(gridStart.getDate() + d);
    var dow = day.getDay(); dow = (dow === 0) ? 6 : dow - 1;
    var mon = new Date(day); mon.setDate(day.getDate() - dow);
    var monKey = mon.getFullYear() + '-' + mon.getMonth() + '-' + mon.getDate();
    if (seen[monKey]) continue;
    seen[monKey] = true;
    var weekDates = [];
    for (var w = 0; w < 7; w++) {
      var wd = new Date(mon); wd.setDate(mon.getDate() + w);
      weekDates.push(wd);
    }
    AppService.materialiseWeek(activeTeacherId, weekDates, function(e) {
      if (e) Toast.error(e.message || e);
    });
  }
}

/* ══════════════════════════════════════════════════════════
   STUDENT WEEK GRID OVERLAY
══════════════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════════════
   MONTH CALENDAR
══════════════════════════════════════════════════════════ */
function renderCalendar() {
  var calSection = document.getElementById('cal-section');
  if (!calSection) return;

  /* Materialise recurring slots for all visible weeks — same as teacher */
  materialiseVisibleMonth(viewYear, viewMonth);

  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;
  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  /* Normalize TODAY to midnight for correct past/today comparison */
  var todayMidnight = new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate());

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow     = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeDayCell(prevDays - i, true));
  }
  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isPast  = date < todayMidnight;
      var isToday = date.getTime() === todayMidnight.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots   = activeTeacherId ? AppService.getSlotsByTeacherDateSync(activeTeacherId, dateStr) : [];
      var hasAvail  = !isPast && slots.some(function(s) { return s.status === 'available' || s.status === 'recurring'; });
      var hasMyBook = slots.some(function(s) { return s.status === 'booked' && s.studentId === currentUser.uid; });

      var cell = makeDayCell(day, false, isToday, isSel, hasAvail, hasMyBook);
      if (!isPast) {
        cell.setAttribute('tabindex', '0');
        cell.addEventListener('click', function() { selectedDate = date; renderCalendar(); renderDaySlots(); });
        cell.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') { selectedDate = date; renderCalendar(); renderDaySlots(); } });
      }
      grid.appendChild(cell);
    })(d);
  }
  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeDayCell(t, true));
  }
}

function makeDayCell(num, otherMonth, isToday, isSelected, hasAvail, hasMyBook) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth) el.classList.add('other-month');
  if (isToday)    el.classList.add('today');
  if (isSelected) el.classList.add('selected');
  if (hasAvail)   el.classList.add('has-avail');
  if (hasMyBook)  el.classList.add('has-mybook');
  el.textContent = num;
  return el;
}

/* ══════════════════════════════════════════════════════════
   DAY SLOT LIST
══════════════════════════════════════════════════════════ */
function renderDaySlots() {
  updateDayNavBar();
  var container = document.getElementById('day-slots');
  if (!container) return;
  container.innerHTML = '';

  if (!selectedDate || !activeTeacherId) return;

  /* Materialise recurring for selected week — mirrors teacher's renderDayPanel */
  var selMonday = new Date(selectedDate);
  var selDow = selMonday.getDay(); selDow = (selDow === 0) ? 6 : selDow - 1;
  selMonday.setDate(selMonday.getDate() - selDow);
  var selWeekDates = [];
  for (var wi = 0; wi < 7; wi++) {
    var wd = new Date(selMonday); wd.setDate(selMonday.getDate() + wi);
    selWeekDates.push(wd);
  }
  AppService.materialiseWeek(activeTeacherId, selWeekDates, function(e) {
    if (e) Toast.error(e.message || e);
  });

  var dateStr = fmtDate(selectedDate);
  var today   = fmtDate(new Date());
  var isPast  = dateStr < today;

  /* ── Same pipeline as renderMyBookingsList but scoped to one day + one teacher ── */

  /* 1. Booked slots for this student on this day — with pending map applied */
  var storeBooked = AppService.getSlotsByTeacherDateSync(activeTeacherId, dateStr)
    .filter(function(s) { return s.status === 'booked' && s.studentId === currentUser.uid; })
    .map(function(s) {
      var p = pendingDayChanges[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  /* 2. Pending-book slots not yet in Store */
  var pendingBookSlots = Object.keys(pendingDayChanges)
    .filter(function(id) {
      var p = pendingDayChanges[id];
      return p.action === 'book' &&
        p.originalSlot.date === dateStr &&
        p.originalSlot.teacherId === activeTeacherId &&
        !storeBooked.some(function(s) { return s.slotId === id; });
    })
    .map(function(id) {
      var orig = pendingDayChanges[id].originalSlot;
      var s = {}; for (var k in orig) s[k] = orig[k];
      s.status    = 'booked';
      s.studentId = currentUser.uid;
      s._pending  = 'book';
      return s;
    });

  var allBooked = storeBooked.concat(pendingBookSlots);

  /* 3. Merge into blocks — same function as My Bookings */
  var blocks = _mergeStudentBookingBlocks(dateStr, allBooked, today);

  /* 4. Free slots on this day (available, not booked by anyone else) */
  var freeSlots = AppService.getSlotsByTeacherDateSync(activeTeacherId, dateStr)
    .filter(function(s) { return s.status === 'available' && !s.studentId; });

  if (!blocks.length && !freeSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted day-slots-empty';
    empty.textContent = 'Keine Slots an diesem Tag.';
    container.appendChild(empty);
    return;
  }

  /* 5. Render free slots as "+ Add" rows (ungrouped, same as _populateStudentBlockDetail) */
  if (freeSlots.length && !isPast) {
    for (var fi = 0; fi < freeSlots.length; fi++) {
      var fs = freeSlots[fi];
      /* Skip if this slot is pending-book (will appear in a block) */
      if (pendingDayChanges[fs.slotId] && pendingDayChanges[fs.slotId].action === 'book') continue;

      var fRow = document.createElement('div');
      fRow.className = 'all-booking-slot-row all-booking-slot-available';

      var fTime = document.createElement('span');
      fTime.className = 'all-booking-slot-time';
      fTime.textContent = fs.time + ' – ' + AppService.slotEndTime(fs.time);

      var fStatus = document.createElement('span');
      fStatus.className = 'all-booking-slot-status';
      fStatus.textContent = 'Frei';

      var fBtns = document.createElement('div');
      fBtns.className = 'all-booking-slot-btns';

      var addBtn = document.createElement('button');
      addBtn.className = 'btn btn-primary btn-sm';
      addBtn.textContent = '+ Add';
      (function(s) {
        addBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingDayChanges[s.slotId] && pendingDayChanges[s.slotId].action === 'book') {
            delete pendingDayChanges[s.slotId];
          } else {
            pendingDayChanges[s.slotId] = { action: 'book', originalSlot: s, newStudentId: currentUser.uid };
          }
          updateDaySaveBtn();
          renderDaySlots();
          _updateMyBookingsBadges();
          renderMyBookingsList();
        });
      })(fs);
      fBtns.appendChild(addBtn);

      fRow.appendChild(fTime);
      fRow.appendChild(fStatus);
      fRow.appendChild(fBtns);
      container.appendChild(fRow);
    }
  }

  /* 6. Render booked blocks — same renderer as My Bookings */
  for (var bi = 0; bi < blocks.length; bi++) {
    container.appendChild(_buildStudentBookingBlock(blocks[bi], isPast));
  }
}


var _closeSgridTeacherDropdown = null;

function openStudentGrid() {
  if (!activeTeacherId) return;

  /* Start on current week (Monday) */
  if (!sgridWeekStart) {
    var monday = new Date(TODAY);
    var dow = monday.getDay();
    dow = (dow === 0) ? 6 : dow - 1;
    monday.setDate(monday.getDate() - dow);
    sgridWeekStart = monday;
  }

  _buildSgridTeacherDropdown();

  document.getElementById('student-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  _sgridMaterialiseAndRender();
}

function _buildSgridTeacherDropdown() {
  var list    = document.getElementById('sgrid-teacher-list');
  var label   = document.getElementById('sgrid-teacher-name');
  var trigger = document.getElementById('sgrid-teacher-trigger');
  if (!list || !label || !trigger) return;

  var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(sel) { return AppService.getUserSync(sel.teacherId); })
    .filter(Boolean);

  if (!myTeachers.length) {
    label.textContent = 'Kein Lehrer';
    return;
  }

  /* Ensure activeTeacherId is valid */
  if (!activeTeacherId || !myTeachers.some(function(t) { return t.uid === activeTeacherId; })) {
    activeTeacherId = myTeachers[0].uid;
  }

  function sgridSetTeacher(uid) {
    activeTeacherId = uid;
    label.textContent = ProfileStore.getDisplayName(uid);
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var k = 0; k < items.length; k++) {
      var active = items[k].getAttribute('data-value') === uid;
      items[k].classList.toggle('is-active', active);
      items[k].setAttribute('aria-selected', active ? 'true' : 'false');
    }
    list.classList.remove('is-open');
    trigger.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    renderStudentGrid();
  }

  /* Rebuild list */
  list.innerHTML = '';
  for (var i = 0; i < myTeachers.length; i++) {
    (function(teacher) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (teacher.uid === activeTeacherId ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', teacher.uid);
      li.setAttribute('aria-selected', teacher.uid === activeTeacherId ? 'true' : 'false');
      li.textContent = ProfileStore.getDisplayName(teacher.uid);
      li.addEventListener('click', function(e) {
        e.stopPropagation();
        sgridSetTeacher(teacher.uid);
      });
      list.appendChild(li);
    })(myTeachers[i]);
  }

  label.textContent = ProfileStore.getDisplayName(activeTeacherId);

  trigger.onclick = function(e) {
    e.stopPropagation();
    var isOpen = list.classList.contains('is-open');
    list.classList.toggle('is-open', !isOpen);
    trigger.classList.toggle('is-open', !isOpen);
    trigger.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
  };

  document.removeEventListener('click', _closeSgridTeacherDropdown);
  _closeSgridTeacherDropdown = function() {
    list.classList.remove('is-open');
    trigger.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
  };
  document.addEventListener('click', _closeSgridTeacherDropdown);
}

function closeStudentGrid() {
  document.getElementById('student-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  renderStats();
}

function sgridPrevWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() - 7);
  _sgridMaterialiseAndRender();
}

function sgridNextWeek() {
  sgridWeekStart.setDate(sgridWeekStart.getDate() + 7);
  _sgridMaterialiseAndRender();
}

/* Materialise ALL selected teachers for current week, then render */
function _sgridMaterialiseAndRender() {
  var weekDates  = getSgridWeekDates();
  var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(sel) { return AppService.getUserSync(sel.teacherId); })
    .filter(Boolean);

  var total   = myTeachers.length;
  var done    = 0;
  if (!total) { renderStudentGrid(); return; }

  myTeachers.forEach(function(t) {
    AppService.materialiseWeek(t.uid, weekDates, function(e) {
      if (e) Toast.error(e.message || e);
      done++;
      if (done === total) renderStudentGrid();
    });
  });
}

/* ── Week grid render ───────────────────────────────────── */
function renderStudentGrid() {
  var weekDates = getSgridWeekDates();
  var times     = AppService.slotTimesInRange(GRID_START, GRID_END);

  document.getElementById('sgrid-week-label').textContent = sgridWeekRangeLabel(weekDates);

  // Pre-build slot lookup for ALL selected teachers: "tid|date|time" → slot
  var myTeacherIds = AppService.getSelectionsByStudentSync(currentUser.uid)
    .map(function(sel) { return sel.teacherId; });
  var allSlots = AppService.getAllSlotsSync();
  var slotMap  = {};
  for (var si = 0; si < allSlots.length; si++) {
    var s = allSlots[si];
    if (myTeacherIds.indexOf(s.teacherId) !== -1) {
      slotMap[s.teacherId + '|' + s.date + '|' + s.time] = s;
    }
  }

  var container = document.getElementById('sgrid-content');
  container.innerHTML = '';

  var table = document.createElement('table');
  table.className = 'slot-grid-table';

  // ── thead ──
  var thead = document.createElement('thead');
  var hrow  = document.createElement('tr');
  var thTime = document.createElement('th');
  thTime.className = 'grid-th-time';
  thTime.textContent = 'Time';
  hrow.appendChild(thTime);

  for (var d = 0; d < weekDates.length; d++) {
    var wd      = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var th = document.createElement('th');
    th.className = 'grid-th-day';
    if (isToday) th.classList.add('grid-th-today');
    var nameSpan = document.createElement('span');
    nameSpan.className = 'grid-day-name';
    nameSpan.textContent = DAY_NAMES[d];
    var numSpan = document.createElement('span');
    numSpan.className = 'grid-day-num';
    if (isToday) numSpan.classList.add('grid-day-today');
    numSpan.textContent = wd.getDate();
    th.appendChild(nameSpan);
    th.appendChild(numSpan);
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // ── tbody ──
  var tbody = document.createElement('tbody');

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    var tr   = document.createElement('tr');
    var tdTime = document.createElement('td');
    tdTime.className = 'grid-td-time';
    tdTime.textContent = time;
    tr.appendChild(tdTime);

    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var isPastDay   = cellDate < TODAY;

      // Active teacher slot
      var slot         = slotMap[activeTeacherId + '|' + cellDateStr + '|' + time] || null;
      var pendingEntry = slot ? pendingDayChanges[slot.slotId] : null;

      // Check if another selected teacher has this student booked here
      var otherSlot = null;
      for (var ti = 0; ti < myTeacherIds.length; ti++) {
        if (myTeacherIds[ti] === activeTeacherId) continue;
        var os = slotMap[myTeacherIds[ti] + '|' + cellDateStr + '|' + time];
        if (os && os.status === 'booked' && os.studentId === currentUser.uid) {
          otherSlot = os;
          break;
        }
      }

      var cellClass;
      var isClickable = false;

      if (isPastDay) {
        cellClass = otherSlot ? 'gc-other' : 'gc-empty';
      } else if (!slot || slot.status === 'disabled' || slot.status === 'timeout') {
        if (pendingEntry && pendingEntry.action === 'book') {
          cellClass   = 'gc-available gc-pending';
          isClickable = true;
        } else {
          cellClass = otherSlot ? 'gc-other' : 'gc-empty';
        }
      } else if (slot.status === 'available' || slot.status === 'recurring') {
        if (pendingEntry && pendingEntry.action === 'book') {
          cellClass = 'gc-mine gc-pending';
        } else {
          cellClass = otherSlot ? 'gc-other' : 'gc-available';
        }
        isClickable = !otherSlot;
      } else if (slot.status === 'booked' && slot.studentId === currentUser.uid) {
        cellClass   = (pendingEntry && pendingEntry.action === 'cancel') ? 'gc-available gc-pending' : 'gc-mine';
        isClickable = true;
      } else {
        cellClass = otherSlot ? 'gc-other' : 'gc-empty';
      }

      var td   = document.createElement('td');
      td.className = 'grid-td-cell';
      var cell = document.createElement('div');
      cell.className      = 'grid-cell ' + cellClass;
      cell.dataset.date   = cellDateStr;
      cell.dataset.time   = time;
      cell.dataset.slotid = slot ? slot.slotId : '';

      if (isClickable) cell.addEventListener('click', onStudentCellClick);

      td.appendChild(cell);
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  container.appendChild(table);
}

function onStudentCellClick(e) {
  var cell   = e.currentTarget;
  var date   = cell.dataset.date;
  var time   = cell.dataset.time;
  var slotId = cell.dataset.slotid;
  var isMine = cell.classList.contains('gc-mine');

  /* Get the real slot */
  var slot = slotId
    ? AppService.getAllSlotsSync().filter(function(x) { return x.slotId === slotId; })[0]
    : AppService.slotExistsSync(activeTeacherId, date, time);

  if (!slot) return;

  var pendingEntry = pendingDayChanges[slot.slotId];
  var teacherName  = ProfileStore.getDisplayName(activeTeacherId);
  var endTime      = AppService.slotEndTime(time);

  if (isMine || (pendingEntry && pendingEntry.action === 'cancel')) {

    /* Staged book — clicking again just undoes it, no dialog needed */
    if (pendingEntry && pendingEntry.action === 'book') {
      delete pendingDayChanges[slot.slotId];
      updateDaySaveBtn();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderStudentGrid();
      return;
    }

    /* Booked (or staged cancel) — show popover with info + Stornieren/Undo */
    if (slot.confirmedAt && !pendingEntry) {
      Toast.error('Best\u00E4tigte Buchungen k\u00F6nnen nicht storniert werden.');
      return;
    }
    var isStaged = !!(pendingEntry && pendingEntry.action === 'cancel');
    var result = Modal.show({
      title: isStaged ? 'Stornierung vorgemerkt' : 'Buchung',
      bodyHTML:
        '<div class="move-dialog">' +
          '<p class="move-dialog-info"><strong>' + teacherName + '</strong></p>' +
          '<p>' + time + ' \u2013 ' + endTime + ' &nbsp;&bull;&nbsp; ' + date + '</p>' +
          (isStaged ? '<p class="confirm-dialog-warning" style="margin-top:8px">\u26a0 Stornierung vorgemerkt \u2014 noch nicht gespeichert.</p>' : '') +
        '</div>',
      footerHTML:
        '<button class="btn btn-ghost" id="modal-cancel">Schlie\u00dfen</button>' +
        (slot.confirmedAt
          ? ''
          : '<button class="btn ' + (isStaged ? 'btn-ghost' : 'btn-danger') + '" id="modal-action">' +
            (isStaged ? 'Undo' : 'Stornieren') + '</button>')
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    var actionBtn = document.getElementById('modal-action');
    if (actionBtn) {
      actionBtn.addEventListener('click', function() {
        if (isStaged) {
          /* Undo staged cancel */
          delete pendingDayChanges[slot.slotId];
        } else {
          /* Stage cancel */
          pendingDayChanges[slot.slotId] = { action: 'cancel', originalSlot: slot, newStudentId: null };
        }
        updateDaySaveBtn();
        _updateMyBookingsBadges();
        renderMyBookingsList();
        renderStudentGrid();
        result.close();
      });
    }

  } else if (slot.status === 'available' || slot.status === 'recurring') {
    /* Free slot — undo or show confirm dialog */
    if (pendingEntry && pendingEntry.action === 'book') {
      /* Undo staged book */
      delete pendingDayChanges[slot.slotId];
      updateDaySaveBtn();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderStudentGrid();
    } else {
      /* Confirm dialog before staging */
      var bookResult = Modal.show({
        title: 'Slot buchen?',
        bodyHTML:
          '<div class="move-dialog">' +
            '<p class="move-dialog-info"><strong>' + teacherName + '</strong></p>' +
            '<p>' + time + ' \u2013 ' + endTime + ' &nbsp;&bull;&nbsp; ' + date + '</p>' +
          '</div>',
        footerHTML:
          '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
          '<button class="btn btn-primary" id="modal-action">Buchen</button>'
      });
      document.getElementById('modal-cancel').addEventListener('click', bookResult.close);
      document.getElementById('modal-action').addEventListener('click', function() {
        pendingDayChanges[slot.slotId] = { action: 'book', originalSlot: slot, newStudentId: currentUser.uid };
        updateDaySaveBtn();
        _updateMyBookingsBadges();
        renderMyBookingsList();
        renderStudentGrid();
        bookResult.close();
      });
    }
  }
}

/* ── Helpers ────────────────────────────────────────────── */
function getSgridWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(sgridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function sgridWeekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

/* ════════════════════════════════════════════════════════
   DAY NAV BAR — ported from teacher.js, renderDayPanel → renderDaySlots
═══════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════
   MY BOOKINGS
══════════════════════════════════════════════════════════ */
function renderMyBookings() {
  /* ── Teacher dropdown — mirrors teacher's student dropdown in All Bookings ── */
  var mbTeacherList    = document.getElementById('mb-teacher-list');
  var mbTeacherLabel   = document.getElementById('mb-teacher-label');
  var mbTeacherTrigger = document.getElementById('mb-teacher-trigger');

  if (mbTeacherList && mbTeacherLabel && mbTeacherTrigger) {
    var myTeachers = AppService.getSelectionsByStudentSync(currentUser.uid)
      .map(function(s) { return AppService.getUserSync(s.teacherId); })
      .filter(Boolean);

    var mbOptions = [{ value: 'all', text: 'Alle Lehrer' }];
    for (var ti = 0; ti < myTeachers.length; ti++) {
      mbOptions.push({ value: myTeachers[ti].uid, text: ProfileStore.getDisplayName(myTeachers[ti].uid) });
    }

    function mbSetTeacher(val) {
      _setFilter('student', val);
      var sel = mbOptions.filter(function(o) { return o.value === val; })[0] || mbOptions[0];
      mbTeacherLabel.textContent = sel.text;
      var items = mbTeacherList.querySelectorAll('.custom-dropdown-item');
      for (var k = 0; k < items.length; k++) {
        items[k].classList.toggle('is-active', items[k].getAttribute('data-value') === val);
      }
      mbTeacherList.classList.remove('is-open');
      mbTeacherTrigger.classList.remove('is-open');
      mbTeacherTrigger.setAttribute('aria-expanded', 'false');
      _updateMyBookingsBadges();
      renderMyBookingsList();
    }

    mbTeacherList.innerHTML = '';
    for (var oi = 0; oi < mbOptions.length; oi++) {
      (function(opt) {
        var li = document.createElement('li');
        li.className = 'custom-dropdown-item' + (opt.value === bookingsFilter.student ? ' is-active' : '');
        li.setAttribute('role', 'option');
        li.setAttribute('data-value', opt.value);
        li.setAttribute('aria-selected', opt.value === bookingsFilter.student ? 'true' : 'false');
        li.textContent = opt.text;
        li.addEventListener('click', function(e) { e.stopPropagation(); mbSetTeacher(opt.value); });
        mbTeacherList.appendChild(li);
      })(mbOptions[oi]);
    }

    var curOpt = mbOptions.filter(function(o) { return o.value === bookingsFilter.student; })[0] || mbOptions[0];
    mbTeacherLabel.textContent = curOpt.text;

    mbTeacherTrigger.onclick = function(e) {
      e.stopPropagation();
      var isOpen = mbTeacherList.classList.contains('is-open');
      mbTeacherList.classList.toggle('is-open', !isOpen);
      mbTeacherTrigger.classList.toggle('is-open', !isOpen);
      mbTeacherTrigger.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
    };
    document.removeEventListener('click', _closeMbTeacherDropdown);
    _closeMbTeacherDropdown = function() {
      mbTeacherList.classList.remove('is-open');
      mbTeacherTrigger.classList.remove('is-open');
      mbTeacherTrigger.setAttribute('aria-expanded', 'false');
    };
    document.addEventListener('click', _closeMbTeacherDropdown);
  }

  /* ── Sort + Date-Range row — shared with teacher ── */
  var sortDateContainer = document.getElementById('mb-sort-date-row');
  if (sortDateContainer) {
    sortDateContainer.innerHTML = '';
    sortDateContainer.appendChild(_buildSortDateRangeRow(function() {
      renderMyBookingsList();
    }));
  }

  /* ── Zeitfilter-Buttons ── */
  var timeBtns = document.querySelectorAll('.mb-time-btn');
  for (var t = 0; t < timeBtns.length; t++) {
    timeBtns[t].classList.toggle('active', timeBtns[t].id === 'mb-filter-' + bookingsFilter.time);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('time', btn.id.replace('mb-filter-', ''));
        allBookingsSortAsc = (bookingsFilter.time !== 'past');
        for (var j = 0; j < timeBtns.length; j++) timeBtns[j].classList.remove('active');
        btn.classList.add('active');
        renderMyBookingsList();
      };
    })(timeBtns[t]);
  }

  /* ── Statusfilter-Buttons ── */
  var confirmBtns = document.querySelectorAll('.mb-confirm-btn');
  for (var ci = 0; ci < confirmBtns.length; ci++) {
    confirmBtns[ci].classList.toggle('active', confirmBtns[ci].dataset.confirm === bookingsFilter.confirmed);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('confirmed', btn.dataset.confirm);
        for (var cj = 0; cj < confirmBtns.length; cj++) confirmBtns[cj].classList.remove('active');
        btn.classList.add('active');
        renderMyBookingsList();
      };
    })(confirmBtns[ci]);
  }

  _updateMyBookingsBadges();
  renderMyBookingsList();
}

function _updateMyBookingsBadges() {
  var today  = fmtDate(new Date());
  var slots  = AppService.getSlotsByStudentSync(currentUser.uid).filter(function(s) { return s.status === 'booked'; });
  /* Teacher filter — mirrors teacher's student filter in All Bookings */
  if (bookingsFilter.student !== 'all') {
    slots = slots.filter(function(s) { return s.teacherId === bookingsFilter.student; });
  }
  slots = slots.filter(function(s) {
    if (bookingsFilter.time === 'past')     return s.date < today;
    if (bookingsFilter.time === 'upcoming') return s.date >= today;
    return true;
  });
  slots = _applyDateRangeFilter(slots);
  var counts = _calcStudentBlockCounts(slots, today);
  function _setBadge(id, count) {
    var el = document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    el.classList.remove('is-hidden');
  }
  _setBadge('mb-all-count-badge',       counts.all);
  _setBadge('mb-unconfirmed-count-badge', counts.unconfirmed);
  _setBadge('mb-confirmed-count-badge',   counts.confirmed);

  /* Time-tab counts — commented out, badges hidden in HTML
  var allTeacherSlots = AppService.getSlotsByStudentSync(currentUser.uid).filter(function(s) { return s.status === 'booked'; });
  if (bookingsFilter.student !== 'all') {
    allTeacherSlots = allTeacherSlots.filter(function(s) { return s.teacherId === bookingsFilter.student; });
  }
  allTeacherSlots = _applyDateRangeFilter(allTeacherSlots);
  var timeCounts = {
    past:     _calcStudentBlockCounts(_applyTimeFilter(allTeacherSlots, 'past',     today), today).all,
    upcoming: _calcStudentBlockCounts(_applyTimeFilter(allTeacherSlots, 'upcoming', today), today).all,
    all:      _calcStudentBlockCounts(allTeacherSlots, today).all
  };
  _setBadge('mb-time-past-count',     timeCounts.past);
  _setBadge('mb-time-upcoming-count', timeCounts.upcoming);
  _setBadge('mb-time-all-count',      timeCounts.all);
  */
}

function _calcStudentBlockCounts(slots, today) {
  /* Group slots by date first */
  var byDate = {};
  for (var i = 0; i < slots.length; i++) {
    var d = slots[i].date;
    if (!byDate[d]) byDate[d] = [];
    byDate[d].push(slots[i]);
  }

  /* Merge ALL slots per date first, then filter blocks by confirm state.
     This mirrors teacher's _calcBlockCounts — confirm filter applied AFTER merge
     so a mixed block (1 confirmed + 1 unconfirmed) counts correctly in both filters. */
  function countBlocks(blockFilterFn) {
    var total = 0;
    var dates = Object.keys(byDate);
    for (var di = 0; di < dates.length; di++) {
      var blocks = _mergeStudentBookingBlocks(dates[di], byDate[dates[di]], today);
      total += blocks.filter(blockFilterFn).length;
    }
    return total;
  }

  return {
    all:         countBlocks(function()  { return true; }),
    unconfirmed: countBlocks(function(b) { return !b.isFullyConfirmed; }),
    confirmed:   countBlocks(function(b) { return !!b.isFullyConfirmed; })
  };
}

function renderMyBookingsList() {
  var container = document.getElementById('my-bookings-list');
  if (!container) return;
  container.innerHTML = '';

  var today = fmtDate(new Date());

  /* Mirror teacher renderAllBookingsList:
     - Keep status=booked slots from Store
     - Map pending-cancel to _pending='cancel' WITHOUT changing status (so they stay visible)
     - Add pending-book slots that aren't yet in Store */
  var storeBooked = AppService.getSlotsByStudentSync(currentUser.uid)
    .filter(function(s) { return s.status === 'booked'; })
    .map(function(s) {
      var p = pendingDayChanges[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  /* Also include pending-book slots not yet in Store */
  var pendingBookSlots = Object.keys(pendingDayChanges)
    .filter(function(id) {
      var p = pendingDayChanges[id];
      return p.action === 'book' &&
        !storeBooked.some(function(s) { return s.slotId === id; });
    })
    .map(function(id) {
      var s = {}; for (var k in pendingDayChanges[id].originalSlot) s[k] = pendingDayChanges[id].originalSlot[k];
      s.status    = 'booked';
      s.studentId = currentUser.uid;
      s._pending  = 'book';
      return s;
    });

  var slots = storeBooked.concat(pendingBookSlots);

  /* Teacher filter */
  if (bookingsFilter.student !== 'all') {
    slots = slots.filter(function(s) { return s.teacherId === bookingsFilter.student; });
  }

  if (bookingsFilter.time === 'past')     slots = slots.filter(function(s) { return s.date < today; });
  else if (bookingsFilter.time === 'upcoming') slots = slots.filter(function(s) { return s.date >= today; });
  slots = _applyDateRangeFilter(slots);

  if (bookingsFilter.confirmed === 'confirmed')   slots = slots.filter(function(s) { return !!s.confirmedAt; });
  else if (bookingsFilter.confirmed === 'unconfirmed') slots = slots.filter(function(s) { return !s.confirmedAt; });

  var emptyReasons = {
    past:     'Keine vergangenen Buchungen.',
    upcoming: 'Keine kommenden Buchungen.',
    all:      'Keine Buchungen gefunden.'
  };

  if (!slots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = emptyReasons[bookingsFilter.time] || 'Keine Buchungen gefunden.';
    container.appendChild(empty);
    return;
  }

  slots.sort(function(a, b) {
    return a.date.localeCompare(b.date) || a.time.localeCompare(b.time);
  });

  /* Gruppe nach Datum */
  var byDate    = {};
  var dateOrder = [];
  for (var i = 0; i < slots.length; i++) {
    var s = slots[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  if (!allBookingsSortAsc) { dateOrder.reverse(); }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr   = dateOrder[d];
    var dateSlots = byDate[dateStr];
    var isPast    = dateStr < today;

    /* ── Datum-Headline (wie Teacher) ── */
    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider' + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    container.appendChild(divider);

    /* ── Blöcke: konsekutive Slots desselben Lehrers zusammenfassen ── */
    var blocks = _mergeStudentBookingBlocks(dateStr, dateSlots, today);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(_buildStudentBookingBlock(blocks[b], isPast));
    }
  }
}

/* Fasst aufeinanderfolgende Slots desselben Lehrers zu einem Block zusammen */
function _mergeStudentBookingBlocks(dateStr, slots, today) {
  var blocks = [];

  /* Sort by teacherId first, then time — same logic as teacher's mergeAllBookingBlocks */
  var sorted = slots.slice().sort(function(a, b) {
    return (a.teacherId || '').localeCompare(b.teacherId || '') || a.time.localeCompare(b.time);
  });

  var i = 0;
  while (i < sorted.length) {
    var s   = sorted[i];
    var end = AppService.slotEndTime(s.time);
    var grp = [s];
    var j   = i + 1;

    /* Merge consecutive OR overlapping slots of same teacher — mirrors teacher logic */
    while (j < sorted.length) {
      var next = sorted[j];
      if (next.teacherId === s.teacherId && next.time <= end) {
        var nextEnd = AppService.slotEndTime(next.time);
        if (nextEnd > end) end = nextEnd;
        grp.push(next);
        j++;
      } else { break; }
    }

    var isFullyConfirmed = grp.every(function(x) { return !!x.confirmedAt; });
    var hasPending = grp.some(function(x) { return !!x._pending; });
    blocks.push({
      dateStr:          dateStr,
      today:            today,
      teacherId:        s.teacherId,
      start:            s.time,
      end:              end,
      bookedSlots:      grp,
      isFullyConfirmed: isFullyConfirmed,
      hasPending:       hasPending
    });
    i = j;
  }

  /* Re-sort blocks by start time */
  blocks.sort(function(a, b) { return a.start.localeCompare(b.start); });
  return blocks;
}

function _buildStudentBookingBlock(block, isPast) {
  var teacherName      = ProfileStore.getDisplayName(block.teacherId);
  var isFullyConfirmed = block.isFullyConfirmed;
  var hasPending       = !!block.hasPending;

  /* blockKey mirrors teacher's expandedAllBlocks key pattern */
  var blockKey = block.dateStr + '-' + block.start + '-' + block.teacherId;
  var isOpen   = !!expandedStudentBlocks[blockKey];

  var wrapper = document.createElement('div');
  wrapper.className = 'all-booking-block-wrapper';

  /* ── Header ── */
  var header = document.createElement('div');
  header.className = 'all-booking-block-header'
    + (isPast ? ' all-booking-block-past' : '')
    + (hasPending ? ' block-pending' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'all-booking-block-time';
  timeEl.textContent = block.start + ' – ' + block.end;

  var teacherEl = document.createElement('span');
  teacherEl.className = 'all-booking-block-student';
  teacherEl.textContent = teacherName;

  var chevron = document.createElement('span');
  chevron.className = 'all-booking-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  header.appendChild(timeEl);
  header.appendChild(teacherEl);

  if (isFullyConfirmed) {
    var confirmedBadge = document.createElement('span');
    confirmedBadge.className = 'badge badge-confirmed';
    confirmedBadge.textContent = '✓ Bestätigt';
    header.appendChild(confirmedBadge);
  } else if (!isPast) {
    /* Bestätigen-Button */
    var confirmBtn = document.createElement('button');
    confirmBtn.className = 'btn btn-ghost btn-sm all-booking-confirm-btn';
    confirmBtn.textContent = '✓ Bestätigen';
    (function(b) {
      confirmBtn.addEventListener('click', function(e) { e.stopPropagation(); _openStudentConfirmBlockDialog(b); });
    })(block);
    header.appendChild(confirmBtn);

    /* Edit-Button — reuses shared openMoveBlockDialogShared from ui.js */
    var editBtn = document.createElement('button');
    editBtn.className = 'btn btn-ghost btn-sm all-booking-move-all-btn';
    editBtn.setAttribute('aria-label', 'Block bearbeiten');
    editBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11.5 2.5a1.414 1.414 0 012 2L5 13H2v-3L11.5 2.5z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    (function(b) {
      editBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        _openStudentEditBlockDialog(b);
      });
    })(block);
    header.appendChild(editBtn);
  }

  header.appendChild(chevron);

  /* ── Detail-Panel — open state persisted via expandedStudentBlocks ── */
  var detail = document.createElement('div');
  detail.className = 'all-booking-block-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) _populateStudentBlockDetail(detail, block, isPast);

  function toggle() {
    if (expandedStudentBlocks[blockKey]) {
      delete expandedStudentBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedStudentBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      _populateStudentBlockDetail(detail, block, isPast);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
  });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

/* Populates block detail: booked slots + ALL available slots for that teacher/day
   Mirrors teacher's populateAllBookingDetail logic */
function _populateStudentBlockDetail(detail, block, isPast) {
  detail.innerHTML = '';

  var allDaySlots = AppService.getSlotsByTeacherDateSync(block.teacherId, block.dateStr);
  var today = fmtDate(new Date());

  /* Show: slots booked by this student OR available (not booked by anyone else) */
  var mySlotIds = {};
  for (var bi = 0; bi < block.bookedSlots.length; bi++) {
    mySlotIds[block.bookedSlots[bi].slotId] = true;
  }

  /* Deduplicate by slotId — same guard as teacher's populateAllBookingDetail */
  var seenIds = {};
  var display = allDaySlots
    .filter(function(s) {
      if (seenIds[s.slotId]) return false;
      /* Free slots only shown when block is NOT fully confirmed */
      var include = mySlotIds[s.slotId] || (!block.isFullyConfirmed && s.status === 'available' && !s.studentId);
      if (include) seenIds[s.slotId] = true;
      return include;
    })
    .map(function(s) {
      return { type: mySlotIds[s.slotId] ? 'booked' : 'free', slot: s };
    });

  for (var ri = 0; ri < display.length; ri++) {
    var item      = display[ri];
    var slot      = item.slot;
    var isConfirmed = !!slot.confirmedAt;
    var isSlotPast  = slot.date < today;

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row';

    var slotTime = document.createElement('span');
    slotTime.className = 'all-booking-slot-time';
    slotTime.textContent = slot.time + ' – ' + AppService.slotEndTime(slot.time);

    var slotStatus = document.createElement('span');
    slotStatus.className = 'all-booking-slot-status';

    var btnGroup = document.createElement('div');
    btnGroup.className = 'all-booking-slot-btns';

    var pendSlot = pendingDayChanges[slot.slotId];
    var isPendingBook   = !!(pendSlot && pendSlot.action === 'book');
    var isPendingCancel = !!(pendSlot && pendSlot.action === 'cancel');
    if (isPendingBook || isPendingCancel) row.classList.add('slot-pending');

    if (item.type === 'free') {
      slotStatus.textContent = 'Frei';
      row.classList.add('all-booking-slot-available');
      if (!block.isFullyConfirmed && !isPast && !isSlotPast) {
        var addBtn = document.createElement('button');
        addBtn.className = isPendingBook ? 'btn btn-ghost btn-sm' : 'btn btn-primary btn-sm';
        addBtn.textContent = isPendingBook ? 'Undo' : '+ Add';
        (function(s) {
          addBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (pendingDayChanges[s.slotId] && pendingDayChanges[s.slotId].action === 'book') {
              delete pendingDayChanges[s.slotId];
            } else {
              pendingDayChanges[s.slotId] = { action: 'book', originalSlot: s, newStudentId: currentUser.uid };
            }
            updateDaySaveBtn();
            _updateMyBookingsBadges();
            renderMyBookingsList();
          });
        })(slot);
        btnGroup.appendChild(addBtn);
      }
    } else if (item.type === 'booked') {
      slotStatus.textContent = isPendingCancel ? 'Storniert' : 'Gebucht';
      if (isConfirmed) {
        var sBadge = document.createElement('span');
        sBadge.className = 'badge badge-confirmed';
        sBadge.textContent = '✓ Bestätigt';
        btnGroup.appendChild(sBadge);
      } else if (!isSlotPast) {
        var sConfirmBtn = document.createElement('button');
        sConfirmBtn.className = 'btn btn-ghost btn-sm';
        sConfirmBtn.textContent = '✓';
        sConfirmBtn.title = 'Bestätigen';
        (function(sid) {
          sConfirmBtn.addEventListener('click', function(e) { e.stopPropagation(); _openStudentConfirmDialog(sid); });
        })(slot.slotId);
        btnGroup.appendChild(sConfirmBtn);

        var sCancelBtn = document.createElement('button');
        sCancelBtn.className = isPendingCancel ? 'btn btn-ghost btn-sm' : 'btn btn-danger btn-sm';
        sCancelBtn.textContent = isPendingCancel ? 'Undo' : 'Cancel';
        (function(s) {
          sCancelBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (pendingDayChanges[s.slotId] && pendingDayChanges[s.slotId].action === 'cancel') {
              delete pendingDayChanges[s.slotId];
            } else {
              pendingDayChanges[s.slotId] = { action: 'cancel', originalSlot: s, newStudentId: null };
            }
            updateDaySaveBtn();
            _updateMyBookingsBadges();
            renderMyBookingsList();
          });
        })(slot);
        btnGroup.appendChild(sCancelBtn);
      }
    }

    row.appendChild(slotTime);
    row.appendChild(slotStatus);
    row.appendChild(btnGroup);
    detail.appendChild(row);
  }
}
function _openStudentConfirmBlockDialog(block) {
  var teacherName = ProfileStore.getDisplayName(block.teacherId);
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">⚠ <strong>Achtung:</strong> Diese Aktion kann nicht rückgängig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Bestätigung deiner Buchung bei <strong>' + teacherName + '</strong> (' + block.start + ' – ' + block.end + '):</p>' +
      '<ul class="confirm-dialog-list">' +
        '<li>kann die Buchung <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung für diese Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';
  var result = Modal.show({
    title: 'Buchung bestätigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
                '<button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      for (var ci = 0; ci < block.bookedSlots.length; ci++) {
        AppService.confirmSlot(block.bookedSlots[ci].slotId, function(e){if(e)Toast.error(e.message||e);});
      }
      Toast.success('Buchung bestätigt.');
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      result.close();
    } catch (e) {
      Toast.error('Fehler bei der Bestätigung: ' + e.message);
      result.close();
    }
  });
}

/* Student Edit Block Dialog — reuses openMoveBlockDialogShared from ui.js */
function _openStudentEditBlockDialog(block) {
  /* Use displayName override so teacher name shows correctly regardless of profile state */
  var teacherName = ProfileStore.getDisplayName(block.teacherId);

  /* Build block with student field for compatibility with openMoveBlockDialogShared */
  var studentBlock = {};
  for (var k in block) studentBlock[k] = block[k];
  studentBlock.student = { uid: currentUser.uid }; /* needed for slot lookup context */

  openMoveBlockDialogShared({
    block:        studentBlock,
    teacherId:    block.teacherId,
    pendingMap:   pendingDayChanges,  /* wire student pending system */
    stuId:        currentUser.uid,
    displayName:  teacherName,        /* override: show teacher name, not student name */
    onConfirmBlock: function() {
      pendingDayChanges = {};
      updateDaySaveBtn();
      _updateMyBookingsBadges();
      renderMyBookingsList();
    },
    onCancelBlock: function() {
      pendingDayChanges = {};
      updateDaySaveBtn();
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
    },
    onConfirm: function() {
      updateDaySaveBtn();
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      renderCalendar();
      renderDaySlots();
    },
    onCalJump: function(dateStr) {
      if (!dateStr) return;
      var d = new Date(dateStr + 'T00:00:00');
      d.setHours(0,0,0,0);
      selectedDate = d;
      viewYear  = d.getFullYear();
      viewMonth = d.getMonth();
      switchView('calendar');
    }
  });
}

/* Block-Level Stornierung (alle Slots des Blocks) */
function _openStudentConfirmDialog(slotId) {
  var slot = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === slotId; })[0];
  if (!slot) return;
  var teacherName = ProfileStore.getDisplayName(slot.teacherId);
  var endTime     = AppService.slotEndTime(slot.time);

  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">\u26a0 <strong>Achtung:</strong> Diese Aktion kann nicht r\u00FCckg\u00E4ngig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Best\u00E4tigung deiner Buchung bei <strong>' + teacherName + '</strong> (' + slot.time + ' \u2013 ' + endTime + '):</p>' +
      '<ul class="confirm-dialog-list">' +
        '<li>kann die Buchung <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung f\u00FCr diese Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';

  var result = Modal.show({
    title: 'Buchung best\u00E4tigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>'
             + '<button class="btn btn-primary" id="modal-confirm">Jetzt best\u00E4tigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      AppService.confirmSlot(slotId, function(e){if(e)Toast.error(e.message||e);});
      Toast.success('Buchung best\u00E4tigt.');
      renderStats();
      _updateMyBookingsBadges();
      renderMyBookingsList();
      result.close();
    } catch (e) {
      Toast.error('Fehler bei der Best\u00E4tigung: ' + e.message);
      result.close();
    }
  });
}

function getSectionJumpTargets() {
  if (activeView === 'my-bookings') {
    var dividers = document.querySelectorAll('#view-my-bookings .all-bookings-day-divider');
    var pageTop  = document.querySelector('.page-header') || document.getElementById('view-my-bookings');
    if (dividers.length) return [pageTop].concat(Array.prototype.slice.call(dividers)).filter(Boolean);
    return [pageTop].filter(Boolean);
  }
  if (activeView === 'calendar') {
    return [
      document.querySelector('.page-header'),
      document.getElementById('cal-section'),
      document.getElementById('day-slots-wrapper')
    ].filter(Boolean);
  }
  return [document.querySelector('.page-header')].filter(Boolean);
}

/* Thin wrappers — call shared ui.js implementations with local render functions */
function navDay(delta)   { _navDayShared(delta, renderDaySlots); }
function navMonth(delta) { _navMonthShared(delta, renderDaySlots); }
function checkDayNavSticky() { checkDayNavStickyShared('day-slots-wrapper'); }

function updateJumpBtns() { _updateJumpBtnsShared((activeView === 'my-bookings' || activeView === 'calendar') && getSectionJumpTargets().length > 1); }

function prevMonth() { _prevMonthShared(renderDaySlots); }
function nextMonth() { _nextMonthShared(renderDaySlots); }
