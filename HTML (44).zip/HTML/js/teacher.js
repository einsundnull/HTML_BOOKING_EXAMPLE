/**
 * teacher.js — Teacher View Logic
 *
 * Grid modes: 'available' | 'timeout'
 * Recurring slots: materialised on-demand per week from app_recurring
 * No inline styles — all classes from teacher.css
 */

var currentUser  = null;
var viewYear     = 0;
var viewMonth    = 0;
var selectedDate = new Date(); /* Heute vorausgewählt */

var gridWeekStart = null;
var gridMode      = 'available'; // 'available' | 'timeout'
var gridPending   = {};          // { "date|time": 'available'|'timeout'|'disabled'|'remove-recurring' }

/* Preserve free-slots accordion open state across renderDayPanel calls */
var _freeSlotsBlockOpen = false;

var TODAY = new Date();
TODAY.setHours(0, 0, 0, 0);

var MONTH_NAMES = ['January','February','March','April','May','June',
                   'July','August','September','October','November','December'];
var DAY_NAMES   = ['Mo','Tu','We','Th','Fr','Sa','Su'];

var GRID_START = '06:00';
var GRID_END   = '22:00';

/* ══════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════ */
window.addEventListener('load', function() {
  currentUser = Auth.require('teacher');
  if (!currentUser) return;
  Navbar.init('teacher');

  var now   = new Date();
  viewYear  = now.getFullYear();
  viewMonth = now.getMonth();

  document.getElementById('prev-btn').addEventListener('click', prevMonth);
  document.getElementById('next-btn').addEventListener('click', nextMonth);
  document.getElementById('grid-close-btn').addEventListener('click', closeSlotGrid);
  document.getElementById('grid-save-btn').addEventListener('click', saveSlotGrid);
  document.getElementById('grid-prev-week').addEventListener('click', gridPrevWeek);
  document.getElementById('grid-next-week').addEventListener('click', gridNextWeek);
  document.getElementById('mode-btn-available').addEventListener('click', function() { setGridMode('available'); });
  document.getElementById('mode-btn-timeout').addEventListener('click', function() { setGridMode('timeout'); });

  renderStudentList();
  renderCalendar();
  renderDayPanel();

  // Main view tabs
  document.getElementById('nav-schedule').addEventListener('click', function() { switchTeacherView('schedule'); });
  document.getElementById('nav-all-bookings').addEventListener('click', function() { switchTeacherView('all-bookings'); });
  document.getElementById('nav-students').addEventListener('click', function() { switchTeacherView('students'); });
  document.getElementById('nav-wallet').addEventListener('click', function() { switchTeacherView('wallet'); });

  // Day panel sub-tabs
  document.getElementById('day-tab-availability').addEventListener('click', function() { switchDayTab('availability'); });
  document.getElementById('day-tab-bookings').addEventListener('click', function() { switchDayTab('bookings'); });
});

var activeDayTab = 'availability';

function switchDayTab(tab) {
  activeDayTab = tab;
  document.getElementById('day-tab-availability').classList.toggle('active', tab === 'availability');
  document.getElementById('day-tab-bookings').classList.toggle('active', tab === 'bookings');
  renderDayPanel();
}

var activeTeacherView = 'schedule';
/* ── Single shared filter state — used by ALL three views:
      All Bookings tab, Day Panel (Buchungen tab), My Students list ── */
var bookingsFilter = {
  student:   'all',
  time:      'upcoming',
  confirmed: 'all',
  dateFrom:  '',   /* 'YYYY-MM-DD' | '' */
  dateTo:    ''    /* 'YYYY-MM-DD' | '' */
};
var allBookingsSortAsc = true; /* true = oldest→newest, false = newest→oldest */

/* Read/write helpers — always go through bookingsFilter */
/* Legacy aliases — read-only snapshots, updated via _setFilter */
var _closeBookingDropdown = null;
var _closeDdDropdown      = null; /* outside-click handler for custom dropdown */
var expandedAllBlocks  = {};


function _applyConfirmFilter(slots, confirmFilter) {
  if (confirmFilter === 'confirmed')   return slots.filter(function(s) { return !!s.confirmedAt; });
  if (confirmFilter === 'unconfirmed') return slots.filter(function(s) { return !s.confirmedAt;  });
  return slots;
}

/* Pending booking changes — staged, not yet written to Store
   { slotId: { action:'book'|'cancel', originalSlot:{...}, newStudentId:uid|null } } */
var pendingBookings = {};

/* Return effective slot — pending overrides Store */
function getEffectiveTeacherSlot(storeSlot) {
  var p = pendingBookings[storeSlot.slotId];
  if (!p) return storeSlot;
  var s = {}; for (var k in storeSlot) s[k] = storeSlot[k];
  if (p.action === 'book') {
    s.status    = 'booked';
    s.studentId = p.newStudentId;
    s._pending  = 'book';
  } else {
    s.status    = storeSlot.baseStatus || 'available';
    s.studentId = null;
    s._pending  = 'cancel';
  }
  return s;
}

function switchTeacherView(view) {
  activeTeacherView = view;
  document.getElementById('nav-schedule').classList.toggle('active',      view === 'schedule');
  document.getElementById('nav-all-bookings').classList.toggle('active',  view === 'all-bookings');
  document.getElementById('nav-students').classList.toggle('active',      view === 'students');
  document.getElementById('nav-wallet').classList.toggle('active',        view === 'wallet');
  document.getElementById('view-schedule').classList.toggle('view-hidden',      view !== 'schedule');
  document.getElementById('view-all-bookings').classList.toggle('view-hidden',  view !== 'all-bookings');
  document.getElementById('view-students').classList.toggle('view-hidden',      view !== 'students');
  document.getElementById('view-wallet').classList.toggle('view-hidden',        view !== 'wallet');
  if (view === 'all-bookings') {
    var bar = document.getElementById('day-nav-bar');
    if (bar) { bar.classList.remove('is-sticky'); }
    renderAllBookings();
    setTimeout(updateJumpBtns, 200);
  }
  if (view === 'students') {
    renderStudentList();
  }
  if (view === 'schedule') {
    updateDayNavBar();
    setTimeout(updateJumpBtns, 100);
  }
  if (view === 'wallet') {
    if (typeof WalletPanel !== 'undefined') {
      WalletPanel.mount('teacher-wallet-panel', currentUser.uid);
    }
  }
}

/* ══════════════════════════════════════════════════════════
   STUDENT LIST
══════════════════════════════════════════════════════════ */

// Track which student rows are expanded
var expandedStudents = {};

/* ── My Students filter state ── */
/* studentListFilter removed — replaced by shared bookingsFilter object */

function renderStudentList() {
  var selections = AppService.getSelectionsByTeacherSync(currentUser.uid);
  var container  = document.getElementById('student-list');
  document.getElementById('stat-students').textContent = selections.length;

  if (!selections.length) {
    container.innerHTML = '<p class="text-muted" style="padding:var(--sp-3) var(--sp-4)">Noch keine Schüler.</p>';
    return;
  }

  container.innerHTML = '';
  var today = fmtDate(new Date());

  /* ── Filter toolbar — same classes as All Bookings / Day Panel ── */
  var toolbar = document.createElement('div');
  toolbar.className = 'student-filter-toolbar';

  /* Time filter — booking-time-filter / booking-time-btn */
  var timeRow = document.createElement('div');
  timeRow.className = 'booking-time-filter';
  var timeOpts = [
    { key: 'past',     label: 'Vergangen' },
    { key: 'upcoming', label: 'Kommende' },
    { key: 'all',      label: 'Alle' }
  ];
  timeOpts.forEach(function(t) {
    var btn = document.createElement('button');
    btn.className = 'booking-time-btn' + (bookingsFilter.time === t.key ? ' active' : '');
    btn.textContent = t.label;
    btn.addEventListener('click', function() {
      _setFilter('time', t.key);
      renderStudentList();
      renderDayPanel();
      if (activeTeacherView === 'all-bookings') renderAllBookings();
    });
    timeRow.appendChild(btn);
  });

  /* Confirm filter — booking-confirm-filter / booking-confirm-btn */
  var confRow = document.createElement('div');
  confRow.className = 'booking-confirm-filter';
  var confOpts = [
    { key: 'all',         label: 'Alle' },
    { key: 'unconfirmed', label: 'Unbestätigt' },
    { key: 'confirmed',   label: 'Bestätigt ✓' }
  ];
  confOpts.forEach(function(c) {
    var btn = document.createElement('button');
    btn.className = 'booking-confirm-btn' + (bookingsFilter.confirmed === c.key ? ' active' : '');
    btn.setAttribute('data-confirm', c.key);
    btn.textContent = c.label;
    btn.addEventListener('click', function() {
      _setFilter('confirmed', c.key);
      renderStudentList();
      renderDayPanel();
      if (activeTeacherView === 'all-bookings') renderAllBookings();
    });
    confRow.appendChild(btn);
  });

  toolbar.appendChild(timeRow);
  toolbar.appendChild(confRow);
  toolbar.appendChild(_buildSortDateRangeRow(function() {
    renderStudentList();
    renderDayPanel();
    if (activeTeacherView === 'all-bookings') renderAllBookings();
  }));
  container.appendChild(toolbar);

  /* ── Per-student rows ── */
  var frag = document.createDocumentFragment();
  var anyVisible = false;

  for (var i = 0; i < selections.length; i++) {
    var student = AppService.getUserSync(selections[i].studentId);
    if (!student) continue;

    var allSlots = AppService.getSlotsByStudentSync(student.uid)
      .filter(function(s) { return s.teacherId === currentUser.uid && s.status === 'booked'; })
      .sort(function(a, b) { return a.date.localeCompare(b.date) || a.time.localeCompare(b.time); });

    var filtered = _applyTimeFilter(allSlots, bookingsFilter.time, today);
    filtered = _applyDateRangeFilter(filtered);
    filtered = _applyConfirmFilter(filtered, bookingsFilter.confirmed);

    if (!filtered.length) continue;
    anyVisible = true;
    frag.appendChild(buildStudentRow(student, filtered));
  }

  if (!anyVisible) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.style.padding = 'var(--sp-3) var(--sp-4)';
    empty.textContent = 'Keine Buchungen für diesen Filter.';
    container.appendChild(empty);
    return;
  }

  container.appendChild(frag);
}

function buildStudentRow(student, bookedSlots) {
  var isOpen     = !!expandedStudents[student.uid];
  var today      = fmtDate(new Date());

  /* Zählung exakt wie _calcBlockCounts — alle drei Confirm-States */
  var counts = _calcBlockCounts(bookedSlots, today);

  var wrapper = document.createElement('div');
  wrapper.className = 'student-row-wrapper';

  var header = document.createElement('div');
  header.className = 'student-row' + (isOpen ? ' student-row-open' : '');
  header.setAttribute('tabindex', '0');

  var info = document.createElement('div');
  info.className = 'student-row-info';

  var name = document.createElement('div');
  name.className = 'student-name';
  name.textContent = ProfileStore.getDisplayName(student.uid);

  /* Badge row: Alle N · Unbestätigt N · Bestätigt N */
  var countRow = document.createElement('div');
  countRow.className = 'student-count-badges';

  var badgeDefs = [
    { label: 'Alle',         val: counts.all },
    { label: 'Unbestätigt',  val: counts.unconfirmed },
    { label: 'Bestätigt ✓',  val: counts.confirmed }
  ];
  badgeDefs.forEach(function(b) {
    var chip = document.createElement('span');
    chip.className = 'student-count-badge';
    chip.textContent = b.label + ' ';
    var chipBadge = document.createElement('span');
    chipBadge.className = 'booking-confirm-count';
    chipBadge.textContent = b.val;
    chip.appendChild(chipBadge);
    countRow.appendChild(chip);
  });

  info.appendChild(name);
  info.appendChild(countRow);

  var right = document.createElement('div');
  right.className = 'student-row-right';
  var uid = document.createElement('code');
  uid.className = 'uid-badge';
  uid.textContent = student.uid;
  var chevron = document.createElement('span');
  chevron.className = 'student-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  right.appendChild(uid);
  right.appendChild(chevron);

  header.appendChild(info);
  header.appendChild(right);

  var detail = document.createElement('div');
  detail.className = 'student-booking-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) populateStudentBookings(detail, student, bookedSlots);

  function toggle() {
    if (expandedStudents[student.uid]) {
      delete expandedStudents[student.uid];
      header.classList.remove('student-row-open');
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedStudents[student.uid] = true;
      header.classList.add('student-row-open');
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      populateStudentBookings(detail, student, bookedSlots);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

/**
 * Merge consecutive booked slots (same date, consecutive times) into blocks.
 * Returns [{ date, start, end, slotIds[] }]
 */

function populateStudentBookings(detail, student, bookedSlots) {
  detail.innerHTML = '';

  if (!bookedSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted student-bookings-empty';
    empty.textContent = 'Noch keine Buchungen.';
    detail.appendChild(empty);
    return;
  }

  var today = fmtDate(new Date());

  /* Group by date */
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < bookedSlots.length; i++) {
    var d = bookedSlots[i].date;
    if (!byDate[d]) { byDate[d] = []; dateOrder.push(d); }
    byDate[d].push(bookedSlots[i]);
  }
  dateOrder.sort();
  if (!allBookingsSortAsc) { dateOrder.reverse(); }

  for (var di = 0; di < dateOrder.length; di++) {
    var dateStr = dateOrder[di];
    var isPast  = dateStr < today;

    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider student-date-divider'
      + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', {
      weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });
    detail.appendChild(divider);

    /* mergeAllBookingBlocks — selbe Logik wie All Bookings und Day Panel */
    var blocks = mergeAllBookingBlocks(dateStr, byDate[dateStr], today);
    for (var bi = 0; bi < blocks.length; bi++) {
      detail.appendChild(buildAllBookingBlock(blocks[bi], {
        showDate: false, isPast: isPast, simpleDetail: true
      }));
    }
  }
}

/* buildBookingBlockRow removed — now uses buildBookingBlock */

/* ══════════════════════════════════════════════════════════
   CALENDAR
══════════════════════════════════════════════════════════ */
function materialiseVisibleMonth(year, month) {
  // Find all Mondays in the visible calendar grid (can span prev/next month)
  var first    = new Date(year, month, 1);
  var startDow = first.getDay(); startDow = (startDow === 0) ? 6 : startDow - 1;
  // First Monday shown = first day of month minus startDow days
  var gridStart = new Date(year, month, 1 - startDow);
  // Calendar shows up to 6 weeks = 42 days
  var seen = {};
  for (var d = 0; d < 42; d++) {
    var day = new Date(gridStart);
    day.setDate(gridStart.getDate() + d);
    // Get Monday of this day's week
    var dow = day.getDay(); dow = (dow === 0) ? 6 : dow - 1;
    var mon = new Date(day); mon.setDate(day.getDate() - dow);
    var monKey = mon.getFullYear() + '-' + mon.getMonth() + '-' + mon.getDate();
    if (seen[monKey]) continue;
    seen[monKey] = true;
    var weekDates = [];
    for (var w = 0; w < 7; w++) {
      var wd = new Date(mon); wd.setDate(mon.getDate() + w);
      weekDates.push(wd);
    }
    AppService.materialiseWeek(currentUser.uid, weekDates, function(e){if(e)Toast.error(e.message||e);});
  }
}

function renderCalendar() {
  document.getElementById('month-label').textContent = MONTH_NAMES[viewMonth] + ' ' + viewYear;

  // Week view button — add once
  var calHeader = document.getElementById('cal-header-actions');
  if (calHeader && !document.getElementById('week-view-btn')) {
    var wvBtn = document.createElement('button');
    wvBtn.id = 'week-view-btn';
    wvBtn.className = 'btn btn-secondary btn-sm';
    wvBtn.textContent = 'Week view';
    wvBtn.addEventListener('click', openSlotGrid);
    calHeader.appendChild(wvBtn);
  }

  // Materialise recurring slots for every week visible this month
  materialiseVisibleMonth(viewYear, viewMonth);

  var grid = document.getElementById('cal-days');
  grid.innerHTML = '';

  var first    = new Date(viewYear, viewMonth, 1);
  var startDow = first.getDay();
  startDow = (startDow === 0) ? 6 : startDow - 1;
  var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
  var prevDays    = new Date(viewYear, viewMonth, 0).getDate();

  for (var i = startDow - 1; i >= 0; i--) {
    grid.appendChild(makeCell(prevDays - i, true));
  }

  for (var d = 1; d <= daysInMonth; d++) {
    (function(day) {
      var date    = new Date(viewYear, viewMonth, day);
      var isToday = date.getTime() === TODAY.getTime();
      var isSel   = selectedDate && date.getTime() === selectedDate.getTime();
      var dateStr = fmtDate(date);
      var slots      = AppService.getSlotsByTeacherDateSync(currentUser.uid, dateStr);
      var hasAny     = slots.length > 0;
      var hasBook    = slots.some(function(s) { return s.status === 'booked'; });
      var hasTimeout = slots.some(function(s) { return s.status === 'timeout'; });

      var cell = makeCell(day, false, isToday, isSel, hasAny, hasBook, hasTimeout);
      cell.addEventListener('click', function() { selectDate(date); });
      cell.setAttribute('tabindex', '0');
      cell.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') selectDate(date);
      });
      grid.appendChild(cell);
    })(d);
  }

  var total    = startDow + daysInMonth;
  var trailing = total % 7 === 0 ? 0 : 7 - (total % 7);
  for (var t = 1; t <= trailing; t++) {
    grid.appendChild(makeCell(t, true));
  }

  updateStats();
}

function makeCell(num, otherMonth, isToday, isSelected, hasSlots, hasBooked, hasTimeout) {
  var el = document.createElement('div');
  el.className = 'cal-day';
  if (otherMonth)  el.classList.add('other-month');
  if (isToday)     el.classList.add('today');
  if (isSelected)  el.classList.add('selected');
  if (hasSlots)    el.classList.add('has-slots');
  if (hasBooked)   el.classList.add('has-booked');
  if (hasTimeout)  el.classList.add('has-timeout');
  el.textContent = num;
  return el;
}

function selectDate(date) {
  selectedDate = date;
  renderCalendar();
  renderDayPanel();
}

/* ══════════════════════════════════════════════════════════
   DAY PANEL
══════════════════════════════════════════════════════════ */

function renderDayPanel() {
  updateDayNavBar();
  var panel = document.getElementById('day-panel');
  panel.innerHTML = '';

  if (!selectedDate) {
    var hint = document.createElement('p');
    hint.className = 'text-muted day-panel-empty';
    hint.textContent = 'Select a day.';
    panel.appendChild(hint);
    return;
  }

  var dateStr = fmtDate(selectedDate);

  // Materialise recurring for the week of selected date
  var selMonday = new Date(selectedDate);
  var selDow = selMonday.getDay(); selDow = (selDow === 0) ? 6 : selDow - 1;
  selMonday.setDate(selMonday.getDate() - selDow);
  var selWeekDates = [];
  for (var wi = 0; wi < 7; wi++) { var wd = new Date(selMonday); wd.setDate(wd.getDate() + wi); selWeekDates.push(wd); }
  AppService.materialiseWeek(currentUser.uid, selWeekDates, function(e){if(e)Toast.error(e.message||e);});

  var slots   = AppService.getSlotsByTeacherDateSync(currentUser.uid, dateStr);

  /* Date label removed — already shown in the sticky day-nav-bar above */
  if (activeDayTab === 'availability') {
    var header = document.createElement('div');
    header.className = 'day-panel-header';
    var btn = document.createElement('button');
    btn.className = 'btn btn-primary btn-sm';
    btn.id = 'add-slot-btn';
    btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg> Add slots';
    btn.addEventListener('click', openSlotGrid);
    header.appendChild(btn);
    panel.appendChild(header);
  }

  if (!slots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted day-panel-empty';
    empty.textContent = activeDayTab === 'availability'
      ? 'Keine Slots für diesen Tag. Klicke auf "+ Add slots" um welche hinzuzufügen.'
      : 'Keine Slots für diesen Tag.';
    panel.appendChild(empty);
    return;
  }

  if (activeDayTab === 'availability') {
    renderAvailabilityPanel(panel, slots);
  } else {
    renderBookingsPanel(panel, slots, dateStr);
  }
}

/* ── Tab 1: Verfügbarkeit ───────────────────────────────── */
function renderAvailabilityPanel(panel, slots) {
  for (var i = 0; i < slots.length; i++) {
    panel.appendChild(buildAvailabilityCard(slots[i]));
  }
}

function buildAvailabilityCard(slot) {
  var base = slot.baseStatus || slot.status;

  var modClass = base === 'disabled' ? ' avail-row-disabled'
               : base === 'timeout'  ? ' avail-row-timeout'
               : '';

  var row = document.createElement('div');
  row.className = 'avail-row' + modClass;

  /* Zeit */
  var timeEl = document.createElement('span');
  timeEl.className = 'avail-row-time';
  timeEl.textContent = slot.time + ' \u2013 ' + AppService.slotEndTime(slot.time);

  /* Status-Label */
  var statusEl = document.createElement('span');
  statusEl.className = 'avail-row-status';
  var statusLabels = { available: 'Frei', disabled: 'Deaktiviert', timeout: 'Timeout', booked: 'Gebucht', recurring: 'Frei' };
  statusEl.textContent = statusLabels[base] || base;

  /* Aktions-Buttons */
  var actions = document.createElement('div');
  actions.className = 'avail-row-actions';

  if (base === 'available' || base === 'recurring') {
    var disableBtn = document.createElement('button');
    disableBtn.className = 'btn btn-ghost btn-sm';
    disableBtn.textContent = 'Deaktivieren';
    (function(s) {
      disableBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        var d = new Date(s.date + 'T00:00:00');
        var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
        AppService.setSlotAvailability(s.slotId, 'disabled', function(e){if(e)Toast.error(e.message||e);});
        AppService.deleteRecurringByDayTime(currentUser.uid, dow, s.time, function(e){if(e)Toast.error(e.message||e);});
        renderDayPanel(); renderCalendar();
      });
    })(slot);
    actions.appendChild(disableBtn);

    var timeoutBtn = document.createElement('button');
    timeoutBtn.className = 'btn btn-ghost btn-sm';
    timeoutBtn.textContent = 'Timeout';
    (function(s) {
      timeoutBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        var current = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0];
        if (current && current.studentId) {
          var sName  = ProfileStore.getDisplayName(current.studentId);
          var result = Modal.show({
            title: 'Slot ist gebucht',
            bodyHTML: '<p>Dieser Slot ist gebucht von <strong>' + sName + '</strong>. Timeout setzt die Buchung zurück.</p>',
            footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Behalten</button><button class="btn btn-danger" id="modal-confirm">Buchung stornieren & Timeout setzen</button>'
          });
          document.getElementById('modal-cancel').addEventListener('click', result.close);
          (function(sid) {
            document.getElementById('modal-confirm').addEventListener('click', function() {
              AppService.cancelSlotBooking(sid, function(e){if(e)Toast.error(e.message||e);});
              AppService.setSlotAvailability(sid, 'timeout', function(e){if(e)Toast.error(e.message||e);});
              renderDayPanel(); renderCalendar(); renderStudentList();
              result.close();
            });
          })(s.slotId);
        } else {
          AppService.setSlotAvailability(s.slotId, 'timeout', function(e){if(e)Toast.error(e.message||e);});
          renderDayPanel(); renderCalendar();
        }
      });
    })(slot);
    actions.appendChild(timeoutBtn);

  } else if (base === 'disabled' || base === 'timeout') {
    var enableBtn = document.createElement('button');
    enableBtn.className = 'btn btn-ghost btn-sm';
    enableBtn.textContent = 'Aktivieren';
    (function(s) {
      enableBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        var d = new Date(s.date + 'T00:00:00');
        var dow = d.getDay(); dow = (dow === 0) ? 6 : dow - 1;
        AppService.setSlotAvailability(s.slotId, 'available', function(e){if(e)Toast.error(e.message||e);});
        AppService.createRecurring(currentUser.uid, dow, s.time, function(e){if(e)Toast.error(e.message||e);});
        renderDayPanel(); renderCalendar();
      });
    })(slot);
    actions.appendChild(enableBtn);
  }

  /* Löschen-Icon */
  var delBtn = document.createElement('button');
  delBtn.className = 'btn btn-ghost btn-sm';
  delBtn.setAttribute('aria-label', 'Slot löschen');
  delBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  (function(s) {
    delBtn.addEventListener('click', function(e) { e.stopPropagation(); deleteSlot(s.slotId); });
  })(slot);
  actions.appendChild(delBtn);

  row.appendChild(timeEl);
  row.appendChild(statusEl);
  row.appendChild(actions);
  return row;
}

/* ── Tab 2: Buchungen ───────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   BOOKINGS PANEL (Tab 2)
══════════════════════════════════════════════════════════ */

// Currently open booking form slot id
var openBookFormSlotId = null;

function renderBookingsPanel(panel, slots, dateStr) {
  var today  = fmtDate(new Date());
  var isPast = dateStr < today;

  /* Effective + deduplicate */
  var seen = {};
  var effective = [];
  for (var ei = 0; ei < slots.length; ei++) {
    var eff = getEffectiveTeacherSlot(slots[ei]);
    if (!seen[eff.slotId]) { seen[eff.slotId] = true; effective.push(eff); }
  }

  var allBooked = effective.filter(function(s) { return !!s.studentId && s._pending !== 'book'; });
  var freeSlots = effective.filter(function(s) { return !s.studentId; });

  /* Filter bar */
  var filterWrap = document.createElement('div');
  filterWrap.className = 'day-bookings-filters';

  /* Student picker — only if >1 student */
  var myStudentUids = AppService.getSelectionsByTeacherSync(currentUser.uid).map(function(sel) { return sel.studentId; });
  var myStudents    = myStudentUids.map(function(uid) { return AppService.getUserSync(uid); }).filter(Boolean);

  if (myStudents.length > 1) {
    var studentRow = document.createElement('div');
    studentRow.className = 'day-bookings-filter-row';
    var studentLbl = document.createElement('span');
    studentLbl.className = 'day-bookings-filter-label';
    studentLbl.textContent = 'Schüler';

    var ddWrap = document.createElement('div');
    ddWrap.className = 'custom-dropdown day-bookings-student-dd';
    var ddTrigger = document.createElement('button');
    ddTrigger.type = 'button';
    ddTrigger.className = 'custom-dropdown-trigger';
    ddTrigger.setAttribute('aria-haspopup', 'listbox');
    ddTrigger.setAttribute('aria-expanded', 'false');
    var ddLabelSpan = document.createElement('span');
    ddLabelSpan.className = 'custom-dropdown-label';
    var ddChevronEl = document.createElement('span');
    ddChevronEl.innerHTML = '<svg class="custom-dropdown-chevron" width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    ddTrigger.appendChild(ddLabelSpan);
    ddTrigger.appendChild(ddChevronEl);
    var ddList = document.createElement('ul');
    ddList.className = 'custom-dropdown-list';
    ddList.setAttribute('role', 'listbox');

    var ddOptions = [{ value: 'all', text: 'Alle Schüler' }];
    for (var si = 0; si < myStudents.length; si++) {
      ddOptions.push({ value: myStudents[si].uid, text: ProfileStore.getDisplayName(myStudents[si].uid) });
    }

    function setStudentFilter(val) {
      _setFilter('student', val);
      var sel = ddOptions.filter(function(o) { return o.value === val; })[0] || ddOptions[0];
      ddLabelSpan.textContent = sel.text;
      var items = ddList.querySelectorAll('.custom-dropdown-item');
      for (var k = 0; k < items.length; k++) {
        items[k].classList.toggle('is-active', items[k].getAttribute('data-value') === val);
      }
      ddList.classList.remove('is-open');
      ddTrigger.classList.remove('is-open');
      ddTrigger.setAttribute('aria-expanded', 'false');
      renderDayPanel();
    }

    for (var di = 0; di < ddOptions.length; di++) {
      (function(opt) {
        var li = document.createElement('li');
        li.className = 'custom-dropdown-item' + (opt.value === bookingsFilter.student ? ' is-active' : '');
        li.setAttribute('role', 'option');
        li.setAttribute('data-value', opt.value);
        li.textContent = opt.text;
        li.addEventListener('click', function(e) { e.stopPropagation(); setStudentFilter(opt.value); });
        ddList.appendChild(li);
      })(ddOptions[di]);
    }
    var curSel = ddOptions.filter(function(o) { return o.value === bookingsFilter.student; })[0] || ddOptions[0];
    ddLabelSpan.textContent = curSel.text;

    ddTrigger.addEventListener('click', function(e) {
      e.stopPropagation();
      var isOpen = ddList.classList.contains('is-open');
      ddList.classList.toggle('is-open', !isOpen);
      ddTrigger.classList.toggle('is-open', !isOpen);
      ddTrigger.setAttribute('aria-expanded', !isOpen ? 'true' : 'false');
    });
    document.removeEventListener('click', _closeDdDropdown);
    _closeDdDropdown = function() {
      ddList.classList.remove('is-open');
      ddTrigger.classList.remove('is-open');
      ddTrigger.setAttribute('aria-expanded', 'false');
    };
    document.addEventListener('click', _closeDdDropdown);

    ddWrap.appendChild(ddTrigger);
    ddWrap.appendChild(ddList);
    studentRow.appendChild(studentLbl);
    studentRow.appendChild(ddWrap);
    filterWrap.appendChild(studentRow);
  }

  /* Time filter */
  var timeRow = document.createElement('div');
  timeRow.className = 'booking-time-filter';
  var timeOpts = [
    { val: 'past',     label: 'Vergangen' },
    { val: 'upcoming', label: 'Kommende'  },
    { val: 'all',      label: 'Alle'      }
  ];
  for (var ti = 0; ti < timeOpts.length; ti++) {
    (function(opt) {
      var btn = document.createElement('button');
      btn.className = 'booking-time-btn' + (opt.val === bookingsFilter.time ? ' active' : '');
      btn.textContent = opt.label;
      btn.addEventListener('click', function() { _setFilter('time', opt.val); renderDayPanel(); if (activeTeacherView === 'students') renderStudentList(); if (activeTeacherView === 'all-bookings') renderAllBookings(); });
      timeRow.appendChild(btn);
    })(timeOpts[ti]);
  }
  filterWrap.appendChild(timeRow);
  filterWrap.appendChild(_buildSortDateRangeRow(function() {
    renderDayPanel();
    if (activeTeacherView === 'students') renderStudentList();
    if (activeTeacherView === 'all-bookings') renderAllBookings();
  }));

  /* Einheitliche Filter-Pipeline — erst filtern, dann aus dem Ergebnis zählen */
  /* Student-Filter */
  var baseFiltered = allBooked.slice();
  if (bookingsFilter.student !== 'all') {
    baseFiltered = baseFiltered.filter(function(s) { return s.studentId === bookingsFilter.student; });
  }
  /* Zeit-Filter */
  baseFiltered = _applyTimeFilter(baseFiltered, bookingsFilter.time, today);
  baseFiltered = _applyDateRangeFilter(baseFiltered);

  /* Blockzahlen aus derselben gefilterten Basis — exakt was unten angezeigt wird */
  var allBlocks    = mergeAllBookingBlocks(dateStr, baseFiltered, today);
  var unconfBlocks = mergeAllBookingBlocks(dateStr, _applyConfirmFilter(baseFiltered, 'unconfirmed'), today);
  var confBlocks   = mergeAllBookingBlocks(dateStr, _applyConfirmFilter(baseFiltered, 'confirmed'),   today);

  /* Confirm filter buttons */
  var confirmRow = document.createElement('div');
  confirmRow.className = 'booking-confirm-filter';
  var confirmOpts = [
    { val: 'all',         label: 'Alle',             count: allBlocks.length },
    { val: 'unconfirmed', label: 'Unbestätigt',       count: unconfBlocks.length },
    { val: 'confirmed',   label: 'Bestätigt \u2713', count: confBlocks.length }
  ];
  for (var ci = 0; ci < confirmOpts.length; ci++) {
    (function(opt) {
      var btn = document.createElement('button');
      btn.className = 'booking-confirm-btn' + (opt.val === bookingsFilter.confirmed ? ' active' : '');
      btn.setAttribute('data-confirm', opt.val);
      btn.textContent = opt.label + ' ';
      var btnBadge = document.createElement('span');
      btnBadge.className = 'booking-confirm-count';
      btnBadge.textContent = opt.count;
      btn.appendChild(btnBadge);
      btn.addEventListener('click', function() { _setFilter('confirmed', opt.val); renderDayPanel(); if (activeTeacherView === 'students') renderStudentList(); if (activeTeacherView === 'all-bookings') renderAllBookings(); });
      confirmRow.appendChild(btn);
    })(confirmOpts[ci]);
  }
  filterWrap.appendChild(confirmRow);
  panel.appendChild(filterWrap);

  /* Anzeigefilter: Bestätigt-Filter auf die bereits gefilterte Basis anwenden */
  var filtered = _applyConfirmFilter(baseFiltered, bookingsFilter.confirmed);

  /* Free slots + booked slots accordion — always shown when not past */
  if (!isPast) {
    var freeWrapper = document.createElement('div');
    freeWrapper.className = 'all-booking-block-wrapper';
    var freeHeader = document.createElement('div');
    freeHeader.className = 'all-booking-block-header';
    var freeLabel = document.createElement('span');
    freeLabel.className = 'all-booking-block-time';
    freeLabel.textContent = freeSlots.length + ' freie Slot' + (freeSlots.length !== 1 ? 's' : '');
    var freeChevron = document.createElement('span');
    freeChevron.className = 'all-booking-chevron';
    freeChevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    freeHeader.appendChild(freeLabel);
    freeHeader.appendChild(freeChevron);
    var freeDetail = document.createElement('div');
    freeDetail.className = 'all-booking-block-detail';
    freeDetail.style.padding = 'var(--sp-1) var(--sp-3)';
    /* Restore open state from before the re-render */
    if (_freeSlotsBlockOpen) {
      freeDetail.classList.add('is-open');
      freeChevron.classList.add('is-open');
    }
    /* Use populateAllBookingDetail (stuId=null → shows free + booked + pending slots) */
    populateAllBookingDetail(freeDetail, {
      student:          null,
      dateStr:          dateStr,
      today:            fmtDate(new Date()),
      isFullyConfirmed: false
    });
    /* Rewire "+ Add" buttons to open buildBookingForm (teacher needs student picker + range) */
    var addBtns = freeDetail.querySelectorAll('.btn-primary, .btn-ghost');
    for (var ab = 0; ab < addBtns.length; ab++) {
      (function(btn) {
        var slotTime = btn.closest('.all-booking-slot-row')
          && btn.closest('.all-booking-slot-row').querySelector('.all-booking-slot-time');
        if (!slotTime || btn.textContent.trim() === 'Undo') return;
        var time = slotTime.textContent.split('–')[0].trim();
        var rawSlot = slots.filter(function(s) { return s.time === time && !s.studentId; })[0];
        if (!rawSlot) return;
        btn.onclick = function(e) {
          e.stopPropagation();
          buildBookingForm(rawSlot, dateStr, slots);
        };
      })(addBtns[ab]);
    }
    freeHeader.setAttribute('tabindex', '0');
    (function(hdr, det, chv) {
      function toggle() {
        var open = det.classList.contains('is-open');
        det.classList.toggle('is-open', !open);
        chv.classList.toggle('is-open', !open);
        _freeSlotsBlockOpen = !open;
      }
      hdr.addEventListener('click', toggle);
      hdr.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });
    })(freeHeader, freeDetail, freeChevron);
    freeWrapper.appendChild(freeHeader);
    freeWrapper.appendChild(freeDetail);
    panel.appendChild(freeWrapper);
  }

  /* Booked blocks */
  if (!filtered.length) {
    var emptyMsg = document.createElement('p');
    emptyMsg.className = 'text-muted';
    emptyMsg.style.padding = 'var(--sp-3) 0';
    emptyMsg.textContent = 'Keine Buchungen für diese Filterauswahl.';
    panel.appendChild(emptyMsg);
    return;
  }

  var blocks = mergeAllBookingBlocks(dateStr, filtered, today);
  for (var b = 0; b < blocks.length; b++) {
    panel.appendChild(buildAllBookingBlock(blocks[b], { showDate: false, isPast: isPast }));
  }
}


function buildBookingForm(startSlot, dateStr, allSlots) {
  /* Opens as a proper Modal instead of inline expansion */
  var selections = AppService.getSelectionsByTeacherSync(currentUser.uid);
  var students   = selections.map(function(s) { return AppService.getUserSync(s.studentId); }).filter(Boolean);

  if (!students.length) {
    Modal.show({
      title: 'Buchung erstellen',
      bodyHTML: '<p class="move-dialog-info">Keine Schüler zugewiesen.</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Schließen</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', function() {
      openBookFormSlotId = null; renderDayPanel();
    });
    return null;
  }

  /* Build student checkboxes HTML */
  var stuHTML = '';
  for (var i = 0; i < students.length; i++) {
    var name = ProfileStore.getDisplayName(students[i].uid);
    stuHTML += '<label class="booking-form-check-row">'
      + '<input type="checkbox" class="booking-form-checkbox bk-modal-stu-cb" value="' + students[i].uid + '">'
      + '<span>' + name + '</span></label>';
  }

  var bodyHTML =
    '<div class="move-dialog">' +
      '<div class="booking-form-label">Schüler</div>' +
      '<div class="booking-form-students">' + stuHTML + '</div>' +
      '<div class="booking-form-time-row">' +
        '<div class="booking-form-time-col">' +
          '<div class="booking-form-label">Von</div>' +
          '<div class="custom-dropdown" id="bk-from-dd" style="min-width:0;width:100%">' +
            '<button type="button" class="custom-dropdown-trigger" id="bk-from-trigger">' +
              '<span class="custom-dropdown-label" id="bk-from-label"></span>' +
              '<svg class="custom-dropdown-chevron" width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '</button>' +
            '<ul class="custom-dropdown-list" id="bk-from-list" role="listbox"></ul>' +
          '</div>' +
        '</div>' +
        '<div class="booking-form-time-col">' +
          '<div class="booking-form-label">Bis</div>' +
          '<div class="custom-dropdown" id="bk-until-dd" style="min-width:0;width:100%">' +
            '<button type="button" class="custom-dropdown-trigger" id="bk-until-trigger">' +
              '<span class="custom-dropdown-label" id="bk-until-label"></span>' +
              '<svg class="custom-dropdown-chevron" width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            '</button>' +
            '<ul class="custom-dropdown-list" id="bk-until-list" role="listbox"></ul>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>';

  var result = Modal.show({
    title: 'Buchung erstellen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>'
              + '<button class="btn btn-primary" id="modal-confirm">Buchen</button>'
  });

  /* ── Custom dropdown wiring ── */
  var allUnbooked = allSlots.filter(function(s) { return !s.studentId; });

  var fromValue  = startSlot.time;
  var untilValue = '';

  var fromTrigger = document.getElementById('bk-from-trigger');
  var fromLabel   = document.getElementById('bk-from-label');
  var fromList    = document.getElementById('bk-from-list');
  var untilTrigger = document.getElementById('bk-until-trigger');
  var untilLabel   = document.getElementById('bk-until-label');
  var untilList    = document.getElementById('bk-until-list');

  function buildUntilOptions() {
    untilList.innerHTML = '';
    untilValue = '';
    var idx = -1;
    for (var x = 0; x < allUnbooked.length; x++) {
      if (allUnbooked[x].time === fromValue) { idx = x; break; }
    }
    if (idx < 0) { untilLabel.textContent = '—'; return; }
    var prevEnd = AppService.slotEndTime(allUnbooked[idx].time);
    var opts = [{ val: allUnbooked[idx].time, label: prevEnd }];
    for (var jj = idx + 1; jj < allUnbooked.length; jj++) {
      if (allUnbooked[jj].time === prevEnd) {
        prevEnd = AppService.slotEndTime(allUnbooked[jj].time);
        opts.push({ val: allUnbooked[jj].time, label: prevEnd });
      } else { break; }
    }
    untilValue = opts[0].val;
    untilLabel.textContent = opts[0].label;
    for (var oi = 0; oi < opts.length; oi++) {
      (function(o, first) {
        var li = document.createElement('li');
        li.className = 'custom-dropdown-item' + (first ? ' is-active' : '');
        li.setAttribute('role', 'option');
        li.textContent = o.label;
        li.addEventListener('click', function(e) {
          e.stopPropagation();
          untilValue = o.val;
          untilLabel.textContent = o.label;
          untilList.querySelectorAll('.custom-dropdown-item').forEach(function(el) { el.classList.remove('is-active'); });
          li.classList.add('is-active');
          untilList.classList.remove('is-open');
          untilTrigger.classList.remove('is-open');
        });
        untilList.appendChild(li);
      })(opts[oi], oi === 0);
    }
  }

  /* Build From options */
  fromLabel.textContent = fromValue;
  for (var f = 0; f < allUnbooked.length; f++) {
    (function(slot) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (slot.time === fromValue ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.textContent = slot.time;
      li.addEventListener('click', function(e) {
        e.stopPropagation();
        fromValue = slot.time;
        fromLabel.textContent = slot.time;
        fromList.querySelectorAll('.custom-dropdown-item').forEach(function(el) { el.classList.remove('is-active'); });
        li.classList.add('is-active');
        fromList.classList.remove('is-open');
        fromTrigger.classList.remove('is-open');
        buildUntilOptions();
      });
      fromList.appendChild(li);
    })(allUnbooked[f]);
  }

  buildUntilOptions();

  /* Toggle handlers */
  fromTrigger.addEventListener('click', function(e) {
    e.stopPropagation();
    var open = fromList.classList.contains('is-open');
    fromList.classList.toggle('is-open', !open);
    fromTrigger.classList.toggle('is-open', !open);
  });
  untilTrigger.addEventListener('click', function(e) {
    e.stopPropagation();
    var open = untilList.classList.contains('is-open');
    untilList.classList.toggle('is-open', !open);
    untilTrigger.classList.toggle('is-open', !open);
  });

  document.getElementById('modal-cancel').addEventListener('click', function() {
    openBookFormSlotId = null;
    renderDayPanel();
    result.close();
  });

  document.getElementById('modal-confirm').addEventListener('click', function() {
    var checkedBoxes = document.querySelectorAll('.bk-modal-stu-cb:checked');
    var selectedUids = [];
    for (var k = 0; k < checkedBoxes.length; k++) { selectedUids.push(checkedBoxes[k].value); }
    if (!selectedUids.length) { Toast.error('Bitte mindestens einen Schüler auswählen.'); return; }
    var fromSlot = allSlots.filter(function(s) { return s.time === fromValue; })[0] || startSlot;
    openBookFormSlotId = null;
    result.close();
    executeBooking(fromSlot, untilValue, selectedUids, dateStr, allSlots);
  });

  return null;
}

function executeBooking(startSlot, untilTime, studentUids, dateStr, allSlots) {
  // Get all slots from start up to and including untilTime
  // Use effective state (pending overrides) for conflict detection
  var range = allSlots.filter(function(s) {
    return s.time >= startSlot.time && s.time <= untilTime;
  }).map(function(s) { return getEffectiveTeacherSlot(s); });

  // Check for conflicts (already booked by someone else)
  var conflicts = range.filter(function(s) {
    return s.studentId && studentUids.indexOf(s.studentId) === -1;
  });

  if (conflicts.length) {
    var conflictNames = conflicts.map(function(s) {
      var stu = AppService.getUserSync(s.studentId);
      return s.time + ' (booked by ' + ProfileStore.getDisplayName(s.studentId) + ')';
    }).join(', ');

    var result = Modal.show({
      title: 'Booking conflict',
      bodyHTML: '<p>The following slots are already booked:</p><p><strong>' + conflictNames + '</strong></p><p>Overwrite these bookings?</p>',
      footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Cancel</button><button class="btn btn-danger" id="modal-confirm">Overwrite</button>'
    });
    document.getElementById('modal-cancel').addEventListener('click', result.close);
    document.getElementById('modal-confirm').addEventListener('click', function() {
      commitBooking(range, studentUids);
      result.close();
    });
  } else {
    commitBooking(range, studentUids);
  }
}

function commitBooking(slots, studentUids) {
  for (var i = 0; i < slots.length; i++) {
    var slot = slots[i];
    var original = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === slot.slotId; })[0];
    pendingBookings[slot.slotId] = {
      action:       'book',
      originalSlot: original,
      newStudentId: studentUids[0],
      extraStudents: studentUids.slice(1)
    };
  }
  openBookFormSlotId = null;
  updateBookingSaveBtn();
  Toast.info('Booking staged — press Save to confirm.');
  renderDayPanel();
  renderCalendar();
  renderStudentList();
}

function updateBookingSaveBtn() {
  var group = document.getElementById('booking-fab-group');
  if (!group) return;
  var count = Object.keys(pendingBookings).length;
  group.classList.toggle('is-visible', count > 0);
  var badge = group.querySelector('.save-badge');
  if (badge) badge.textContent = count;
}

function discardBookingChanges() {
  pendingBookings = {};
  openBookFormSlotId = null;
  updateBookingSaveBtn();
  renderDayPanel();
  Toast.info('Changes dismissed.');
}

function saveBookingChanges() {
  var ids = Object.keys(pendingBookings);
  var savedChanges = {};
  for (var i = 0; i < ids.length; i++) {
    var p = pendingBookings[ids[i]];
    savedChanges[ids[i]] = p;
    if (p.action === 'book') {
      AppService.bookSlot(ids[i], p.newStudentId, function(e){if(e)Toast.error(e.message||e);});
      // Extra students — create new slots
      if (p.extraStudents && p.extraStudents.length) {
        var orig = p.originalSlot;
        for (var j = 0; j < p.extraStudents.length; j++) {
          AppService.createSlot({
            teacherId:  orig.teacherId,
            studentId:  p.extraStudents[j],
            date:       orig.date,
            time:       orig.time,
            status:     'booked',
            baseStatus: 'available'
          }, function(e){if(e)Toast.error(e.message||e);});
        }
      }
    } else {
      AppService.cancelSlotBooking(ids[i], function(e){if(e)Toast.error(e.message||e);});
    }
  }
  var emailIds = Object.keys(savedChanges || {});
  for (var ei = 0; ei < emailIds.length; ei++) {
    var ep    = savedChanges[emailIds[ei]];
    var es    = ep.originalSlot;
    var stu   = AppService.getUserSync(ep.action === 'book' ? ep.newStudentId : es.studentId);
    if (!stu) continue;
    var dateObj   = new Date(es.date + 'T00:00:00');
    var dateLabel = dateObj.toLocaleDateString('de-DE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    var endTime   = AppService.slotEndTime(es.time);
    if (ep.action === 'book') {
      EmailService.onBookingCreated(stu.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(currentUser.uid),
        studentName: ProfileStore.getDisplayName(stu.uid)
      });
    } else {
      EmailService.onBookingCancelled(stu.uid, {
        actorName:   ProfileStore.getDisplayName(currentUser.uid),
        date:        dateLabel,
        time:        es.time,
        endTime:     endTime,
        teacherName: ProfileStore.getDisplayName(currentUser.uid),
        studentName: ProfileStore.getDisplayName(stu.uid)
      });
    }
  }
  pendingBookings = {};
  updateBookingSaveBtn();
  renderDayPanel();
  renderCalendar();
  renderStudentList();
  renderAllBookingsList();
  Toast.success('Bookings saved.');
}

function deleteSlot(slotId) {
  AppService.deleteSlot(slotId, function(e){if(e)Toast.error(e.message||e);});
  Toast.success('Slot removed.');
  renderDayPanel();
  renderCalendar();
}

/* ══════════════════════════════════════════════════════════
   SLOT GRID OVERLAY
══════════════════════════════════════════════════════════ */
function openSlotGrid() {
  if (!selectedDate) return;

  var monday = new Date(selectedDate);
  var dow = monday.getDay();
  dow = (dow === 0) ? 6 : dow - 1;
  monday.setDate(monday.getDate() - dow);
  gridWeekStart = monday;
  gridPending   = {};

  // Materialise recurring for this week
  AppService.materialiseWeek(currentUser.uid, getWeekDates());

  document.getElementById('slot-grid-overlay').classList.add('is-open');
  document.body.classList.add('overlay-open');

  setGridMode('available');
  renderGridTable();
}

function closeSlotGrid() {
  document.getElementById('slot-grid-overlay').classList.remove('is-open');
  document.body.classList.remove('overlay-open');
  gridPending = {};
  renderCalendar();
  renderDayPanel();
}

function saveSlotGrid() {
  flushGridPending();
  Toast.success('Slots saved.');
  renderCalendar();
  renderDayPanel();
  // Re-render grid to reflect saved state
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridPrevWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() - 7);
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function gridNextWeek() {
  flushGridPending();
  gridWeekStart.setDate(gridWeekStart.getDate() + 7);
  AppService.materialiseWeek(currentUser.uid, getWeekDates());
  renderGridTable();
}

function setGridMode(mode) {
  gridMode = mode;
  var btnAvail   = document.getElementById('mode-btn-available');
  var btnTimeout = document.getElementById('mode-btn-timeout');
  btnAvail.className   = 'grid-mode-btn' + (mode === 'available' ? ' active-available' : '');
  btnTimeout.className = 'grid-mode-btn' + (mode === 'timeout'   ? ' active-timeout'   : '');
}

/* ── Grid table render ────────────────────────────────────── */
function renderGridTable() {
  var weekDates = getWeekDates();
  var times     = Store.slotTimesInRange(GRID_START, GRID_END);

  // Update week label
  document.getElementById('grid-week-label').textContent = weekRangeLabel(weekDates);

  var container = document.getElementById('slot-grid-content');
  container.innerHTML = '';

  var table = document.createElement('table');
  table.className = 'slot-grid-table';

  // ── thead ──
  var thead = document.createElement('thead');
  var hrow  = document.createElement('tr');

  var thTime = document.createElement('th');
  thTime.className = 'grid-th-time';
  thTime.textContent = 'Time';
  hrow.appendChild(thTime);

  for (var d = 0; d < weekDates.length; d++) {
    var wd      = weekDates[d];
    var isToday = wd.getTime() === TODAY.getTime();
    var isSel   = selectedDate && wd.getTime() === selectedDate.getTime();

    var th = document.createElement('th');
    th.className = 'grid-th-day';
    if (isToday) th.classList.add('grid-th-today');
    if (isSel)   th.classList.add('grid-th-selected');

    var nameSpan = document.createElement('span');
    nameSpan.className = 'grid-day-name';
    nameSpan.textContent = DAY_NAMES[d];

    var numSpan = document.createElement('span');
    numSpan.className = 'grid-day-num';
    if (isToday) numSpan.classList.add('grid-day-today');
    numSpan.textContent = wd.getDate();

    th.appendChild(nameSpan);
    th.appendChild(numSpan);
    hrow.appendChild(th);
  }
  thead.appendChild(hrow);
  table.appendChild(thead);

  // ── tbody ──
  var tbody = document.createElement('tbody');

  for (var t = 0; t < times.length; t++) {
    var time = times[t];
    var tr   = document.createElement('tr');

    var tdTime = document.createElement('td');
    tdTime.className = 'grid-td-time';
    tdTime.textContent = time;
    tr.appendChild(tdTime);

    for (var dd = 0; dd < weekDates.length; dd++) {
      var cellDate    = weekDates[dd];
      var cellDateStr = fmtDate(cellDate);
      var dayOfWeek   = dd; // 0=Mon
      var slot        = AppService.slotExistsSync(currentUser.uid, cellDateStr, time);
      var recurring   = AppService.recurringExistsSync(currentUser.uid, dayOfWeek, time);

      // Determine display status
      var status = slot ? slot.status : (recurring ? 'recurring' : 'none');
      var pendingKey = cellDateStr + '|' + time;
      if (gridPending[pendingKey] !== undefined) {
        status = gridPending[pendingKey];
      }

      var td   = document.createElement('td');
      td.className = 'grid-td-cell';

      var cell = document.createElement('div');
      cell.className = 'grid-cell';
      cell.dataset.date      = cellDateStr;
      cell.dataset.time      = time;
      cell.dataset.dayofweek = String(dayOfWeek);
      cell.dataset.booked    = (status === 'booked') ? '1' : '0';

      if (status === 'available' || status === 'recurring') {
        if (slot && slot.releasedAt) {
          cell.classList.add('gc-released');
        } else {
          cell.classList.add('gc-available');
        }
      }
      else if (status === 'booked')    cell.classList.add('gc-booked');
      else if (status === 'timeout')   cell.classList.add('gc-timeout');
      else                             cell.classList.add('gc-empty');

      if (status !== 'booked') {
        cell.addEventListener('click', onGridCellClick);
      }

      td.appendChild(cell);
      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  }

  table.appendChild(tbody);
  container.appendChild(table);
}

function onGridCellClick(e) {
  var cell       = e.currentTarget;
  var date       = cell.dataset.date;
  var time       = cell.dataset.time;
  var dayOfWeek  = parseInt(cell.dataset.dayofweek, 10);
  var key        = date + '|' + time;

  var isAvailable = cell.classList.contains('gc-available') || cell.classList.contains('gc-recurring');
  var isTimeout   = cell.classList.contains('gc-timeout');
  var isEmpty     = cell.classList.contains('gc-empty');

  if (gridMode === 'available') {
    if (isAvailable) {
      // Toggle off — available (=recurring) → disabled, remove recurring rule
      gridPending[key] = 'disabled';
      cell.className = 'grid-cell gc-empty';
    } else if (isTimeout || isEmpty) {
      // Toggle on — always creates recurring rule
      gridPending[key] = 'available';
      cell.className = 'grid-cell gc-available';
    }
  } else if (gridMode === 'timeout') {
    if (isAvailable || cell.classList.contains('gc-recurring')) {
      // Check if booked
      var existingSlot = AppService.slotExistsSync(currentUser.uid, date, time);
      if (existingSlot && existingSlot.studentId) {
        // Warning: slot is booked
        var student = AppService.getUserSync(existingSlot.studentId);
        var sName   = ProfileStore.getDisplayName(existingSlot.studentId);
        var result  = Modal.show({
          title: 'Slot is booked',
          bodyHTML: '<p>This slot is booked by <strong>' + sName + '</strong>. Setting timeout will cancel their lesson.</p>',
          footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Keep booking</button><button class="btn btn-danger" id="modal-confirm">Cancel lesson & set timeout</button>'
        });
        document.getElementById('modal-cancel').addEventListener('click', result.close);
        (function(k, c, sid) {
          document.getElementById('modal-confirm').addEventListener('click', function() {
            AppService.cancelSlotBooking(sid, function(e){if(e)Toast.error(e.message||e);});
            AppService.setSlotAvailability(sid, 'timeout', function(e){if(e)Toast.error(e.message||e);});
            gridPending[k] = 'timeout';
            c.className = 'grid-cell gc-timeout';
            renderCalendar();
            renderStudentList();
            result.close();
          });
        })(key, cell, existingSlot.slotId);
      } else {
        gridPending[key] = 'timeout';
        cell.className = 'grid-cell gc-timeout';
      }
    } else if (isTimeout) {
      // Remove timeout — restore to available/recurring
      var rec2 = AppService.recurringExistsSync(currentUser.uid, dayOfWeek, time);
      gridPending[key] = rec2 ? 'available' : 'available-no-recurring';
      cell.className = 'grid-cell gc-' + (rec2 ? 'recurring' : 'available');
    }
  }
}

function flushGridPending() {
  var keys = Object.keys(gridPending);
  for (var i = 0; i < keys.length; i++) {
    var key    = keys[i];
    var parts  = key.split('|');
    var date   = parts[0];
    var time   = parts[1];
    var action = gridPending[key];

    // Get dayOfWeek from date string
    var d = new Date(date + 'T00:00:00');
    var dow = d.getDay();
    dow = (dow === 0) ? 6 : dow - 1;

    var existing = AppService.slotExistsSync(currentUser.uid, date, time);

    if (action === 'available-new-recurring' || action === 'available' || action === 'available-no-recurring') {
      // available always means recurring
      AppService.createRecurring(currentUser.uid, dow, time, function(e){if(e)Toast.error(e.message||e);});
      if (existing) AppService.setSlotAvailability(existing.slotId, 'available', function(e){if(e)Toast.error(e.message||e);});
      else AppService.createSlot({ teacherId: currentUser.uid, date: date, time: time, status: 'available', baseStatus: 'available' }, function(e){if(e)Toast.error(e.message||e);});

    } else if (action === 'timeout') {
      // timeout = one-time unavailable, recurring rule stays
      if (existing) AppService.setSlotAvailability(existing.slotId, 'timeout', function(e){if(e)Toast.error(e.message||e);});
      else AppService.createSlot({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout', baseStatus: 'timeout' }, function(e){if(e)Toast.error(e.message||e);});

    } else if (action === 'disabled') {
      // disabled = permanently off, remove recurring rule
      AppService.deleteRecurringByDayTime(currentUser.uid, dow, time, function(e){if(e)Toast.error(e.message||e);});
      if (existing && !existing.studentId) AppService.deleteSlot(existing.slotId, function(e){if(e)Toast.error(e.message||e);});

    } else if (action === 'timeout-disabled') {
      // Keep recurring rule, but mark this specific week's slot as timeout
      if (existing) AppService.setSlotAvailability(existing.slotId, 'timeout', function(e){if(e)Toast.error(e.message||e);});
      else AppService.createSlot({ teacherId: currentUser.uid, date: date, time: time, status: 'timeout' }, function(e){if(e)Toast.error(e.message||e);});
    }
  }
  gridPending = {};
}

/* ── Helpers ──────────────────────────────────────────────── */
/* ══════════════════════════════════════════════════════════
   ALL BOOKINGS VIEW
══════════════════════════════════════════════════════════ */

function updateBookingSortBtn() {
  var sortBtn = document.getElementById('bookings-sort-btn');
  if (!sortBtn) return;
  sortBtn.setAttribute('aria-label', allBookingsSortAsc ? 'Älteste zuerst — umkehren' : 'Neueste zuerst — umkehren');
  sortBtn.querySelector('.sort-icon-asc').classList.toggle('is-hidden', !allBookingsSortAsc);
  sortBtn.querySelector('.sort-icon-desc').classList.toggle('is-hidden', allBookingsSortAsc);
}

function renderAllBookings() {
  var selections = AppService.getSelectionsByTeacherSync(currentUser.uid);
  var students   = selections.map(function(s) { return AppService.getUserSync(s.studentId); }).filter(Boolean);

  /* ── Build custom dropdown options ── */
  var list    = document.getElementById('bookings-student-list');
  var label   = document.getElementById('bookings-student-label');
  var trigger = document.getElementById('bookings-student-trigger');
  if (!list || !label || !trigger) return;

  var options = [{ value: 'all', text: 'Alle Schüler' }];
  for (var i = 0; i < students.length; i++) {
    options.push({ value: students[i].uid, text: ProfileStore.getDisplayName(students[i].uid) });
  }

  function setFilter(val) {
    _setFilter('student', val);
    var selected = options.filter(function(o) { return o.value === val; })[0] || options[0];
    label.textContent = selected.text;
    /* Update active state */
    var items = list.querySelectorAll('.custom-dropdown-item');
    for (var j = 0; j < items.length; j++) {
      items[j].classList.toggle('is-active', items[j].getAttribute('data-value') === val);
      items[j].setAttribute('aria-selected', items[j].getAttribute('data-value') === val ? 'true' : 'false');
    }
    closeDropdown();
    renderAllBookingsList();
  }

  function openDropdown() {
    list.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
    trigger.classList.add('is-open');
  }

  function closeDropdown() {
    list.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.classList.remove('is-open');
  }

  /* Rebuild list items */
  list.innerHTML = '';
  for (var k = 0; k < options.length; k++) {
    (function(opt) {
      var li = document.createElement('li');
      li.className = 'custom-dropdown-item' + (opt.value === bookingsFilter.student ? ' is-active' : '');
      li.setAttribute('role', 'option');
      li.setAttribute('data-value', opt.value);
      li.setAttribute('aria-selected', opt.value === bookingsFilter.student ? 'true' : 'false');
      li.textContent = opt.text;
      li.addEventListener('click', function() { setFilter(opt.value); });
      list.appendChild(li);
    })(options[k]);
  }

  /* Sync label to current filter */
  var cur = options.filter(function(o) { return o.value === bookingsFilter.student; })[0] || options[0];
  label.textContent = cur.text;

  /* Toggle open/close */
  trigger.onclick = function(e) {
    e.stopPropagation();
    if (list.classList.contains('is-open')) { closeDropdown(); } else { openDropdown(); }
  };

  /* Close on outside click — rebind each time to avoid stale refs */
  document.removeEventListener('click', _closeBookingDropdown);
  _closeBookingDropdown = function() { closeDropdown(); };
  document.addEventListener('click', _closeBookingDropdown);

  // Time filter buttons — scoped to all-bookings view
  var timeBtns = document.querySelectorAll('#view-all-bookings .booking-time-btn');
  for (var t = 0; t < timeBtns.length; t++) {
    timeBtns[t].classList.toggle('active', timeBtns[t].id === 'filter-' + bookingsFilter.time);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('time', btn.id.replace('filter-', ''));
        // Smart default: past → newest-first (desc), upcoming/all → oldest-first (asc)
        allBookingsSortAsc = (bookingsFilter.time !== 'past');
        for (var j = 0; j < timeBtns.length; j++) timeBtns[j].classList.remove('active');
        btn.classList.add('active');
        updateBookingSortBtn();
        renderAllBookingsList();
        if (activeTeacherView === 'students') renderStudentList();
        renderDayPanel();
      };
    })(timeBtns[t]);
  }

  // Sort + date-range row — rebuilt each render so state stays fresh
  var sortDateContainer = document.getElementById('all-bookings-sort-date-row');
  if (sortDateContainer) {
    sortDateContainer.innerHTML = '';
    sortDateContainer.appendChild(_buildSortDateRangeRow(function() {
      renderAllBookingsList();
      if (activeTeacherView === 'students') renderStudentList();
      renderDayPanel();
    }));
  }

  // Confirm filter tabs — scoped to all-bookings view
  var confirmBtns = document.querySelectorAll('#view-all-bookings .booking-confirm-btn');
  for (var ci = 0; ci < confirmBtns.length; ci++) {
    confirmBtns[ci].classList.toggle('active', confirmBtns[ci].dataset.confirm === bookingsFilter.confirmed);
    (function(btn) {
      btn.onclick = function() {
        _setFilter('confirmed', btn.dataset.confirm);
        for (var cj = 0; cj < confirmBtns.length; cj++) confirmBtns[cj].classList.remove('active');
        btn.classList.add('active');
        renderAllBookingsList();
        if (activeTeacherView === 'students') renderStudentList();
        renderDayPanel();
      };
    })(confirmBtns[ci]);
  }
  _updateAllBookingsBadges();

  renderAllBookingsList();
}

/* Berechnet Blockzahlen (merged) für alle drei Confirm-Filter.
 * Wird von All Bookings und Day Panel gleichermaßen verwendet. */
function _calcBlockCounts(slots, today) {
  var byDate = {};
  for (var i = 0; i < slots.length; i++) {
    var d = slots[i].date;
    if (!byDate[d]) byDate[d] = [];
    byDate[d].push(slots[i]);
  }
  function countBlocks(filterFn) {
    var total = 0;
    var dates = Object.keys(byDate);
    for (var di = 0; di < dates.length; di++) {
      var filtered = byDate[dates[di]].filter(filterFn);
      total += mergeAllBookingBlocks(dates[di], filtered, today).length;
    }
    return total;
  }
  return {
    all:         countBlocks(function() { return true; }),
    unconfirmed: countBlocks(function(s) { return !s.confirmedAt; }),
    confirmed:   countBlocks(function(s) { return !!s.confirmedAt; })
  };
}

function _updateAllBookingsBadges() {
  var today = fmtDate(new Date());

  /* Dieselbe Filter-Pipeline wie renderAllBookingsList */
  var slots = AppService.getSlotsByTeacherSync(currentUser.uid)
    .filter(function(s) { return s.status === 'booked' && s.studentId; });

  if (bookingsFilter.student !== 'all') {
    slots = slots.filter(function(s) { return s.studentId === bookingsFilter.student; });
  }
  slots = _applyTimeFilter(slots, bookingsFilter.time, today);
  slots = _applyDateRangeFilter(slots);

  /* Zählung direkt aus mergeAllBookingBlocks — exakt wie die Anzeige */
  var counts = _calcBlockCounts(slots, today);

  function _setBadge(id, count) {
    var container = document.getElementById('view-all-bookings');
    var el = container ? container.querySelector('#' + id) : document.getElementById(id);
    if (!el) return;
    el.textContent = count;
    el.classList.remove('is-hidden');
  }
  _setBadge('all-count-badge',         counts.all);
  _setBadge('unconfirmed-count-badge', counts.unconfirmed);
  _setBadge('confirmed-count-badge',   counts.confirmed);

  /* Time-tab counts — commented out, badges hidden in HTML
  var allStudentSlots = AppService.getSlotsByTeacherSync(currentUser.uid)
    .filter(function(s) { return s.status === 'booked' && s.studentId; });
  if (bookingsFilter.student !== 'all') {
    allStudentSlots = allStudentSlots.filter(function(s) { return s.studentId === bookingsFilter.student; });
  }
  allStudentSlots = _applyDateRangeFilter(allStudentSlots);
  var timeCounts = {
    past:     _calcBlockCounts(_applyTimeFilter(allStudentSlots, 'past',     today), today).all,
    upcoming: _calcBlockCounts(_applyTimeFilter(allStudentSlots, 'upcoming', today), today).all,
    all:      _calcBlockCounts(allStudentSlots, today).all
  };
  _setBadge('time-past-count',     timeCounts.past);
  _setBadge('time-upcoming-count', timeCounts.upcoming);
  _setBadge('time-all-count',      timeCounts.all);
  */
}

function renderAllBookingsList() {
  var container = document.getElementById('all-bookings-list');
  container.innerHTML = '';

  var today = fmtDate(new Date()); /* FIX: defined here, passed to sub-functions via block.today */

  var allSlots = AppService.getSlotsByTeacherSync(currentUser.uid)
    .filter(function(s) {
      return s.status === 'booked' && s.studentId;
    })
    .map(function(s) {
      var p = pendingBookings[s.slotId];
      if (p && p.action === 'cancel') {
        var copy = {}; for (var k in s) copy[k] = s[k];
        copy._pending = 'cancel';
        return copy;
      }
      return s;
    });

  // Filter by student
  if (bookingsFilter.student !== 'all') {
    allSlots = allSlots.filter(function(s) { return s.studentId === bookingsFilter.student; });
  }

  allSlots = _applyTimeFilter(allSlots, bookingsFilter.time, today);
  allSlots = _applyDateRangeFilter(allSlots);
  allSlots = _applyConfirmFilter(allSlots, bookingsFilter.confirmed);

  var emptyReasons = {
    past: 'Keine vergangenen Buchungen.',
    upcoming: 'Keine kommenden Buchungen.',
    all: 'Keine Buchungen gefunden.'
  };
  if (!allSlots.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.textContent = emptyReasons[bookingsFilter.time] || 'Keine Buchungen gefunden.';
    container.appendChild(empty);
    return;
  }

  // Always sort ascending for correct merging — direction only affects display order
  allSlots.sort(function(a, b) {
    return a.date.localeCompare(b.date) || a.time.localeCompare(b.time);
  });

  // Group by date
  var byDate = {};
  var dateOrder = [];
  for (var i = 0; i < allSlots.length; i++) {
    var s = allSlots[i];
    if (!byDate[s.date]) { byDate[s.date] = []; dateOrder.push(s.date); }
    byDate[s.date].push(s);
  }

  if (!allBookingsSortAsc) { dateOrder.reverse(); }

  for (var d = 0; d < dateOrder.length; d++) {
    var dateStr   = dateOrder[d];
    var dateSlots = byDate[dateStr];
    var isPast    = dateStr < today;

    var divider = document.createElement('div');
    divider.className = 'all-bookings-day-divider' + (isPast ? ' all-bookings-day-divider-past' : '');
    var dt = new Date(dateStr + 'T00:00:00');
    divider.textContent = dt.toLocaleDateString('de-DE', { weekday:'long', day:'numeric', month:'long', year:'numeric' });
    container.appendChild(divider);

    var blocks = mergeAllBookingBlocks(dateStr, dateSlots, today);
    for (var b = 0; b < blocks.length; b++) {
      container.appendChild(buildAllBookingBlock(blocks[b], { showDate: false, isPast: isPast }));
    }
  }
  _updateAllBookingsBadges();
  setTimeout(updateJumpBtns, 50);
}

/**
 * Merge consecutive booked slots of the same student into blocks.
 * Also include available slots between booked ones for display when expanded.
 */
function mergeAllBookingBlocks(dateStr, bookedSlots, today) {
  var blocks = [];

  /* Sort by studentId first, then time — so same-student slots are adjacent */
  var sorted = bookedSlots.slice().sort(function(a, b) {
    return (a.studentId || '').localeCompare(b.studentId || '') || a.time.localeCompare(b.time);
  });

  var i = 0;
  while (i < sorted.length) {
    var s       = sorted[i];
    var student = AppService.getUserSync(s.studentId);
    var end     = AppService.slotEndTime(s.time);
    var grp     = [s];
    var j       = i + 1;

    /* Merge consecutive OR overlapping slots of same student.
     * next.time <= end covers: exact continuation (==) and overlap/duplicate (<). */
    while (j < sorted.length) {
      var next = sorted[j];
      if (next.studentId === s.studentId && next.time <= end) {
        var nextEnd = AppService.slotEndTime(next.time);
        if (nextEnd > end) end = nextEnd;
        grp.push(next);
        j++;
      } else { break; }
    }

    var blockHasPending     = grp.some(function(x) { return !!x._pending; });
    var blockFullyConfirmed = grp.every(function(x) { return !!x.confirmedAt; });
    blocks.push({
      dateStr:          dateStr,
      today:            today,
      student:          student,
      start:            s.time,
      end:              end,
      bookedSlots:      grp,
      hasPending:       blockHasPending,
      isFullyConfirmed: blockFullyConfirmed
    });
    i = j;
  }

  /* Re-sort blocks by start time for display */
  blocks.sort(function(a, b) { return a.start.localeCompare(b.start); });

  return blocks;
}

function buildAllBookingBlock(block, options) {
  var showDate     = !options || options.showDate !== false;
  var isPast       = !!(options && options.isPast);
  var simpleDetail = !!(options && options.simpleDetail);
  var blockKey = block.dateStr + '-' + block.start + '-' + (block.student ? block.student.uid : 'x');
  var isOpen   = !!expandedAllBlocks[blockKey];
  var studentName = ProfileStore.getDisplayName(block.student ? block.student.uid : '?');

  var hasPending = !!block.hasPending;
  var isFullyConfirmed = !!block.isFullyConfirmed;
  var wrapper = document.createElement('div');
  wrapper.className = 'all-booking-block-wrapper';

  // Header
  var header = document.createElement('div');
  header.className = 'all-booking-block-header'
    + (isPast ? ' all-booking-block-past' : '')
    + (hasPending ? ' block-pending' : '');
  header.setAttribute('tabindex', '0');

  var timeEl = document.createElement('span');
  timeEl.className = 'all-booking-block-time';
  var dateObj = new Date(block.dateStr + 'T00:00:00');
  if (showDate) {
    var dateLabel = dateObj.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
    timeEl.textContent = dateLabel + '  ' + block.start + ' \u2013 ' + block.end;
  } else {
    timeEl.textContent = block.start + ' \u2013 ' + block.end;
  }

  var studentEl = document.createElement('span');
  studentEl.className = 'all-booking-block-student';
  studentEl.textContent = studentName;

  var chevron = document.createElement('span');
  chevron.className = 'all-booking-chevron' + (isOpen ? ' is-open' : '');
  chevron.innerHTML = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M2 4l4 4 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  header.appendChild(timeEl);
  header.appendChild(studentEl);

  // Confirmed badge OR confirm button
  if (isFullyConfirmed) {
    var confirmedBadge = document.createElement('span');
    confirmedBadge.className = 'badge badge-confirmed';
    confirmedBadge.textContent = '✓ Bestätigt';
    header.appendChild(confirmedBadge);

    // Release button — only for past confirmed blocks
    if (isPast) {
      var releaseBtn = document.createElement('button');
      releaseBtn.className = 'btn btn-ghost btn-sm all-booking-release-btn';
      releaseBtn.textContent = '↩ Freigeben';
      (function(b) {
        releaseBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          _openReleaseDialog(b);
        });
      })(block);
      header.appendChild(releaseBtn);
    }
  } else {
    var confirmAllBtn = document.createElement('button');
    confirmAllBtn.className = 'btn btn-ghost btn-sm all-booking-confirm-btn';
    confirmAllBtn.textContent = '✓ Bestätigen';
    (function(b) {
      confirmAllBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        _openConfirmDialog(b);
      });
    })(block);
    header.appendChild(confirmAllBtn);
  }

  /* Bearbeiten-Button (Move/Cancel/Recurring) — future, unconfirmed blocks only */
  if (!isPast && !isFullyConfirmed) {
    var moveAllBtn = document.createElement('button');
    moveAllBtn.className = 'btn btn-ghost btn-sm all-booking-move-all-btn';
    moveAllBtn.setAttribute('aria-label', 'Block bearbeiten');
    moveAllBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11.5 2.5a1.414 1.414 0 012 2L5 13H2v-3L11.5 2.5z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    (function(b) {
      moveAllBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        openMoveBlockDialog(b);
      });
    })(block);
    header.appendChild(moveAllBtn);
  }

  // Detail panel
  var detail = document.createElement('div');
  detail.className = 'all-booking-block-detail' + (isOpen ? ' is-open' : '');
  if (isOpen) {
    if (simpleDetail) populateSimpleBlockDetail(detail, block);
    else populateAllBookingDetail(detail, block);
  }

  function toggle() {
    if (expandedAllBlocks[blockKey]) {
      delete expandedAllBlocks[blockKey];
      chevron.classList.remove('is-open');
      detail.classList.remove('is-open');
      detail.innerHTML = '';
    } else {
      expandedAllBlocks[blockKey] = true;
      chevron.classList.add('is-open');
      detail.classList.add('is-open');
      if (simpleDetail) populateSimpleBlockDetail(detail, block);
      else populateAllBookingDetail(detail, block);
    }
  }
  header.addEventListener('click', toggle);
  header.addEventListener('keydown', function(e) { if (e.key === 'Enter' || e.key === ' ') toggle(); });

  wrapper.appendChild(header);
  wrapper.appendChild(detail);
  return wrapper;
}

function populateAllBookingDetail(detail, block) {
  detail.innerHTML = '';
  var stuId = block.student ? block.student.uid : null;
  var today = block.today || fmtDate(new Date()); /* FIX: today passed via block, fallback safe */

  var allDateSlots = AppService.getSlotsByTeacherDateSync(currentUser.uid, block.dateStr)
    .sort(function(a, b) { return a.time.localeCompare(b.time); });

  /* Deduplicate: each slotId appears at most once.
     pendingBookings check covers slots not yet written to store (action=book on free slot). */
  var seenSlotIds = {};
  var display = allDateSlots.filter(function(s) {
    if (seenSlotIds[s.slotId]) return false;
    var include = false;
    if (s.status === 'booked' && (stuId === null || s.studentId === stuId)) include = true;
    if ((s.status === 'available' || s.status === 'recurring') && !s.studentId) include = true;
    if (pendingBookings[s.slotId]) include = true;
    if (include) seenSlotIds[s.slotId] = true;
    return include;
  });

  if (!display.length) {
    var empty = document.createElement('p');
    empty.className = 'text-muted';
    empty.style.padding = 'var(--sp-3)';
    empty.textContent = 'No slots available on this day.';
    detail.appendChild(empty);
    return;
  }

  for (var i = 0; i < display.length; i++) {
    var origSlot   = display[i];
    var isPending  = !!pendingBookings[origSlot.slotId];
    var pendingObj = pendingBookings[origSlot.slotId];
    var isBooked   = (origSlot.status === 'booked' && origSlot.studentId === stuId)
                   || (isPending && pendingObj.action === 'book');

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row' + (isBooked ? '' : ' all-booking-slot-available') + (isPending ? ' slot-pending' : '');

    var timeEl = document.createElement('span');
    timeEl.className = 'all-booking-slot-time';
    timeEl.textContent = origSlot.time + ' – ' + AppService.slotEndTime(origSlot.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'all-booking-slot-status';
    statusEl.textContent = isBooked ? 'Gebucht' : 'Frei';

    var btnGroup = document.createElement('div');
    btnGroup.className = 'all-booking-slot-btns';

    if (isBooked) {
      var isSlotPast = origSlot.date < today;
      var isConfirmed = !!origSlot.confirmedAt;

      if (isConfirmed) {
        var cBadge = document.createElement('span');
        cBadge.className = 'badge badge-confirmed';
        cBadge.textContent = '✓ Bestätigt';
        btnGroup.appendChild(cBadge);
        /* confirmed: no cancel, no move */
      } else {
        var confirmBtn = document.createElement('button');
        confirmBtn.className = 'btn btn-ghost btn-sm';
        confirmBtn.textContent = '✓';
        confirmBtn.title = 'Bestätigen';
        (function(s) {
          confirmBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            _openConfirmDialogSingle(s.slotId);
          });
        })(origSlot);
        btnGroup.appendChild(confirmBtn);

        if (!isSlotPast) {
          var cancelBtn = document.createElement('button');
          cancelBtn.className = (isPending && pendingObj.action === 'cancel') ? 'btn btn-ghost btn-sm' : 'btn btn-danger btn-sm';
          cancelBtn.textContent = (isPending && pendingObj.action === 'cancel') ? 'Undo' : 'Cancel';
          (function(s) {
            cancelBtn.addEventListener('click', function(e) {
              e.stopPropagation();
              if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'cancel') {
                delete pendingBookings[s.slotId];
              } else if (pendingBookings[s.slotId] && pendingBookings[s.slotId].action === 'book') {
                delete pendingBookings[s.slotId];
              } else {
                var original = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0];
                pendingBookings[s.slotId] = { action: 'cancel', originalSlot: original, newStudentId: null };
              }
              updateBookingSaveBtn();
              renderStudentList();
              renderAllBookingsList();
            });
          })(origSlot);
          btnGroup.appendChild(cancelBtn);
        }
      }

    } else {
      /* Free slot — only show + Add if block is NOT fully confirmed */
      var blockIsConfirmed = !!(block && block.isFullyConfirmed);
      if (!blockIsConfirmed) {
        var addBtn = document.createElement('button');
        addBtn.className = isPending ? 'btn btn-ghost btn-sm' : 'btn btn-primary btn-sm';
        addBtn.textContent = isPending ? 'Undo' : '+ Add';
      (function(s, b) {
        addBtn.addEventListener('click', function(e) {
          e.stopPropagation();
          if (pendingBookings[s.slotId]) {
            delete pendingBookings[s.slotId];
          } else {
            var original = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0];
            pendingBookings[s.slotId] = { action: 'book', originalSlot: original, newStudentId: stuId, extraStudents: [] };
          }
          updateBookingSaveBtn();
          renderStudentList();
          renderAllBookingsList();
          renderDayPanel();
        });
      })(origSlot, block);
      btnGroup.appendChild(addBtn);
      } /* end if !blockIsConfirmed */

    } /* end else (free slot) */

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    row.appendChild(btnGroup);
    detail.appendChild(row);
  }
}

/* ── Simple detail — only the block's own booked slots, no day-lookup ── */
function populateSimpleBlockDetail(detail, block) {
  detail.innerHTML = '';
  var slots = block.bookedSlots;
  if (!slots || !slots.length) return;

  for (var i = 0; i < slots.length; i++) {
    var s    = slots[i];
    var orig = AppService.getAllSlotsSync().filter(function(x) { return x.slotId === s.slotId; })[0] || s;
    var isConfirmed = !!orig.confirmedAt;

    var row = document.createElement('div');
    row.className = 'all-booking-slot-row';

    var timeEl = document.createElement('span');
    timeEl.className = 'all-booking-slot-time';
    timeEl.textContent = orig.time + ' \u2013 ' + AppService.slotEndTime(orig.time);

    var statusEl = document.createElement('span');
    statusEl.className = 'all-booking-slot-status';
    statusEl.textContent = isConfirmed ? '\u2713 Bestätigt' : 'Gebucht';

    row.appendChild(timeEl);
    row.appendChild(statusEl);
    detail.appendChild(row);
  }
}

/* ── Bestätigungs-Dialog (Block-Level) ───────────────── */
function _openConfirmDialog(block) {
  var stuName = ProfileStore.getDisplayName(block.student ? block.student.uid : '?');
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">⚠ <strong>Achtung:</strong> Diese Aktion kann nicht rückgängig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Bestätigung der Stunde von <strong>' + stuName + '</strong> (' + block.start + ' – ' + block.end + '):</p>' +
      '<ul style="margin:0;padding-left:var(--sp-5);display:flex;flex-direction:column;gap:var(--sp-1);color:var(--neutral-700);font-size:var(--text-body)">' +
        '<li>kann die Stunde <strong>nicht mehr verschoben</strong> werden</li>' +
        '<li>kann die Stunde <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung für die Stunde freigegeben</strong></li>' +
      '</ul>' +
    '</div>';
  var result = Modal.show({
    title: 'Stunde bestätigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    for (var ci = 0; ci < block.bookedSlots.length; ci++) {
      AppService.confirmSlot(block.bookedSlots[ci].slotId, function(e){if(e)Toast.error(e.message||e);});
    }
    _updateAllBookingsBadges();
    renderAllBookingsList();
    renderDayPanel();   /* FIX: refresh day panel so badge + block state update immediately */
    result.close();
  });
}

/* ── Bestätigungs-Dialog (Slot-Level) ────────────────── */
function _openConfirmDialogSingle(slotId) {
  var slot = AppService.getAllSlotsSync().filter(function(s) { return s.slotId === slotId; })[0];
  if (!slot) return;
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="confirm-dialog-warning">⚠ <strong>Achtung:</strong> Diese Aktion kann nicht rückgängig gemacht werden.</p>' +
      '<p class="move-dialog-info">Mit der Bestätigung des Slots <strong>' + slot.time + ' – ' + AppService.slotEndTime(slot.time) + '</strong>:</p>' +
      '<ul style="margin:0;padding-left:var(--sp-5);display:flex;flex-direction:column;gap:var(--sp-1);color:var(--neutral-700);font-size:var(--text-body)">' +
        '<li>kann der Slot <strong>nicht mehr verschoben</strong> werden</li>' +
        '<li>kann der Slot <strong>nicht mehr storniert</strong> werden</li>' +
        '<li>wird die <strong>Zahlung für diesen Slot freigegeben</strong></li>' +
      '</ul>' +
    '</div>';
  var result = Modal.show({
    title: 'Slot bestätigen',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Jetzt bestätigen</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    AppService.confirmSlot(slotId, function(e){if(e)Toast.error(e.message||e);});
    _updateAllBookingsBadges();
    renderAllBookingsList();
    renderDayPanel();   /* FIX: refresh day panel so badge + block state update immediately */
    result.close();
  });
}

/* ── Freigabe-Dialog ─────────────────────────────────── */
function _openReleaseDialog(block) {
  var stuName = ProfileStore.getDisplayName(block.student ? block.student.uid : '?');
  var bodyHTML =
    '<div class="move-dialog">' +
      '<p class="move-dialog-info">Möchtest du die Zeitslots der Stunde von <strong>' + stuName + '</strong> (' + block.start + ' – ' + block.end + ') freigeben?</p>' +
      '<p class="move-dialog-info">Die Stunde wurde bestätigt und bezahlt. Die Slots werden wieder für andere Schüler verfügbar gemacht.</p>' +
      '<p class="move-dialog-info">Ein Hinweis bleibt im Kalender sichtbar.</p>' +
    '</div>';
  var result = Modal.show({
    title: 'Slot freigeben',
    bodyHTML: bodyHTML,
    footerHTML: '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button><button class="btn btn-primary" id="modal-confirm">Freigeben</button>'
  });
  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    for (var ri = 0; ri < block.bookedSlots.length; ri++) {
      AppService.releaseSlot(block.bookedSlots[ri].slotId, function(e){if(e)Toast.error(e.message||e);});
    }
    renderAllBookingsList();
    renderCalendarMonth();
    result.close();
  });
}

/* ── Move Dialog ─────────────────────────────────────── */
/* ── Move Block Dialog (alle Slots auf einmal) ───────── */
function openMoveBlockDialog(block) {
  openMoveBlockDialogShared({
    block:           block,
    teacherId:       currentUser.uid,
    pendingMap:      pendingBookings,
    stuId:           block.student ? block.student.uid : null,
    onConfirmBlock:  function() {
      _updateAllBookingsBadges();
      renderAllBookingsList();
      renderDayPanel();
    },
    onCancelBlock:   function() {
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderDayPanel();
    },
    onConfirm:  function() {
      updateBookingSaveBtn();
      renderStudentList();
      renderAllBookingsList();
      renderDayPanel();
    },
    onCalJump: function(dateStr, result) {
      if (!dateStr) return;
      var target = new Date(dateStr + 'T00:00:00');
      selectedDate = target;
      viewYear  = target.getFullYear();
      viewMonth = target.getMonth();
      activeDayTab = 'bookings';
      switchTeacherView('schedule');
      renderCalendar();
      renderDayPanel();
      result.close();
      setTimeout(function() {
        var panel = document.getElementById('section-daypanel');
        if (panel) {
          var offset = getStickyOffset();
          var top = panel.getBoundingClientRect().top + window.scrollY - offset;
          window.scrollTo({ top: top, behavior: 'smooth' });
        }
      }, 80);
    }
  });
}

function getWeekDates() {
  var dates = [];
  for (var d = 0; d < 7; d++) {
    var wd = new Date(gridWeekStart);
    wd.setDate(wd.getDate() + d);
    dates.push(wd);
  }
  return dates;
}

function weekRangeLabel(dates) {
  return dates[0].toLocaleDateString('en-GB', { day:'numeric', month:'short' })
    + ' – '
    + dates[6].toLocaleDateString('en-GB', { day:'numeric', month:'short', year:'numeric' });
}

function updateStats() {
  var allSlots = AppService.getSlotsByTeacherSync(currentUser.uid);
  var today    = fmtDate(new Date());

  /* stat-booked: all-time total — same guard as badges (requires studentId) */
  var booked = allSlots.filter(function(s) { return s.status === 'booked' && s.studentId; });
  var counts = _calcBlockCounts(booked, today);
  document.getElementById('stat-booked').textContent = counts.all;

  var availEl = document.getElementById('stat-available');
  if (availEl) availEl.textContent = allSlots.filter(function(s) { return s.status === 'available'; }).length;

  /* keep confirm-filter badges in sync from the same trigger */
  _updateAllBookingsBadges();
}

/* ── Section jump buttons ─────────────────────────────── */
function getSectionJumpTargets() {
  if (activeTeacherView === 'all-bookings') {
    var dividers = document.querySelectorAll('#view-all-bookings .all-bookings-day-divider');
    var pageTop  = document.querySelector('.page-header') || document.getElementById('view-all-bookings');
    if (dividers.length) return [pageTop].concat(Array.prototype.slice.call(dividers)).filter(Boolean);
    return [pageTop].filter(Boolean);
  }
  return [
    document.querySelector('.page-header'),
    document.getElementById('section-calendar'),
    document.getElementById('section-daypanel')
  ].filter(Boolean);
}

window.addEventListener('scroll', updateJumpBtns);
window.addEventListener('scroll', checkDayNavSticky);

window.addEventListener('resize', function() {
  _dayNavStickyActive = !_dayNavStickyActive;
  checkDayNavSticky();
});


function navDay(delta) { _navDayShared(delta, renderDayPanel); }
function navMonth(delta) { _navMonthShared(delta, renderDayPanel); }

function checkDayNavSticky() { checkDayNavStickyShared('section-daypanel'); }

/* ── Cross-tab sync via AppService.onChange ── */
AppService.onChange(function(e) {
  if (e.key === 'app_slots' || e.key === 'app_selections' || e.key === 'app_users') {
    updateStats();
    renderStudentList();
    renderCalendar();
    renderDayPanel();
    if (activeTeacherView === 'all-bookings') renderAllBookings();
  }
});

function updateJumpBtns() { _updateJumpBtnsShared(activeTeacherView === 'all-bookings' && getSectionJumpTargets().length > 1); }

function prevMonth() { _prevMonthShared(); }
function nextMonth() { _nextMonthShared(); }
