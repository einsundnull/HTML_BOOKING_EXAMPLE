/**
 * navbar.js — Universal Navbar
 *
 * Injiziert die Navbar in jede Seite.
 * Aufruf: Navbar.init(activePage) nach store.js und auth.js.
 *
 * Features:
 *  - Hamburger-Button → Dropdown-Menü mit Menüpunkten
 *  - Dropdown-Menü: Home, Profil ansehen, Profil bearbeiten (role-abhängig)
 *  - Welcome-Dialog für Teacher ohne ausgefülltes Profil
 *  - Aktive Seite wird hervorgehoben
 *
 * Regeln: var only, function(){}, string concat, no arrow functions,
 *         no ?. or ??, no template literals, no inline styles
 */

var Navbar = {

  /* Nav-Links pro Rolle — AUSKOMMENTIERT, werden später aktiviert
  _links: {
    admin:   [{ label: 'Users',    href: './admin.html',   page: 'admin'   }],
    teacher: [{ label: 'Kalender', href: './teacher.html', page: 'teacher' }],
    student: [{ label: 'Katalog',  href: './skiing-catalog.html', page: 'catalog' }]
  },
  */
  _links: { admin: [], teacher: [], student: [] },

  /* Hamburger-Menü Einträge pro Rolle */
  _menuItems: {
    admin: [
      { label: 'Home',   href: './index.html',  icon: 'home'   },
      { label: 'Wallet', href: './wallet.html', icon: 'wallet', uidParam: true }
    ],
    teacher: [
      { label: 'Home',              href: './index.html',        icon: 'home'      },
      { label: 'Dashboard',         href: './dashboard.html',    icon: 'dashboard', uidParam: true },
      { label: 'Kalender',          href: './teacher.html',      icon: 'calendar', uidParam: true },
      { label: 'Wallet',            href: './wallet.html',       icon: 'wallet',   uidParam: true },
      { label: 'Profil ansehen',    href: './profile-view.html', icon: 'eye',    uidParam: true, profileUid: true },
      { label: 'Profil bearbeiten', href: './profile-edit.html', icon: 'edit',    uidParam: true, ownerParam: true },
      { label: 'Finanzplaner',      href: './financial.html',    icon: 'finance',  uidParam: true }
    ],
    student: [
      { label: 'Home',              href: './index.html',          icon: 'home'    },
      { label: 'Dashboard',         href: './dashboard.html',      icon: 'dashboard', uidParam: true },
      { label: 'Katalog',           href: './skiing-catalog.html', icon: 'catalog', uidParam: true },
      { label: 'Kalender',          href: './student.html',        icon: 'calendar', uidParam: true },
      { label: 'Wallet',            href: './wallet.html',         icon: 'wallet',  uidParam: true },
      { label: 'Profil ansehen',    href: './profile-view.html',   icon: 'eye',     uidParam: true, profileUid: true },
      { label: 'Profil bearbeiten', href: './profile-edit.html',   icon: 'edit',    uidParam: true, ownerParam: true }
    ]
  },

  /* i18n Texte */
  _i18n: {
    welcomeTitle:    'Willkommen bei BookingSystem!',
    welcomeBody:     'Füll dein Profil aus, damit Schüler dich finden und buchen können.',
    welcomeBtn:      'Profil jetzt ausfüllen',
    welcomeSkip:     'Später',
    signOut:         'Abmelden'
  },

  /* Welcome-Dialog: localStorage-Key */
  _WELCOME_KEY: 'app_welcome_seen',

  /* ── init ──────────────────────────────────────────────── */
  /* options (optional): { loginBtn: { label, onClick } } */
  init: function(activePage, options) {
    var self = this;
    var user = Auth.current();

    self._user       = user;
    self._activePage = activePage;
    self._uid        = user ? encodeURIComponent(user.uid) : '';
    self._options    = options || {};

    self._build();
    self._bindHamburger();
    self._bindScrollBehavior();

    /* Welcome-Dialog nur für Teacher */
    if (user && user.role === 'teacher') {
      self._maybeShowWelcome();
    }
  },

  /* ── Build Navbar ──────────────────────────────────────── */
  _build: function() {
    var self = this;
    var user = self._user;

    var nav = document.createElement('nav');
    nav.className = 'navbar';
    nav.id        = 'main-navbar';

    /* Nav links (Hauptnavigation) */
    var linksHTML = '';
    if (user) {
      var roleLinks = self._links[user.role] || [];
      for (var i = 0; i < roleLinks.length; i++) {
        var l        = roleLinks[i];
        var href     = l.href + (self._uid ? '?uid=' + self._uid : '');
        var isActive = (self._activePage === l.page) ? ' active' : '';
        linksHTML   += '<a class="navbar-link' + isActive + '" href="' + href + '">' + l.label + '</a>';
      }
    }

    /* Optional login button (für Seiten ohne Auth, z.B. Landing) */
    var loginBtnHTML = '';
    if (!user && self._options && self._options.loginBtn) {
      var lbl = self._options.loginBtn.label || 'Anmelden';
      loginBtnHTML = '<button class="btn btn-secondary btn-sm" id="navbar-login-btn">' + lbl + '</button>';
    }

    nav.innerHTML =
      '<div class="navbar-inner">' +
        '<a class="navbar-brand" href="./index.html">' +
          '<svg width="18" height="18" viewBox="0 0 20 20" fill="none">' +
            '<rect x="1" y="1" width="18" height="18" rx="4" stroke="currentColor" stroke-width="1.5"/>' +
            '<path d="M6 10h8M10 6v8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
          '</svg>' +
          'BookingSystem' +
        '</a>' +
        '<div class="navbar-links">' + linksHTML + '</div>' +
        '<div class="navbar-right">' +
          (user ? '<a class="navbar-wallet-badge" id="navbar-wallet-badge" href="./wallet.html?uid=' + (self._uid || '') + '" aria-label="Wallet">' +
            '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" aria-hidden="true"><rect x="1" y="4" width="14" height="10" rx="1.5" stroke="currentColor" stroke-width="1.5"/><path d="M1 8h14" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="11" r="1" fill="currentColor"/></svg>' +
            '<span id="navbar-wallet-amount">…</span>' +
          '</a>' : '') +
          loginBtnHTML +
          '<div class="navbar-hamburger-wrap">' +
            '<button class="navbar-hamburger" id="navbar-hamburger" aria-label="Menü öffnen" aria-expanded="false" aria-haspopup="true">' +
              '<span class="navbar-hamburger-bar"></span>' +
              '<span class="navbar-hamburger-bar"></span>' +
              '<span class="navbar-hamburger-bar"></span>' +
            '</button>' +
          '</div>' +
        '</div>' +
      '</div>';

    document.body.insertBefore(nav, document.body.firstChild);

    /* ── Drawer overlay + panel — appended to body (not inside navbar) ── */
    var overlay = document.createElement('div');
    overlay.className = 'navbar-drawer-overlay';
    overlay.id        = 'navbar-drawer-overlay';
    document.body.appendChild(overlay);

    var drawer = document.createElement('div');
    drawer.className = 'navbar-dropdown';
    drawer.id        = 'navbar-dropdown';
    drawer.setAttribute('aria-hidden', 'true');
    drawer.innerHTML = self._buildDropdownItems();
    document.body.appendChild(drawer);
    /* Login-Button Callback binden */
    if (self._options && self._options.loginBtn && self._options.loginBtn.onClick) {
      var loginBtn = document.getElementById('navbar-login-btn');
      if (loginBtn) loginBtn.addEventListener('click', self._options.loginBtn.onClick);
    }
    /* Wallet-Badge befüllen — warte auf Currency-Cache */
    if (user && typeof AppService !== 'undefined') {
      function _fillNavBadge() {
        AppService.getWallet(user.uid, function(err, wallet) {
          var el = document.getElementById('navbar-wallet-amount');
          if (!el) return;
          el.textContent = err ? '—' : (typeof _fmtForUser !== 'undefined'
            ? _fmtForUser(parseFloat(wallet.balance), user.uid)
            : parseFloat(wallet.balance).toFixed(2).replace('.', ',') + ' €');
        });
      }
      if (typeof CurrencyService !== 'undefined' && typeof CurrencyService.onReady === 'function') {
        CurrencyService.onReady(_fillNavBadge);
      } else {
        _fillNavBadge();
      }
    }
  },
  _buildDropdownItems: function() {
    var self  = this;
    var user  = self._user;
    if (!user) return '';

    var items = self._menuItems[user.role] || [];
    var roleLabel = { admin: 'Admin', teacher: 'Lehrer', student: 'Schüler' };

    /* Avatar HTML */
    var avatarHTML = (typeof buildAvatarHTML !== 'undefined')
      ? buildAvatarHTML(user.uid, { size: 'md', role: user.role })
      : '<div class="avatar-initials avatar-md avatar-role-' + user.role + '">' +
          (ProfileStore.getDisplayName(user.uid) || '?').slice(0,2).toUpperCase() +
        '</div>';

    /* ── Header: close button + avatar + name + role ── */
    var html =
      '<div class="navbar-dropdown-header">' +
        '<button class="navbar-drawer-close" id="navbar-drawer-close" aria-label="Menü schließen">' +
          '<svg width="14" height="14" viewBox="0 0 16 16" fill="none">' +
            '<path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
          '</svg>' +
        '</button>' +
        '<div class="navbar-dropdown-avatar">' + avatarHTML + '</div>' +
        '<div class="navbar-dropdown-user">' +
          '<span class="navbar-dropdown-username" id="navbar-dropdown-username">' +
            ProfileStore.getDisplayName(user.uid) +
          '</span>' +
          '<span class="navbar-dropdown-role">' + (roleLabel[user.role] || user.role) + '</span>' +
        '</div>' +
      '</div>' +
      '<div class="navbar-dropdown-scroll">';

    for (var i = 0; i < items.length; i++) {
      var item = items[i];
      var href = item.href;

      if (item.uidParam && self._uid) {
        href = href + '?uid=' + self._uid;
      }
      if (item.profileUid && self._uid) {
        href = item.href + '?uid=' + self._uid + '&viewer=' + self._uid;
      }
      if (item.ownerParam && self._uid) {
        href = href + '&owner=' + self._uid;
      }

      html +=
        '<a class="navbar-dropdown-item" href="' + href + '">' +
          self._buildIcon(item.icon) +
          '<span>' + item.label + '</span>' +
        '</a>';
    }

    html += '</div>'; /* close scroll */

    /* Logout in footer */
    html +=
      '<div class="navbar-dropdown-footer">' +
        '<button class="navbar-dropdown-item navbar-dropdown-logout" id="navbar-dropdown-logout">' +
          self._buildIcon('logout') +
          '<span>' + self._i18n.signOut + '</span>' +
        '</button>' +
      '</div>';

    return html;
  },

  /* ── SVG Icons ─────────────────────────────────────────── */
  _buildIcon: function(name) {
    var icons = {
      home:     '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M2 6.5L8 2l6 4.5V14a1 1 0 01-1 1H3a1 1 0 01-1-1V6.5z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 15V9h4v6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      eye:      '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M1 8s3-5 7-5 7 5 7 5-3 5-7 5-7-5-7-5z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><circle cx="8" cy="8" r="2" stroke="currentColor" stroke-width="1.5"/></svg>',
      edit:     '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M11 2l3 3-9 9H2v-3L11 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      logout:   '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M10 2h3a1 1 0 011 1v10a1 1 0 01-1 1h-3M7 11l4-4-4-4M11 8H3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      calendar: '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="1" y="3" width="14" height="12" rx="1" stroke="currentColor" stroke-width="1.5"/><path d="M1 7h14M5 1v4M11 1v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
      catalog:  '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><circle cx="6" cy="6" r="4" stroke="currentColor" stroke-width="1.5"/><path d="M10 10l4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
      wallet:   '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="1" y="4" width="14" height="10" rx="1.5" stroke="currentColor" stroke-width="1.5"/><path d="M1 8h14" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="11" r="1" fill="currentColor"/></svg>',
      finance:  '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="1" y="4" width="14" height="10" rx="1.5" stroke="currentColor" stroke-width="1.5"/><path d="M5 8h2m2 0h2M5 11h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M5 1l3 3 3-3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      dashboard: '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.5"/><rect x="9" y="1" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.5"/><rect x="1" y="9" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.5"/><rect x="9" y="9" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.5"/></svg>'
    };
    return icons[name] || '';
  },

  /* ── Bind Hamburger ────────────────────────────────────── */
  _bindHamburger: function() {
    var hamburger = document.getElementById('navbar-hamburger');
    var dropdown  = document.getElementById('navbar-dropdown');
    var overlay   = document.getElementById('navbar-drawer-overlay');
    var closeBtn  = document.getElementById('navbar-drawer-close');
    var logoutDd  = document.getElementById('navbar-dropdown-logout');

    if (!hamburger || !dropdown) return;

    hamburger.addEventListener('click', function(e) {
      e.stopPropagation();
      if (dropdown.classList.contains('is-open')) {
        Navbar._closeDropdown();
      } else {
        Navbar._openDropdown();
      }
    });

    /* Close on overlay click */
    if (overlay) {
      overlay.addEventListener('click', function() { Navbar._closeDropdown(); });
    }

    /* Close button inside drawer */
    if (closeBtn) {
      closeBtn.addEventListener('click', function() { Navbar._closeDropdown(); });
    }

    /* Close with Escape */
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') Navbar._closeDropdown();
    });

    /* Logout */
    if (logoutDd) {
      logoutDd.addEventListener('click', function() { Auth.logout(); });
    }
  },

  _openDropdown: function() {
    var hamburger = document.getElementById('navbar-hamburger');
    var dropdown  = document.getElementById('navbar-dropdown');
    var overlay   = document.getElementById('navbar-drawer-overlay');
    if (!dropdown) return;

    /* Refresh name + avatar when opening */
    var user = Auth.current();
    var nameEl = document.getElementById('navbar-dropdown-username');
    if (nameEl && user) {
      nameEl.textContent = ProfileStore.getDisplayName(user.uid);
    }

    dropdown.classList.add('is-open');
    dropdown.setAttribute('aria-hidden', 'false');
    if (overlay) overlay.classList.add('is-open');
    if (hamburger) {
      hamburger.classList.add('is-open');
      hamburger.setAttribute('aria-expanded', 'true');
    }
    document.body.style.overflow = 'hidden';
  },

  _closeDropdown: function() {
    var hamburger = document.getElementById('navbar-hamburger');
    var dropdown  = document.getElementById('navbar-dropdown');
    var overlay   = document.getElementById('navbar-drawer-overlay');
    if (!dropdown) return;
    dropdown.classList.remove('is-open');
    dropdown.setAttribute('aria-hidden', 'true');
    if (overlay) overlay.classList.remove('is-open');
    if (hamburger) {
      hamburger.classList.remove('is-open');
      hamburger.setAttribute('aria-expanded', 'false');
    }
    document.body.style.overflow = '';
  },

  /* ── Welcome Dialog ────────────────────────────────────── */
  _maybeShowWelcome: function() {
    var self    = this;
    var user    = self._user;
    if (!user) return;

    /* Never show on profile-edit or profile-view pages */
    var path = window.location.pathname;
    if (path.indexOf('profile-edit') !== -1) return;
    if (path.indexOf('profile-view') !== -1) return;

    /* Schon gesehen? */
    try {
      var seen = localStorage.getItem(self._WELCOME_KEY + '_' + user.uid);
      if (seen) return;
    } catch(e) { return; }

    /* Profil schon ausgefüllt (Name + mind. 1 weiteres Feld)? */
    var profile = null;
    try {
      profile = ProfileStore ? ProfileStore.get(user.uid) : null;
    } catch(e) { /* ProfileStore evtl. nicht geladen */ }

    if (profile && profile.bio && profile.pricePerHalfHour) return;

    /* Kleines Timeout damit die Seite erst rendert */
    setTimeout(function() {
      self._showWelcomeDialog();
    }, 600);
  },

  _showWelcomeDialog: function() {
    var self = this;
    var user = self._user;
    var uid  = self._uid;
    var t    = self._i18n;

    var overlay = document.createElement('div');
    overlay.className  = 'modal-overlay';
    overlay.id         = 'welcome-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', t.welcomeTitle);

    overlay.innerHTML =
      '<div class="modal welcome-modal">' +
        '<div class="welcome-modal-icon">' +
          '<svg width="32" height="32" viewBox="0 0 32 32" fill="none">' +
            '<rect width="32" height="32" rx="8" fill="var(--color-900)"/>' +
            '<path d="M10 16h12M16 10v12" stroke="white" stroke-width="2" stroke-linecap="round"/>' +
          '</svg>' +
        '</div>' +
        '<h2 class="modal-title welcome-modal-title">' + t.welcomeTitle + '</h2>' +
        '<p class="welcome-modal-body">' + t.welcomeBody + '</p>' +
        '<div class="modal-footer">' +
          '<button class="btn btn-ghost btn-sm" id="welcome-skip">' + t.welcomeSkip + '</button>' +
          '<a class="btn btn-primary" id="welcome-go" href="./profile-edit.html' + (uid ? '?uid=' + uid + '&owner=' + uid : '') + '">' +
            '<svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M11 2l3 3-9 9H2v-3L11 2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
            t.welcomeBtn +
          '</a>' +
        '</div>' +
      '</div>';

    document.body.appendChild(overlay);

    function dismiss() {
      overlay.remove();
      try {
        localStorage.setItem(self._WELCOME_KEY + '_' + user.uid, '1');
      } catch(e) {}
    }

    document.getElementById('welcome-skip').addEventListener('click', dismiss);
    /* Also dismiss (set seen) when user clicks the profile link */
    var goBtn = document.getElementById('welcome-go');
    if (goBtn) goBtn.addEventListener('click', dismiss);
    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) dismiss();
    });
    document.addEventListener('keydown', function esc(e) {
      if (e.key === 'Escape') {
        dismiss();
        document.removeEventListener('keydown', esc);
      }
    });
  },

  /* ── Smart scroll: hide on down, show on up ────────────── */
  _bindScrollBehavior: function() {
    var nav        = document.getElementById('main-navbar');
    if (!nav) return;

    var lastY      = window.pageYOffset || 0;
    var hidden     = false;
    var THRESHOLD  = 6;
    var ticking    = false;

    function update() {
      var currentY = window.pageYOffset || 0;
      var delta    = currentY - lastY;

      /* Always show at very top */
      if (currentY <= 4) {
        if (hidden) { nav.classList.remove('navbar-hidden'); hidden = false; }
        lastY   = currentY;
        ticking = false;
        return;
      }

      /* Don't hide if dropdown is open */
      var dropdown = document.getElementById('navbar-dropdown');
      if (dropdown && dropdown.classList.contains('is-open')) {
        lastY   = currentY;
        ticking = false;
        return;
      }

      if (delta > THRESHOLD && !hidden) {
        nav.classList.add('navbar-hidden');
        hidden = true;
      } else if (delta < -THRESHOLD && hidden) {
        nav.classList.remove('navbar-hidden');
        hidden = false;
      }

      lastY   = currentY;
      ticking = false;
    }

    window.addEventListener('scroll', function() {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
      }
    }, { passive: true });
  }

};

window.Navbar = Navbar;
