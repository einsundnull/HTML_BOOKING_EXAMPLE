/* ── user-detail.js ──────────────────────────────────────────
   Admin-Detailseite für einen einzelnen User.
   URL: user-detail.html?uid=xxx
   Zeigt: Kontostand, Transaktionshistorie, Escrow-Historie.
   Namespace: admin (gleiche i18n wie admin.html)
──────────────────────────────────────────────────────────── */

(function() {
  'use strict';

  var _uid  = null;
  var _user = null;

  /* ── Helpers ─────────────────────────────────────────── */
  function _esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function _fmt(amount) {
    var n = parseFloat(amount);
    return (isNaN(n) ? '0,00' : n.toFixed(2).replace('.', ',')) + ' €';
  }

  function _fmtDate(iso) {
    if (!iso) return '—';
    try {
      var d = new Date(iso);
      return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' })
        + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch(e) { return iso; }
  }

  function _showError(msg) {
    if (typeof Toast !== 'undefined') { Toast.error(msg); return; }
    console.error('[UserDetail]', msg);
  }

  /* ── URL param ───────────────────────────────────────── */
  function _getUidParam() {
    try {
      var params = new URLSearchParams(window.location.search);
      return params.get('uid') || null;
    } catch(e) {
      /* IE fallback */
      var m = window.location.search.match(/[?&]uid=([^&]+)/);
      return m ? decodeURIComponent(m[1]) : null;
    }
  }

  /* ── Header ──────────────────────────────────────────── */
  function _renderHeader(user, wallet) {
    var nameEl = document.getElementById('ud-user-name');
    var uidEl  = document.getElementById('ud-user-uid');
    var roleEl = document.getElementById('ud-role-badge');

    if (nameEl) nameEl.textContent = ProfileStore.getDisplayName(user.uid) || user.name || user.uid;
    if (uidEl)  uidEl.textContent  = user.uid;
    if (roleEl) {
      roleEl.textContent = user.role === 'teacher' ? 'Lehrer' : user.role === 'student' ? 'Schüler' : user.role;
      roleEl.className   = 'ud-role-badge ud-role-' + (user.role || 'unknown');
    }

    var bal = document.getElementById('ud-balance');
    if (bal) bal.textContent = wallet ? _fmt(wallet.balance) : '0,00 €';
  }

  /* ── Transaktionen ───────────────────────────────────── */
  var _TX_ICONS = {
    deposit: '↑', withdrawal: '↓', refund: '↩',
    escrow_hold: '⏸', escrow_release: '▶', transfer: '⇄'
  };

  var _TX_LABELS = {
    deposit:        'Einzahlung',
    withdrawal:     'Auszahlung',
    refund:         'Rückerstattung',
    escrow_hold:    'Deposit hinterlegt',
    escrow_release: 'Zahlung freigegeben',
    transfer:       'Transfer'
  };

  var _STATUS_LABELS = {
    completed: 'Abgeschlossen',
    pending:   'Ausstehend',
    failed:    'Fehlgeschlagen'
  };

  function _renderTransactions(txs) {
    var list  = document.getElementById('ud-tx-list');
    var empty = document.getElementById('ud-tx-empty');
    var count = document.getElementById('ud-tx-count');
    if (!list) return;

    var items = list.querySelectorAll('.wallet-tx-item');
    for (var i = 0; i < items.length; i++) { items[i].remove(); }

    if (count) count.textContent = txs ? txs.length : 0;

    if (!txs || !txs.length) {
      if (empty) empty.classList.remove('is-hidden');
      return;
    }
    if (empty) empty.classList.add('is-hidden');

    for (var j = 0; j < txs.length; j++) {
      list.appendChild(_buildTxItem(txs[j]));
    }
  }

  function _buildTxItem(tx) {
    var li = document.createElement('li');
    li.className = 'wallet-tx-item';
    li.style.cursor = 'pointer';

    var txType    = tx.type || 'deposit';
    var isPos     = (tx.amount || 0) >= 0;
    var icon      = _TX_ICONS[txType]    || '·';
    var typeLabel = _TX_LABELS[txType]   || txType;
    var statLabel = _STATUS_LABELS[tx.status] || (tx.status || 'completed');

    li.innerHTML =
      '<div class="wallet-tx-icon ' + _esc(txType) + '" aria-hidden="true">' + icon + '</div>' +
      '<div class="wallet-tx-body">' +
        '<div class="wallet-tx-row1">' +
          '<span class="wallet-tx-type">' + _esc(typeLabel) + '</span>' +
          '<span class="wallet-tx-amount ' + (isPos ? 'positive' : 'negative') + '">' +
            _esc((isPos ? '+' : '') + _fmt(tx.amount || 0)) +
          '</span>' +
        '</div>' +
        '<div class="wallet-tx-row2">' +
          '<span class="wallet-tx-date">' + _fmtDate(tx.createdAt) + '</span>' +
          '<span class="wallet-tx-status ' + _esc(tx.status || 'completed') + '">' + _esc(statLabel) + '</span>' +
        '</div>' +
        (tx.description ? '<div class="wallet-tx-desc">' + _esc(tx.description) + '</div>' : '') +
      '</div>';

    /* ── Open full TX detail sheet on click ── */
    (function(t) {
      li.addEventListener('click', function() {
        if (typeof WalletCore !== 'undefined' && WalletCore.showTxDetail) {
          WalletCore.showTxDetail(t, _uid);
        }
      });
    })(tx);

    return li;
  }

  /* ── Escrows ─────────────────────────────────────────── */
  var _ESCROW_STATUS_LABELS = {
    unpaid:           'Offen',
    held:             'Hinterlegt',
    released:         'Freigegeben',
    refund_requested: 'Erstattung beantragt',
    refunded:         'Erstattet',
    forfeited:        'Einbehalten'
  };

  var _ESCROW_STATUS_CLASSES = {
    unpaid:           'escrow-status-open',
    held:             'escrow-status-held',
    released:         'escrow-status-released',
    refund_requested: 'escrow-status-refund',
    refunded:         'escrow-status-refunded',
    forfeited:        'escrow-status-forfeited'
  };

  function _renderEscrows(escrows) {
    var container = document.getElementById('ud-escrow-list');
    var empty     = document.getElementById('ud-escrow-empty');
    var countEl   = document.getElementById('ud-escrow-count');
    if (!container) return;

    var heldCount = escrows ? escrows.filter(function(e) { return e.depositStatus === 'held'; }).length : 0;
    if (countEl) countEl.textContent = heldCount + ' offen';

    if (!escrows || !escrows.length) {
      if (empty) empty.classList.remove('is-hidden');
      return;
    }
    if (empty) empty.classList.add('is-hidden');

    container.innerHTML = '';

    for (var i = 0; i < escrows.length; i++) {
      container.appendChild(_buildEscrowItem(escrows[i]));
    }
  }

  function _buildEscrowItem(esc) {
    var wrapper = document.createElement('div');
    wrapper.className = 'ud-escrow-item';

    var status      = esc.depositStatus || 'unpaid';
    var statusLabel = _ESCROW_STATUS_LABELS[status] || status;
    var statusClass = _ESCROW_STATUS_CLASSES[status] || '';

    /* Find counterpart name */
    var isTeacher    = _user && _user.role === 'teacher';
    var counterpartId = isTeacher ? esc.studentId : esc.teacherId;
    var counterpart   = counterpartId ? (ProfileStore.getDisplayName(counterpartId) || counterpartId) : '—';
    var counterLabel  = isTeacher ? 'Schüler' : 'Lehrer';

    wrapper.innerHTML =
      '<div class="ud-escrow-header">' +
        '<div class="ud-escrow-meta">' +
          '<span class="ud-escrow-amount">' + _esc(_fmt(esc.depositAmount || 0)) + '</span>' +
          '<span class="ud-escrow-counterpart">' + _esc(counterLabel) + ': <strong>' + _esc(counterpart) + '</strong></span>' +
          '<span class="ud-escrow-date">' + _fmtDate(esc.createdAt) + '</span>' +
        '</div>' +
        '<span class="ud-escrow-status ' + statusClass + '">' + _esc(statusLabel) + '</span>' +
      '</div>' +
      '<div class="ud-escrow-ids">' +
        '<code class="uid-badge">Slot: ' + _esc(esc.slotId || '—') + '</code>' +
        '<code class="uid-badge">Escrow: ' + _esc(esc.escrowId || '—') + '</code>' +
      '</div>';

    return wrapper;
  }

  /* ── Daten laden ─────────────────────────────────────── */
  function _load() {
    _uid = _getUidParam();
    if (!_uid) {
      _showError('Kein User angegeben (uid-Parameter fehlt).');
      return;
    }

    _user = AppService.getUserSync(_uid);
    if (!_user) {
      _showError('User nicht gefunden: ' + _uid);
      return;
    }

    /* Header sofort rendern mit Wallet-Platzhalter */
    _renderHeader(_user, null);

    /* Wallet */
    AppService.getWallet(_uid, function(err, wallet) {
      if (err) { _showError('Wallet: ' + err.message); return; }
      _renderHeader(_user, wallet);
    });

    /* Transaktionen */
    AppService.getTransactions(_uid, function(err, txs) {
      if (err) { _showError('Transaktionen: ' + err.message); return; }
      _renderTransactions(txs);
    });

    /* Escrows — je nach Rolle */
    var escrowFn = (_user.role === 'teacher')
      ? AppService.getEscrowsByTeacher
      : AppService.getEscrowsByStudent;

    escrowFn(_uid, function(err, escrows) {
      if (err) { _showError('Escrows: ' + err.message); return; }
      _renderEscrows(escrows);
    });
  }

  /* ── Init ────────────────────────────────────────────── */
  /* Use 'load' not 'DOMContentLoaded': defer scripts run after DOMContentLoaded. */
  window.addEventListener('load', function() {
    function _initUserDetail() {
      if (typeof Navbar !== 'undefined') Navbar.init('admin');
      _load();
    }
    if (typeof CurrencyService !== 'undefined' && typeof CurrencyService.onReady === 'function') {
      CurrencyService.onReady(_initUserDetail);
    } else {
      _initUserDetail();
    }
  });

}());
