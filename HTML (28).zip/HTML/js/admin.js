/**
 * admin.js — Admin View Logic
 *
 * Regeln: var only, function(){}, no arrow, no template literals,
 *         no ?. or ??, kein inline-style — classList only.
 */

var currentUser      = null;
var activeTab        = 'teacher';
var activeMainTab    = 'users';
var activeEscrowFilter = 'held';

window.addEventListener('load', function() {
  currentUser = Auth.require('admin');
  if (!currentUser) return;
  Navbar.init('admin');

  /* ── Haupt-Tabs (Benutzer / Zahlungen) ── */
  var mainTabBtns = document.querySelectorAll('.admin-tab-btn');
  for (var m = 0; m < mainTabBtns.length; m++) {
    (function(btn) {
      btn.addEventListener('click', function() {
        activeMainTab = btn.dataset.mainTab;
        for (var i = 0; i < mainTabBtns.length; i++) { mainTabBtns[i].classList.remove('active'); }
        btn.classList.add('active');
        document.getElementById('admin-tab-users').style.display    = activeMainTab === 'users'    ? '' : 'none';
        document.getElementById('admin-tab-payments').style.display = activeMainTab === 'payments' ? '' : 'none';
        if (activeMainTab === 'payments') renderEscrows();
      });
    })(mainTabBtns[m]);
  }

  /* ── User-Tab-Wechsel (Lehrer / Schüler) ── */
  var tabBtns = document.querySelectorAll('.segmented-btn');
  for (var t = 0; t < tabBtns.length; t++) {
    (function(btn) {
      btn.addEventListener('click', function() {
        activeTab = btn.dataset.tab;
        for (var i = 0; i < tabBtns.length; i++) { tabBtns[i].classList.remove('active'); }
        btn.classList.add('active');
        renderTable();
      });
    })(tabBtns[t]);
  }

  /* ── Escrow-Filter-Chips ── */
  var escrowFilters = document.querySelectorAll('[data-escrow-filter]');
  for (var ef = 0; ef < escrowFilters.length; ef++) {
    (function(chip) {
      chip.addEventListener('click', function() {
        activeEscrowFilter = chip.dataset.escrowFilter;
        for (var i = 0; i < escrowFilters.length; i++) { escrowFilters[i].classList.remove('active'); }
        chip.classList.add('active');
        renderEscrows();
      });
    })(escrowFilters[ef]);
  }

  /* ── Escrow Aktualisieren ── */
  var refreshBtn = document.getElementById('escrow-refresh-btn');
  if (refreshBtn) refreshBtn.addEventListener('click', renderEscrows);

  /* ── Disziplin-Gruppe toggle ── */
  var roleSelect = document.getElementById('f-role');
  if (roleSelect) roleSelect.addEventListener('change', function() {
    var grp = document.getElementById('discipline-group');
    if (grp) grp.style.display = (this.value === 'teacher') ? '' : 'none';
    if (this.value !== 'teacher') {
      var disc = document.getElementById('f-discipline');
      if (disc) disc.value = '';
    }
  });

  var createForm = document.getElementById('create-form');
  if (createForm) createForm.addEventListener('submit', handleCreate);

  renderStats();
  renderTable();
});

/* ── CREATE ───────────────────────────────────────────── */
function handleCreate(e) {
  e.preventDefault();
  var uid        = document.getElementById('f-uid').value.trim();
  var name       = document.getElementById('f-name').value.trim();
  var email      = document.getElementById('f-email').value.trim();
  var role       = document.getElementById('f-role').value;
  var password   = document.getElementById('f-password').value;
  var discipline = role === 'teacher'
    ? document.getElementById('f-discipline').value.trim()
    : '';

  _clearErrors();
  var valid = true;
  if (!uid)  { _showError('e-uid',  'UID ist erforderlich.');  valid = false; }
  if (!name) { _showError('e-name', 'Name ist erforderlich.'); valid = false; }
  if (!role) { _showError('e-role', 'Rolle wählen.');          valid = false; }
  if (!valid) return;

  try {
    Store.Users.create({ uid: uid, name: name, role: role, email: email, discipline: discipline, password: password });
    var roleLabel = role === 'teacher' ? 'Lehrer' : 'Schüler';
    Toast.success(roleLabel + ' <strong>' + name + '</strong> erstellt.');
    e.target.reset();
    _toggleDisciplineField('f-discipline-group', '');
    activeTab = role;
    var tabBtns = document.querySelectorAll('.segmented-btn');
    for (var i = 0; i < tabBtns.length; i++) {
      tabBtns[i].classList.toggle('active', tabBtns[i].dataset.tab === role);
    }
    renderStats();
    renderTable();
  } catch(err) {
    _showError('e-uid', err.message);
  }
}

/* ── EDIT ─────────────────────────────────────────────── */
function handleEdit(uid) {
  var user = Store.Users.byUid(uid);
  if (!user) return;

  var tpl = document.getElementById('tpl-edit-modal');
  var body = document.importNode(tpl.content, true);
  var wrapper = document.createElement('div');
  wrapper.appendChild(body);

  var nameInput  = wrapper.querySelector('#edit-name');
  var emailInput = wrapper.querySelector('#edit-email');
  var discInput  = wrapper.querySelector('#edit-discipline');
  var discGroup  = wrapper.querySelector('#edit-discipline-group');

  nameInput.value  = user.name  || '';
  emailInput.value = user.email || '';
  discInput.value  = user.discipline || '';

  /* Disziplin nur für Lehrer anzeigen */
  if (discGroup) {
    discGroup.classList.toggle('is-hidden', user.role !== 'teacher');
  }

  var result = Modal.show({
    title: 'Benutzer bearbeiten — ' + uid,
    bodyHTML: wrapper.innerHTML,
    footerHTML:
      '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '<button class="btn btn-primary" id="modal-save">Speichern</button>'
  });

  /* Werte nach Modal-Injection lesen */
  document.getElementById('edit-name').value  = user.name  || '';
  document.getElementById('edit-email').value = user.email || '';
  document.getElementById('edit-password').value  = '';
  document.getElementById('edit-discipline').value = user.discipline || '';

  document.getElementById('modal-cancel').addEventListener('click', result.close);

  document.getElementById('modal-save').addEventListener('click', function() {
    var newName  = document.getElementById('edit-name').value.trim();
    var newEmail = document.getElementById('edit-email').value.trim();
    var newPw    = document.getElementById('edit-password').value;
    var newDisc  = user.role === 'teacher'
      ? document.getElementById('edit-discipline').value.trim()
      : '';

    var errEl = document.getElementById('edit-e-name');
    if (!newName) {
      if (errEl) { errEl.textContent = 'Name ist erforderlich.'; errEl.classList.remove('is-hidden'); }
      return;
    }
    if (errEl) { errEl.textContent = ''; errEl.classList.add('is-hidden'); }

    try {
      Store.Users.update(uid, { name: newName, email: newEmail, discipline: newDisc, password: newPw });
      Toast.success('Benutzer <strong>' + newName + '</strong> aktualisiert.');
      renderStats();
      renderTable();
      result.close();
    } catch(err) {
      Toast.error(err.message);
    }
  });
}

/* ── DELETE ───────────────────────────────────────────── */
function handleDelete(uid) {
  var user = Store.Users.byUid(uid);
  if (!user) return;

  var displayName = ProfileStore.getDisplayName(user.uid);
  var result = Modal.show({
    title: 'Benutzer löschen',
    bodyHTML:
      '<p><strong>' + displayName + '</strong> (' + uid + ') wirklich löschen?</p>' +
      '<p class="text-muted">Alle Buchungen und Auswahlen werden ebenfalls entfernt.</p>',
    footerHTML:
      '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
      '<button class="btn btn-danger" id="modal-confirm">Löschen</button>'
  });

  document.getElementById('modal-cancel').addEventListener('click', result.close);
  document.getElementById('modal-confirm').addEventListener('click', function() {
    try {
      Store.Users.delete(uid);
      Toast.success('Benutzer <strong>' + displayName + '</strong> gelöscht.');
      renderStats();
      renderTable();
    } catch(err) {
      Toast.error(err.message);
    }
    result.close();
  });
}

/* ── STATS ────────────────────────────────────────────── */
function renderStats() {
  var users    = Store.Users.all();
  var teachers = users.filter(function(u) { return u.role === 'teacher'; }).length;
  var students = users.filter(function(u) { return u.role === 'student'; }).length;
  var bookings = Store.Slots.all().filter(function(s) { return s.status === 'booked'; }).length;
  document.getElementById('stat-teachers').textContent = teachers;
  document.getElementById('stat-students').textContent = students;
  document.getElementById('stat-bookings').textContent = bookings;

  /* Offene Escrows zählen */
  try {
    var raw = localStorage.getItem('app_escrow');
    var escrows = raw ? JSON.parse(raw) : [];
    var open = escrows.filter(function(e) { return e.depositStatus === 'held'; }).length;
    var el = document.getElementById('stat-escrows');
    if (el) el.textContent = open;
  } catch(e) {}
}

/* ── TABLE ────────────────────────────────────────────── */
function renderTable() {
  var users = Store.Users.byRole(activeTab);
  var tbody = document.getElementById('user-tbody');

  if (!users.length) {
    tbody.innerHTML =
      '<tr><td colspan="5" class="table-empty-cell">Noch keine ' +
      (activeTab === 'teacher' ? 'Lehrer' : 'Schüler') +
      ' vorhanden.</td></tr>';
    return;
  }

  var rows = '';
  for (var i = 0; i < users.length; i++) {
    var u = users[i];
    var bookingCount = activeTab === 'teacher'
      ? Store.Slots.byTeacher(u.uid).length
      : Store.Slots.byStudent(u.uid).length;
    var selCount = activeTab === 'teacher'
      ? Store.Selections.byTeacher(u.uid).length
      : Store.Selections.byStudent(u.uid).length;

    var discBadge = (activeTab === 'teacher' && u.discipline)
      ? '<span class="admin-discipline-badge">' + _esc(_disciplineLabel(u.discipline)) + '</span>'
      : '';

    var emailBadge = u.email
      ? '<span class="admin-email-badge">' + _esc(u.email) + '</span>'
      : '';

    var infoText = activeTab === 'teacher'
      ? selCount + ' Schüler · ' + bookingCount + ' Slots'
      : selCount + ' Lehrer · ' + bookingCount + ' Buchungen';

    rows +=
      '<tr>' +
      '<td><code class="uid-badge">' + _esc(u.uid) + '</code></td>' +
      '<td class="td-name">' +
        '<span class="admin-user-name">' + _esc(ProfileStore.getDisplayName(u.uid)) + '</span>' +
        (discBadge || '') + (emailBadge || '') +
      '</td>' +
      '<td class="td-meta">' + infoText + '</td>' +
      '<td class="admin-actions">' +
        '<a href="./user-detail.html?uid=' + _esc(u.uid) + '" class="btn btn-secondary btn-sm">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>' +
            '<path d="M8 7v4M8 5.5v.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' +
          '</svg>' +
          ' Detail' +
        '</a>' +
        '<button class="btn btn-secondary btn-sm" onclick="handleEdit(\'' + _esc(u.uid) + '\')">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<path d="M11.5 2.5a2 2 0 012.8 2.8L5 14.5l-4 1 1-4 9.5-9z"' +
            ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>' +
          ' Bearbeiten' +
        '</button>' +
        '<button class="btn btn-danger btn-sm" onclick="handleDelete(\'' + _esc(u.uid) + '\')">' +
          '<svg width="13" height="13" viewBox="0 0 16 16" fill="none">' +
            '<path d="M2 4h12M6 4V2h4v2M5 4v9a1 1 0 001 1h4a1 1 0 001-1V4"' +
            ' stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>' +
          '</svg>' +
          ' Löschen' +
        '</button>' +
      '</td>' +
      '</tr>';
  }
  tbody.innerHTML = rows;
}

/* ── ESCROW PANEL ─────────────────────────────────────── */
function renderEscrows() {
  var container = document.getElementById('escrow-list');
  var empty     = document.getElementById('escrow-empty');
  if (!container) return;

  AppService.getAllEscrows(function(err, escrows) {
    if (err) { console.error('[Admin] Escrows:', err); return; }

    /* Filter anwenden */
    var filtered = escrows.filter(function(e) {
      if (activeEscrowFilter === 'held')     return e.depositStatus === 'held';
      if (activeEscrowFilter === 'released') return e.depositStatus === 'released';
      return true;
    });

    /* Escrow-Zähler updaten */
    var heldCount = escrows.filter(function(e) { return e.depositStatus === 'held'; }).length;
    var statEl = document.getElementById('stat-escrows');
    if (statEl) statEl.textContent = heldCount;

    /* Liste leeren */
    var items = container.querySelectorAll('.admin-escrow-row');
    for (var i = 0; i < items.length; i++) { items[i].remove(); }

    if (!filtered.length) {
      if (empty) empty.style.display = '';
      return;
    }
    if (empty) empty.style.display = 'none';

    for (var j = 0; j < filtered.length; j++) {
      container.appendChild(_buildEscrowRow(filtered[j]));
    }
  });
}

var _ESCROW_STATUS = {
  unpaid:           { label: 'Offen',                  cls: 'wallet-tx-status pending' },
  held:             { label: 'Ausstehend',              cls: 'wallet-tx-status pending' },
  released:         { label: 'Freigegeben',             cls: 'wallet-tx-status completed' },
  refund_requested: { label: 'Erstattung beantragt',   cls: 'wallet-tx-status pending' },
  refunded:         { label: 'Erstattet',               cls: 'wallet-tx-status completed' },
  forfeited:        { label: 'Einbehalten',             cls: 'wallet-tx-status failed' }
};

function _buildEscrowRow(esc) {
  var row = document.createElement('div');
  row.className = 'admin-escrow-row wallet-tx-item';

  var status   = esc.depositStatus || 'unpaid';
  var statusCfg = _ESCROW_STATUS[status] || { label: status, cls: 'wallet-tx-status' };
  var fmt = function(n) {
    var v = parseFloat(n);
    return (isNaN(v) ? '0,00' : v.toFixed(2).replace('.', ',')) + ' €';
  };
  var fmtDate = function(iso) {
    if (!iso) return '—';
    try {
      var d = new Date(iso);
      return d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' })
        + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } catch(e) { return iso; }
  };

  var teacherName  = ProfileStore.getDisplayName(esc.teacherId)  || esc.teacherId  || '—';
  var studentName  = ProfileStore.getDisplayName(esc.studentId)  || esc.studentId  || '—';

  row.innerHTML =
    '<div class="wallet-tx-icon escrow_hold" aria-hidden="true">⏸</div>' +
    '<div class="wallet-tx-info">' +
      '<div class="wallet-tx-type">' +
        _esc(studentName) + ' → ' + _esc(teacherName) +
      '</div>' +
      '<div class="wallet-tx-desc">' +
        'Slot: <code>' + _esc(esc.slotId || '—') + '</code> · ' + fmtDate(esc.createdAt) +
      '</div>' +
      '<div class="admin-escrow-links">' +
        '<a href="./user-detail.html?uid=' + _esc(esc.studentId) + '" class="admin-detail-link">Schüler</a>' +
        '<a href="./user-detail.html?uid=' + _esc(esc.teacherId) + '" class="admin-detail-link">Lehrer</a>' +
      '</div>' +
    '</div>' +
    '<div class="wallet-tx-right">' +
      '<div class="wallet-tx-amount positive">' + _esc(fmt(esc.depositAmount)) + '</div>' +
      '<span class="' + statusCfg.cls + '">' + _esc(statusCfg.label) + '</span>' +
    '</div>';

  /* Freigabe-Button nur für 'held' */
  if (status === 'held') {
    var releaseBtn = document.createElement('button');
    releaseBtn.className = 'btn btn-primary btn-sm admin-release-btn';
    releaseBtn.textContent = '▶ Freigeben';
    (function(escrow, btn) {
      btn.addEventListener('click', function() {
        var result = Modal.show({
          title: 'Zahlung freigeben',
          bodyHTML:
            '<div class="move-dialog">' +
              '<p class="move-dialog-info">Deposit von <strong>' + _esc(studentName) + '</strong>' +
              ' in Höhe von <strong>' + _esc(fmt(escrow.depositAmount)) + '</strong>' +
              ' an <strong>' + _esc(teacherName) + '</strong> freigeben?</p>' +
              '<p class="move-dialog-info">Der Betrag wird sofort dem Lehrer-Wallet gutgeschrieben.</p>' +
            '</div>',
          footerHTML:
            '<button class="btn btn-ghost" id="modal-cancel">Abbrechen</button>' +
            '<button class="btn btn-primary" id="modal-confirm">Jetzt freigeben</button>'
        });
        document.getElementById('modal-cancel').addEventListener('click', result.close);
        document.getElementById('modal-confirm').addEventListener('click', function() {
          AppService.adminReleaseEscrow(escrow.escrowId, currentUser.uid, function(releaseErr) {
            result.close();
            if (releaseErr) {
              Toast.error('Fehler: ' + releaseErr.message);
              return;
            }
            Toast.success('Zahlung erfolgreich freigegeben.');
            renderEscrows();
            renderStats();
          });
        });
      });
    })(esc, releaseBtn);

    var rightCol = row.querySelector('.wallet-tx-right');
    if (rightCol) rightCol.appendChild(releaseBtn);
  }

  return row;
}

/* ── Discipline label map ────────────────────────────── */
var DISCIPLINE_LABELS = {
  'ski':         'Ski-Instruktor',
  'paragliding': 'Paragliding-Instruktor',
  'diving':      'Tauch-Instruktor',
  'tourguide':   'Reiseführer'
};

function _disciplineLabel(key) {
  return DISCIPLINE_LABELS[key] || key;
}

/* ── Helpers ──────────────────────────────────────────── */
function _showError(id, msg) {
  var el = document.getElementById(id);
  if (el) { el.textContent = msg; el.classList.remove('is-hidden'); }
}

function _clearErrors() {
  var ids = ['e-uid', 'e-name', 'e-role'];
  for (var i = 0; i < ids.length; i++) {
    var el = document.getElementById(ids[i]);
    if (el) { el.textContent = ''; el.classList.add('is-hidden'); }
  }
}

function _esc(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
